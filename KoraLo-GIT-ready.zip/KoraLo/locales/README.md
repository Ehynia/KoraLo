# KoraLo localization packs

KoraLo loads UTF-8 `*.lang` files at runtime. No recompilation is required for a new language.

1. Copy `en-US.lang` to `<locale>.lang`.
2. Change `meta.code` and `meta.name`.
3. Translate values after the first `=`. Keep keys unchanged.
4. Put the file into the `locales/` folder next to KoraLo (CMake copies this folder beside the executable).
5. Select a language with the Preferences language control, or set `KORALO_LANG=<code>` before launch.

Missing keys fall back to `en-US`, then to the fallback text embedded at the call site.
