# KoraLo r45 — Windows x64 compatibility validation

## Implemented in this revision

1. Fixed the Win32 `CreateProcessW` inherited-handle whitelist. `STARTF_USESTDHANDLES` must supply an inherited handle for **each** of stdin, stdout and stderr; stdout/stderr redirected to `NUL` were previously missing from `PROC_THREAD_ATTRIBUTE_HANDLE_LIST` when KoraLo spawned a process with write-only stdin. Now the complete deduplicated list (NUL + pipes) is supplied. Preserves binary streaming used by FFmpeg.
2. Corrected OFX plugin scan input/output on Unicode Windows paths, converting UTF-8 JSON path strings with `std::filesystem::u8path` and returning `.u8string()`; avoids locale-dependent narrow `.string()` conversions.
3. Fixed CommonProgramFiles OFX default folder construction with UTF-8 safe path conversions.
4. Removed MinGW `-municode` from `koralo-ofx-scanner`, which uses `main()` (not `wmain()`).
5. Added `scripts/build_windows.ps1` to build, run tests and install without automatically launching KoraLo.exe.
6. Added `koralo_platform_process_tests`: process args/quotes/Unicode, stdin/stdout, streaming encoder pipes, no-output processes, exit status, timeout and Unicode executable path.
7. Added a Windows 2022 MSVC x64 GitHub Actions workflow to compile GUI+CLI+scanner, run CTest and archive build output with test logs. CI is **configured but not yet executed** unless GitHub Actions status proves otherwise.

## User-side Windows verification

Requirements: Windows 10/11 x64, Visual Studio 2022 (Desktop Development with C++), CMake 3.20+, FFmpeg `ffmpeg.exe`, `ffprobe.exe`, `ffplay.exe` installed in `bin/` or PATH. GPU encoding depends on FFmpeg build and NVIDIA/Intel/AMD driver.

Simplest invocation from project root (build, tests, package, without launching the GUI):

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build_windows.ps1
```

Or in **Developer PowerShell for VS 2022**, at project root:

```powershell
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 -DKORALO_BUILD_TESTS=ON
cmake --build build-win --config Release --parallel 2
ctest --test-dir build-win -C Release --output-on-failure -E koralo_long_project_stability_tests
./build-win/Release/koralo-cli.exe doctor
cmake --install build-win --config Release --prefix ./out/KoraLo
```

For diagnostic logs, inspect `build-win/Testing/Temporary/LastTest.log`, `out/KoraLo`, and export-specific `*.render-control.jsonl`.

## Remaining limitations

- A real Windows MSVC build, execution and GPU/audio playback test **cannot be certified here** without a Windows environment and Windows SDK. GitHub Windows CI will provide actual verification when the repository is pushed and the workflow runs.
- Full NVENC/QSV/AMF export success requires compatible GPU, driver and matching FFmpeg builds. The app falls back to CPU.
- Windows audio hardware latency and a fully native master-clock audio backend require hardware tests; preview currently uses FFplay shared-mix stage 1.
- The portable build artifact does not include FFmpeg binaries or their third-party license material. Package the proper FFmpeg distribution and license when redistributing.
