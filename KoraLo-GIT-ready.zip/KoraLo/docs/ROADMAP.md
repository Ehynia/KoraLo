# KoraLo roadmap

This roadmap keeps the editor native C++20 and advances in small testable layers. Later work should extend the existing architecture rather than restart the application.

## Native workspace UI reference pass

Completed as a presentation-layer pass on top of the existing editor architecture:

- compact command toolbar;
- Project Media tree/grid workspace;
- Video Preview + Master layout;
- timeline toolbar/timecode shell;
- widened track headers and event styling based on the supplied mockup;
- existing edit hit-testing adapted to the new track-header geometry.

This pass intentionally does **not** introduce HTML/WebView runtime code. A follow-up functional-control pass now wires the visible command buttons, Project Media filtering/search, transport, Trimmer In/Out + initial Insert/Overwrite, track Lock/Mute/Solo/level/pan, basic opacity controls and Auto Crossfade into real KoraLo actions. Docking, resizable pane splitters, thumbnail decode caching, real audio metering and a full generator/FX/transition model remain later UI work.

The current hardening pass also replaces text-surrogate toolbar controls with a native generated bitmap icon atlas sourced from the supplied Font Awesome SVG set, adds persistent Win32 GDI double buffering to prevent half-painted/flickering frames, and makes track level/pan drags preview-first with one undo commit on mouse-up.

## Current milestone — timeline interaction hardening

Completed in this update:

- `SelectionModel`;
- marquee multi-select and additive marquee;
- group-aware selection;
- multi-selection/group-aware move;
- group-aware trim and slip;
- transaction-based drag preview/commit;
- Roll;
- Slide;
- Ripple Trim;
- same-kind track reorder;
- native regression tests for move, trim, group move, marquee, Roll, Slide, Ripple Trim, track reorder, undo, and redo.

Deferred within this milestone:

- Stretch drag mode;
- richer trim cursor/tool affordances;
- track-header ghost/insertion visualization beyond the current target-row highlight.

## Next — Media / Take / Event model

Refactor incrementally toward:

```text
Media -> Take -> TrackEvent -> Track -> Project
```

Priorities:

- explicit `Media`/`Take`/`TrackEvent` separation while preserving project compatibility where practical;
- migrate the initial Source Trimmer UI and source In/Out behavior onto explicit `Take`/`TrackEvent` objects;
- timeline In/Out;
- harden the initial transactional Insert/Overwrite implementation around takes, target-track choice and timeline ranges;
- proper generic group-aware split that creates correct left/right linked groups;
- advanced trim tools and edge cases;
- source/take offsets and playback-rate semantics.

## Then — persistent media engine

The temporary process-per-operation layer is now shell-free and Unicode-safe. ffprobe metadata parsing is delimiter-based with a selected-stream fallback rather than relying on `std::regex` over one writer format, but the process-per-operation architecture is still intentionally transitional. Replace per-frame process launches in the uncached preview path with persistent sessions:

- persistent decoder sessions;
- seek queue and request coalescing;
- frame prefetch/cache;
- realtime audio mixer;
- audio master clock;
- A/V synchronization;
- scrub playback;
- proxy/cache policy integration.

## Later — compositor / FX / GPU

The compositor must be independent from FFmpeg render-command generation. Minimum graph nodes:

```text
source
transform
crop
opacity
blend
transition
effect
output
```

Effects should use:

```text
EffectDefinition -> ParameterDefinition -> EffectInstance
```

Minimum parameter types:

```text
double
integer
bool
choice
color/RGBA
vec2
string
group
action/button
```

Each parameter declares whether it is animatable; keyframes belong to a specific parameter. Background-analysis effects such as stabilization or optical flow should use a separate `AnalysisJob`/cache subsystem.

OpenColorIO/ACES remains a separate color-management layer around the compositor, not timeline logic.

## Long-term NLE features

- fades/transitions and transition editor;
- keyframed VideoMotion/transform;
- Media FX / Event FX / Track FX / Video Output FX separation;
- markers/regions and render Project/Selection/Regions;
- renderer/template model;
- waveform cache;
- nested timelines;
- multicam;
- OFX/VST hosting after the native edit/playback core is stable.

## r16 viewport hardening

Horizontal timeline scrolling now keeps Event rendering and Event hit-testing strictly inside the content pane; long audio waveform drawing is limited to visible columns.
