# Smooth UI/render pass r31

Revision: `2026-10-02-smooth-ui-render-r31`

This pass targets the visible toolbar artifacts and interaction stutter reported on Windows while keeping KoraLo's custom native C++ UI.

## Rendering changes

- Replaced the 1-bit 16x16 icon mask with a supersampled anti-aliased coverage atlas generated at development time from the existing Font Awesome SVG references. Runtime remains native C++ and does not load SVG/CSS/WebView assets.
- Rounded UI surfaces now use fractional edge coverage instead of hard staircase corners.
- Windows translucent rectangle rendering caches the premultiplied 1x1 AlphaBlend sources instead of creating/deleting a DIB section and compatible DC for every shadow/glyph edge.
- Windows GDI brushes, pens and fonts are cached for the process lifetime and released on shutdown instead of being rebuilt on every WM_PAINT.
- Repeated RGB->BGRX conversion of the same preview/thumbnail frame is cached on Windows.
- Removed an unused 16 ms Win32 timer; the existing editor tick is the single scheduling clock.
- Linux/X11 draws into a Pixmap backbuffer before one final XCopyArea. When XRender is available, translucent edges use true alpha instead of stipple dithering.

## Motion

- Compact toolbar buttons are flat at rest and animate into their hover/active surfaces.
- Hover color, icon brightness and press offset use short exponential easing rather than instant state changes.
- UI animation redraws are requested only while an interpolation is still moving and are capped at about 60 Hz.
- Pointer motion no longer forces unconditional full redraws on X11.

The animation layer is deliberately lightweight and does not run a permanent 60 Hz repaint loop when the editor is idle.
