# KoraLo OFX scanner IPC (protocol v1)

KoraLo does not load third-party OpenFX binaries in the editor process during
discovery. `koralo-ofx-scanner` is a small helper process and is the only normal
runtime component allowed to call `LoadLibrary` / `dlopen` for OFX discovery.
A plug-in crash therefore terminates the scanner, not the editor.

## Transport

The protocol is synchronous JSON Lines over inherited standard streams:

- editor -> scanner: one UTF-8 JSON object followed by `\n` on stdin;
- scanner -> editor: one UTF-8 JSON object followed by `\n` on stdout;
- stderr is not merged into stdout, so loader diagnostics cannot corrupt the
  machine-readable channel;
- no sockets, ports, RPC framework or network library are used.

The editor launches the helper without a command shell. Search paths therefore
remain individual JSON strings and are never shell-escaped or interpreted.

## Request

```json
{"protocol":1,"command":"scan","paths":["/usr/OFX/Plugins"]}
```

Limits in protocol v1:

- at most 128 search roots;
- each path at most 32768 bytes of UTF-8;
- NUL bytes are rejected at the native process boundary.

## Response

```json
{"protocol":1,"ok":true,"bundle_count":1,"error":"","plugins":[...]}
```

Each plug-in record contains identifier/API/version, binary and bundle paths,
vendor classification, image-effect/Boris flags, loader state and a bounded
error string.

The editor accepts exactly one response line, validates the protocol version
and field types, caps the response to 16 MiB and rejects more than 16384 plug-in
records.

## Failure policy

`OfxHostRegistry` never falls back to in-process loading when the scanner is
missing, crashes, times out or returns malformed JSON. It clears the discovered
set and exposes the failure through `last_error()` / `summary()`.

The scanner timeout is currently 20 seconds. A hung third-party plug-in is
terminated with the scanner process when that deadline expires.

`KORALO_OFX_SCANNER` may override the helper path for controlled development and
tests. Normal builds resolve the helper beside the running KoraLo executable.

## Regression coverage

The native test suite builds two synthetic OFX bundles:

- `FakeBoris` returns a valid image-effect descriptor and must round-trip through
  the JSONL subprocess protocol;
- `Crash` calls `abort()` from `OfxGetNumberOfPlugins`. The helper dies, while
  `koralo_native_tests` remains alive and observes an isolated scanner failure.

This test is the security boundary: future OFX discovery changes must not move
third-party code back into the editor process.
