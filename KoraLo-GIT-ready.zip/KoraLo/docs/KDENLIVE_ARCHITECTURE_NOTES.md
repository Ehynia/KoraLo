# Kdenlive architecture notes used for KoraLo Native

Reference examined: KDE/Kdenlive public repository and its developer architecture documentation.

## What was useful

Kdenlive's current codebase is C++ and separates the editor UI from the actual editing backend. Its developer documentation describes MLT as the media-editing backend while Kdenlive provides the interface and project/edit logic around it.

The most important reference for fixing KoraLo's failed early timeline interaction was Kdenlive's Timeline 2 model. Public declarations in `TimelineModel` show a few useful design principles:

1. **The timeline model is the single edit entry point.** The UI requests moves/resizes/deletions instead of freely mutating visual widgets.
2. **Moves are validated/suggested before commit.** Functions such as `suggestClipMove` separate the proposed pointer location from the accepted edit state.
3. **Dragging can be fake until drop.** Kdenlive exposes `requestFakeClipMove`/group variants for edit modes where the visual move should happen before the final model operation.
4. **Snapping is its own responsibility.** The model owns a `SnapModel` rather than scattering snap calculations through mouse handlers.
5. **Undo/redo is built into edit requests.** Move, resize, insertion and deletion operations collect undo/redo state as one logical action.
6. **Track and clip models are separate.** The project is not represented as a pile of canvas rectangles.

## KoraLo's independent implementation

KoraLo Native reimplements those *design ideas*, not Kdenlive code:

- `Project` owns media, tracks and clips.
- `EditController` owns hit-testing and edit proposals.
- `DragState.preview` is an independent fake-move state rendered while the mouse is held.
- The actual `Project` is modified only by `commit_drag` on mouse release.
- Snap candidates are computed centrally from event edges, markers, playhead and timeline start.
- `UndoStack` captures a transaction before the operation and commits it only if model state changed.
- `MediaEngine` is separate from the UI and provides decoding/render services.

Unlike Kdenlive, KoraLo does **not** use MLT. The goal is an independent KoraLo editing engine with FFmpeg only as the codec/format backend.

## Why this fixes the previous KoraLo problem

The Python prototype mixed UI state and project state. A pointer drag could be blocked by widget bindings or require full redraw/mutation during every motion. In the native rewrite, mouse movement updates a lightweight preview map. This makes event dragging cheap, keeps the actual timeline consistent, and makes cancel/drop/undo deterministic.

## Public references

- `https://github.com/KDE/kdenlive/blob/master/dev-docs/architecture.md`
- `https://github.com/KDE/kdenlive/blob/master/src/timeline2/model/timelinemodel.hpp`
- `https://github.com/KDE/kdenlive/blob/master/src/timeline2/model/trackmodel.hpp`
- `https://github.com/KDE/kdenlive/blob/master/dev-docs/mlt-intro.md`

Kdenlive is GPL licensed. These files were read for architecture/behavior research only. No code from them is included here.
