# r23 — still-image Anime Restore validation

The supplied 1125x631 JPEG exposed a real FFmpeg 7.x still-image preview issue in KoraLo's exact-frame path. KoraLo used a pre-input `-ss 0` seek even for single-frame images; on FFmpeg 7.x that combination can complete successfully while producing zero filtered frames.

r23 omits source seeking for still images, uses `-update 1` for the one-frame PPM decode, and skips meaningless still-image seeking in the persistent preview stream. This fixes stopped/scrub preview and timeline thumbnails for JPG/PNG images, including odd dimensions.

Regression coverage creates an odd-size 1125x631 JPEG and requests a random-access preview with Anime Line Restore enabled. The real asynchronous MediaEngine path must return a full non-empty frame.

The supplied thumbnail was also exercised through the individual Anime Restore CPU stages. Line Restore, Vector Colors, Text Restore, Paper Texture and Detail Sharpen are appropriate creative/restoration stages. Deinterlace is intentionally not a general enhancement for progressive stills and should only be enabled for interlaced material.
