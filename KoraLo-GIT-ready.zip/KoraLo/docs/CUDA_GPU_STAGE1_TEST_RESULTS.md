# Stage 1 — test log (2026-10-10)

Configured on Debian 13, GCC 14.2, FFmpeg 7.1.5, CMake/Ninja:

```sh
cmake -S . -B /mnt/data/KoraLo_cuda_fsr_build -G Ninja \
  -DKORALO_BUILD_GUI=OFF -DKORALO_BUILD_CLI=OFF \
  -DKORALO_BUILD_TESTS=ON -DKORALO_ENABLE_CUDA=ON -DCMAKE_BUILD_TYPE=Release
cmake --build /mnt/data/KoraLo_cuda_fsr_build \
  --target koralo_export_improvements_tests koralo_gpu_fsr_tests \
           koralo_frame_worker_tests koralo_effect_tests -j 2
ctest --test-dir /mnt/data/KoraLo_cuda_fsr_build \
  --output-on-failure -R 'koralo_(gpu_fsr|export_improvements|frame_worker|effect)_tests' -j 2
```

Result:
```
koralo_frame_worker_tests           Passed 0.41s
koralo_gpu_fsr_tests                 Passed 0.03s
koralo_effect_tests                  Passed 4.34s
koralo_export_improvements_tests     Passed 4.94s
100% tests passed, 0 tests failed out of 4
```

The export-improvements test includes a **one-frame input, three-second timeline** and verifies full output duration after FSR scaling. It exercises the FFmpeg infinite-tail clone regression associated with premature EOF (e.g. an error at frame 13).

Configure explicitly reported: **CUDA compiler NOTFOUND**. CPU fallback and project build are verified; actual CUDA kernel compilation, parity and speed on NVIDIA hardware, and Windows/MSVC integration are **not verified**. Run `koralo_gpu_fsr_tests` on an NVIDIA CUDA-capable Windows machine once a CUDA-enabled build succeeds.
