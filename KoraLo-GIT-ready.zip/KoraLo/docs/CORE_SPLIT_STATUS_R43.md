# KoraLo r43 Stage 1 — Core Split / OFX IPC integration

This stage is intentionally behavior-preserving. It reduces the number of
responsibilities owned directly by `media_engine.cpp` and makes the OFX process
boundary physical at link time.

## Media split

- `src/media/frame_cache.*` now owns `Frame` storage and the existing bounded
  cache implementation. Cache behavior is unchanged in this stage; O(1) LRU
  and zero-copy buffers remain Stage 2 work.
- `src/media/ffmpeg_runtime.*` owns executable discovery and FFmpeg hardware
  capability probing.
- `src/media/media_probe.*` owns FFprobe metadata parsing/import normalization.
- `MediaEngine::locate_binary()` and `MediaEngine::probe()` remain as public
  compatibility wrappers, so UI/CLI callers do not change.

## OFX process boundary

- `OfxHostRegistry` no longer contains `LoadLibrary`/`dlopen` code.
- `src/plugins/ofx_inspector.*` is linked only into `koralo-ofx-scanner`.
- `src/plugins/ofx_ipc.*` defines the versioned JSONL request/response protocol.
- `koralo-ofx-scanner` is a small helper executable and no longer links the
  complete `koralo_core` editor library.
- The editor talks to the helper through stdin/stdout with timeout/output caps.
- A synthetic crashing OFX module verifies that helper failure cannot terminate
  the native test/editor process.

## Deliberately not changed

- Frame copies and cache eviction complexity are unchanged. Those belong to the
  Frame Pipeline stage after instrumentation.
- Preview/render algorithms, FFmpeg command construction and effect math are
  unchanged.
- No GPU compositor or scheduler behavior is introduced here.

## Verification

- Debug GUI build succeeds with strict warnings and reports zero compiler warnings.
- `koralo_native_tests`, `koralo_effect_tests`, `koralo_animation_tests`,
  `koralo_media_concurrency_tests` and `koralo_runtime_tests` pass.
- The synthetic healthy OFX returns Boris-style metadata through JSONL.
- The synthetic bad OFX aborts the scanner process (exit 134 on Linux); the
  native registry regression confirms the editor/test process stays alive and
  records a scanner error.
- Link inspection confirms `KoraLo` contains no
  `inspect_ofx_paths_in_process` symbol, while `koralo-ofx-scanner` does.
  The scanner is ~1.4 MiB in this Debug Linux build versus ~59 MiB for the GUI.
- GUI smoke test remained alive under Xvfb until the external smoke timeout.

The monolithic full Debug `koralo_media_tests` remains too slow for a short
wall-clock CI window because it also performs long media generation/render
scenarios. Stage 1 changed its Anime frame wait from a ~1.2 s micro-deadline to
a longer correctness wait; optimized media validation remains the appropriate
full-suite configuration until Instrumentation introduces dedicated benchmarks.

## Playback / graph split

Stage 1 additionally moves realtime scheduling boundaries out of the monolith:

- `src/media/playback_controller.*` owns preview request coalescing, token/epoch
  freshness rules, result publication/polling and worker wake-up state.
- `src/media/decoder_pool.*` owns the persistent FFmpeg raw-video decoder
  session. It deliberately preserves one decoder slot in Stage 1; the boundary
  is designed to grow into A/B source slots during Media Scheduler work.
- `src/media/render_planner.*` owns pure render preflight: output validation,
  preset dimensions/rates, source/project overwrite protection, solo/mute
  filtering, input ordering and cancellation checks.
- `src/media/render_graph.*` turns a validated plan into renderer-neutral video
  and audio layers with explicit stage ordering, opacity/gain/pan and computed
  overlap fades. The existing FFmpeg exporter now consumes this semantic graph
  for those values. This is the seam for a later CPU/GPU compositor; Stage 1
  does not change pixel algorithms.

Dedicated regressions cover `RenderPlanner`, `RenderGraph` and
`PlaybackController`. Existing media concurrency/runtime tests exercise the
`DecoderPool` boundary through MediaEngine.

## Editor split

Button command orchestration is no longer kept entirely in `editor_app.cpp`.
`src/ui/editor_commands.cpp` now owns modal, edit, FX, workspace, track and
main button dispatch handlers. Drawing, pointer interaction and layout remain
in `editor_app.cpp` for later UI decomposition. This is a translation-unit
split only; command semantics are unchanged.

## Current Stage 1 fast matrix

After relinking every test executable against the split core:

- `koralo_native_tests` — PASS
- `koralo_effect_tests` — PASS
- `koralo_animation_tests` — PASS
- `koralo_media_concurrency_tests` — PASS
- `koralo_render_planner_tests` — PASS
- `koralo_render_graph_tests` — PASS
- `koralo_playback_controller_tests` — PASS
- `koralo_runtime_tests` — PASS

Strict GCC warning count is zero for the rebuilt Stage 1 targets. GUI smoke
under Xvfb remains alive until the external smoke timeout.

## Stage 1 sanitizer recheck

After the PlaybackController/DecoderPool split, the new boundaries were checked
again independently of the large MediaEngine translation unit:

- PlaybackController regression (including concurrent producer/worker/poller
  stress): ASan+UBSan PASS, TSan PASS.
- DecoderPool process/session smoke (start, pipe read, time advance, reset):
  ASan+UBSan PASS, TSan PASS.

The existing `koralo_media_concurrency_tests` also remains green after the
split. These targeted checks preserve the Stage 0 memory/race guarantees while
avoiding treating the old full Anime render wall-clock deadline as a sanitizer
correctness condition.
