# Win32 DPI/link fix r35

Revision: `2026-10-02-win32-dpi-link-fix-r35`

The r34 Windows build compiled but failed to link because `EditorApp::set_ui_scale(double)` was declared in `editor_app.hpp` and called by the Win32 frontend, but had no definition in `editor_app.cpp`.

r35 adds the missing definition and keeps Win32 DPI scaling explicit: the initial `GetDpiForWindow` value and later `WM_DPICHANGED` values set the editor scale through the same method. `EditorApp::draw()` no longer overwrites an explicit Windows DPI value with the resolution-derived fallback on every paint. The resolution fallback remains for platforms that do not provide an explicit DPI scale.
