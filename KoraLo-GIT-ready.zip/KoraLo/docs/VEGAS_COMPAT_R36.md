# VEGAS .veg / Chroma Key / Masking clean-room notes (r36)

This document records only compatibility evidence observed in the user-supplied
VEGAS 17 research package, the supplied `Sv_intro75` project, public OFX-style
resource metadata shipped with that package, and KoraLo's own differential tests.
It does **not** describe or copy proprietary VEGAS implementation source code.

## What is validated in `.veg`

KoraLo's importer treats `.veg` as a versioned Wave64-style record container and
only decodes record layouts that have been validated against supplied projects.
The currently validated import surface is:

- project video size, frame rate and audio sample rate for the observed VEGAS
  12/17 layouts;
- media-pool paths and local-folder relinking;
- track order, including empty tracks;
- TrackEvent `Start` / `Length` timing;
- active Take source offset;
- event FX identity strings (`{Svfx:...}` and observed OFX IDs);
- selected legacy audio-track FX identities;
- old Svfx Chroma Keyer named values when their layout passes strict range checks.

Unknown records are not guessed. They remain an interoperability research target.

## Chroma Keyer evidence

The supplied VEGAS 17 `Vfx1.ofx.bundle` resources identify the plug-in as:

`com.vegascreativesoftware:chromakeyer`

and expose this filter control surface:

- `color` — RGB key color;
- `LowThreshold` — double;
- `HighThreshold` — double;
- `BlurAmount` — double;
- `ShowMaskOnly` — boolean.

The preset package contains Blue Screen, Green Screen and pure RGB presets. For
example, the observed Green Screen preset color is approximately
`(0.160784, 0.956863, 0.094118)`.

The supplied VEGAS 12 `.veg` project contains the old ID
`{Svfx:com.sonycreativesoftware:chromakeyer}` followed by the same parameter
names. In that file the immediate value slots decode as:

- `color`: three little-endian doubles (the supplied project has 0, 0, 0);
- `LowThreshold`: little-endian double 0.0;
- `HighThreshold`: little-endian double 1.0;
- `BlurAmount`: little-endian double 0.0;
- `ShowMaskOnly`: immediate zero value slot.

r36 therefore converts this *validated named-value shape* to KoraLo's native
Chroma Key effect. It does not apply this decoder to arbitrary unknown FX blobs.

## KoraLo native Chroma Key

The previous KoraLo preview implementation only darkened green pixels. r36 uses
an actual matte/alpha pipeline:

1. RGB is projected into a luma/chroma representation.
2. Distance to the selected key color is measured in chroma only, so luminance
   variation in green-screen shadows/highlights does not by itself protect the
   background.
3. `Low Threshold` / `High Threshold` form a smooth matte ramp.
4. Optional `Mask Blur` softens the matte.
5. The matte multiplies the event alpha rather than RGB.
6. Preview composites the keyed top event over the next visible lower video
   event; final render uses FFmpeg alpha compositing through the full track graph.
7. `Show Mask Only` displays the matte as grayscale.

The KoraLo algorithm is an independent implementation. The parameter names and
observable control surface are compatibility facts; the exact VEGAS pixel math
has not been claimed or copied.

## VEGAS Bézier Masking evidence

The VEGAS 17 resource metadata identifies:

`com.vegascreativesoftware:bzmasking` — **VEGAS Bézier Masking**.

It exposes global controls:

- `Invert`;
- `MaskFX`;
- `Blend`.

It then exposes **five mask slots**, numbered 0 through 4. Every slot has:

- `Enable_N`;
- `Type_N`: `Oval`, `Rectangle`, `Diamond`, `Curve`;
- `EditMode_N`;
- `EditTool_N`: `Normal`, `Add`, `Delete`, `Split`;
- `Width_N`, `Height_N`, `Angle_N`, `Opacity_N`, `Feather_N`;
- `FeatherStyle_N`: `In`, `Out`, `Both`;
- `Location_N` (2D);
- `AnchorScale_N` (2D);
- `AnchorList_N` (custom parameter containing curve-anchor state);
- tracking controls.

Observed tracking controls per mask include:

- precision: `Normal` / `High`;
- tracking mode: `Location`, `Rotation & Location`, `Shape & Location`,
  `Perspective`;
- direction: `Forward`, `Backward`, `Both`;
- shear, keyframe interval and a start-tracking action.

The shipped presets `Circle`, `Square`, and `Diamond` enable mask 0 and confirm
primitive defaults such as center `(0.5, 0.5)`, opacity 1.0, no feather, and
`FeatherStyle=Both`. The preset files leave `AnchorList` empty, so they do **not**
reveal the private curve-point serialization.

### What is still unknown about masks

The supplied material is sufficient to reconstruct the user-facing schema, but
not to claim bit-for-bit mask compatibility. Still requiring differential VEGAS
projects are:

- `AnchorList_N` binary/custom serialization for arbitrary Bézier points,
  tangents and per-anchor flags;
- exact composition rule when several mask slots overlap;
- exact feather distance/kernel and feather behavior at self-intersections;
- semantics of `MaskFX` relative to the event alpha/effect chain at every stage;
- tracker state serialization and the tracking algorithm itself;
- keyframe encoding for custom anchor lists inside `.veg`.

The correct clean-room next step is to create tiny VEGAS projects in which only
one mask property changes at a time, then compare the resulting `.veg` records.
That is much safer than inferring the curve blob from unrelated bytes.

## Path to broad `.veg` compatibility

KoraLo should not build a monolithic "guessing parser". The intended path is:

1. **Versioned container reader.** Keep known Wave64 record GUID/layout decoders
   separated by validated VEGAS generation.
2. **Opaque preservation.** Preserve unknown records/plugin state alongside the
   decoded model so opening a file does not silently destroy information.
3. **Stable plug-in identity layer.** Map old `{Svfx:...}` identities and modern
   OFX IDs to one compatibility registry.
4. **Native mappings for validated built-ins.** Chroma Key is the first example.
   Other effects are converted only after their parameter state is validated.
5. **OpenFX host path.** When the original OFX plug-in is legally installed on
   the user's machine, host it instead of trying to clone every third-party FX.
6. **Differential fixtures.** Keep small source `.veg` files for one parameter,
   mask operation, transition, envelope or group behavior per test.
7. **No fake export promise.** Writing `.veg` safely requires substantially more
   format coverage than reading it. Until unknown records and version rules can
   be round-tripped, `.kora` remains KoraLo's authoritative editable format.

## r36 regressions

The native test suite now covers:

- Windows-safe Audio FX undo/roundtrip using stable IDs rather than a dangling
  reference invalidated by Project snapshot undo;
- synthetic `.veg` recovery of Chroma Key RGB/threshold/blur/mask values using
  the observed UTF-16-name + immediate-value layout;
- real alpha Chroma Key preview over a lower video layer;
- final rendered Chroma Key composite decoded back and checked for the expected
  lower-layer color.
