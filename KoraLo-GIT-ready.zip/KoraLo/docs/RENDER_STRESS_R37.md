# KoraLo r37 — four-minute render stress run

Source revision: `2026-10-02-render-stress-fix-r37`

## Source media

The stress project was assembled from the supplied `Sv_intro75.zip` media:

- `Overlay 17.mp4`
- `Shockwave_08.mp4`
- `Teilchen.mp4`
- `TEST.wmv`
- `blue.wmv`
- `Tincup-Lost_Original_Mix(www.mp3vip.org).mp3`

## Timeline

- 240.000 s project duration
- 640x360 @ 24 fps stress render preset
- 21 timeline events / 10 media entries
- 12 sequential 20-second video sections
- generated Titles & Text at minutes 1–4
- blue WMV overlay sections with Chroma Key + Glow
- one looped music event for the entire 4 minutes

Video effects exercised across the timeline:

- Brightness/Contrast
- Saturation
- Hue Shift
- Levels
- Vignette
- Pixelate
- Lens Distortion
- RGB Split
- Scanlines
- Glow
- Anime Line Restore
- Anime Vector Colors
- Sharpen
- Chroma Key
- output Letterbox

Audio effects exercised:

- Echo
- Reverb
- 3-Band EQ
- Compressor
- Limiter

## Results before the r37 export fix

The first successful stress render produced all 5760 video frames but the MP4 container duration was `240.353991 s` because echo/reverb were allowed to append an audio tail after the project end. The output audio also inherited the source MP3's 44.1 kHz sample rate rather than the project's 48 kHz setting.

No decode corruption or FFmpeg warning was found; a full `ffmpeg -xerror` decode passed.

## r37 fixes

`MediaEngine::render_project` now:

1. clamps final output to the exact project duration using the timeline duration;
2. explicitly encodes audio at `ProjectSettings::sample_rate`.

A media regression test now checks both conditions on an Audio FX render.

## Final stress render

- Render result: OK
- Render wall time: `55.518055 s`
- Project duration: `240.000000 s`
- Output duration: `240.000000 s`
- Video: H.264, 640x360, 24 fps
- Video frames: `5760`
- Audio: AAC stereo, `48000 Hz`
- Output size: `54,241,177 bytes`
- Approximate render throughput: `103.7 video frames/s` / `4.32x realtime`
- Full post-render decode with `-xerror`: passed
- Full decode wall time: `2.39 s`
- Decode max RSS: `55,844 KiB`

This measurement is a CPU 640x360 stress run in the validation container; it is not a claim for 1080p/4K or for Windows GPU performance.
