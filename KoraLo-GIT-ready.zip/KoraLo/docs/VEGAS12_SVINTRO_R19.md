# VEGAS 12 / Sv_intro75 clean-room compatibility notes — r19

The supplied `Sv_intro75` archive is used only as an observable project-format/media compatibility fixture. KoraLo does not copy VEGAS implementation code or private plug-in code.

## Confirmed project facts

The `.veg` identifies VEGAS Pro 12-era data. For this fixture KoraLo has validated:

- project video: 1920x1080 at 23.976 fps;
- project audio sample rate: 48000 Hz;
- 8 track slots, including empty track slots whose order matters;
- 4 recoverable TrackEvents with timeline Start/Length and Take source offsets;
- 5 referenced media paths; the additional `TEST.wmv` in the archive is not referenced by the `.veg`;
- one `(Legacy) Text` generated-media Event;
- Event FX identities for Chroma Keyer, Color Corrector and Cookie Cutter;
- audio-track FX identity strings for Sony Track Noise Gate, Sony Track EQ and Sony Track Compressor.

The media package exercises H.264/AAC MP4, WMV3/WMA, MP3 and 44.1/48/96 kHz audio metadata. KoraLo relinks old absolute VEGAS paths by basename when the referenced file exists beside the `.veg`.

## What r19 imports

The importer preserves the validated project settings, all observed track slots, Event timing/Take offsets, same-folder relinked media, the Legacy Text Event as a generated-media placeholder, disabled opaque Event FX compatibility nodes, and audio-track FX identity references. WMV/ASF extensions are recognized by the import/media picker path and decoded through FFmpeg when available.

Opaque FX nodes are deliberately disabled because the private parameter blobs have not yet been mapped. This prevents KoraLo from inventing effect values that would change the source project.

## Still pending

- render the Legacy Text generator from validated generator fields;
- controlled differential mapping of Chroma Keyer, Color Corrector and Cookie Cutter parameters;
- validate Noise Gate / Track EQ / Track Compressor parameter storage before importing DSP values;
- validate fades, groups, envelopes and other private Track/Event fields;
- continue one-variable-at-a-time binary comparisons rather than guessing unknown records.
