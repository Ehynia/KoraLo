# VEGAS project timing research — r10

This note records clean-room observations used by KoraLo's experimental `.veg` reader. It documents **data shapes and observable semantics**, not VEGAS implementation code.

## Supplied test project

The user-supplied `Untitled.veg` is a GUID-based RIFF/Wave64-style container. r10 validates a track collection and TrackEvent/Take timing records in that project.

Observed outer record types include:

- track collection type `4d6c0747-2316-11d2-86b0-00c04f8edb8a`;
- track list type `4d6c0748-2316-11d2-86b0-00c04f8edb8a`;
- track header/event collection type `4d6c0749-2316-11d2-86b0-00c04f8edb8a`;
- event list type `4d6c074a-2316-11d2-86b0-00c04f8edb8a`;
- event timing record `168d206a-2321-11d2-86b0-00c04f8edb8a`;
- take timing record `168d206d-2321-11d2-86b0-00c04f8edb8a`.

The validated timing fields use 10,000,000 ticks per second (100 ns units). For the supplied project KoraLo recovers two TrackEvents in container order:

1. timeline start `0.0000000 s`, duration `49.5161333 s`, Take offset `0.0000000 s`;
2. timeline start `50.2168333 s`, duration `40.8918667 s`, Take offset `49.5161333 s`.

The referenced media path is recovered as `C:\Users\Саня\Downloads\transformers-remix.mp3`. Audio-only extensions are normalized as audio media even if FFmpeg exposes embedded cover art as a video stream.

## Import rule in r10

KoraLo preserves validated track-list order and creates TrackEvents from recovered timeline start/duration plus Take source offset. Unknown records are not guessed. Fades, groups, envelopes, event FX and other private records remain opaque until they can be validated independently.

The original `.veg` is treated read-only. KoraLo edits are saved to `.kora`.

## Regression coverage

`koralo_native_tests` now builds a synthetic Wave64 hierarchy with the same validated record shapes and asserts:

- track ordering;
- TrackEvent start/duration;
- Take offset;
- raw track discriminator preservation.

This lets the importer evolve without silently reverting to the previous full-source fallback.
