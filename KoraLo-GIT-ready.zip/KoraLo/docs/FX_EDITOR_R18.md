# KoraLo r18 — Video Event FX editor and project preview settings

Revision: `2026-10-02-fx-editor-project-preview-r18`

## Video Event FX editor

The event FX context action now opens a dedicated native editor. It contains the built-in effect catalog, selected event FX chain, large effect preview, enable/remove controls and numeric parameter sliders.

Numeric slider drags follow KoraLo's transaction rule. Mouse movement updates `EffectParamDrag` only. `Project` is left unchanged until mouse-up. Preview requests copy the event effect chain and apply the transient parameter value to that copy, so the user sees the effect change without committing it. Mouse-up applies the value and creates one Undo entry. Escape cancels the drag and requests the committed frame again.

## Project-owned preview configuration

`ProjectSettings` now stores:

- preview quality (Draft / Preview / Good / Best);
- preview FPS cap;
- optimized prepared-cache enable/disable.

These values round-trip in `.kora` v10. The preview toolbar's settings button opens Project Properties. Application Preferences no longer presents those controls as application-wide settings.

## Native UI polish

The button renderer uses deeper layered shadows, subtle top highlights and hover/active accent treatment. The native bitmap icon atlas adds add, remove, reset, power and close glyphs used by the FX editor. No browser, WebView or icon-font runtime is involved.

## Validation

Linux Release build and both native/media test binaries pass. X11 smoke was run under Xvfb with a real H.264/AAC event containing Color Corrector. The FX editor opened from the event context menu, displayed the affected video frame, and a real Brightness slider drag updated the preview and committed on mouse-up.

Windows/MSVC is not claimed validated for this exact revision because it was not built on a Windows host here.
