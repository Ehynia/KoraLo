# Windows MSVC build fix — r28

Revision: `2026-10-02-windows-msvc-build-fix-r28`

A Visual Studio 17 2022 build exposed a portability error in the r27 audio-recording code. `media_engine.cpp` used `std::array<char, 65536>` without directly including `<array>`. GCC happened to compile because of transitive includes, while MSVC correctly rejected the incomplete `std::array` type and then emitted a secondary `std::min<uint64_t>` overload error.

The fix adds the missing standard header and cleans the MSVC warnings reported in the same log: guarded Windows macros in the OFX host and `_dupenv_s` for environment-variable reads on Windows.

The PCM/WAV path is already covered by `koralo_media_tests`, which writes raw PCM, finalizes it to WAV, checks duration, and probes the resulting audio file.
