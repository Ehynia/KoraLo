# Titles & Text / autosave / close safety — r20

Revision: `2026-10-02-titles-text-autosave-ui-r20`

## Clean-room reference

The supplied VEGAS 17 screenshots were used as an observable UX reference for the existence and rough workflow of Insert -> Text / Generated Media and a text-generator editor. KoraLo's model, controls, renderer and persistence are independent native implementations. No VEGAS implementation code or private parameter layout is copied.

## Native generated-text model

`MediaItem::generated_text` stores the editable source for a generated-media item. A timeline `TrackEvent` continues to own event duration, fades, opacity, motion and FX. A generated text event therefore behaves like normal video media on the timeline while its source is synthesized by KoraLo.

Implemented source parameters: UTF-8 multiline text, Open Sans family label, font size, bold, italic, alignment, RGBA text color, scale, normalized X/Y location, 3x3 anchor, outline, shadow, and a simple fade animation preset.

The editor works on a pending copy. Preview updates while editing and mouse-positioning do not mutate the Project. **Apply** creates one undoable project change; **Cancel** discards pending changes.

## Preview and render

Preview rasterizes Open Sans glyphs in-process and alpha-composites them over the current project frame. Text-only events are previewed over the project black frame. Final rendering emits a temporary transparent PAM frame for each generated text source and feeds it into KoraLo's existing FFmpeg composition graph, so event/track opacity, fades, Pan/Crop/motion and supported FX still participate. Temporary files are removed after encode.

## Autosave and closing

When a project first becomes dirty, KoraLo starts a 30-second recovery timer. Recovery snapshots are stored under `<KoraLo executable directory>/autosave/` when writable, otherwise under the operating-system temporary directory in `KoraLo/autosave/`. Autosave is skipped during active timeline/Pan-Crop/FX parameter transactions and final rendering. A forced recovery snapshot is attempted before a dirty close decision.

Closing a dirty project presents Save / Discard / Cancel. Save uses the normal project-save flow; cancelling the Save As dialog leaves KoraLo open. Discard removes the recovery file and closes. Cancel keeps both the editor and recovery data. A successful normal save removes the recovery copy.
