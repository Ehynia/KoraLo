# r15 — direct Event fades and persistent playback preview

Revision: `2026-10-01-fade-stream-preview-r15`

## Clean-room UI behavior

The supplied VEGAS 17 screenshots show two observable event interactions used as the behavioral reference:

- a fade-out is created by dragging the top-right event handle left;
- a fade-in is created by dragging the top-left event handle right;
- the top handle moves with the chosen duration while a diagonal fade line is visible;
- a small tooltip reports the fade offset/duration while dragging.

KoraLo implements that behavior independently. No VEGAS binary implementation code is copied. The supplied VEGAS and OpenColorIO backup archives remain research/reference inputs only.

## Transaction model

`DragMode::FadeIn` / `DragMode::FadeOut` store temporary `ClipVisualOverride.fade_in/fade_out` values. `update_drag()` quantizes the duration to the project frame rate and never writes the Project. `commit_drag()` writes the final fade values inside one Undo transaction on mouse-up. The fade is per TrackEvent; linked A/V group IDs and membership are untouched.

## Preview/render behavior

Video preview multiplies the current event fade envelope by event opacity and video-track opacity. Final rendering already uses FFmpeg alpha fades and now shares the same serialized event values. The Master meter multiplies cached source levels by the event fade envelope. Interim ffplay audio preview uses a time-varying volume expression so the fade continues while audio is playing rather than being sampled once at play start.

## Playback throughput change

The old uncached playback path launched a new FFmpeg process and wrote/read a temporary PPM for every requested frame. r15 adds `ReadPipeProcess`, a shell-free cross-platform child-process wrapper with binary stdout. For ordinary sequential playback (no dynamic Event Pan/Crop and no per-frame FX chain), `MediaEngine` starts FFmpeg once and reads fixed-size RGB24 frames from the pipe.

The session tracks the expected next source time. Small UI scheduling gaps are handled by dropping a bounded number of stale raw frames; large jumps/backward seeks restart at the requested timestamp. Hardware decode is attempted when detected, with CPU retry on stream failure. Exact scrub/seek frames and dynamic Pan/Crop/FX requests keep the existing random-access decoder until the session/seek/compositor layer is generalized.

- The fade handle hit target has priority over the compact Event FX/Pan-Crop buttons in the top-corner radius, so dragging the edge cannot accidentally open Pan/Crop.
