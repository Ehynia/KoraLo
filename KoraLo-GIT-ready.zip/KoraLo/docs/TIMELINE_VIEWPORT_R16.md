# KoraLo r16 — timeline content viewport isolation

Revision: `2026-10-02-timeline-viewport-clip-r16`

## Defect

When the timeline was horizontally panned, an Event that began before the visible time window retained a negative/off-header draw coordinate. The outer timeline body clip intentionally included both the fixed track headers and the timeline content, so the Event could paint over its own track header. The same hidden geometry could also be returned by Event hit-testing in the header pane.

A long audio Event additionally generated waveform columns from the raw Event left edge even when most of those columns were off-screen.

## Fix

- Event painting is wrapped in a nested clip restricted to `timeline.x + header_w ... timeline.x + width`.
- `EditController::hit_clip()` immediately rejects x coordinates outside that content viewport.
- Event Pan/Crop / FX compact buttons are only registered when fully visible in the content viewport.
- Audio waveform drawing computes the first visible five-pixel sample column and stops at the visible right edge.
- Ruler markers outside the content viewport are not painted over the fixed header.

## Regression

`test_timeline_horizontal_scroll_keeps_header_noninteractive()` constructs an Event whose raw left edge moves behind the fixed header after horizontal scrolling. It verifies that a click in the header returns no Event while a click on the visible continuation still returns the Event.

## Validation

A clean Linux Release build and both native/media test binaries pass. X11 smoke was run with a 100-second Event and the timeline panned to approximately 00:30; the Event remains clipped to the content pane and the track headers remain unobscured.
