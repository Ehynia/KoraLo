# KoraLo r43 — keyframe RMB UX

- Right-clicking an Animation Workspace keyframe now selects that exact keyframe and opens a context menu.
- The menu provides Delete keyframe.
- Right-clicking a Pan/Crop keyframe provides the same action.
- Pan/Crop hit-testing snaps to an existing keyframe (8 px radius), rather than deleting at an approximate scrub time.
- Both delete paths use the project Undo stack.
- Empty-space RMB keeps the previous non-destructive behavior.
- EN/RU locale keys were added and locale key sets remain synchronized.

Validation: editor_app.cpp, editor_commands.cpp and animation_workspace.cpp pass -Wall -Wextra -Wshadow -Werror -fsyntax-only. A full Release rebuild was started but exceeded the available compile window while rebuilding the existing large core; no compile diagnostic from this change was produced before the timeout.
