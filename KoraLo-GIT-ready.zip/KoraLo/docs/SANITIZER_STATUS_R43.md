# r43 Stage 0 — Sanitizer status

Revision: `2026-10-06-stabilization-sanitizers-r43-stage0`

## Repeatable CMake switches

Linux/GCC or Clang builds can enable the sanitizer modes directly:

```sh
cmake -S . -B build-asan -DKORALO_BUILD_GUI=OFF -DKORALO_ENABLE_ASAN_UBSAN=ON
cmake --build build-asan

cmake -S . -B build-tsan -DKORALO_BUILD_GUI=OFF -DKORALO_ENABLE_TSAN=ON
cmake --build build-tsan
```

ASan/UBSan and TSan must use separate build directories and cannot be enabled together.

## ASan + UBSan result

The following test paths completed without AddressSanitizer or UndefinedBehaviorSanitizer diagnostics:

- `koralo_native_tests`
- `koralo_effect_tests`
- `koralo_animation_tests`
- `koralo_runtime_tests`
- `koralo_media_concurrency_tests`

The full debug `koralo_media_tests` reaches the existing Anime Restore preview timing assertion before the complete suite can finish under instrumentation. The same media suite passes in the normal optimized build. No ASan/UBSan diagnostic is emitted before the timing assertion.

## ThreadSanitizer result

The following paths completed without ThreadSanitizer race reports:

- `koralo_native_tests`
- `koralo_effect_tests`
- `koralo_runtime_tests`
- `koralo_media_concurrency_tests`

`koralo_media_concurrency_tests` specifically exercises the four MediaEngine background paths while the foreground queries their state:

- preview worker
- thumbnail worker
- audio meter worker
- media preparation worker

It drives preview requests, asynchronous thumbnails, meter analysis, preparation-state reads and cache invalidation during one MediaEngine lifetime, then waits for all worker outputs to become observable before destruction.

The full TSan media suite has the same pre-existing Anime Restore correctness-test timing barrier as the ASan debug run. This is a test timing limitation under heavy instrumentation, not a sanitizer finding.

## Policy

Sanitizer failures are release blockers for Stage 0. Performance assertions should be measured in a separate optimized benchmark configuration rather than using short wall-clock deadlines inside sanitizer correctness runs.

## Stage 1 note

Stage 1 separates the large Anime preview check from a micro-benchmark concern by
extending that correctness test's wait window. The assertion still requires the
expected frame/token/dimensions, but no longer treats a Debug/instrumented CPU
frame taking longer than ~1.2 seconds as functional failure. Dedicated
performance limits will move to the Instrumentation stage.
