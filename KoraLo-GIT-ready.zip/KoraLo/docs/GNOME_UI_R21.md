# r21 — Modern GNOME-style native UI pass

Revision: `2026-10-02-gnome-modern-ui-r21`

This pass modernizes KoraLo's existing native Canvas interface without replacing the Win32/GDI or X11 frontends and without adding GTK, WebView, HTML or CSS at runtime.

## Visual system

- neutral dark surfaces with lower-contrast separators;
- restrained GNOME-like blue accent states;
- rounded native buttons, cards, tabs, fields, scrollbars and preview surfaces;
- softer multi-layer shadows and fewer hard bevels;
- larger header/tool spacing and clearer grouping;
- Open Sans remains the primary UI face;
- Project Media, Preview and Timeline now read as separate cards instead of one flat grid;
- menus and context menus use rounded hover rows and softer dividers;
- Project Properties, Preferences, Pan/Crop, Video Event FX, Titles & Text and Render As share the refreshed dark dialog language.

## Scope

This is a visual/layout pass only. Timeline transaction rules, Project semantics, Undo/Redo, media decoding, caching, render behavior and project serialization are unchanged.

## Validation

- clean Linux Release configure/build: passed;
- `koralo_native_tests`: passed;
- `koralo_media_tests`: passed;
- X11 GUI smoke under Xvfb with a real H.264/AAC clip: passed;
- fresh screenshot captured from the running r21 binary.

Windows/MSVC for this exact revision was not executed in this environment and is not claimed as verified.
