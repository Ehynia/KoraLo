#include "media/media_engine.hpp"
#include "media/native_effects.hpp"
#include "media/paint_mask.hpp"
#include <chrono>
#include <iostream>
#include <iomanip>
using namespace koralo;
namespace koralo {bool apply_native_effect_r41(Frame&,const EffectInstance&,double);}
int main(){using Clock=std::chrono::steady_clock;Frame base;base.width=960;base.height=540;base.rgb.assign(960*540*3,180);auto effect=make_effect_instance("koralo.paint_mask",777);std::string history;for(int i=0;i<1024;++i){double x=.12+(i%30)*.024,y=.12+(i%21)*.031;history+=encode_brush_stroke({x,y,x+.02,y+.008,.04,.75,i%9!=0});}std::get<std::string>(effect_parameter(effect,"strokes")->value)=history;Frame warm=base;apply_native_effect(warm,effect,0);double old_ms=0,new_ms=0,max_error=0;for(int i=0;i<80;++i){double x=.2+i*.006;history+=encode_brush_stroke({x,.5,x+.006,.51,.04,.75,true});std::get<std::string>(effect_parameter(effect,"strokes")->value)=history;Frame old=base,current=base;auto t=Clock::now();apply_native_effect_r41(old,effect,0);old_ms+=std::chrono::duration<double,std::milli>(Clock::now()-t).count();t=Clock::now();apply_native_effect(current,effect,0);new_ms+=std::chrono::duration<double,std::milli>(Clock::now()-t).count();for(std::size_t p=0;p<old.alpha.size();++p)max_error=std::max(max_error,double(std::abs(int(old.alpha[p])-int(current.alpha[p]))));}std::cout<<std::setprecision(8)<<"{\"width\":960,\"height\":540,\"initial_segments\":1024,\"updates\":80,\"r41_mean_ms\":"<<old_ms/80<<",\"r42_mean_ms\":"<<new_ms/80<<",\"speedup\":"<<old_ms/new_ms<<",\"max_alpha_error\":"<<max_error<<"}\n";return max_error>1?1:0;}
