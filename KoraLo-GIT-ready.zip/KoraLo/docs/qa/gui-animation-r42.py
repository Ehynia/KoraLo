import ctypes as C,os,socket,subprocess as S,time,json,math
from pathlib import Path
from PIL import Image
root=Path.cwd();(root/'KoraLo/docs/qa').mkdir(exist_ok=True);log=(root/'.deps/xvfb.log').open('w');env=os.environ.copy();env.update(GALLIUM_DRIVER='llvmpipe',LIBGL_ALWAYS_SOFTWARE='1',MESA_LOADER_DRIVER_OVERRIDE='swrast',MESA_SHADER_CACHE_DIR=str(root/'KoraLo/build/gl-cache'),LP_NUM_THREADS='2',LIBGL_DRIVERS_PATH=str(root/'.deps/glroot/usr/lib/x86_64-linux-gnu/dri'),LD_PRELOAD=str(root/'.deps/qa_xkb.so'),LD_LIBRARY_PATH=str(root/'.deps/glroot/usr/lib/x86_64-linux-gnu')+':'+str(root/'.deps/sysroot/usr/lib/x86_64-linux-gnu'))
server=S.Popen([str(root/'.deps/sysroot/usr/bin/Xvfb'),':104','-screen','0','1600x1000x24','-nolock','-nolisten','unix','-listen','tcp','-ac','-xkbdir',str(root/'.deps/sysroot/usr/share/X11/xkb')],env=env,stdout=log,stderr=S.STDOUT);app=None
try:
 for _ in range(50):
  try:s=socket.create_connection(('127.0.0.1',6104),.1);s.close();break
  except OSError:
   if server.poll() is not None:raise RuntimeError('Xvfb exited')
   time.sleep(.1)
 else:raise RuntimeError('Xvfb unavailable')
 work=root/'KoraLo/build/gui-animation';work.mkdir(exist_ok=True);(work/'animation.kora').unlink(missing_ok=True);env=os.environ.copy();env.update(GALLIUM_DRIVER='llvmpipe',LIBGL_ALWAYS_SOFTWARE='1',MESA_LOADER_DRIVER_OVERRIDE='swrast',MESA_SHADER_CACHE_DIR=str(root/'KoraLo/build/gl-cache'),LP_NUM_THREADS='2',LIBGL_DRIVERS_PATH=str(root/'.deps/glroot/usr/lib/x86_64-linux-gnu/dri'),LD_LIBRARY_PATH=str(root/'.deps/glroot/usr/lib/x86_64-linux-gnu'),KORALO_FFMPEG_DIR=str(root/'KoraLo/portable/Linux-x86_64/bin'),DISPLAY='127.0.0.1:104',KORALO_LANG='ru-RU',KORALO_DATA_DIR=str(root/'KoraLo/build/gui-data'),KORALO_CACHE_DIR=str(root/'KoraLo/build/gui-cache'),TMPDIR=str(root/'KoraLo/build/test-tmp'))
 app_log=(root/'.deps/gui-app.log').open('w');app=S.Popen([str(root/'KoraLo/build/KoraLo')],cwd=work,env=env,stdout=app_log,stderr=S.STDOUT)
 x=C.CDLL('libX11.so.6');handler=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p)(lambda d,e:0);x.XSetErrorHandler.argtypes=[C.c_void_p];x.XSetErrorHandler(C.cast(handler,C.c_void_p));x.XOpenDisplay.argtypes=[C.c_char_p];x.XOpenDisplay.restype=C.c_void_p;d=x.XOpenDisplay(b'127.0.0.1:104')
 if not d:raise RuntimeError('Display unavailable')
 x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XDefaultRootWindow.restype=C.c_ulong;r=x.XDefaultRootWindow(d)
 x.XQueryTree.argtypes=[C.c_void_p,C.c_ulong,C.POINTER(C.c_ulong),C.POINTER(C.c_ulong),C.POINTER(C.POINTER(C.c_ulong)),C.POINTER(C.c_uint)];x.XFetchName.argtypes=[C.c_void_p,C.c_ulong,C.POINTER(C.c_void_p)];x.XFree.argtypes=[C.c_void_p];x.XFlush.argtypes=[C.c_void_p]
 def windows():
  rr=C.c_ulong();pp=C.c_ulong();children=C.POINTER(C.c_ulong)();count=C.c_uint();x.XQueryTree(d,r,C.byref(rr),C.byref(pp),C.byref(children),C.byref(count));result=[]
  for i in range(count.value):
   name=C.c_void_p()
   if x.XFetchName(d,children[i],C.byref(name)) and name.value:result.append((children[i],C.string_at(name).decode('utf8',errors='replace')));x.XFree(name)
  x.XFree(children);return result
 def wait_window(predicate):
  for _ in range(100):
   found=[(w,t) for w,t in windows() if predicate(t)]
   if found:return found[-1][0]
   if app.poll() is not None:raise RuntimeError('GUI exited')
   time.sleep(.1)
  raise RuntimeError('Window missing '+repr(windows()))
 class KeyEvent(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('root',C.c_ulong),('subwindow',C.c_ulong),('time',C.c_ulong),('x',C.c_int),('y',C.c_int),('x_root',C.c_int),('y_root',C.c_int),('state',C.c_uint),('keycode',C.c_uint),('same_screen',C.c_int)]
 class Event(C.Union):_fields_=[('key',KeyEvent),('pad',C.c_long*24)]
 x.XStringToKeysym.argtypes=[C.c_char_p];x.XStringToKeysym.restype=C.c_ulong;x.XKeysymToKeycode.argtypes=[C.c_void_p,C.c_ulong];x.XKeysymToKeycode.restype=C.c_ubyte;x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)]
 def key(window,name,state=0):
  e=Event();e.key=KeyEvent(2,0,1,d,window,r,0,0,1,1,1,1,state,x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode())),1);x.XSendEvent(d,window,0,1,C.byref(e));x.XFlush(d)
 class XImage(C.Structure):_fields_=[('width',C.c_int),('height',C.c_int),('xoffset',C.c_int),('format',C.c_int),('data',C.c_void_p),('byte_order',C.c_int),('bitmap_unit',C.c_int),('bitmap_bit_order',C.c_int),('bitmap_pad',C.c_int),('depth',C.c_int),('bytes_per_line',C.c_int),('bits_per_pixel',C.c_int)]
 x.XGetImage.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_ulong,C.c_int];x.XGetImage.restype=C.POINTER(XImage);x.XDestroyImage.argtypes=[C.POINTER(XImage)]
 def capture(name):
  im=x.XGetImage(d,r,0,0,1600,1000,2**64-1,2)
  if not im or im.contents.bits_per_pixel!=32:raise RuntimeError('Framebuffer unavailable')
  v=im.contents;raw=C.string_at(v.data,v.bytes_per_line*v.height);Image.frombytes('RGB',(v.width,v.height),raw,'raw','BGRX',v.bytes_per_line,1).save(root/'KoraLo/docs/qa'/name);x.XDestroyImage(im)
 main=wait_window(lambda t:'KoraLo' in t);x.XResizeWindow.argtypes=[C.c_void_p,C.c_ulong,C.c_uint,C.c_uint];x.XResizeWindow(d,main,1560,940);x.XFlush(d);time.sleep(.3)
 class ButtonEvent(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('root',C.c_ulong),('subwindow',C.c_ulong),('time',C.c_ulong),('x',C.c_int),('y',C.c_int),('x_root',C.c_int),('y_root',C.c_int),('state',C.c_uint),('button',C.c_uint),('same_screen',C.c_int)]
 class BEvent(C.Union):_fields_=[('button',ButtonEvent),('pad',C.c_long*24)]
 def button(px,py,typ,state=0):
  e=BEvent();e.button=ButtonEvent(typ,0,1,d,main,r,0,0,px,py,px,py,state,1,1);x.XSendEvent(d,main,0,4 if typ==4 else 8,C.cast(C.byref(e),C.POINTER(Event)));x.XFlush(d)
 def mouse(px,py):button(px,py,4);button(px,py,5)
 class MotionEvent(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('root',C.c_ulong),('subwindow',C.c_ulong),('time',C.c_ulong),('x',C.c_int),('y',C.c_int),('x_root',C.c_int),('y_root',C.c_int),('state',C.c_uint),('is_hint',C.c_char),('same_screen',C.c_int)]
 class MEvent(C.Union):_fields_=[('motion',MotionEvent),('pad',C.c_long*24)]
 def move(px,py):
  e=MEvent();e.motion=MotionEvent(6,0,1,d,main,r,0,0,px,py,px,py,256,b'\0',1);x.XSendEvent(d,main,0,64,C.cast(C.byref(e),C.POINTER(Event)));x.XFlush(d)
 mouse(505,43);time.sleep(.3);mouse(215,115);time.sleep(1.5);capture('animation-linux-r42.png')
 mouse(485,113);time.sleep(.2);capture('animation-nodes-r42.png')
 key(main,'s',4);modal=wait_window(lambda t:'Save KoraLo' in t)
 key(modal,'a',4)
 for ch in 'animation.kora':key(modal,'period' if ch=='.' else ch)
 key(modal,'Return');time.sleep(.8)
 saved=(work/'animation.kora').read_text();(root/'.deps/gui-before.kora').write_text(saved);capture('animation-saved-r42.png');print('before',len(saved),flush=True);assert 'VANIM' in saved,'No saved vector scene'
 nx,ny=616,343
 button(nx,ny,4)
 for px in range(nx+5,nx+41,5):move(px,ny+15);time.sleep(.02)
 button(nx+40,ny+15,5);time.sleep(.4);key(main,'s',4);time.sleep(.8)
 edited=(work/'animation.kora').read_text();(root/'.deps/gui-after.kora').write_text(edited);capture('animation-edited-r42.png');print('after',len(edited),flush=True);assert edited!=saved,'Node drag did not edit vector'
 key(main,'z',4);time.sleep(.2);key(main,'s',4);time.sleep(.8);assert (work/'animation.kora').read_text()==saved,'Vector undo failed'
 key(main,'y',4);time.sleep(.2);key(main,'s',4);time.sleep(.8);assert (work/'animation.kora').read_text()==edited,'Vector redo failed'
 # Drag a key in time and a Bezier handle; each operation is undoable.
 button(678,681,4);move(575,681);button(575,681,5);time.sleep(.6);key(main,'s',4);time.sleep(.9)
 assert (work/'animation.kora').read_text()!=edited,'Key drag did not change animation'
 key(main,'z',4);time.sleep(.3);key(main,'s',4);time.sleep(.7);assert (work/'animation.kora').read_text()==edited,'Key drag undo failed'
 button(1327,884,4);move(1280,825);button(1280,825,5);time.sleep(.6);key(main,'s',4);time.sleep(.9)
 assert (work/'animation.kora').read_text()!=edited,'Bezier handle drag did not change easing'
 key(main,'z',4);time.sleep(.3);key(main,'s',4);time.sleep(.7);assert (work/'animation.kora').read_text()==edited,'Bezier undo failed'
 key(main,'b');time.sleep(.1);button(690,340,4)
 for px in range(695,841,10):move(px,340);time.sleep(.015)
 button(840,340,5);time.sleep(.8);key(main,'s',4);time.sleep(.8);painted=(work/'animation.kora').read_text();assert painted!=edited,'Vector brush did not paint';capture('animation-brush-r42.png')
 button(740,370,4);move(800,380);key(main,'Escape');button(800,380,5);time.sleep(.2);key(main,'s',4);time.sleep(.8);assert (work/'animation.kora').read_text()==painted,'Escape failed to restore vector scene'
 mouse(630,113);time.sleep(.1);button(480,205,4);move(1050,425);button(1050,425,5);time.sleep(.7);key(main,'s',4);time.sleep(.8);cropped=(work/'animation.kora').read_text();assert cropped!=painted,'Vector crop was not saved';capture('animation-crop-r42.png')
 mouse(325,113);time.sleep(.1);key(main,'space');time.sleep(.5);capture('animation-play-a-r42.png');time.sleep(.8);capture('animation-play-b-r42.png');key(main,'space');time.sleep(.3)
 # The menu switches the same window between OpenGL and the X11 CPU fallback.
 mouse(430,14);time.sleep(.1);mouse(455,43);time.sleep(.7);capture('animation-cpu-r42.png')
 mouse(430,14);time.sleep(.1);mouse(455,43);time.sleep(.7);capture('animation-opengl-r42.png')
 print(json.dumps({'interface_toggle':True,'key_drag':True,'bezier_handle':True,'animation_native_gui':True,'saved_vectors':True,'node_or_move_edit':True,'undo_redo':True,'brush':True,'crop':True,'escape_restores_scene':True}),flush=True)

finally:
 if app is not None:app.terminate();app.wait(timeout=3)
 server.terminate();server.wait(timeout=3);log.close()
