// Spatial CPU port of the user-supplied Anime Line Restore V45, 1.py.
// No Python bootstrap, process termination or dependency installation is run.
#include "native_effects.hpp"
#include "media_engine.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <sstream>
#include <vector>
namespace koralo {
namespace {
using Plane = std::vector<float>;
using RGB = std::array<Plane, 3>;
float clamp(float x) { return std::clamp(x, 0.f, 1.f); }
int reflect(int x, int n) {
  if (n < 2)
    return 0;
  while (x < 0 || x >= n)
    x = x < 0 ? -x : 2 * n - 2 - x;
  return x;
}
Plane gaussian(const Plane &p, int w, int h, float sigma) {
  if (sigma <= 0)
    return p;
  int r = std::clamp(int(std::nearbyint(2.5f * sigma)), 1, 32);
  Plane k(2 * r + 1), tmp(p.size()), out(p.size());
  float total = 0;
  for (int i = -r; i <= r; ++i) {
    k[i + r] = std::exp(-i * i / (2 * sigma * sigma));
    total += k[i + r];
  }
  for (auto &x : k)
    x /= total;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float v = 0;
      for (int i = -r; i <= r; ++i)
        v += p[y * w + reflect(x + i, w)] * k[i + r];
      tmp[y * w + x] = v;
    }
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float v = 0;
      for (int i = -r; i <= r; ++i)
        v += tmp[reflect(y + i, h) * w + x] * k[i + r];
      out[y * w + x] = v;
    }
  return out;
}
Plane morph(const Plane &p, int w, int h, int radius, bool maximum) {
  Plane tmp(p.size()), out(p.size());
  auto combine = [&](float a, float b) {
    return maximum ? std::max(a, b) : std::min(a, b);
  };
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float v = p[y * w + x];
      for (int i = -radius; i <= radius; ++i)
        v = combine(v, p[y * w + std::clamp(x + i, 0, w - 1)]);
      tmp[y * w + x] = v;
    }
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float v = tmp[y * w + x];
      for (int i = -radius; i <= radius; ++i)
        v = combine(v, tmp[std::clamp(y + i, 0, h - 1) * w + x]);
      out[y * w + x] = v;
    }
  return out;
}
Plane average_zero(const Plane &p, int w, int h, int r) {
  std::vector<double> integral(std::size_t(w + 1) * (h + 1));
  Plane out(p.size());
  for (int y = 0; y < h; ++y) {
    double row = 0;
    for (int x = 0; x < w; ++x) {
      row += p[y * w + x];
      integral[(y + 1) * (w + 1) + x + 1] = integral[y * (w + 1) + x + 1] + row;
    }
  }
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      int x0 = std::max(0, x - r), y0 = std::max(0, y - r),
          x1 = std::min(w, x + r + 1), y1 = std::min(h, y + r + 1);
      out[y * w + x] =
          float((integral[y1 * (w + 1) + x1] - integral[y0 * (w + 1) + x1] -
                 integral[y1 * (w + 1) + x0] + integral[y0 * (w + 1) + x0]) /
                ((2 * r + 1) * (2 * r + 1)));
    }
  return out;
}
Plane luma(const RGB &rgb) {
  Plane p(rgb[0].size());
  for (std::size_t i = 0; i < p.size(); ++i)
    p[i] = .299f * rgb[0][i] + .587f * rgb[1][i] + .114f * rgb[2][i];
  return p;
}
float sigmoid(float x) { return 1 / (1 + std::exp(-x)); }
float bilinear(const Plane &p, int w, int h, float x, float y) {
  x = std::clamp(x, 0.f, float(w - 1));
  y = std::clamp(y, 0.f, float(h - 1));
  int ix = int(x), iy = int(y);
  float dx = x - ix, dy = y - iy;
  int xx = std::min(ix + 1, w - 1), yy = std::min(iy + 1, h - 1);
  return (p[iy * w + ix] * (1 - dx) + p[iy * w + xx] * dx) * (1 - dy) +
         (p[yy * w + ix] * (1 - dx) + p[yy * w + xx] * dx) * dy;
}
float param(const EffectInstance &e, const char *key, double t, float fallback,
            float lo, float hi) {
  double v = effect_numeric(e, key, t, fallback);
  return std::isfinite(v) ? std::clamp(float(v), lo, hi) : fallback;
}
struct Detector {
  Plane smooth, valley, gx, gy, gradient, blackhat, zone;
};
Detector detect(const RGB &rgb, int w, int h, float denoise, float local,
                int blackhat) {
  Detector d;
  d.smooth = gaussian(luma(rgb), w, h, denoise);
  d.valley = gaussian(d.smooth, w, h, local);
  auto closed = morph(morph(d.smooth, w, h, blackhat / 2, true), w, h,
                      blackhat / 2, false);
  auto n = d.smooth.size();
  d.gx.resize(n);
  d.gy.resize(n);
  d.gradient.resize(n);
  d.blackhat.resize(n);
  auto at = [&](int x, int y) {
    return d.smooth[reflect(y, h) * w + reflect(x, w)];
  };
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      int i = y * w + x;
      float gx = (at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1) -
                  at(x - 1, y - 1) - 2 * at(x - 1, y) - at(x - 1, y + 1)) /
                 8;
      float gy = (at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1) -
                  at(x - 1, y - 1) - 2 * at(x, y - 1) - at(x + 1, y - 1)) /
                 8;
      d.gx[i] = gx;
      d.gy[i] = gy;
      d.gradient[i] = std::sqrt(gx * gx + gy * gy + 1e-7f);
      d.valley[i] = std::max(0.f, d.valley[i] - d.smooth[i]);
      d.blackhat[i] = std::max(0.f, closed[i] - d.smooth[i]);
    }
  return d;
}
Plane text_zone(const Detector &d, int w, int h, float local) {
  Plane edges(d.gradient.size());
  for (std::size_t i = 0; i < edges.size(); ++i)
    edges[i] = d.gradient[i] > .4f ? 1 : 0;
  auto density = average_zero(edges, w, h, 10);
  for (auto &x : density)
    x = sigmoid(20 * (x - .15f));
  return gaussian(density, w, h, local);
}
RGB vector_color(const RGB &original, int w, int h, const EffectInstance &e,
                 double t) {
  RGB out = original;
  float flat = param(e, "flatness", t, .65f, 0, 1),
        levels = param(e, "levels", t, 48, 0, 256),
        contrast = param(e, "contrast", t, 1.1f, 0, 3),
        sat = param(e, "saturation", t, 1.25f, 0, 3),
        blend = param(e, "original_blend", t, .35f, 0, 1);
  if (flat > 0)
    for (int c = 0; c < 3; ++c) {
      auto smoothed = gaussian(original[c], w, h, 2.5f);
      for (std::size_t i = 0; i < out[c].size(); ++i)
        out[c][i] =
            levels > 0
                ? smoothed[i] + (std::nearbyint(smoothed[i] * levels) / levels -
                                 smoothed[i]) *
                                    flat
                : original[c][i] + (smoothed[i] - original[c][i]) * flat;
    }
  for (std::size_t i = 0; i < out[0].size(); ++i) {
    for (int c = 0; c < 3; ++c)
      out[c][i] = clamp((out[c][i] - .5f) * contrast + .5f);
    float lum = .299f * out[0][i] + .587f * out[1][i] + .114f * out[2][i];
    for (int c = 0; c < 3; ++c)
      out[c][i] = clamp(lum + (out[c][i] - lum) * sat) * (1 - blend) +
                  original[c][i] * blend;
  }
  return out;
}
void restore_lines(RGB &out, const RGB &original, int w, int h,
                   const EffectInstance &e, double t, bool text) {
  float local = param(e, "local_sigma", t, 3, .1f, 10);
  int size = int(param(e, "blackhat_size", t, 7, 3, 21)) | 1;
  auto d = detect(original, w, h, param(e, "denoise_sigma", t, .8f, .1f, 5),
                  local, size);
  float threshold = param(e, "threshold", t, 16, 0, 80),
        maxlum = param(e, "max_luma", t, 230, 0, 255) / 255,
        artifact = param(e, "artifact_threshold", t, .08f, 0, 1);
  Plane candidate(d.smooth.size()), ridge(candidate.size());
  for (std::size_t i = 0; i < candidate.size(); ++i)
    candidate[i] =
        (.55f * d.blackhat[i] + .30f * d.valley[i] + .15f * d.gradient[i]) *
                        255 >=
                    threshold &&
                d.smooth[i] <= maxlum
            ? 1
            : 0;
  auto d3 = average_zero(candidate, w, h, 1),
       d7 = average_zero(candidate, w, h, 3);
  if (text)
    d.zone = text_zone(d, w, h, local);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      int i = y * w + x;
      if (!candidate[i] || d3[i] < .22f || d7[i] < artifact ||
          (text && d.zone[i] >= .2f))
        continue;
      float nx = d.gx[i] / (d.gradient[i] + 1e-6f) * (w - 1) / w,
            ny = d.gy[i] / (d.gradient[i] + 1e-6f) * (h - 1) / h;
      ridge[i] = d.valley[i] >= bilinear(d.valley, w, h, x + nx, y + ny) &&
                         d.valley[i] >= bilinear(d.valley, w, h, x - nx, y - ny)
                     ? 1
                     : 0;
    }
  auto stroke =
           gaussian(ridge, w, h, param(e, "line_width", t, 1.1f, .1f, 5) * .5f),
       maximum = morph(stroke, w, h, 1, true);
  float hard = param(e, "edge_hardness", t, 8, 1, 20),
        minimum = sigmoid(-.4f * hard),
        strength = param(e, "strength", t, .85f, 0, 1.5f),
        peak = *std::max_element(d.blackhat.begin(), d.blackhat.end());
  Plane alpha(stroke.size()), weight(alpha.size());
  for (std::size_t i = 0; i < alpha.size(); ++i) {
    alpha[i] = clamp(
        (sigmoid(hard * (stroke[i] / (maximum[i] + 1e-6f) - .4f)) - minimum) /
        (1 - minimum) * strength *
        std::clamp(d.blackhat[i] / (peak + 1e-6f), .2f, 1.f));
    weight[i] = alpha[i] + 1e-4f;
  }
  auto denom = gaussian(weight, w, h, local);
  float gamma = 1 + param(e, "color_pull", t, .85f, 0, 1) * 1.5f;
  for (int c = 0; c < 3; ++c) {
    Plane weighted(alpha.size());
    for (std::size_t i = 0; i < alpha.size(); ++i)
      weighted[i] = original[c][i] * weight[i];
    weighted = gaussian(weighted, w, h, local);
    for (std::size_t i = 0; i < alpha.size(); ++i) {
      float ink = std::pow(
          std::clamp(weighted[i] / std::max(denom[i], 1e-6f), 1e-4f, 1.f),
          gamma);
      out[c][i] = out[c][i] * (1 - alpha[i]) + ink * alpha[i];
    }
  }
}
void restore_text(RGB &out, const RGB &original, int w, int h,
                  const EffectInstance &e, double t, bool full) {
  float local = param(e, "local_sigma", t, 3, .1f, 10);
  auto d = detect(original, w, h, param(e, "denoise_sigma", t, .8f, .1f, 5),
                  local, 7);
  auto zone = text_zone(d, w, h, local);
  auto lum = luma(original), bg = gaussian(lum, w, h, 2.5f);
  float threshold =
            param(e, full ? "text_threshold" : "threshold", t, .1f, 0, 1),
        boost = param(e, full ? "text_boost" : "boost", t, .2f, 0, 1);
  for (int c = 0; c < 3; ++c) {
    auto clean = gaussian(morph(morph(out[c], w, h, 3, false), w, h, 3, true),
                          w, h, local);
    for (std::size_t i = 0; i < lum.size(); ++i) {
      float a = sigmoid(30 * (std::max(0.f, lum[i] - bg[i]) - threshold));
      float restored =
          clamp(original[c][i] * (1 + boost)) * a + clean[i] * (1 - a);
      out[c][i] += zone[i] * (restored - out[c][i]);
    }
  }
}
void paper(RGB &out, int w, int h, const EffectInstance &e, double t,
           bool full) {
  float texture = param(e, full ? "paper_texture" : "texture", t, .05f, 0, .5f),
        warmth = param(e, full ? "paper_warmth" : "warmth", t, .08f, 0, .5f);
  if (texture == 0)
    return;
  Plane noise(out[0].size());
  std::uint32_t state = 0x6d2b79f5u;
  for (auto &v : noise) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    v = float(state & 65535) / 32767.5f - 1;
  }
  auto low = gaussian(noise, w, h, 6), high = gaussian(noise, w, h, 1.2f);
  auto normalize = [](Plane &p) {
    double mean = 0, var = 0;
    for (float x : p)
      mean += x;
    mean /= p.size();
    for (float x : p)
      var += (x - mean) * (x - mean);
    float sd = std::sqrt(var / std::max<std::size_t>(1, p.size() - 1)) + 1e-5f;
    for (auto &x : p)
      x = (x - float(mean)) / sd;
  };
  normalize(low);
  normalize(high);
  auto lum = luma(out);
  const float tint[3] = {1 + warmth * .5f, 1 + warmth * .1f, 1 - warmth * .4f};
  for (int c = 0; c < 3; ++c)
    for (std::size_t i = 0; i < noise.size(); ++i)
      out[c][i] *=
          1 +
          (((1 + (.65f * low[i] + .35f * high[i]) * texture) * tint[c]) - 1) *
              clamp(lum[i]);
}
void sharpen(RGB &out, int w, int h, float amount) {
  if (amount <= 0)
    return;
  for (auto &p : out) {
    auto blur = gaussian(p, w, h, 1.2f);
    for (std::size_t i = 0; i < p.size(); ++i)
      p[i] += amount * (p[i] - blur[i]);
  }
}
} // namespace
bool is_native_exact_effect_r41(const EffectInstance &e) {
  if (!e.enabled)
    return false;
  const std::string &id = e.definition_id;
  return id == "koralo.anime_restore_v45" ||
         id == "koralo.anime_line_restore" ||
         id == "koralo.anime_vector_color" ||
         id == "koralo.anime_text_restore" ||
         id == "koralo.anime_paper_texture" ||
         id == "koralo.anime_detail_sharpen" ||
         id == "koralo.anime_deinterlace" || id == "koralo.layer_mask" ||
         id == "koralo.paint_mask" || id == "koralo.curves";
}
bool apply_native_effect_r41(Frame &f, const EffectInstance &e, double t) {
  if (!is_native_exact_effect_r41(e))
    return false;
  int w = f.width, h = f.height;
  std::size_t n = std::size_t(std::max(0, w)) * std::max(0, h);
  if (!n || f.rgb.size() != n * 3)
    return true;
  const auto &id = e.definition_id;
  if (id == "koralo.layer_mask") {
    float cx = param(e, "center_x", t, .5f, 0, 1),
          cy = param(e, "center_y", t, .5f, 0, 1),
          sx = param(e, "width", t, .8f, .001f, 2),
          sy = param(e, "height", t, .8f, .001f, 2),
          feather = param(e, "feather", t, .02f, 0, .5f);
    bool ellipse = effect_numeric(e, "shape", t, 1) > .5,
         invert = effect_numeric(e, "invert", t, 0) > .5;
    if (f.alpha.size() != n)
      f.alpha.assign(n, 255);
    for (int y = 0; y < h; ++y)
      for (int x = 0; x < w; ++x) {
        float dx = std::abs((x + .5f) / w - cx),
              dy = std::abs((y + .5f) / h - cy),
              distance = ellipse
                             ? (1 - std::sqrt(std::pow(dx / (sx * .5f), 2) +
                                              std::pow(dy / (sy * .5f), 2))) *
                                   std::min(sx, sy) * .5f
                             : std::min(sx * .5f - dx, sy * .5f - dy);
        float a = feather > 0 ? clamp(distance / feather + .5f)
                              : (distance >= 0 ? 1 : 0);
        a = a * a * (3 - 2 * a);
        if (invert)
          a = 1 - a;
        f.alpha[y * w + x] = std::uint8_t(std::lround(f.alpha[y * w + x] * a));
      }
    return true;
  }
  // A compact vector stroke mask: each line is x0 y0 x1 y1 radius hardness
  // erase. Normalized coordinates survive project resolution and preview
  // quality changes.
  if (id == "koralo.paint_mask") {
    Plane mask(n, 1);
    const auto *state = effect_parameter(e, "strokes");
    const auto *text =
        state ? std::get_if<std::string>(&state->value) : nullptr;
    if (text) {
      std::istringstream stream(*text);
      float x0, y0, x1, y1, r, hard, erase;
      int segments = 0;
      while (segments++ < 4096 &&
             stream >> x0 >> y0 >> x1 >> y1 >> r >> hard >> erase) {
        if (!std::isfinite(x0) || !std::isfinite(y0) || !std::isfinite(x1) ||
            !std::isfinite(y1) || !std::isfinite(r) || r <= 0)
          continue;
        if (!std::isfinite(hard) || !std::isfinite(erase))
          continue;
        x0 = clamp(x0);
        y0 = clamp(y0);
        x1 = clamp(x1);
        y1 = clamp(y1);
        r = std::clamp(r, .001f, .5f);
        hard = clamp(hard);
        float ax = x0 * w, ay = y0 * h, bx = x1 * w, by = y1 * h,
              rad = r * std::min(w, h), vx = bx - ax, vy = by - ay,
              len = vx * vx + vy * vy;
        int left = std::clamp(int(std::min(ax, bx) - rad - 1), 0, w),
            right = std::clamp(int(std::max(ax, bx) + rad + 2), 0, w),
            top = std::clamp(int(std::min(ay, by) - rad - 1), 0, h),
            bottom = std::clamp(int(std::max(ay, by) + rad + 2), 0, h);
        for (int y = top; y < bottom; ++y)
          for (int x = left; x < right; ++x) {
            float u = len > 0
                          ? clamp(((x + .5f - ax) * vx + (y + .5f - ay) * vy) /
                                  len)
                          : 0,
                  dx = x + .5f - ax - u * vx, dy = y + .5f - ay - u * vy,
                  dist = std::sqrt(dx * dx + dy * dy) / rad,
                  a = hard >= .999f ? (dist <= 1 ? 1 : 0)
                                    : clamp((1 - dist) / (1 - hard));
            auto &value = mask[y * w + x];
            value = erase > .5f ? value * (1 - a) : value + (1 - value) * a;
          }
      }
    }
    if (f.alpha.size() != n)
      f.alpha.assign(n, 255);
    for (std::size_t i = 0; i < n; ++i)
      f.alpha[i] = std::uint8_t(std::lround(f.alpha[i] * mask[i]));
    return true;
  }
  RGB original;
  for (auto &p : original)
    p.resize(n);
  for (std::size_t i = 0; i < n; ++i)
    for (int c = 0; c < 3; ++c)
      original[c][i] = f.rgb[i * 3 + c] / 255.f;
  RGB out = original;
  bool full = id == "koralo.anime_restore_v45";
  if (full || id == "koralo.anime_vector_color")
    out = vector_color(original, w, h, e, t);
  if (full || id == "koralo.anime_line_restore")
    restore_lines(out, original, w, h, e, t,
                  full && effect_numeric(e, "restore_text", t, 0) > .5);
  if ((full && effect_numeric(e, "restore_text", t, 0) > .5) ||
      id == "koralo.anime_text_restore")
    restore_text(out, original, w, h, e, t, full);
  if (full || id == "koralo.anime_paper_texture")
    paper(out, w, h, e, t, full);
  if (full || id == "koralo.anime_detail_sharpen")
    sharpen(out, w, h,
            param(e, full ? "post_sharpen" : "amount", t, .5f, 0, 2));
  if (id == "koralo.anime_deinterlace") {
    float strength = param(e, "strength", t, 1, 0, 1);
    for (int c = 0; c < 3; ++c)
      for (int y = 1; y < h - 1; y += 2)
        for (int x = 0; x < w; ++x) {
          int i = y * w + x;
          out[c][i] +=
              (.5f * (original[c][i - w] + original[c][i + w]) - out[c][i]) *
              strength;
        }
  }
  if (id == "koralo.curves") {
    const char *keys[] = {"black", "shadows", "midtones", "highlights",
                          "white"};
    float points[5];
    for (int i = 0; i < 5; ++i)
      points[i] = param(e, keys[i], t, i * .25f, 0, 1);
    int channel = int(param(e, "channel", t, 0, 0, 3));
    for (int c = 0; c < 3; ++c)
      if (channel == 0 || channel == c + 1)
        for (auto &v : out[c]) {
          float x = clamp(v) * 4;
          int i = std::min(3, int(x));
          v = points[i] + (points[i + 1] - points[i]) * (x - i);
        }
  }
  for (std::size_t i = 0; i < n; ++i)
    for (int c = 0; c < 3; ++c)
      f.rgb[i * 3 + c] = std::uint8_t(clamp(out[c][i]) * 255.f);
  return true;
}
} // namespace koralo
