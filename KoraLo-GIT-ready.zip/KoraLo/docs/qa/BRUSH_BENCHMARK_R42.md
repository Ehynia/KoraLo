# Reproducing the brush mask measurement

Build KoraLo with CMake Release. From the source root:

```sh
g++ -std=c++20 -O3 -Isrc -Isrc/media -c docs/qa/native_effects_r41_benchmark.cpp -o build/mask-r41.o
g++ -std=c++20 -O3 -Isrc docs/qa/brush-benchmark-r42.cpp build/mask-r41.o build/libkoralo_core.a -pthread -ldl -o build/brush-benchmark
./build/brush-benchmark
```

The retained r41 source changes only the exported function name so the old and new implementations can run in one process. The benchmark uses 960×540, 1024 initial segments, 80 appended segments, a warmed r42 cache and alternating erase/restore history. It measures the mask stage, including applying alpha to a frame, and compares every alpha pixel. It does not measure video decoding, UI latency or GPU speed. The result depends on hardware and load; see brush-benchmark-r42.json for this environment.
