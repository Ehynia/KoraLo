# OpenCut architectural reference notes

OpenCut was used only as a high-level reference for separating editor-facing state from heavier media-engine responsibilities. KoraLo 0.5 no longer follows the earlier plan of keeping a Python shell around a future native engine: the active application itself is now C++20.

Useful general ideas retained:

- keep the project/timeline model independent from the presentation layer;
- isolate decode/cache/render services behind a media-engine API;
- keep UI interactions responsive while background media work is running;
- serialize project semantics rather than UI widget state.

KoraLo does not require OpenCut and does not copy its implementation.

Reference: https://github.com/opencut-app/opencut
