# VEGAS 17 clean-room public API / behavior notes

This note records only externally observable/public scripting concepts from the user-supplied VEGAS 17 research package. It is **not** a transcription or decompilation of the VEGAS implementation and no VEGAS implementation code is copied into KoraLo.

## Public scripting surface confirmed

The supplied scripting assembly metadata exposes names consistent with the documented VEGAS scripting model, including:

- `Project`
- `Media`
- `Take`
- `TrackEvent`
- `TrackEventGroup`
- `VideoEvent` / `AudioEvent`
- `VideoTrack` / `AudioTrack`
- `Transport`
- `Marker` / `Region`
- `Renderer` / `RenderTemplate`
- `VideoMotion`

The supplied Script Menu samples also exercise public concepts around event grouping and batch rendering. KoraLo uses these only to validate expected NLE-level concepts and command boundaries.

## KoraLo design consequences

The current `MediaItem` / `Clip` implementation should continue to evolve incrementally toward:

```text
Media -> Take -> TrackEvent -> Track -> Project
```

UI commands should remain above the model/transaction layer. For example, Cut/Copy/Paste, group, split, Insert, Overwrite, markers, transport and render-region commands should manipulate KoraLo-owned objects through `EditController`/future command services rather than calling FFmpeg directly.

Renderers/templates are a separate model from timeline events. Likewise, future `VideoMotion` and FX should not be encoded as ad-hoc timeline command strings.

## Clean-room boundary

Allowed research for KoraLo includes public API/type names, scripting object behavior, metadata/XML/plugin descriptors, layouts and observed behavior. Proprietary internal implementation code is not used as KoraLo source, and VEGAS binaries are not linked or required at runtime.

## Functional-command pass

The current UI command pass uses the public model observations only to validate command boundaries: transport is treated separately from project edits; event grouping is handled in the KoraLo edit layer; markers are project objects; renderer/template concepts remain separate from events; and future VideoMotion/FX remain separate from timeline trim/move semantics. No implementation from `ScriptPortal.Vegas.dll` or shipped scripts is linked, translated, or copied into KoraLo.
