# VEGAS FX clean-room observations — r9

This note records externally observable/public plugin metadata used to guide KoraLo's independent FX model. No VEGAS implementation code is copied into KoraLo.

## Evidence reviewed

VEGAS 17 research package resources under `OFX Video Plug-Ins/*/Contents/Resources/*.xml` expose OFX-facing metadata. The metadata shows parameter categories including Double, Boolean, Choice, RGBA, Group and PushButton/action controls. For example, the Filters bundle describes numeric offsets/zoom/rotation, choice parameters, a boolean auto-crop control, groups and an action button. The checkerboard/generator metadata also exposes RGBA controls and grouped numeric controls.

The Stabilize resource explicitly describes stabilization as a media-level effect rather than an event/track/output effect and exposes an Apply/analyze action plus numeric and boolean parameters. This supports keeping analysis jobs separate from ordinary per-frame parameter evaluation.

## KoraLo interpretation

KoraLo now models:

`EffectDefinition -> ParameterDefinition -> EffectInstance`

Parameter definitions can represent `double`, `integer`, `bool`, `choice`, `color/RGBA`, `vec2`, `string`, `group`, and `action`. Instances own parameter state; numeric parameters already support parameter-owned keyframes. Effect instances can live at Media FX, Event FX, Track FX and Video Output FX scopes.

The first independent built-ins are intentionally small and generic: Brightness/Contrast, Saturation and Gaussian Blur. They are KoraLo effects, not copies of VEGAS algorithms or presets.

## r9 execution status

Event FX are editable in the Video FX pane and affect preview/render. Track FX and Video Output FX participate in render; Media FX participate before event FX. The current media renderer translates the generic effect instances into FFmpeg filters as a temporary execution backend. The effect data model itself is independent of FFmpeg and is intended to feed the future compositor graph.

Stabilization/optical-flow style effects are not implemented yet. They remain scheduled for an `AnalysisJob` + cache subsystem.
