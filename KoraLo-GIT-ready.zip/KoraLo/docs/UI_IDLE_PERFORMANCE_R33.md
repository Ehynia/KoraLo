# r33 — UI idle / preview performance

Revision: `2026-10-02-ui-idle-performance-r33`

## Windows paint path

The Win32 backbuffer is now a persistent top-down 32-bit `DIBSection`. KoraLo's custom Canvas can blend opaque/transparent rectangles, rounded-corner coverage, lines, borders, icons and the generated Open Sans atlas directly into this memory instead of issuing thousands of tiny `AlphaBlend`/GDI calls per full repaint.

Preview images still use `StretchDIBits`; KoraLo synchronizes that GDI operation before continuing software overlays. The complete backbuffer is presented with one final `BitBlt`.

## Message loop

The main Windows loop now uses `MsgWaitForMultipleObjectsEx` with an 8 ms editor tick timeout instead of an unconditional `Sleep(8)`. If `tick()` invalidates the window for a hover/press animation or a new preview frame, the wait returns immediately and the paint is processed without an extra fixed delay.

## Empty timeline

Starting playback on a timeline with zero duration is rejected. The preview path also no longer invalidates the entire window every tick merely because there is no video frame. The empty preview is cleared only when its visual state actually changes.

These fixes target the reported case where even a completely empty project could feel like a 2–5 FPS interface.

## Preview presentation cache

Win32 now caches the already-scaled preview bitmap by source frame signature and destination size. Hover animations, menus and other UI-only repaints therefore reuse the same scaled preview with `BitBlt` instead of re-running HALFTONE `StretchDIBits` for an unchanged frame. A stronger sampled frame signature is used to avoid stale cache hits when frame buffers are recycled.
