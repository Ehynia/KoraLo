# Reference analysis: supplied VEGAS 13 package

This document records the reference observations that informed KoraLo 0.2. It intentionally contains architectural/behavioral notes rather than copied implementation code.

## Package shape

The supplied archive contains a full VEGAS 13-era program tree: the main executable, managed/public API assemblies, codec/FileIO plug-ins, video plug-ins, OFX plug-ins, audio plug-ins, sample scripts, workspace layouts, color-management resources and external-control components. The supplied archive inspected for this pass has SHA-256 `6422b9dacfc71d00ab63f034acab0f03c50fe2ceda7e8d51cd4fb358618035a9`; its ZIP directory lists 375 entries totaling 545,586,772 uncompressed bytes.

Workspace files such as `Audio Mixing.VegasWindowLayout`, `Color Correction.VegasWindowLayout` and `Default Expanded Edit Mode.VegasWindowLayout` further confirm task-oriented dock layouts. That package shape suggests a mature editor split into a project/edit model, media I/O layer, effect/plug-in hosts, render subsystem, scripting API, window-layout system, and hardware/control integrations. KoraLo mirrors those *responsibilities*, but not the implementation or binary interfaces.

## Public scripting model observed

Bundled sample scripts include `Batch Render.cs`, `Export EDL.js`, `Promote Media Markers.cs`, `Resize Generated Media.cs`, `Stereo to Mono.cs`, `Render Audio Tracks.cs` and caption/chapter exporters. They demonstrate a public editing vocabulary that includes:

- projects, tracks, video/audio events and takes;
- linked/grouped events;
- markers and regions;
- generated media;
- renderers, render templates and render ranges such as project/selection/regions;
- event/media property manipulation.

KoraLo 0.2 therefore promotes these concepts to first-class data rather than treating the timeline as only painted rectangles.

## User-facing editing concepts observed

Readable resource/string metadata and the screenshots expose mature NLE behavior around:

- split, move, trim, ripple modes, slip/slide-style operations and event grouping;
- overlapping events and automatic crossfades;
- event fades, speed/time stretch, reverse and channel modes;
- event/track effects, envelopes and keyframes;
- markers, regions, media markers and takes;
- per-track compositing, mute/solo, audio level/pan and buses;
- proxy/prerender workflows, render-to-new-track and multiple output templates;
- VST/audio plug-ins, OFX/video plug-ins, color correction and generated media.

## Effect / generator / transition inventory

Resource metadata exposes broad families such as color correction, levels/curves, blur/sharpen, chroma key, masking, stylization, geometry/distortion and utility effects. Generated-media families include solid color, gradients, checkerboards/noise, test patterns and text. Transition families include dissolves, wipes, iris, slides/pushes, blinds, squeezes/zooms and 3D-style transitions.

KoraLo uses independent IDs such as `koralo.video.*` and `koralo.generator.*`. Implemented nodes are translated to FFmpeg filter graphs today; unimplemented nodes are still serializable so projects do not need a schema change when the GPU renderer gains them.

## KoraLo mapping

The 0.2 architecture created from this analysis contains:

- a serializable project/edit model with tracks, events, takes, groups, markers, regions, envelopes and keyframes;
- event transforms, fades, playback rate/reverse/loop/channel properties;
- event and track effect chains;
- generated-media objects;
- ripple modes, snapping and automatic overlap crossfades;
- a compositor/render graph with event/track video FX and audio FX;
- multiple render presets and an audio-only master;
- a classic docked Project Media / FX / Generators / Preview / Timeline desktop workflow.

## Explicit non-goals of this reference pass

The reference package is **not** a runtime dependency. KoraLo does not attempt to load VEGAS project files, binary plug-ins, internal DLL interfaces or proprietary codecs. Future OFX/VST support, if implemented, should target public third-party standards through KoraLo-owned host code.

## Additional 0.4 references

KoraLo 0.4 also used two public references supplied by the user:

1. **OpenCut** (`opencut-app/opencut`, MIT) as an architecture/performance reference. The current project is moving toward a shared Rust core used by multiple frontends, while the archived classic repository explicitly separated UI shells from platform-agnostic compositor/effects/GPU/WASM crates. KoraLo adopted the same separation principle by introducing a UI-agnostic `MediaEngine` service for expensive media work. No OpenCut source is a runtime dependency in this release.
2. **SkyPro's VEGAS workflow guide** as a user-workflow checklist. The guide highlights project/preview tuning, autosave, media organization, split/delete, ripple/slip/slide editing, track grouping, keyframes, effects/transitions and render workflow. KoraLo 0.4 maps several of those behaviors into the product: Preview (Half), 5-minute autosave, Source Trimmer, Insert/Overwrite, ripple delete, slip/slide/roll/stretch, grouping, loop selection and proxy/caching tools.

These public materials supplement rather than replace the supplied VEGAS package analysis. The proprietary reference remains behavior-only; the OpenCut reference is MIT-licensed and used at the architectural level.
