# KoraLo Native 0.5 build validation

Current source revision: `2026-10-02-render-stress-fix-r37`.

Validation environment: Linux, GNU C++ 14.2, CMake, X11 development libraries, FFmpeg/ffprobe available.

## r37 four-minute render stress validation

- Built a real 240-second project from the supplied Sv_intro75 media with 12 video-effect sections, Chroma Key overlays, generated text and an Audio FX chain.
- Final CPU render at 640x360/24 fps completed in 55.52 s (about 4.32x realtime).
- Output contains exactly 5760 video frames and passes a full FFmpeg `-xerror` decode.
- Fixed render duration drift caused by echo/reverb tails; output is now clamped to the project duration.
- Fixed output audio sample rate so render follows `ProjectSettings::sample_rate` instead of inheriting a source file's rate.
- See `docs/RENDER_STRESS_R37.md` for the reproducible project composition and measurements.

## r32 revision/package synchronization

- `BUILD_REVISION.txt` is now the single source of truth for the source/package revision.
- CMake reads the revision directly from `BUILD_REVISION.txt` instead of carrying its own hard-coded revision.
- `install_and_run_windows.ps1` also reads that same file and validates that CMake is wired to it; it no longer has a second hard-coded expected revision that can drift on the next release.
- The installer still removes `build/` before configure and keeps the MSVC `<array>` sanity check, so stale build artifacts cannot hide source changes.


## r30 Windows package guard

- `install_and_run_windows.ps1` now verifies the exact source revision before building.
- The installer sanity-checks that the MSVC `<array>` portability fix is present in `src/media/media_engine.cpp`.
- Any existing `build/` directory is removed before CMake configure so stale objects/CMake cache cannot mask the source actually being tested.
- This guard is specifically intended to make accidental execution of an older extracted r27/r28 tree obvious.

## r26 validation

- Fresh Linux Release configure/build succeeded with source revision `2026-10-02-user-open-sans-atlas-r26`.
- `koralo_native_tests` passed.
- `koralo_media_tests` passed.
- X11 GUI smoke under Xvfb completed and rendered the regenerated Open Sans atlas.
- The downloadable archive contains the generated C++ raster atlas only; no TTF/OTF font files are present.

## Validated in this update

- CMake configure: successful.
- Native C++20 Release build: successful.
- `koralo_native_tests`: passed, including project save/load through a filename containing spaces and UTF-8 Cyrillic.
- `koralo_media_tests`: passed.
  - generates a real H.264/AAC test asset with FFmpeg;
  - probes it with the media engine;
  - decodes a real preview frame;
  - builds and executes a real KoraLo render;
  - now runs the media pipeline from a temp directory containing spaces and UTF-8 non-ASCII characters;
  - exercises render-time track/event opacity, audio gain/pan and overlap crossfade controls.
- Linux GUI smoke test: direct `DISPLAY=:0` was not accessible from the build sandbox; under `xvfb-run` the X11 executable started and remained running for the smoke-test interval with no startup error.
- X11 `zenity`/`kdialog` file/message actions now use the native argv process layer rather than shell command strings.
- Win32 paint path now uses a persistent compatible back buffer and presents the completed frame with one `BitBlt`; this specifically addresses whole-window flicker/half-painted frames while dragging controls.
- Win32 source portability fix: the back-buffer client-size calculation now explicitly converts `RECT`/`LONG` dimensions to `int`, resolving the MSVC template-deduction error reported at `win32_main.cpp:98`.
- The previous MSVC `C4458` warning in `Project::add_track` is removed by renaming the parameter that shadowed `Project::name`.
- Win32 startup branding is compiled into the executable through a native `.rc`: supplied splash artwork as a bitmap resource and supplied square badge as a multi-resolution `.ico`.

## Native UI reference + functional-control pass included

- workspace palette/layout updated from the supplied interface mockup;
- top command buttons wired to project/undo/clipboard/import/proxy/render/help actions;
- Project Media Grid/List, search and type filters;
- Video Preview quality/Fit controls and transport;
- Trimmer source In/Out plus initial transactional Insert/Overwrite;
- timeline Select/Split/Lock/Snap/Ripple/Add Track commands;
- undoable track Lock/Mute/Solo and level/pan/opacity controls;
- basic Video FX opacity and Auto Crossfade controls connected to final-render behavior;
- supplied Font Awesome SVG assets are staged under `assets/icons/fontawesome` with their license; a generated 16x16 native C++ bitmap atlas (`src/ui/icon_atlas.hpp`) now drives toolbar, Project Media, Preview transport and timeline-tool icons without an SVG/WebView runtime dependency;
- track level/pan controls now use preview-only drag state and commit one undoable project change on mouse-up.

The HTML mockup itself is not embedded or executed. The application remains a native C++20 Win32/GDI + X11 program.

## Timeline interaction hardening included

- dedicated `SelectionModel`;
- group-aware click selection;
- marquee and additive multi-select;
- transactional multi/group move;
- group-aware left/right trim and slip;
- Roll;
- Slide;
- Ripple Trim;
- transactional same-kind track reorder;
- undo/redo coverage including advanced edit modes and track order.

All edit drags above keep `Project` unchanged during preview and commit the completed gesture once on mouse-up.

## Runtime architecture

KoraLo remains a native C++20 application. No Python runtime, Python UI, or Python editing engine was added. FFmpeg/ffprobe remain external media backends.

## Windows status

A user-run Windows/MSVC 17.14 build of the previous package successfully configured and produced `KoraLo.exe`, `koralo_native_tests.exe`, and `koralo_media_tests.exe`; `koralo_native_tests` passed. After the Unicode-safe process-launch fix, the next user run reached FFmpeg/ffprobe successfully but `koralo_media_tests` still failed in metadata recognition with `No supported audio/video stream`.

This package keeps the native argv process layer (`CreateProcessW` on Windows, `fork`/`exec` on Linux) and also replaces the `std::regex` parser for ffprobe's flat output with a delimiter-based compact parser. If a Windows ffprobe build still produces a different compact representation, KoraLo falls back to selected-stream `key=value` probes for video/audio metadata. KoraLo paths remain UTF-8 internally and are converted to native filesystem paths at the platform boundary. Binary discovery, project save/load, proxy path handling and the media regression tests cover spaces plus UTF-8 non-ASCII path components.

The latest user-run MSVC attempt reached the Win32 frontend but failed at compile time because `RECT::right/bottom` are `LONG` while the new back-buffer code called `std::max(1, LONG)`. This package fixes that exact source line with explicit integer conversion, also removes the reported `C4458` shadowing warning, and adds the native splash/icon resource file.

The new package was **not compiled or smoke-tested by this validation environment on an actual Windows host**. The current Linux validation proves the shared C++ core remains healthy, while the corrected Win32 source and resource compilation still require the next user-run MSVC build before Windows validation is claimed.

## Known next engineering work

Sequential timeline playback now uses a persistent FFmpeg decoder session instead of starting a new process for every displayed frame. Random-access scrubbing, Pan/Crop/FX-heavy preview requests and thumbnail extraction still use the exact-frame path. Remaining media work is a generalized seek queue/prefetch layer, a native realtime audio mixer, audio-master-clock A/V sync, scrub audio, and a compositor path that can keep dynamic FX/Pan-Crop on a persistent stream.

## Source revision 2026-10-01-win32-splash-r3

- Win32 `RECT` dimensions no longer use mixed-type `std::max`; dimensions are explicitly converted to `int` and clamped.
- CMake prints `KoraLo source revision: 2026-10-01-win32-splash-r3` during configure so stale source folders are obvious.
- Native splash and application icon resources remain included.
- Linux Release build and both native test targets passed in this environment.
- Windows/MSVC still requires confirmation on a real Windows host.

### Win32 splash portability fix (r3)
The splash window procedure now names and forwards `WPARAM`/`LPARAM`, and splash centering no longer calls `std::max` with mixed `int`/`LONG` operands.

## Source revision 2026-10-01-audio-ui-r4

Linux validation for r4:

- clean CMake Release configure/build: passed;
- `koralo_native_tests`: passed;
- `koralo_media_tests`: passed with real H.264/AAC probe/preview/render pipeline;
- realtime audio code is compiled on Linux and uses the new shell-free detached process handle; no audio device is required by the automated tests;
- Win32 GDI now requests Open Sans and keeps the r3 back-buffer/splash fixes;
- native File/Edit/View/Insert/Tools/Options/Help menus and Project Properties/Preferences overlays compile in the shared C++ UI layer.

This exact r4 revision has not been compiled on an actual Windows host in this environment. Do not treat the Windows path as validated until the next user-run MSVC build/test log confirms it.


## Source revision 2026-10-01-vegas-edit-semantics-r6

- canonical Media/Take/TrackEvent core and project format v6;
- backward reading of KoraLo v5 projects;
- group-aware split with new right-side linked group;
- Ignore Event Grouping, Slip All Takes, Event Loop, active-take cycling;
- Quantize to Frames and snap-offset-aware move;
- Trim Start/End to Cursor;
- group-aware vertical track movement;
- two-sided automatic overlap fades in final render;
- expanded native regression suite for all above semantics.

Windows/MSVC for this exact r6 revision has not been executed in this Linux validation environment and is not claimed as verified.

### r6 validation in this environment

- clean Release configure/build from an empty build directory: passed;
- compiler warnings in the clean GNU build: none;
- `koralo_native_tests`: passed;
- `koralo_media_tests`: passed with the real FFmpeg H.264/AAC fixture pipeline;
- X11 startup/import/preview smoke under Xvfb: passed;
- fresh screenshot captured from the running r6 binary: `KoraLo_current_r6.png` (delivered alongside the package, not embedded in runtime).

## Source revision 2026-10-01-event-pancrop-r7

- project format v7 adds parameter-owned event motion keyframes;
- native Video Event Pan/Crop editor is implemented in the shared Canvas UI layer;
- Pan/Crop drag is preview-only until mouse-up and commits one undo command;
- event split preserves motion continuity and shifts right-side keyframes to local time zero;
- async preview decode applies the current event motion sample;
- final FFmpeg render graph animates Center X/Y, Zoom and Rotation from keyframes;
- core tests cover interpolation, implicit baseline keys, split continuity, undo/redo and v7 save/load;
- media tests execute a real animated Pan/Crop FFmpeg render graph.

Windows/MSVC for this exact r7 revision has not been executed in this Linux validation environment and is not claimed as verified.

## 2026-10-01 r8 validation
Source revision: `2026-10-01-audio-meter-veg-import-r8`.

Linux validation after the r8 changes includes a clean Release build, native core tests, media tests with a real H.264/AAC fixture, asynchronous real-audio meter regression, and X11 smoke. The supplied `Untitled.veg` was also inspected with the new clean-room parser and yielded 1920x1080 / ~29.97 fps / 48000 Hz plus one MP3 media reference.

Windows/MSVC is **not** claimed validated for r8 in this environment.

## Source revision 2026-10-01-gpu-thumbnails-fx-r9

This revision adds phase-1 GPU assist, asynchronous event filmstrip thumbnails and the first generic native FX model. The GPU path intentionally treats hardware support as opportunistic: FFmpeg capability discovery enables an attempted hardware decode/encode path, and every operation retains a CPU fallback. This revision does **not** claim a finished native GPU compositor.

Project format v8 serializes Media/Event/Track/Video Output effect chains and numeric parameter keyframes. Native tests cover effect interpolation, undo/redo and v8 roundtrip; media tests cover real asynchronous timeline thumbnail decode and a real FFmpeg render using Event/Track/Output effects.

Windows/MSVC for this exact r9 revision is not executed by this Linux validation environment and must not be described as verified until a user-run Windows log confirms it.

## Source revision 2026-10-01-veg-timing-vfx-r10

Linux validation for r10 includes a clean Release build, native core tests, media tests with real H.264/AAC probe/thumbnail/meter/render paths, direct inspection of the supplied `Untitled.veg`, and X11 GUI smoke/screenshots.

New native regressions cover scroll-aware timeline track hit-testing and a synthetic VEGAS Wave64 track/event hierarchy with validated TrackEvent start/length and Take offsets. The supplied `Untitled.veg` is also inspected during development and currently yields two ordered events: 0.0/49.5161333/offset 0.0 and 50.2168333/40.8918667/offset 49.5161333 seconds.

Windows/MSVC for this exact r10 revision has not been executed in this Linux environment and is not claimed as verified.


## r11 (2026-10-01-timeline-render-optimization-r11)

Linux Release build and native/media tests are required before packaging. Windows/MSVC is not claimed unless verified on Windows.

## Source revision 2026-10-01-preview-cache-r12

Linux validation in this environment:

- clean CMake Release configure/build: passed;
- compiler warnings after the final clean build: none expected/accepted before packaging;
- `koralo_native_tests`: passed;
- `koralo_media_tests`: passed, including a real 46-second H.264 long-form preparation regression that requires creation of the optimized preview cache;
- X11 GUI smoke: passed;
- fresh screenshot captured from the running r12 Preferences panel with the new Preview quality/FPS/cache controls.

The Windows r12 path adds GDI AlphaBlend modal dimming and splash progress/check rendering. This exact revision has not been compiled on an actual Windows host in this environment, so MSVC/Win32 validation is not claimed until a user-run build log confirms it.

## Source revision 2026-10-01-msvc-dispatch-r13

Triggered by an actual Visual Studio 2022 r12 build log. MSVC stopped in `editor_app.cpp` with C1061 because the single giant `dispatch_button` `else-if` chain exceeded its compiler nesting limit. r13 splits that dispatcher into five small handlers and removes the C4458/C4456 shadow warnings from `Project::add_take` and effect value formatting.

Linux validation in this environment: clean Release build passed; `koralo_native_tests` passed; `koralo_media_tests` passed. A second build with `-Wshadow` also passed without warnings. The exact Windows/MSVC r13 build is not claimed verified until a Windows log confirms it.


## Revision 2026-10-01-locales-context-r14
- Added `src/ui/localization.*` and external `locales/` packs copied next to the executable.
- Added functional Canvas right-click menus on Win32/X11.
- Added runtime localization regression test.
- Linux Release build/tests/smoke verified in this environment; Windows/MSVC must be confirmed on Windows.


## Source revision 2026-10-01-fade-stream-preview-r15

Linux validation for r15:

- Release build: passed after the final fade-handle hit-priority fix;
- `koralo_native_tests`: passed, including transactional Fade In/Fade Out preview/commit/undo and linked-group preservation;
- `koralo_media_tests`: passed, including persistent sequential preview-stream reuse, preview opacity, fade-aware audio metering and real FFmpeg render coverage;
- the sequential preview regression consumed multiple adjacent frames from one persistent FFmpeg stdout pipe rather than one process per frame;
- X11 GUI smoke under Xvfb: passed with a real H.264/AAC project;
- a real mouse drag was injected against the running X11 application: the top-right Event corner produced a live Fade Out diagonal and a drop-frame `Fade out offset 00:00:02;23` tooltip, then committed on mouse-up;
- Event FX / Pan-Crop compact buttons no longer steal the top-corner fade handle; the corner drag gets priority within the fade-handle hit radius;
- video preview/final render and realtime audio preview/master meter apply event fade envelopes.

The supplied VEGAS 17 and OpenColorIO backup archives are research/reference material only. No proprietary VEGAS implementation or archive contents were copied into KoraLo. OpenColorIO was not integrated as part of this r15 task.

This exact r15 revision has **not** been compiled or smoke-tested on a Windows host in this environment. Windows/MSVC validation is not claimed.

## Source revision 2026-10-02-timeline-viewport-clip-r16

Linux validation for r16:

- clean CMake Release configure/build: passed with `-Wall -Wextra -Wpedantic -Wshadow`;
- `koralo_native_tests`: passed, including the new horizontal-scroll/header hit-isolation regression;
- `koralo_media_tests`: passed;
- X11 GUI smoke under Xvfb: passed with a 100-second Event and the timeline panned to approximately 00:30;
- visual verification confirms the Event is clipped at the timeline content boundary while Video/Audio track headers remain fully visible;
- long audio waveform drawing now iterates only the visible sample columns rather than the off-screen Event span.

This exact r16 revision has not been compiled or smoke-tested on a Windows host in this environment. Windows/MSVC validation is not claimed.


## Source revision 2026-10-02-hidpi-photo-preview-cache-r17

Linux validation for r17:

- final clean CMake Release configure/build: passed with the project's warning flags;
- `koralo_native_tests`: passed, including linked A/V detach/Undo and still-event extension;
- `koralo_media_tests`: passed, including still-image probe/preview/render, dynamic FX sequential playback reuse and stationary FX source-frame-cache reuse;
- adaptive logical HiDPI drawing/input path exercised under a 2560x1440 Xvfb desktop;
- X11 GUI smoke: passed using the clean-build executable and a real video/audio project;
- prepared media now uses seek-oriented all-I H.264 from >=20 seconds and timeline thumbnails resolve the prepared cache when available.

Preview notes: KoraLo's CPU realtime transform/effect implementation is deliberately lightweight for responsiveness and can approximate the authoritative final FFmpeg render for blur/chroma/transform sampling. Random uncached source seeks can still launch one exact FFmpeg decode; repeated FX changes at that source/time reuse the cached raw frame.

The supplied VEGAS 17/OpenColorIO backup archives remain research/reference material only and are not included in or copied into this implementation. This exact r17 revision is not claimed as Windows/MSVC-validated in this Linux environment.


## Source revision 2026-10-02-fx-editor-project-preview-r18

Linux validation for r18:

- Release build passed with the project warning flags;
- `koralo_native_tests`: passed, including `.kora` round-trip coverage for project preview quality/FPS/cache policy;
- `koralo_media_tests`: passed;
- X11 GUI smoke under Xvfb passed with a real H.264/AAC project and Event Color Corrector;
- the Video Event FX dialog was opened from the real event context menu; its live preview rendered the event effect chain;
- a real mouse drag was injected into the Brightness slider: the temporary preview changed while the Project remained transaction-backed, and mouse-up committed the new value;
- fresh screenshots were captured from the running r18 build.

This exact r18 revision has not been compiled or smoke-tested on a Windows/MSVC host in this environment, so Windows validation is not claimed.

## Source revision 2026-10-02-open-sans-svintro-r19

r19 switches the Linux/X11 normal UI text path from legacy core bitmap fonts to a generated Open Sans raster atlas while keeping the Win32 GDI `Open Sans` request. The archive does not contain Open Sans TTF/OTF files.

The supplied `Sv_intro75` archive is now an explicit clean-room compatibility fixture. The VEGAS reader recognizes its VEGAS Pro 12 settings layout, relinks the five referenced media files beside the project, accepts WMV/ASF references, preserves all eight track slots and the four validated Event timing/Take-offset records, retains the Legacy Text generated event as a placeholder, imports supported Event FX identities as disabled opaque nodes, and preserves observed audio-track FX identity references in `.kora` v11.

Legacy Text rendering, exact VEGAS FX parameter decoding/DSP, and still-unvalidated private fades/groups/envelopes are intentionally not claimed as implemented.

Linux validation for r19:

- clean CMake Release configure/build (`build_r19`): passed with the project warning flags and no compiler warnings in the final clean build;
- `koralo_native_tests`: passed, including VEGAS 12 settings/WMV inspection, Event FX identity recovery and imported audio-FX `.kora` round-trip coverage;
- `koralo_media_tests`: passed;
- clean-build X11 GUI smoke under Xvfb: passed by opening the actual supplied `OPEN TO EDIT! by V2GX.veg` directly;
- runtime import report recovered 5 media references, all 5 relinked online beside the `.veg`, 8 tracks, 4 TrackEvents, one Legacy Text placeholder, 3 unique Event FX identities and 3 observed audio-track FX identities;
- fresh screenshot captured from the clean r19 executable with the supplied project open.

This exact r19 revision has not been compiled or smoke-tested on a Windows/MSVC host in this environment, so Windows validation is not claimed.


## Source revision 2026-10-02-titles-text-autosave-ui-r20

r20 adds native generated Titles & Text, `.kora` v12 text persistence, preview/render integration, 30-second recovery autosave, a Save/Discard/Cancel dirty-close flow, direct text positioning, and another native dark-interface pass. Open Sans remains the requested/rasterized UI and generated-text face; font files are not redistributed.

Linux validation for r20:

- clean CMake Release configure/build (`build_r20_final`): passed with `-Wall -Wextra -Wpedantic -Wshadow` and no compiler warnings;
- `koralo_native_tests`: passed, including generated-text project roundtrip;
- `koralo_media_tests`: passed, including source-less generated-text preview and final MP4 render;
- X11 GUI smoke on a 1920x1080 virtual display: Insert -> Text opened the live native Titles & Text editor and rendered `Sample Text`;
- recovery smoke: a dirty Untitled project produced `autosave/Untitled.autosave.kora`; a scripted native-dialog Discard path closed the app and removed that recovery copy.

This exact r20 revision has not been compiled or smoke-tested on a Windows/MSVC host in this environment, so Windows validation is not claimed.


## Source revision 2026-10-02-gnome-modern-ui-r21

Linux validation for r21: clean Release configure/build passed; `koralo_native_tests` and `koralo_media_tests` passed; X11 GUI smoke under Xvfb passed with a real H.264/AAC clip; a fresh screenshot was captured from the running binary. The UI pass changes only shared native drawing/layout styling: GNOME-inspired rounded surfaces, neutral dark palette, header/tool buttons, panel cards, Preview, Timeline, menus and dialogs. No GTK/WebView runtime was added. Windows/MSVC for this exact r21 revision has not been executed in this environment and is not claimed as verified.

## Source revision 2026-10-02-anime-restore-fx-r22

r22 adds six native Anime Restore filters derived from the user-provided `1.py` parameter groups without embedding Python, PyTorch, Gradio, OpenCV or rembg into KoraLo. The pack is exposed through the existing native Video FX browser/editor and participates in Event/Track/Output effect chains, `.kora` persistence, undo and preview caching.

Linux validation for r22: clean Release configure/build passed; `koralo_native_tests` passed with Anime Restore catalog/instance regression coverage; `koralo_media_tests` passed with a combined six-filter in-process preview plus a real FFmpeg final render containing the six-filter chain. This exact r22 revision has not been built on a Windows/MSVC host in this environment, so Windows validation is not claimed.


## Source revision 2026-10-02-still-image-anime-validation-r23

r23 fixes a real FFmpeg 7.x compatibility issue found while validating the Anime Restore pack on the supplied 1125x631 JPEG: exact-frame still preview could return no frame because the random-access decoder always supplied `-ss 0` before a one-frame image input. Still images now bypass source seeking and use single-image `-update 1` output. A new media regression covers odd-size JPEG random-access preview with Anime Line Restore enabled.


## Source revision 2026-10-02-realtime-fx-ofx-foundation-r24

- Realtime FX preview now fuses consecutive pixel-only color operations into one memory pass instead of rescanning the whole frame for every simple effect.
- Blur work buffers and common sharpen/vector-color scratch frames are reused across preview frames to reduce allocator churn during playback and slider drags.
- Playback uses adaptive realtime resolution for heavy FX chains (up to 640x360, or 480x270 for very heavy chains) while pause/stop immediately restores the project's selected preview quality.
- Preview worker drops completed stale frames when a newer request already exists, reducing visible lag during fast scrubbing and effect editing.
- Added an experimental native OpenFX discovery layer. It follows OFX_PLUGIN_PATH plus standard Windows/Linux OFX locations, loads OFX binaries only far enough to enumerate exported plug-in identities, and marks Boris FX / GenArts / Sapphire / Continuum-style identifiers.
- Video FX shows OFX/Boris discovery counts. Tools -> Rescan OpenFX / Boris FX refreshes the registry.
- Third-party OFX pixel rendering is intentionally gated in r24: detected OFX effects cannot yet be inserted into the render graph until the Image Effect, Property, Parameter, Memory and related host suites are implemented and validated.
- Added a synthetic OFX module regression fixture that validates native bundle scanning and Boris-style plug-in identification without shipping any Boris FX code or binaries.
- Clean Linux Release build: passed with no compiler warnings. Native and media tests: passed. X11 GUI smoke: passed.
- Windows/MSVC for this exact r24 revision was not run in this environment.

## Source revision 2026-10-02-free-editing-fx-r25

r25 adds nine clean-room native editing effects researched from public free/open filter catalogs: Glow, Hue Shift, Levels, Vignette, Pixelate/Mosaic, Lens Distortion, RGB Split, Letterbox and Scanlines. Realtime implementations are native C++; Hue Shift and Levels reuse the fused pixel-operation path. Final render uses FFmpeg filter equivalents/approximations. Regression tests cover catalog construction, native preview pixel changes and a combined final MP4 render. No frei0r or Kdenlive GPL implementation code is copied or linked.

## Source revision 2026-10-02-audio-recording-fx-r27

r27 adds native in-application audio recording and a first-class Audio FX layer. Recording is launched from the timeline `REC` control or Insert -> Record Audio. KoraLo captures the OS default input through FFmpeg without a shell (DirectShow on Windows; PulseAudio with ALSA fallback on Linux), writes headerless PCM during capture, then wraps the data into a standard PCM WAV in KoraLo itself before inserting the recording into Project Media and the target audio track. This keeps abrupt recorder termination from leaving a half-written WAV header.

Native Event/Track Audio FX now include Echo/Delay, Room Reverb, Chorus, Flanger, Compressor, Limiter, Noise Gate, 3-band EQ, High Pass, Low Pass, Distortion, Tremolo, Stereo Width and Gain. The same serialized chains are applied to realtime ffplay preview and the final FFmpeg render graph. VEGAS-imported Noise Gate, Track EQ and Track Compressor identities can be mapped to disabled native nodes while unknown original private parameters stay unguessed.

Linux validation for r27:

- clean Release rebuild (`build_r27`): passed with the project warning flags and no compiler warnings in the final rebuild;
- `koralo_native_tests`: passed, including Event/Track Audio FX `.kora` v13 round-trip/Undo coverage;
- `koralo_media_tests`: passed, including a real render through the 14-effect audio chain plus native raw-PCM -> WAV finalization/probe regression;
- X11 GUI smoke: Audio FX browser and recording controls were exercised visually in the final build;
- physical microphone capture could not be end-to-end validated in the headless CI/Xvfb environment, so capture-device success is not claimed here;
- Windows/MSVC for this exact r27 revision was not built in this environment and is not claimed as verified.


## Source revision 2026-10-02-windows-msvc-build-fix-r28

Windows/MSVC build fix after a user-reported Visual Studio 17 2022 failure:

- `src/media/media_engine.cpp` now explicitly includes `<array>` before using `std::array<char, 65536>` in the PCM-to-WAV finalizer. This also resolves the cascading MSVC `std::min<uint64_t>` diagnostic on the same line.
- Windows macro definitions in `src/plugins/ofx_host.cpp` are guarded to avoid C4005 redefinition warnings when CMake already supplies `NOMINMAX` / `WIN32_LEAN_AND_MEAN`.
- Windows environment reads in the OFX host and localization layer use `_dupenv_s`, avoiding MSVC C4996 warnings for `getenv`.
- Linux Release build and native/media tests remain green. A physical MSVC build is still required to claim Windows verification.

## Source revision 2026-10-02-windows-native-tests-fix-r29

The user-run Visual Studio 2022 build of r28 successfully produced `KoraLo.exe`, `koralo_native_tests.exe`, and `koralo_media_tests.exe`; the media suite passed, while `koralo_native_tests` terminated with Windows fast-fail `0xc0000409`. The failure path was in the synthetic OFX discovery regression rather than the editor executable itself.

r29 fixes three concrete Windows test issues:

- Visual Studio multi-config output previously placed the synthetic `.ofx` module under `Contents/Win64/Release/`, while the test scanner intentionally accepts the standard OpenFX bundle layout `Contents/Win64/<plugin>.ofx`. CMake now overrides the per-configuration output directories so Debug/Release do not add that extra nesting.
- The native OFX regression previously used the normal production `scan()`, which also walks system OFX directories. On a machine with real third-party OFX plug-ins installed this made a unit test depend on external plug-ins and could execute third-party DLL initializers. The regression now scans only its synthetic test bundle through `scan_paths()`.
- The test embedded an absolute build path in a narrow compile-time string. It now uses the relative `ofx_test` path with an explicit CTest working directory, avoiding code-page issues when the Windows user profile contains non-ASCII characters.

The native test main now catches assertion exceptions and prints the failing reason instead of allowing an uncaught `std::runtime_error` to become an opaque MSVC fast-fail. The `std::fill` call reported as `C4244` by MSVC now uses an explicit `std::uint8_t{0}` value.

Fresh Linux Release validation for r29: `koralo_native_tests` passed and `koralo_media_tests` passed. The exact r29 Windows/MSVC build still requires the next user-run Visual Studio build before Windows validation is claimed.

## 2026-10-02-smooth-ui-render-r31

- Anti-aliased icon coverage atlas replaces the former 1-bit icon renderer.
- Rounded corners use fractional edge coverage.
- Native hover/press easing added with a 60 Hz-on-demand animation scheduler.
- Win32 caches brushes/pens/fonts/AlphaBlend tiles and repeated Frame->BGRX conversions.
- Unused Win32 timer removed.
- X11 now presents through a Pixmap backbuffer and uses XRender alpha where available.
- Linux Release build + native/media tests passed.


## r33 UI idle/performance pass

- Windows backbuffer is now a persistent top-down 32-bit DIBSection with direct software compositing for KoraLo UI rectangles, rounded-corner alpha coverage, lines, borders, icons and the generated Open Sans atlas. This removes thousands of tiny GDI/AlphaBlend calls from a full UI repaint.
- The Windows message loop uses `MsgWaitForMultipleObjectsEx` instead of an unconditional sleep, so an animation/preview invalidation can be painted immediately while idle still sleeps efficiently.
- Empty timelines no longer enter a pointless playback/redraw loop; an empty/no-video preview is cleared only when its visual state actually changes.
- Preview/video `StretchDIBits` remains native and is synchronized before software overlays continue.
- Goal: smooth 60 Hz hover/press animation without a permanent repaint loop, and low CPU while completely idle.

## r34 — fractional DPI scaling fix

- Fixed fractional-scale seams in icons/rounded UI by mapping logical rectangle edges instead of rounding origins and sizes separately.
- Win32 now uses actual per-monitor DPI for UI scale rather than treating a maximized 2K/4K window as a reason to scale the UI.
- `WM_DPICHANGED` updates UI scale live.
## r35 Windows DPI/link fix

- Added the missing `EditorApp::set_ui_scale(double)` definition that caused MSVC `LNK2019` in r34.
- Explicit Win32 per-monitor DPI is now preserved across paints instead of being overwritten by resolution-based scaling.
- `WM_DPICHANGED` and initial `GetDpiForWindow` scale now share the same clamped UI-scale path.


## r36 — VEGAS Chroma / compatibility research

- Fixes the Windows-only `event audio FX roundtrip` test UB by keeping stable IDs across snapshot Undo.
- Adds real alpha Chroma Key preview/compositing plus final-render coverage.
- Converts validated old Svfx Chroma Key named values from imported `.veg` projects.
- Documents the observed VEGAS Bézier Masking OFX control schema and the remaining unknown curve-state fields in `docs/VEGAS_COMPAT_R36.md`.
