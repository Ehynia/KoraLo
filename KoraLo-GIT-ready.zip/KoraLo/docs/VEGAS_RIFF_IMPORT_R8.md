# VEGAS RIFF project research — r8

KoraLo r8 begins a **clean-room, read-only VEG project importer**. The goal is
semantic interoperability, not reproduction of VEGAS private implementation.
No proprietary VEGAS code is linked, copied, or required at runtime.

## Evidence used

The importer is based on observable bytes in user-supplied `.veg` projects,
public/shipped scripting object-model behavior already documented elsewhere in
this repository, and independent plausibility checks. Unknown records remain
opaque rather than being guessed.

For the r8 research sample `Untitled.veg`, the outer container is a GUID-based
RIFF/Wave64-style structure. The importer can independently recover:

- project width/height: 1920 x 1080
- frame rate: approximately 29.97002997 fps
- audio sample rate: 48000 Hz
- a referenced media path ending in `transformers-remix.mp3`

The same parser is covered by a synthetic native test; the user sample is not
redistributed with KoraLo.

## What r8 imports

1. Project video/audio settings from the observed outer project-settings record.
2. UTF-16 media references with common audio/video/still extensions.
3. Existing referenced media are probed through KoraLo's normal MediaEngine.
4. When the project contains exactly one recoverable source and that source is
   online, r8 conservatively creates a full-source timeline event (and linked
   A/V pair when both streams exist). This is deliberately a narrow bridge for
   simple projects while timeline records are still being reverse engineered.
5. Imported VEG projects have no `.veg` save target in KoraLo. Saving prompts
   for a `.kora` file so the original project is not overwritten.

## Not claimed yet

r8 does **not** claim direct recovery of arbitrary private VEG timeline records,
FX chains, envelopes, compositing state, render templates, generated media,
nested projects, or plugin-private state. Those will only be enabled when a
field can be validated from multiple clean-room observations/tests.

## Next research steps

- correlate repeated track/event records using controlled VEG projects with one
  variable changed at a time (start, length, take offset, group, fade)
- compare recovered values against public `TrackEvent`/`Take` semantics
- identify stable IDs/references between media pool records and event records
- add import-report parity tests rather than silently inventing unknown state
- investigate `ProjectInterchange.dll` only as metadata/public behavior context;
  do not transplant its implementation
