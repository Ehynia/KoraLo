# KoraLo Native 0.5

KoraLo is a **native C++20 non-linear editor for Windows and Linux**. The application runtime does not use Python, Tkinter, a browser UI, or a Python editing engine. FFmpeg/ffprobe are codec and encode/decode backends; KoraLo owns the project model, editing semantics, transaction previews, undo/redo, UI behavior, scheduling, and render-graph construction.

KoraLo is developed clean-room. Public APIs, metadata, XML/layout information, scripting object models, plugin descriptors, and observable NLE behavior may be used as references. Proprietary VEGAS implementation code is not copied. GPL Kdenlive source is not copied into KoraLo.

## r37 render stress validation

A 240-second stress project assembled from the supplied Sv_intro75 media now exercises color/stylize/anime effects, chroma-key overlays, generated Titles & Text and native Audio FX in one full render. The validation run completed without FFmpeg/decode errors. Final export is now clamped to project duration and audio is encoded at the project sample rate. See `docs/RENDER_STRESS_R37.md`.

## Architecture

- **Project model** — tracks, media, clips/events, linked A/V groups, markers, project serialization.
- **Selection model** — primary/multi selection with linked-group expansion.
- **Edit controller** — hit testing, snapping, non-destructive drag previews, advanced trim modes, track reorder, and atomic commit.
- **Undo stack** — one completed user edit gesture becomes one undo transaction.
- **Media engine** — probing, persistent sequential playback decode, background preview/cache preparation, proxy creation, and final rendering.
- **Platform UI** — Win32/GDI on Windows and X11 on Linux; external Linux dialog helpers are launched through the native argv process layer rather than shell command strings.

## Native branding and startup

The supplied KoraLo artwork is now part of the native application packaging rather than an external web/UI asset. On Windows, the first supplied logo is compiled into `KoraLo.exe` as the startup splash bitmap, and the square badge from the second supplied artwork is compiled as a multi-resolution application icon (16–256 px) for the executable, window title bar and taskbar. Source/reference PNGs are kept under `assets/branding/`; Win32 resource inputs live under `src/platform/windows/`. No image decoder, WebView, Python runtime or external splash process is required at startup.

The splash is shown immediately and remains visible for at least about 650 ms only when initialization is otherwise faster than that; genuinely slow initialization is not extended by an additional fixed delay.

The source tree is intentionally native:

```text
src/core/project.*              project/timeline model
src/core/selection_model.*      clip selection and linked-group expansion
src/core/edit_controller.*      drag/edit transaction layer
src/core/undo.hpp               undo/redo project snapshots
src/media/media_engine.*        media probe/preview/proxy/render engine
src/ui/editor_app.*             platform-independent editor behavior/layout
src/ui/canvas.hpp               KoraLo drawing abstraction
src/platform/x11_main.cpp       Linux X11 frontend + Xdnd
src/platform/win32_main.cpp     Windows Win32/GDI frontend + Explorer drop
```

## Native workspace UI and functional-control pass

The current workspace shell follows the supplied KoraLo interface mockup while remaining fully native. The visible controls in this pass are wired to native commands instead of being decorative placeholders:

- top toolbar: New/Open/Save, project settings information, Undo/Redo, Cut/Copy/Paste, snapping, event lock, marker, Import, Proxy, Render and Help;
- Project Media: Grid/List, live name search, All/Audio/Video/Stills filters and media selection/drag;
- Preview: quality cycling, Fit/1:1, frame step, Play/Pause/Stop, Video Preview/Trimmer tabs;
- Trimmer: source In/Out plus initial transactional Insert/Overwrite;
- timeline toolbar: selection/split tools, lock, snapping, ripple mode and add video/audio track;
- track headers: undoable Lock/Mute/Solo, clickable level/opacity, audio pan and a Video FX/compositing entry point;
- Video FX pane: current event and video-track opacity controls; Transitions pane: render-active Auto Crossfade toggle;
- render graph: video/event opacity, audio gain/pan, track/event mute/solo and overlap fades now affect final rendering.

The supplied Font Awesome SVG set is converted during development into a tiny generated C++ 16x16 bitmap atlas (`src/ui/icon_atlas.hpp`). The runtime therefore gets real file/folder/save/settings, undo/redo, cut/copy/paste, magnet/lock/comment, list/grid/search, transport and timeline-tool icons without loading SVG, HTML, CSS, a browser, or an icon font. On Win32, painting is double-buffered into a persistent compatible bitmap and presented in one `BitBlt`, eliminating the previously visible partial-frame redraw while dragging timeline controls. Track level and pan sliders are also transaction-based: drag updates only the UI preview and mouse-up creates at most one undo entry.

The Media Generators tab intentionally exposes no fake generator actions until the native generator model exists. The supplied HTML/Tailwind mockup is a **design reference only**: KoraLo does not embed it, use WebView/Electron, or add a browser/Python runtime. All workspace drawing continues through `src/ui/canvas.hpp` into Win32/GDI or X11.

## Timeline interaction hardening

The current timeline now supports:

- marquee multi-select; `Ctrl` or `Shift` marquee adds to the existing selection;
- group-aware selection: selecting one linked A/V event selects its group;
- multi-selection move with linked A/V timing preserved;
- group-aware left/right trim and slip;
- transactional preview: drag updates `DragState::preview`, not `Project`; mouse-up commits once;
- **Roll**: `Shift` + drag a touching event edge;
- **Slide**: `Alt+Shift` + drag an event body when it has touching neighbors;
- **Ripple Trim**: `Ctrl+Shift` + drag an event edge;
- **Slip**: `Alt` + drag an event body;
- track reorder by dragging a track header; video tracks stay within the video section and audio tracks within the audio section;
- linked A/V horizontal move, same-kind vertical event move, snapping, split/delete/ripple/nudge, and undo/redo.

Advanced drag modes preserve source and timeline constraints as far as the current `Clip` model permits. `Stretch` is intentionally deferred.


## Video Event Pan/Crop and keyframes

r7 adds the first native compositor-side spatial editor. Video events now expose a `P/C` control that opens a dedicated Pan/Crop editor with a draggable crop frame, corner zoom handles, rotation controls and an event-local keyframe timeline. `Center X`, `Center Y`, `Zoom` and `Rotation` each own their own keyframes through the new `AnimatedDouble`/`VideoMotion` model.

Pan/Crop pointer drags follow the same transaction rule as timeline edits: the gesture updates only temporary preview state and commits the Project once on mouse-up. Motion curves survive project save/load, undo/redo and event split. Preview decoding and final rendering both consume the same motion state; animated render output is covered by `koralo_media_tests`. See `docs/PAN_CROP_R7.md`.

## Transaction rule

Timeline edit gestures are preview-first. `update_drag()` calculates visual overrides without modifying the project. `commit_drag()` opens one undo transaction, applies the preview, and commits it once. Cancelling a drag discards preview state.

Selection-only marquee gestures do not create undo entries because they do not change `Project`.

## Native media engine

`src/media/media_engine.cpp` currently implements:

- FFmpeg/ffprobe discovery and media probing;
- shell-free native subprocess launching (`CreateProcessW` on Windows, `fork`/`exec` on Linux) with UTF-8 path handling;
- compact delimiter-based ffprobe metadata parsing with a selected-stream `key=value` fallback for ffprobe builds that format combined output differently;
- background preview decode requests with stale-request coalescing;
- LRU preview frame cache;
- proxy creation;
- KoraLo-owned render command/graph generation for timed clips, video layering, and audio mixing;
- background final rendering.

During normal timeline playback, consecutive frames come from one persistent FFmpeg raw-video decoder pipe instead of launching FFmpeg and writing a temporary PPM for every frame. r17 keeps Pan/Crop/FX playback on that decoder and applies the realtime preview transform/effects in-process. Exact uncached random scrub/seek frames can still use the single-frame fallback, while repeated FX edits at the same source/time reuse the raw source-frame cache. The next media milestone is a generalized seek queue/prefetch layer plus the native realtime mixer, audio master clock, A/V sync, scrub, and native GPU compositor.

## Build and run — Linux

Automatic install/run:

```bash
chmod +x install_and_run_linux.sh
./install_and_run_linux.sh
```

Manual build:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/KoraLo
```

## Build and run — Windows

Use `install_and_run_windows.bat` or the PowerShell bootstrap. The Windows frontend uses Win32/GDI and native common dialogs.

The Windows target is implemented. The media engine disables the legacy Win32 `min`/`max` macros (`NOMINMAX`) and launches FFmpeg/ffprobe directly with `CreateProcessW`, avoiding `cmd.exe`, `_popen`, and narrow `std::system` path quoting. KoraLo keeps path strings as UTF-8 and converts at the Win32 boundary. The bootstrap stops on the first failed native command. User logs confirm MSVC 17.14 builds `KoraLo.exe` and both test binaries and passes `koralo_native_tests`; the latest reported failure was ffprobe metadata recognition inside `koralo_media_tests`, which this revision addresses with a non-regex compact parser plus selected-stream fallback. This exact revision still requires a fresh Windows retest before Windows media/runtime validation is claimed.

## Tests

`tests_native/test_core.cpp` covers project roundtrip (including a UTF-8/non-ASCII project filename), transactional move/trim, linked-group move, marquee selection, Roll, Slide, Ripple Trim, track reorder, clipboard copy/paste, event locking, Trimmer Insert/Overwrite and undo/redo. `tests_native/test_media.cpp` creates real media with FFmpeg, probes it, decodes a preview frame, and executes real renders from a temp directory containing spaces and UTF-8 non-ASCII characters; it also exercises opacity, gain, pan and overlap/crossfade render controls.

```bash
ctest --test-dir build --output-on-failure
```

See `ROADMAP.md`, `PARITY_MATRIX.md`, `BUILD_INFO.md`, and `CLEAN_ROOM.md` for the current scope and validation status.

## r4 realtime audio + native menu/settings pass

Revision `2026-10-01-audio-ui-r4` starts the playback/UI hardening requested from the supplied VEGAS behavior screenshots without copying proprietary implementation code.

- Timeline Play now starts realtime audio preview for audible audio events through `ffplay`, launched with the same shell-free native process boundary used by FFmpeg/ffprobe. Active events honor track/event mute, track solo, event/track gain, track pan and playback rate. Pause, Stop and seek terminate/restart preview children cleanly. This is an interim backend behind `MediaEngine`; the roadmap still replaces it with KoraLo's own realtime mixer and audio master clock.
- Preview decoding is throttled by quality during playback (Draft/Preview/Best), duplicate pending requests are coalesced, and the LRU frame cache is protected from UI/worker races. This reduces the previous process-per-frame CPU spikes while persistent decoder sessions are still pending.
- The native command surface now has File/Edit/View/Insert/Tools/Options/Help menus with only commands KoraLo can actually execute.
- Project Properties is now an editable native overlay for resolution, frame rate, sample rate and HD/UHD presets. Applying it is one undoable Project transaction.
- Preferences is a native overlay for realtime audio preview, preview quality, snapping and automatic crossfades.
- Win32 GDI requests `Open Sans` for UI text; when the family is not installed, Windows' native font mapper provides the fallback. X11 also makes a best-effort Open Sans core-font request. No font files are bundled into the runtime package.

See `docs/VEGAS_BEHAVIOR_NOTES_R4.md` for the clean-room behavior mapping taken from the supplied screenshots.


## Editing semantics r6

KoraLo now uses a canonical clean-room `Media -> Take -> TrackEvent -> Track -> Project` model. TrackEvents can contain multiple Takes with an active Take and source offset; project format v6 serializes this while the loader remains backward-compatible with v5 projects. Group-aware split creates independent left/right groups, and editing includes Ignore Event Grouping, Slip All Takes, Event Loop, Quantize to Frames, Trim Start/End to Cursor, advanced drag modes, and transactional vertical group movement.

Research notes grounded in the supplied VEGAS 17 shipped scripts/public managed facade are in `docs/VEGAS_EDIT_SEMANTICS_R6.md`. No VEGAS implementation code is copied into KoraLo.

## r8 — audio meter, Project Media hardening, direct VEG inspection

- Master L/R meters now follow a cached real source-audio envelope instead of a fixed playback animation. Meter analysis runs off the UI thread and observes mute/solo/gain/pan at the current playhead.
- Video events with Event Pan/Crop animation now expose a small motion lane and keyframe diamonds directly on the timeline event.
- Project Media's All Media / Media Bins / By Type / Tags tree is fully clickable with expand/collapse behavior; visible rows are no longer decorative dead controls.
- The main toolbar was reduced to non-duplicated quick actions: file operations, undo/redo, clipboard, import and render. Timeline/pane commands remain in their own controls/menus.
- `.veg` can be selected in Open Project or dropped onto KoraLo. r8 clean-room inspection recovers validated project settings and media references; a conservative one-source timeline reconstruction is performed when the referenced media is online. Save remains `.kora` and never overwrites the original `.veg`. See `docs/VEGAS_RIFF_IMPORT_R8.md`.

## r9 — GPU assist, timeline filmstrips and first native FX layer

Revision `2026-10-01-gpu-thumbnails-fx-r9` begins the next compositor/media pass without replacing the existing native C++20 architecture.

- `MediaEngine` now detects FFmpeg hardware-acceleration/encoder capabilities and exposes a runtime GPU acceleration toggle. Preview decode, proxy creation and H.264 render attempt a hardware-assisted path when available and always retain a CPU fallback. This is phase 1 GPU support; a persistent native GPU compositor is still a later milestone.
- Video events now request asynchronous cached timeline thumbnails. The strip follows the event's active Take/source offset, playback rate, loop state and trim preview, so edge trimming exposes real source frames instead of a flat blue placeholder.
- A generic clean-room FX model has been introduced: `EffectDefinition -> ParameterDefinition -> EffectInstance`. Parameter types cover double/integer/bool/choice/RGBA/vec2/string/group/action, and animatable numeric parameters own their keyframes.
- The first independent KoraLo effects are Brightness/Contrast, Saturation and Gaussian Blur. Event FX can be added/toggled/removed/adjusted from the Video FX pane. Media/Track/Output effect chains are represented in the project model and render pipeline, with Track/Output UI still intentionally minimal.
- Project format is now v8 while the loader remains compatible with previous KoraLo project revisions.

See `docs/VEGAS_FX_RE_R9.md` for the public-OFX-metadata observations used to shape the effect model. No VEGAS implementation code is copied.

## r10 — timeline viewport, VEG timing import and Video FX browser

r10 fixes the timeline viewport so track rows are clipped to the timeline body and vertically scrollable instead of drawing underneath the status/window edge. A visible scrollbar indicates hidden rows, and hit-testing follows the vertical scroll offset. Horizontal timeline zoom can now go down to 8 px/s; direct `.veg` import requests a one-time fit so recovered edits are visible as a whole.

The supplied `Untitled.veg` now imports validated TrackEvent start/duration and Take source offsets instead of falling back to one full-length audio event. The clean-room Wave64 reader preserves recovered track-list order. See `docs/VEGAS_WAVE64_TIMING_R10.md`.

Event Pan/Crop now explicitly displays both event-local time and the corresponding project timeline time. Final render normalizes each source event to `PTS-STARTPTS` before evaluating event-local motion/FX expressions, so Pan/Crop keyframes are evaluated against the TrackEvent's own 0..Length time domain rather than inherited source timestamps.

The Video FX pane is reorganized around the VEGAS-style workflow: searchable effect list on the left, selected effect/preset area on the right, and an Event FX chain with enable/remove plus live numeric parameter controls. The catalog remains KoraLo-owned and only exposes effects with implemented preview/render behavior.


## r11 interaction/render hardening

- 12-hour timeline horizon with native horizontal navigator.
- Middle-drag pan, pointer-anchored Ctrl+wheel zoom and Shift+wheel horizontal navigation.
- Pan/Crop rotation handle with keyframed rotation.
- Startup system capability check and asynchronous import/render cache warmup.
- Drag Video FX directly onto timeline video events.
- Native Render As preset editor with GPU/CPU fallback.

## r12 — preview quality, long-form media preparation, cache progress

Revision `2026-10-01-preview-cache-r12` makes preview quality and import preparation operational rather than cosmetic.

- Preview has four real decode tiers: Draft 320x180, Preview 640x360, Good 960x540 and Best/Full. Playback preview FPS is independently selectable at 15/24/30/60 fps. Draft/Preview/Good may use KoraLo's prepared seek cache while Best always evaluates the original source unless the user explicitly selected a manual proxy.
- Import queues an asynchronous media-preparation job. Representative timeline frames are decoded up front, audio analysis is queued, and video sources >=20 seconds get a persistent all-I seek-friendly preview cache in the system temporary KoraLoCache directory. GPU decode/encode is attempted when available with a CPU fallback.
- The bottom status bar shows preparation percentage/stage and explicitly asks the user to wait while caching is active. The editor remains interactive and cache generation is cancellable when KoraLo exits.
- Preview quality, preview FPS and optimized-cache policy are project-owned settings in r18 and are stored in `.kora`; the preview gear opens Project Properties. Application Preferences keeps GPU/audio/editor-wide controls.
- Modal settings/render/Pan-Crop overlays now use alpha dimming on Win32; X11 uses a stippled transparency fallback without adding a browser/UI runtime.
- The Windows splash shows startup/check phases and a progress bar while native resources and the media/GPU/audio environment are initialized.

The prepared cache now targets random-seek responsiveness on long-GOP media with an all-I H.264 layout and is also used by timeline thumbnail requests. r15 adds a persistent decoder session for ordinary sequential playback; r17 extends that session through dynamic Pan/Crop/FX preview while random uncached seeks still use the exact source-frame decode fallback.

## r13 — MSVC compiler-limit hardening

Revision `2026-10-01-msvc-dispatch-r13` is a portability-only hardening pass after a real Visual Studio 2022 build exposed MSVC `C1061` in the monolithic UI command dispatcher. The dispatcher is now split into modal/edit/FX/workspace/track handlers with early returns, preserving command behavior while keeping lexical nesting safely below MSVC limits. Reported `C4458/C4456` shadow warnings were removed, and non-MSVC builds now enable `-Wshadow` so equivalent mistakes are caught before packaging. No timeline/media/cache behavior was intentionally changed in this pass.


## r14 — runtime locales and right-click editing

Revision `2026-10-01-locales-context-r14` adds external UTF-8 language packs under `locales/` and native cross-platform right-click menus for events, empty timeline space, track headers and Project Media items. Language packs are copied beside the executable at build/install time and can be selected without recompiling. See `docs/LOCALIZATION_CONTEXT_R14.md`.

## r15 — mouse fades and persistent playback decode

Revision `2026-10-01-fade-stream-preview-r15` implements the event fade gesture shown in the supplied VEGAS 17 screenshots using clean-room behavior only. The top-left/top-right event handles now create **Fade In**/**Fade Out** by direct mouse drag. The handle follows the pointer at frame-quantized duration, the diagonal fade line is drawn from the live transaction preview, and the tooltip/status reports `Fade in offset` / `Fade out offset` with project timecode. The `Project` is not mutated until mouse-up; one completed drag creates one Undo command. Linked A/V grouping is preserved, while the fade itself remains per-event.

Video preview now applies event fade opacity (together with event/track opacity), the real Master meter applies audio fade gain, realtime ffplay audio preview evaluates the fade envelope during playback, and final rendering continues to use the serialized `fade_in`/`fade_out` values for video alpha and audio gain. Drop-frame 29.97/59.94 project timecode uses the `;` frame separator.

The main playback bottleneck was also removed for the common path. Previously every uncached playback frame started a new FFmpeg process and wrote/read a temporary PPM. r15 adds a shell-free cross-platform binary stdout pipe and keeps one FFmpeg raw-RGB decoder process alive across consecutive playback frames. Stale-frame catch-up drops only a bounded number of raw frames, large seeks restart the session, GPU decode is attempted first when available, and CPU fallback remains mandatory. r17 extends this persistent path through Pan/Crop/FX playback by applying lightweight preview transforms/effects in-process after source decode. Random uncached seeks still use exact source-frame decode, then reuse the cached raw frame while parameters are adjusted.

The supplied `VEGAS17_Research_BACKUP` and `OpenColorIO_BACKUP` archives are treated as research/reference material only; no proprietary VEGAS implementation code and no archive contents were copied into KoraLo.


## r16 — timeline content viewport isolation

Revision `2026-10-02-timeline-viewport-clip-r16` fixes the horizontal-scroll rendering defect where a long Event could paint over the fixed track-header pane after its start moved off-screen. Event drawing is now clipped to the timeline content viewport, and event hit-testing explicitly rejects the header pane, so hidden Event geometry cannot steal track-header input.

The audio waveform loop now starts at the first visible sample column and stops at the viewport edge instead of iterating across the off-screen portion of a long Event. This keeps timeline drawing cost proportional to what is visible while panning through long media. Event FX/Pan-Crop compact buttons are also registered only when their rectangles are inside the visible timeline content area.


## r17 — HiDPI UI, still images, detachable A/V and effect-aware preview cache

Revision `2026-10-02-hidpi-photo-preview-cache-r17` is a native UI/media responsiveness pass. The editor now lays out in logical coordinates and scales drawing/input for 1440p/4K-class windows, Win32 opts into process DPI awareness, X11 text honors requested sizes, and panels/buttons/preview/Event surfaces have layered native shadows and a more coherent dark palette. No WebView or browser UI was introduced.

Still images (`png`, `jpg/jpeg`, `bmp`, `webp`, `tif/tiff`) are now first-class media. A still creates a five-second video Event by default, can be extended past that nominal duration, remains visible at arbitrary Event-local times during preview, loops correctly through the persistent stream path, and is rendered for the full Event duration. Background preparation intentionally warms one still frame instead of building a pointless long-form proxy.

Linked video/audio can now be separated from the Event context menu with **Detach Audio from Video**. The command clears the linked group in one undoable transaction and leaves both Events independently editable.

Preview now separates source decode from the lightweight compositor step. Raw source frames have their own LRU cache; changing FX/Pan-Crop invalidates only the composite cache, so repeated parameter edits at the same playhead do not launch FFmpeg again. Sequential playback with dynamic Pan/Crop/FX stays on the persistent raw-video decoder and applies KoraLo's current built-in preview effects/transform in-process. Final rendering remains the authoritative FFmpeg render path; the CPU realtime preview for some blur/chroma/transform details is intentionally an approximation until the native GPU compositor is implemented.

Prepared media is now generated for video sources >=20 seconds using seek-oriented all-I H.264 (GPU attempt with CPU fallback). Timeline filmstrip requests transparently use the prepared cache when available, which makes the cache useful for timeline navigation as well as playback. An uncached arbitrary source seek can still require one exact FFmpeg decode; subsequent FX edits at that source/time reuse the cached raw frame.

See `docs/HIDPI_PHOTO_PREVIEW_CACHE_R17.md` for implementation/validation notes. This Linux environment does not validate the exact r17 Win32/MSVC build.


## r18 — Video Event FX editor, project preview settings and icon/control polish

Revision `2026-10-02-fx-editor-project-preview-r18` adds a dedicated native **Video Event FX** editor instead of forcing parameter work into the compact browser pane. The window contains an effect catalog, the selected event FX chain, a large live video preview, enable/remove controls and real horizontal numeric parameter sliders. Slider drags are preview-first: the Project model is not modified while the pointer moves; a temporary effect copy is passed to the preview request, and mouse-up commits one Undo transaction. Escape cancels the drag and restores the committed preview.

Preview quality, preview FPS limit and optimized-media-cache policy now belong to `ProjectSettings` and round-trip in `.kora` format v10. The preview-toolbar settings button opens Project Properties, where those fields are edited alongside width/height/FPS/sample rate. Undo/redo resynchronizes the live preview controls from the restored project snapshot.

The native button treatment was refined with layered shadows/highlights and active/hover accents, and the icon atlas gained dedicated add/remove/reset/power/close glyphs used by the FX editor. No WebView, icon font or browser runtime was introduced.

## r19 — Open Sans UI and Sv_intro75 VEGAS 12 compatibility pass

Revision `2026-10-02-open-sans-svintro-r19` makes Open Sans the common native UI face and starts a clean-room compatibility pass against the supplied `Sv_intro75` project. Win32 continues to request the installed `Open Sans` family through GDI. X11 no longer depends on the old bitmap/core-font path for normal editor text: it renders a generated raster glyph atlas derived from the locally installed Open Sans Regular/Bold faces. No TTF/OTF font file is bundled in the KoraLo package.

The supplied `OPEN TO EDIT! by V2GX.veg` is a VEGAS Pro 12 project, so the importer now accepts the observed VEGAS 12 project-settings layout in addition to the previously validated VEGAS 17 layout. For this supplied project the clean-room reader recovers 1920x1080, 23.976 fps, 48 kHz, all eight track slots (including empty slots), four validated TrackEvents, their timing/Take offsets, and five referenced media files. Same-folder basename relinking reconnects all five media files in the supplied archive even though the `.veg` stores old absolute Windows paths. WMV/ASF media is recognized by the importer and Windows media picker.

Compatibility metadata is preserved without guessing private parameter blobs. The Legacy Text event is retained as a generated-media placeholder, Event FX identities such as Chroma Keyer, Color Corrector and Cookie Cutter are imported as disabled opaque compatibility nodes, and the observed audio-track Noise Gate/EQ/Compressor identities are preserved in the native project. `.kora` format v11 serializes those imported audio FX references. Missing generated-media rendering and exact VEGAS FX parameter/DSP mapping remain explicit follow-up work; unknown fades/groups/envelopes are not fabricated.


## r20 — native Titles & Text, recovery autosave, safe close, modern UI pass

Revision `2026-10-02-titles-text-autosave-ui-r20` adds the first native KoraLo generated-text workflow, using the supplied VEGAS Titles & Text screenshots only as clean-room UX/behavior references. `Insert -> Text...` and `Insert -> Generated Media...` now create a five-second video event at the cursor, and the Media Generators pane exposes a real `Titles & Text` generator instead of a placeholder. The event can be trimmed to any duration like ordinary generated media.

The dedicated Titles & Text editor is transactional: edits live in a temporary `GeneratedText` state until **Apply**. It supports UTF-8 text and multiple lines, Open Sans, size, bold/italic, left/center/right alignment, text-color presets, scale, normalized X/Y location, a 3x3 anchor model, outline, shadow, a simple fade animation, and direct mouse positioning in the live preview. Generated text is rasterized natively from KoraLo's Open Sans glyph atlas for preview and is passed into the final FFmpeg render graph as a temporary transparent RGBA image; no browser, Python runtime, drawtext/font discovery, or bundled TTF/OTF file is required. Legacy VEGAS text events that are detected during import are now represented by an editable native generated-text object, but unknown proprietary text payload fields are still not invented.

Dirty projects are recovery-autosaved every 30 seconds to an `autosave/` directory beside the KoraLo executable when writable, with a temporary-directory fallback. A normal save removes the recovery copy. Closing a dirty project now asks **Save / Discard / Cancel** on Win32 and through the available native Linux dialog helper; cancelling a Save As keeps the editor open. A recovery copy is also forced immediately before the close decision.

The workspace palette, pane chrome, buttons, status bar and Project Properties/Preferences surfaces received another native dark-UI pass with softer borders, layered shadows and clearer active/hover states. The native `.kora` format is now version 12 to persist generated-text state.


## Modern GNOME-style native UI pass

Revision `2026-10-02-gnome-modern-ui-r21` refreshes the shared native Canvas UI toward a contemporary GNOME/libadwaita-inspired visual language without embedding GTK, WebView, HTML or CSS. The editor keeps the existing Win32/GDI and X11 backends, while the shared drawing layer now uses calmer neutral surfaces, softer separators, rounded native controls/cards, restrained blue accent states, larger spacing, pill-like tabs, compact header bars, rounded preview surfaces, refreshed timeline/event chrome, subtler scrollbars and more consistent dark dialogs. Editing/media behavior is unchanged; this pass is deliberately visual so existing transaction/undo semantics remain intact.

## r22 — Anime Restore filter pack

Revision `2026-10-02-anime-restore-fx-r22` ports the user-supplied Anime Line Restore V45 visual stages into KoraLo's native C++ FX model instead of embedding its Python/PyTorch/Gradio runtime. The restoration workflow is deliberately split into independently reorderable/bypassable filters under the `Anime Restore` category: **Anime Line Restore**, **Anime Vector Colors**, **Anime Text Restore**, **Anime Paper Texture**, **Anime Detail Sharpen**, and **Anime Deinterlace**. Their user-facing defaults follow the supplied tool's GUI defaults where those differ from its dataclass defaults.

Realtime preview implementations run in-process on decoded RGB frames, so the pack keeps the persistent decoder/source-frame cache path and does not launch Python or a new decoder for every parameter edit. Final render maps the filters to the existing FFmpeg render graph; Line Restore/Text Restore use render-safe approximations until the native GPU compositor can run the exact same kernels at export time. The supplied ML character-isolation stage (`rembg/u2net`), IVTC timing conversion and true multi-frame temporal gate are intentionally not represented as fake one-frame effects: they require the planned analysis/source-processing layer before KoraLo can preserve timeline semantics honestly.


## r23 — still-image preview hardening and Anime Restore validation

Revision `2026-10-02-still-image-anime-validation-r23` fixes stopped/scrub preview of single-frame JPG/PNG media on newer FFmpeg builds. KoraLo no longer issues an input `-ss 0` seek for still images, because FFmpeg 7.x can legally finish with zero filtered frames for that combination. Single-frame PPM output now uses `-update 1`, and continuous still playback likewise skips meaningless source seeking. This restores Project Media/timeline still thumbnails and random-access still preview, including odd-size images such as 1125x631.

The media regression suite now creates an odd-size JPEG, probes it, applies Anime Line Restore through the real asynchronous preview path, and verifies that the full 1125x631 frame is returned. The user-supplied anime thumbnail was also exercised against each r22 Anime Restore CPU stage and a combined chain. Deinterlace is intentionally not recommended for progressive stills; it is a source-condition filter, not a universal enhancement.


## Source revision 2026-10-02-realtime-fx-ofx-foundation-r24

- Realtime FX preview now fuses consecutive pixel-only color operations into one memory pass instead of rescanning the whole frame for every simple effect.
- Blur work buffers and common sharpen/vector-color scratch frames are reused across preview frames to reduce allocator churn during playback and slider drags.
- Playback uses adaptive realtime resolution for heavy FX chains (up to 640x360, or 480x270 for very heavy chains) while pause/stop immediately restores the project's selected preview quality.
- Preview worker drops completed stale frames when a newer request already exists, reducing visible lag during fast scrubbing and effect editing.
- Added an experimental native OpenFX discovery layer. It follows OFX_PLUGIN_PATH plus standard Windows/Linux OFX locations, loads OFX binaries only far enough to enumerate exported plug-in identities, and marks Boris FX / GenArts / Sapphire / Continuum-style identifiers.
- Video FX shows OFX/Boris discovery counts. Tools -> Rescan OpenFX / Boris FX refreshes the registry.
- Third-party OFX pixel rendering is intentionally gated in r24: detected OFX effects cannot yet be inserted into the render graph until the Image Effect, Property, Parameter, Memory and related host suites are implemented and validated.
- Added a synthetic OFX module regression fixture that validates native bundle scanning and Boris-style plug-in identification without shipping any Boris FX code or binaries.
- Clean Linux Release build: passed with no compiler warnings. Native and media tests: passed. X11 GUI smoke: passed.
- Windows/MSVC for this exact r24 revision was not run in this environment.

## r25 — free editing effects pack

Revision `2026-10-02-free-editing-fx-r25` adds nine clean-room native effects selected from common concepts documented by free/open video-filter ecosystems: **Glow, Hue Shift, Levels, Vignette, Pixelate / Mosaic, Lens Distortion, RGB Split, Letterbox, and Scanlines**. No frei0r or Kdenlive GPL implementation code is copied or linked. The effects run in KoraLo's in-process realtime preview and map to FFmpeg export filters where available. Hue Shift and Levels join the r24 fused pixel pass so common color chains avoid extra full-frame memory scans. See `docs/FREE_EFFECTS_R25.md`.


## Source revision 2026-10-02-user-open-sans-atlas-r26

The user-supplied `open-sans.zip` is now the build-time source for KoraLo's native raster font atlas. `OpenSans.ttf` supplies Regular, `OpenSans-Italic.ttf` supplies real Italic, and the atlas synthesizes bold/bold-italic coverage for the native UI and generated Titles & Text. Raw TTF files are not bundled in the distributed KoraLo archive. X11 renders the atlas directly; Win32 continues to use native ClearType Open Sans when the exact family is installed and falls back to the same bundled raster atlas when it is not, so KoraLo no longer silently changes to a different system face. Titles & Text now uses the real italic atlas rather than the previous geometric slant approximation.

## r27 — direct audio recording and native Audio FX

KoraLo can now record the system default microphone/input directly into the open project. The timeline toolbar exposes **REC / STOP**, and the same command is available through **Insert -> Record Audio**. Recording targets the selected audio track (or the first audio track, creating one if necessary), follows the project sample rate, stores a PCM WAV in a project-side `Recordings` directory for saved projects, and inserts the result as normal Project Media + TrackEvent when recording stops. The capture process writes raw PCM first and KoraLo finalizes the WAV container itself, avoiding corrupt WAV headers if the FFmpeg capture process must be terminated.

Audio processing is now separate from Video FX. The new **Audio FX** tab supports Event and Track chains with native project persistence, Undo/Redo, enable/remove controls and numeric parameter editing. The initial pack is Echo/Delay, Room Reverb, Chorus, Flanger, Compressor, Limiter, Noise Gate, 3-band EQ, High Pass, Low Pass, Distortion, Tremolo, Stereo Width and Gain. Realtime audio preview and final rendering consume the same chain ordering. Imported VEGAS Noise Gate / Track EQ / Track Compressor identities are conservatively mapped to disabled native equivalents until the original private parameter payloads are validated.

KoraLo itself still contains no Python audio runtime and no shell-based recorder. The actual capture/decode/encode boundary remains FFmpeg; the project/timeline/effect model, recording lifecycle, WAV finalization, editing UI and serialization are native C++20.


## r29 — Windows native-test / OFX regression hardening

Revision `2026-10-02-windows-native-tests-fix-r29` fixes the Windows-only native-test failure reported after r28 successfully built all executables. The synthetic OpenFX fixture is now emitted directly into the standard `Contents/Win64` bundle directory for every Visual Studio configuration, and the regression scans only that fixture instead of also loading arbitrary system-installed OFX plug-ins. The test uses a relative build-tree path so Windows user-profile Unicode does not pass through a narrow compile-time absolute pathname. Native-test exceptions are caught and reported as readable failures rather than surfacing only as `0xc0000409`. The MSVC `C4244` warning in the RGB frame clear path is also removed with an explicit `std::uint8_t` fill value.

## r31 smooth UI rendering

r31 replaces the old binary toolbar icon raster with an anti-aliased coverage atlas, smooths rounded UI edges, adds short native hover/press easing, and removes several avoidable paint-time costs. Win32 now reuses GDI/AlphaBlend resources and converted preview frames instead of rebuilding them every repaint. X11 uses a Pixmap backbuffer and XRender alpha when available. The animation scheduler redraws only while motion is active, so idle UI does not become a permanent 60 Hz loop. See `docs/SMOOTH_UI_RENDER_R31.md`.


## Revision/package synchronization (r32)

Revision `2026-10-02-revision-sync-r32` removes the duplicated hard-coded source revision that caused a valid r31 package to be rejected by the Windows installer. `BUILD_REVISION.txt` is now the single revision source: both CMake and `install_and_run_windows.ps1` read it directly. The installer still validates package structure, removes stale `build/` output, and checks the required MSVC portability fix before configuring.


## r33 UI idle/performance pass

- Windows backbuffer is now a persistent top-down 32-bit DIBSection with direct software compositing for KoraLo UI rectangles, rounded-corner alpha coverage, lines, borders, icons and the generated Open Sans atlas. This removes thousands of tiny GDI/AlphaBlend calls from a full UI repaint.
- The Windows message loop uses `MsgWaitForMultipleObjectsEx` instead of an unconditional sleep, so an animation/preview invalidation can be painted immediately while idle still sleeps efficiently.
- Empty timelines no longer enter a pointless playback/redraw loop; an empty/no-video preview is cleared only when its visual state actually changes.
- Preview/video `StretchDIBits` remains native and is synchronized before software overlays continue.
- Goal: smooth 60 Hz hover/press animation without a permanent repaint loop, and low CPU while completely idle.

### r34 — 2K / fractional DPI scaling

Fractional 125/150% scaling no longer creates cracks in icon strokes or rounded UI geometry. On Windows the editor scale is now driven by per-monitor DPI, not by raw window resolution.

## Win32 per-monitor DPI link fix (r35)

r35 fixes the MSVC `LNK2019` for `EditorApp::set_ui_scale(double)` introduced by the per-monitor DPI pass. Windows now supplies the initial and `WM_DPICHANGED` scale explicitly, and the draw path preserves that DPI value instead of replacing it with the resolution-based fallback on every paint. This is important for 125%/150% scaling on 1440p displays where icon/text cracks were previously observed.

### r36: real Chroma Key and VEGAS mask compatibility research

The native Chroma Key is now an alpha-producing keyer rather than a green-to-black preview approximation. The preview compositor can show a keyed event over the next lower video event, and final render keeps the alpha through the complete track graph. The importer also recognizes the validated legacy Svfx Chroma Key named-value layout found in the supplied VEGAS project. See `docs/VEGAS_COMPAT_R36.md` for the clean-room evidence, the observed five-mask VEGAS Bézier Masking schema, and the remaining fields that must be validated before broader `.veg` mask compatibility can be claimed.
