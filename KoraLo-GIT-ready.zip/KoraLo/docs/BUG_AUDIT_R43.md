# KoraLo r43 — bug audit from state/invariant perspective

Revision: 2026-10-07-r43-audited-state-invariants

This pass deliberately did not focus on feature count. It reviewed state-machine
ordering, stale UI state, project-file invariants, audio routing semantics,
Undo-sensitive operations and concurrency regressions.

## Confirmed bugs fixed

1. Keyframe RMB stale state
   - In Animation and Pan/Crop, right-clicking empty space after opening a keyframe
     context menu could leave the old menu alive.
   - Fixed by clearing the context state before each RMB key hit-test.

2. Delete shortcut could target the wrong object
   - The keyframe context menu advertised `Del`, but Animation Workspace processed
     Delete before the context menu. It could delete a selected vector shape/node
     instead of the keyframe represented by the open menu.
   - Context-menu keyboard handling now runs first. Delete dispatches the exact
     Animation/Pan-Crop key deletion action stored in the context state.

3. Auto Duck ignored Audio Solo semantics
   - A muted track was excluded, but a non-solo upper audio track could still
     trigger ducking while another audio track was soloed.
   - Duck trigger discovery now uses the same audio-solo visibility rule as the
     render planner and ignores media that has no audio stream.

4. Finite but destructive values in hand-edited/corrupt .kora files
   - NaN/Inf were already rejected, but extreme finite track/event values could
     reach timeline geometry or render paths.
   - On load, track gain/pan/opacity/height, event gain/opacity/fades/snap offset,
     Pan/Crop channels and marker time are normalized to safe supported ranges.
   - Motion keys are sorted and de-duplicated after normalization.

## Validation

Strict syntax pass for changed core/UI/media files:
`-Wall -Wextra -Wshadow -Werror` — clean.

Built and passed:
- koralo_native_tests
- koralo_effect_tests
- koralo_animation_tests
- koralo_media_concurrency_tests
- koralo_render_graph_tests
- koralo_render_planner_tests
- koralo_playback_controller_tests
- koralo_runtime_tests

No claim is made that a non-trivial editor can be proven bug-free. The result of
this audit is that the reproduced defects above are fixed and the listed regression
suites remain green.
