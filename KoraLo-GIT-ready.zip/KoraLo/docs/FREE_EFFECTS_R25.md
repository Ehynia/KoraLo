# Free editing effects pack — r25

Revision `2026-10-02-free-editing-fx-r25` adds a clean-room native pack of common editing effects selected after surveying public free/open video-filter catalogs. The public catalogs were used only to identify broadly useful effect concepts and user-facing terminology. KoraLo does not copy or link frei0r/Kdenlive GPL implementation code.

Added native effects:

- Glow — highlight bloom-style softening with Radius, Strength and Highlight Threshold.
- Hue Shift — hue rotation in degrees.
- Levels — Input Black/White, Gamma, Output Black/White.
- Vignette — Amount and Softness.
- Pixelate / Mosaic — configurable block size.
- Lens Distortion — primary/secondary radial coefficients plus center X/Y.
- RGB Split — independent red/blue spatial offset around the green channel.
- Letterbox — adjustable top/bottom cinema bars.
- Scanlines — adjustable strength and spacing.

Realtime preview implementations are native C++ and remain on KoraLo's persistent decoder/source-frame cache path. Hue Shift and Levels participate in the fused pixel-operation pass introduced in r24, avoiding separate full-frame scans when adjacent to other simple color operations.

Final rendering maps the effects to stable FFmpeg filters when available. The preview implementation is authoritative for interaction, while the FFmpeg export mapping is intended to preserve the same editing intent. Glow currently uses a render-safe soft-glow approximation because KoraLo's current FFmpeg render chain is linear and does not yet expose arbitrary multi-branch blend nodes.

Regression coverage verifies that all nine effects instantiate, alter native preview pixels, and survive a combined final MP4 render chain.
