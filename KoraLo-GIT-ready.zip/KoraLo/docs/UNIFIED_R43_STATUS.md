# KoraLo r43 Unified — integrated status

Revision: `2026-10-06-r43-unified-stabilized-core-split`

This package is the single integrated r43 source tree. It supersedes the separate
Stage 0/Stage 1 prototype archives while retaining their documentation for audit
history.

## Integrated changes

- Russian/English localization cleanup and equal locale key sets.
- Animation Workspace localization and interactive regression verification.
- Timeline vertical-scrollbar hit testing, click/drag behavior and shared geometry math.
- Warning Zero cleanup for the GCC strict-warning build used during r43 stabilization.
- Project semantic save/load/save/load round-trip regression coverage.
- ASan/UBSan and TSan CMake modes plus a targeted MediaEngine concurrency stress test.
- Core Split seams: FrameCache, FFmpeg runtime/probe, RenderPlanner, RenderGraph,
  PlaybackController and DecoderPool are separate modules instead of being embedded
  entirely in MediaEngine.
- Out-of-process OFX discovery via `koralo-ofx-scanner` and JSONL stdin/stdout IPC.
  Third-party OFX loading lives only in the scanner/inspector binary boundary.
- Long-project stability regression built from the supplied plush/CPU photograph:
  a 15-minute source, nine video tracks, repeated fade-in/fade-out overlaps and
  Anime Restore coverage. A bounded subset renders end-to-end and the full 15-minute
  stress render is started, observed for progress and then cancelled cleanly.

## Stability fixture

`tests_native/data/stability_plush.jpg` is the image supplied for the stability
scenario. CTest configures `KORALO_STABILITY_IMAGE` automatically, so the test is
self-contained in this source package.

## Important architectural boundary

The unified r43 package is still CPU-first. It deliberately does **not** claim that
99-layer realtime preview, FSR or a native GPU compositor are complete. Those belong
after the stabilized scheduler/frame-pipeline work. The nine-layer stability test is
there to detect crashes, bad project/render planning, transition/fade failures and
cancellation regressions; it is not a promise of realtime nine-layer CPU playback.

## Next phase

Stage 2 should add instrumentation and measurable frame-pipeline work: Performance
HUD/counters, byte-budgeted O(1) LRU, buffer reuse/FrameBuffer ownership, followed by
A/B scheduling and the GPU compositor.

## Final unified verification

A clean Debug build of the unified tree completed successfully for the GUI, CLI,
OFX scanner and all test executables. The final build used `-j1` after a parallel
compile exhausted the available container memory while compiling the still-large
`media_engine.cpp`; no source-code compiler error caused that parallel-build failure.

The following final unified tests passed directly: `koralo_native_tests`,
`koralo_effect_tests`, `koralo_animation_tests`, `koralo_media_concurrency_tests`,
`koralo_render_planner_tests`, `koralo_render_graph_tests`,
`koralo_playback_controller_tests`, and `koralo_runtime_tests`.

`koralo_long_project_stability_tests` also passed as a CTest target in about 25 seconds.
It generates a 15-minute source from `tests_native/data/stability_plush.jpg`, constructs
nine video layers with repeated 10-second fade overlaps, includes Anime Restore on the
stress timeline, fully renders a compact nine-layer/fade/Anime subset, then starts the
full 15-minute render, observes progress and verifies clean cancellation.

The full monolithic `koralo_media_tests` remains too slow in an unoptimized Debug build
for this execution environment. The Stage 1 optimized media-suite had already passed;
the final unified integration after that point only changes the self-contained stability
fixture/test, CMake test wiring, revision metadata and documentation, not MediaEngine
production behavior.

A GUI smoke test under virtual X11 remained alive until the external six-second timeout.
