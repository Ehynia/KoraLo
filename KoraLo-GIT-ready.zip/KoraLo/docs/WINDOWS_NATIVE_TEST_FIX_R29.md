# Windows native-test fix — r29

Revision: `2026-10-02-windows-native-tests-fix-r29`

The user-run Visual Studio 2022 build of r28 compiled and linked all KoraLo targets. `koralo_media_tests` passed, while `koralo_native_tests` terminated with Windows fast-fail `0xc0000409`.

The native suite runs the synthetic OpenFX discovery regression very early. Under Visual Studio multi-config generators, the synthetic module was emitted under `FakeBoris.ofx.bundle/Contents/Win64/Release/koralo_fake_ofx.ofx`. The scanner intentionally recognizes the standard bundle layout with the plug-in binary directly under `Contents/Win64`, so the test fixture was not in the location expected by the regression. The old regression also called the normal production OFX scan, which walks the machine's standard OFX folders and could therefore load unrelated third-party plug-ins during a unit test.

r29 changes the test path as follows:

- per-configuration Visual Studio output directories place the synthetic plug-in directly under `Contents/Win64`;
- the regression uses `OfxHostRegistry::scan_paths()` to scan only the synthetic fixture;
- the test fixture root is a relative `ofx_test` path, with CTest explicitly running from the build directory, avoiding a narrow compile-time absolute path through a non-ASCII Windows profile;
- native-test exceptions are caught and printed before returning a normal non-zero test status, avoiding an opaque fast-fail for ordinary assertion failures;
- the reported `std::fill` MSVC `C4244` warning now uses an explicit `std::uint8_t{0}` value;
- the lens-distortion temporary output was also moved to a separately sized byte buffer for cleaner bounds behavior.

The r29 shared source was rebuilt on Linux in Release mode and both native and media suites passed. An actual r29 MSVC run is still required before claiming Windows validation.
