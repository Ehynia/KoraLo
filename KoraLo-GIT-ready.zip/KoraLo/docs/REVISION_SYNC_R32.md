# KoraLo revision/package synchronization

Revision: `2026-10-02-revision-sync-r32`

`BUILD_REVISION.txt` is the only source revision marker. CMake and the Windows installer both read it directly, preventing the package guard from rejecting a newer source tree because an older hard-coded expected revision remained in the script.
