# KoraLo r45 — Multi-frame CPU export (Anime / FSR)

Ревизия: `2026-10-09-r45-parallel-export-frames`.

## Причина

До этого изменения `bake_native_video()` обрабатывал кадры строго по очереди:
`decode → Anime/FSR → RGBA copy → temporary raw → FFV1`, затем следующий кадр.
Распараллеливание строк внутри некоторых фильтров не означало одновременной
обработки разных кадров. При многопроходных CPU-эффектах оставались периоды
ожидания и высокая цена постоянного создания внутренних потоков.

## Что изменено

- `src/media/export_parallelism.hpp`: постоянный пул `OrderedFrameWorkers` из
  фиксированного количества потоков. Не создаёт новый OS-thread на каждый кадр.
- `src/media/native_export.inc`: единственный producer читает FFmpeg pipe в
  исходном порядке, затем отправляет **отдельную копию кадра** worker-потоку.
  В каждом worker'е независимо вычисляются Motion, FSR, Anime и native FX.
- Максимум `frame_workers` кадров в очереди; готовые буферы потребляются
  **строго в порядке индексов**. Прогресс увеличивается после успешной записи.
- `src/media/native_effects.cpp`, `src/media/fsr_upscaler.cpp`: внутренние
  parallel_rows получают лимит из thread-local `ExportInnerThreadBudget`.
  Например, на 24 логических ядрах: 8 frame workers × до 3 inner workers.
  Это предотвращает переподписку 8 × 16 потоков.
- По умолчанию число frame-workers: `min(8, max(1, hardware_concurrency/3))`,
  дополнительно ограниченное оценкой RAM (примерно 512 MiB на in-flight scratch
  buffers). Для крупных кадров количество workers уменьшается автоматически.
- Для диагностики и воспроизводимого A/B теста задаётся окружение:
  `KORALO_EXPORT_FRAME_WORKERS=1` (старый последовательный режим) либо 2–8.
  Качество, экспортные настройки, имена эффектов и формат `.kora` не менялись.

## Тесты

- `koralo_frame_worker_tests`: точный порядок, предел конкурентности, корректная
  обработка исключений, восстановление thread-local budget, memory limit.
- `koralo_export_parallel_tests`: одна и та же короткая сцена с **Anime Restore
  V45**, сначала export с 1 worker, затем с 4; чтение видеофайлов назад и
  сравнение декодированных RGB кадров. Результат: **полное совпадение пикселей**
  в проверенных временны́х точках.
- Проходили также `koralo_export_improvements_tests`, `koralo_effect_tests` и
  `koralo_media_concurrency_tests` (5/5 в выделенном CTest-прогоне).
- GUI `KoraLo`, CLI `koralo-cli`, helper `koralo-ofx-scanner` слинкованы
  в доступной Linux Debug конфигурации.

Измерение малой сцены 160×90, 18 кадров, Anime V45:
`serial=3.181 s; 4 workers=1.995 s` (из одного локального запуска).
Время зависит от окружения и не является обещанием скорости на Windows/1080p.
При тесте 640×360 с полным V45 наблюдалось превышение временного лимита;
полный 1080p/3-минутный экспорт на пользовательском ПК не тестировался.

## Что **ещё не** оптимизировано

1. FFmpeg decoder по-прежнему выдаёт кадры последовательно в одном pipe —
   это нормально для сохранения порядка; A/B decoding отдельных источников
   требует отдельного scheduler.
2. После каждой пачки KoraLo всё ещё запускает отдельный FFV1 encoder и
   использует временные сегменты/concat. Encoder пока **не перекрывается**
   полностью со следующей пачкой. Это следующий большой шаг.
3. Anime Restore V45 и FSR EASU/RCAS — CPU-эффекты; GPU-вычисление фильтра
   этим патчем не появилось. Наличие NVENC/QSV само по себе не ускорит Anime.
4. Render Native Project по-прежнему может запекать **разные клипы** по очереди.
   Новая параллельность применяется **внутри одного запекаемого клипа**.
5. Требуется отдельный профилируемый тест реального 1080p 29.97 FPS на Windows,
   с `KORALO_EXPORT_FRAME_WORKERS=1`, затем по умолчанию, при одинаковых
   настройках и без фоновой игры. Проверить elapsed, CPU usage KoraLo/FFmpeg,
   память и hash/паритет финального результата.

## Сборка

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 1
ctest --test-dir build -R 'koralo_(frame_worker|export_parallel|export_improvements|effect|media_concurrency)_tests' --output-on-failure
```

Сборка в этой среде была Debug и использовала Clang для компиляции очень
тяжёлого `media_engine.cpp`; полноценная Windows-сборка и GPU-runtime не
проверялись. Изменения упакованы как отдельная ветка поверх r45, исходный
архив не перезаписан.
