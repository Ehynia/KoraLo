# DPI scaling fix r34

Revision: `2026-10-02-dpi-scaling-fix-r34`

## Problem

At 1440p/2K with fractional UI scaling, the old `ScaledCanvas` rounded a rectangle origin and its width/height independently. One logical 1 px row could therefore map to a physical row that did not share an exact edge with the next row. Supersampled icon masks and rounded UI elements are composed from many adjacent tiny rectangles, so 125%/150% scaling could create visible seams, broken circles and split icon strokes.

The editor also inferred UI scale from the current window pixel dimensions. Maximizing a window on a 2560x1440 display therefore forced 1.25x UI scaling even at 100% Windows DPI, while resizing the same window could change the UI scale.

## Fix

- `ScaledCanvas` now transforms both rectangle edges and derives the physical width/height from those transformed edges. Adjacent logical rectangles therefore remain adjacent at fractional scale factors.
- Windows uses per-monitor-v2 DPI awareness when available.
- Windows passes `GetDpiForWindow()/96` to `EditorApp` as the explicit UI scale instead of inferring scale from 2K/4K resolution.
- `WM_DPICHANGED` updates the scale and accepts the Windows suggested window rectangle.
- Linux keeps the existing resolution fallback, but benefits from the crack-free edge mapping as well.

## Validation

Release build and native/media tests pass on Linux. A 2560x1440 Xvfb smoke run was captured at the fractional scaling path. Windows/MSVC runtime DPI behavior still requires validation on a real Windows monitor.
