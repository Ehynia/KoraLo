# r43 Stage 0 — stabilization, part 1

This package continues from the localized r42 archive and intentionally does not merge the experimental OFX IPC prototype yet.

## Timeline vertical scrollbar

The r42 timeline drew a vertical scrollbar indicator, but the bar had no independent hit-testing or drag state. Mouse-wheel vertical scrolling worked, while clicking or dragging the visible thumb did not behave like a real scrollbar.

The fix introduces shared `TimelineVerticalScrollMetrics` in `edit_controller` so drawing, clamping and pointer mapping use the same values:

- total track content height;
- timeline-body viewport height (`height - ruler_h`);
- `max_scroll = max(0, content_height - viewport_height)`;
- thumb size from `viewport_height / content_height`, with a minimum usable thumb size;
- thumb travel and scroll-to-thumb / thumb-to-scroll mapping.

`EditorApp` now stores the vertical scrollbar track/thumb rectangles and a drag state. Mouse-down supports both direct thumb grabs and page-style track clicks, mouse-move updates `scroll_y`, and mouse-up ends the drag. The scrollbar rectangles are cleared when scrolling is not needed so stale hit zones cannot remain active.

A native regression test verifies the content/viewport ratio, maximum scroll, top/bottom mapping and round-trip drag mapping. The existing scroll-aware track hit-test remains in place.

The GUI was also tested under X11 with a synthetic 12-track project: dragging the visible vertical thumb from the top to the bottom moved the viewport from the first video tracks to the lower audio tracks.

## Warning Zero pass

The current GCC build is warning-clean after this pass.

### `src/core/project.cpp`

- split misleading single-line control flow around the minimum-record check;
- made duplicate `SETTINGS` handling explicit with braces;
- made the generated text/vector ownership check explicit before enabling generated text;
- removed `-Wshadow` for the `name` lambda argument and `media` loop variable.

### `src/ui/editor_app.cpp`

- split the recording-stop and project-replace confirmation in `import_vegas_project()` into independent explicit statements, removing `-Wmisleading-indentation`.

### `src/media/media_engine.cpp`

- explicitly initialize `ThumbnailRequest::vector_source`;
- extracted the solo-filter expression into a named boolean, removing precedence ambiguity;
- separated the final progress update and `return true`, removing misleading indentation.

A complete Debug build finishes with no compiler `warning:` lines.

## Project round-trip regression

A new semantic round-trip test performs:

`Project -> save -> load -> save -> load -> semantic assertions`

The assertions cover:

- project dimensions, fps and sample rate;
- preview quality, preview FPS limit and prepared-cache flag;
- snapping, crossfade, ripple, grouping, slip-all-takes and frame quantization flags;
- video/audio track names, states, levels, heights and track effects;
- imported audio-FX identities;
- generated text settings;
- generated vector scene fingerprint;
- event/take state, timing, fades, loop/mute and active take;
- video-motion state and keyframes;
- event/audio/output effects;
- markers.

Negative load tests also verify that duplicate `SETTINGS` records and conflicting generated-media ownership (`GTEXT` followed by `VANIM` on the same media item) are rejected rather than silently accepted.

## Verification

- full Debug application build: PASS;
- GCC warnings in full build: 0;
- `koralo_native_tests`: PASS;
- `koralo_effect_tests`: PASS;
- `koralo_animation_tests`: PASS;
- `koralo_runtime_tests`: PASS;
- interactive 12-track vertical scrollbar drag: PASS.

`koralo_media_tests` is not counted as green in this Debug verification. The existing odd-size JPEG + Anime-FX timing assertion exceeds its short wait window in the unoptimized build. This Stage 0 patch does not change that Anime processing path; the optimized media suite should be used for release verification.

## Next Stage 0 work

1. ASan + UBSan test build.
2. TSan pass focused on media/cache/worker threads.
3. Investigate or make the media timing regression deterministic across Debug/Release configurations.
4. Only after sanitizer cleanup, begin the Core Split phase.
