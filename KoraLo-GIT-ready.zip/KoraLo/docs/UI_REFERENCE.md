# KoraLo native workspace UI reference

The supplied `vegasproclone.html` / `vegasproclone(2).html` mockup is used only as an observable layout/style and control-placement reference. It is not linked into the product, embedded in a WebView, or shipped as the application UI.

## Mapped workspace regions

- Top command bar -> `EditorApp::draw_toolbar`.
- Project Media pane -> `EditorApp::draw_bin`.
- Video Preview / transport / Master -> `EditorApp::draw_preview`.
- Timeline toolbar, ruler, track headers, events -> `EditorApp::draw_timeline` and `draw_clip`.
- Palette -> native constants in `src/ui/canvas.hpp`.

## Functional-control audit

Visible button-like controls in the current Canvas UI are either connected to a real command or disabled when their required context is unavailable. The pass covers New/Open/Save/settings, Undo/Redo, Cut/Copy/Paste, Snap/Lock/Marker, Import/Proxy/Render/Help, Project Media List/Grid/Search/type filters, Preview quality/Fit/transport/tabs, Trimmer In/Out/Insert/Overwrite, timeline Select/Split/Lock/Snap/Ripple/Add Track, track Lock/Mute/Solo, the Video FX entry point/opacity controls, and Auto Crossfade.

Track level/opacity and audio pan are direct clickable controls rather than `Button` objects. Mute/solo/opacity/gain/pan/crossfade states feed preview visibility or final rendering as currently supported. Locked events/tracks block destructive edit gestures.

The Media Generators pane deliberately does not display nonfunctional generator buttons: a real native generator object/model is still future work. Likewise, the Master meter is a presentation placeholder until the realtime mixer exists, and the event corner fade drawings are affordances rather than toolbar buttons.

## Assets

The user-supplied `vegaspro_icons` archive contains Font Awesome Free SVG assets and license material. Redistributable SVGs are staged under `assets/icons/fontawesome/` with the license recorded in `THIRD_PARTY_NOTICES.md`. They are not loaded through HTML/CSS and there is no web runtime; the current Canvas renderer still uses compact native text labels until SVG/native icon drawing is added.

## Current intentional approximations

The native Canvas abstraction currently provides rectangles, lines, text, and decoded frames, not a dock/widget/SVG framework. Native placeholder thumbnail strips remain until decoded thumbnail caching lands. Audio meter values remain presentation placeholders until the realtime audio mixer/meter path exists. Video Preview is still a source-frame preview rather than the future full compositor output.

## Follow-up UI work

- draggable horizontal/vertical pane splitters and real dock/tab model;
- decoded media/event thumbnail cache;
- real audio peak/RMS meters;
- native SVG/icon rasterization and DPI-aware metrics;
- richer project settings editor;
- full generator, EffectDefinition/EffectInstance, transition and compositor editors;
- platform cursor changes for trim/roll/slide/ripple/fade modes.

## 2026-10-01 native icon / Win32 paint hardening

The supplied Font Awesome SVG reference assets are converted during development to a generated 16x16 C++ bitmap atlas (`src/ui/icon_atlas.hpp`). KoraLo does not load SVG, HTML, CSS, WebView, Electron, or an icon font at runtime. The atlas is drawn through the existing native Canvas abstraction on both Win32/GDI and X11.

The Windows frontend now renders each complete UI frame into a persistent compatible back buffer and presents it with a single `BitBlt`. This removes the visible intermediate states that were previously observable while dragging timeline controls. Track level/pan sliders use preview-only UI state during drag and commit one undoable project change on mouse-up.
