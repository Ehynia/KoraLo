# r17 — HiDPI UI, still media and preview/cache pass

Revision: `2026-10-02-hidpi-photo-preview-cache-r17`

## Native UI / large displays

KoraLo keeps the existing native Canvas abstraction. `EditorApp` now chooses a logical UI scale from the physical window size and draws through a scaled Canvas wrapper; pointer, wheel and drop coordinates are converted back to the same logical coordinate system. This keeps hit-testing and painting aligned while giving 1440p/4K-class windows larger text and controls instead of simply exposing more tiny pixels.

Win32 opts into process DPI awareness. X11's Canvas text implementation now caches fonts by requested size/weight and therefore respects the UI's logical text sizes. The dark theme also adds layered panel/button/preview/Event shadows and highlights using only native drawing primitives.

## Still-image media

Recognized still-image extensions are `png`, `jpg`, `jpeg`, `bmp`, `webp`, `tif` and `tiff`.

- Probe exposes stills as video-only media and assigns a 5-second editable default duration when the container has no duration.
- A still TrackEvent can be right-trimmed beyond that nominal duration.
- Exact frame decode normalizes the still's source time to zero, so a paused playhead at a later Event-local time still displays the image.
- The persistent sequential decoder loops a still input for continuous playback.
- Final render loops the still input at project render FPS for the full Event duration.
- Background preparation warms one source image and avoids generating a long-form optimized proxy for a still.

## Detach audio from video

An Event context command, **Detach Audio from Video**, is available for linked A/V groups. It clears the common group id for the group members in one project transaction; the action is undoable and reselects the clicked Event for independent editing.

## Preview pipeline

r17 separates source decoding from realtime preview compositing:

1. decode/scale the source frame;
2. retain it in a source-frame LRU cache;
3. apply Pan/Crop motion and supported built-in Event FX in-process;
4. apply Event/track/fade opacity;
5. keep the finished result in the existing composite frame cache.

Changing an FX or Pan/Crop control clears only the composite cache. A stationary frame therefore does not respawn FFmpeg simply because a parameter changed. Consecutive playback with dynamic Pan/Crop/FX also remains on the persistent raw-video FFmpeg pipe rather than dropping to one process per output frame.

The realtime CPU path intentionally favors responsiveness. Some blur, chroma-key, sharpen and transform sampling details are approximations of the authoritative final FFmpeg render. Exact shader-level parity belongs to the planned native GPU compositor.

## Prepared/optimized cache

For ordinary video sources of at least 20 seconds, background preparation now creates a seek-oriented all-I H.264 cache (hardware encoder attempt with CPU fallback). CPU generation uses x264 fast-decode settings and a one-frame GOP. Timeline filmstrip thumbnail requests resolve this prepared path when it exists, so completed background preparation also improves timeline navigation/random thumbnail seeking.

Best/Full-quality behavior and the user's explicit proxy choice remain separate. An arbitrary uncached source-frame miss can still require one exact FFmpeg process; once that raw frame is cached, repeated FX edits at the same source/time reuse it.

## Validation scope

Native tests cover still-event extension and linked A/V detach/Undo. Media tests cover persistent FX playback reuse, source-frame cache reuse across FX changes, still-image preview and still-image final render. Linux Release build + X11 smoke are used for this revision. Windows/MSVC is not claimed until it is actually built on Windows.

The supplied VEGAS 17 and OpenColorIO backup archives remain clean-room research/reference inputs only; no proprietary implementation code is copied into KoraLo.
