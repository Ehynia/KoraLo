# Runtime localization + context menus (r14)

## Runtime language packs

KoraLo now has an external `locales/` directory. Each language is a UTF-8 `*.lang` file containing flat `key=value` entries plus `meta.code` / `meta.name`.

The executable discovers language packs at runtime beside the executable and from the development root. Missing keys fall back to `en-US`, then to the fallback text at the call site. CMake copies the full `locales/` directory beside `KoraLo` after each build and installs it with the application.

`KORALO_LANG=<locale>` can select a pack before launch. Preferences exposes a language cycle control using the discovered pack list. New languages therefore do not require recompiling the C++ application.

The current Win32 text path is fully Unicode (`TextOutW`). The legacy Linux X11 canvas still uses core X11 text drawing; ASCII locales are reliable there and the planned Xft/font renderer upgrade is required for full non-Latin display parity.

## Right-click workflow

KoraLo now routes mouse button 3 through the same native Canvas UI on Windows and Linux. Menus are generated from actual editor state; disabled or unimplemented commands are not presented as working actions.

Implemented targets:

- Video/audio event: Open in Trimmer, Pan/Crop (video), Event FX (video), Cut/Copy/Delete, Trim Start/End Here, Split Here, Loop, Lock, Next/Previous Take when applicable.
- Empty timeline: Import, Paste Here, add Video/Audio Track, Marker Here, Preferences.
- Track header: add tracks, Lock, Mute, Solo.
- Project Media item: Open in Trimmer, Add to Timeline at Cursor, Create Optimized Media/Proxy.

Context edits reuse the existing transaction-based edit controller and undo stack.
