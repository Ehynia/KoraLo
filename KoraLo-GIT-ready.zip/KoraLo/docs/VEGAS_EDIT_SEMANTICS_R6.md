# VEGAS 17 editing-semantics research — clean-room notes (r6)

This document records observable/public behavior used to design KoraLo.  It is **not** a copy of VEGAS internal implementation code.  KoraLo's implementation is independently written in C++20.

## Sources examined in the supplied VEGAS17 research bundle

- shipped `Script Menu/Group Video and Audio Events.cs`;
- shipped `Script Menu/Export EDL.js`;
- shipped `Script Menu/Repair and Smooth unwanted Section.cs`;
- public managed facade metadata in `ScriptPortal.Vegas.dll` (member/type names only);
- supplied VEGAS 17 UI screenshots for command grouping and visible behavior.

## Findings directly supported by the supplied materials

### Media / Take / TrackEvent are distinct concepts

`Export EDL.js` obtains `currentEvent.ActiveTake`, computes source-in from the active take's `Offset` (plus media timecode-in), and computes timeline-in from `currentEvent.Start`.  It separately reads `currentEvent.Length` and `currentEvent.PlaybackRate`.

KoraLo consequence: source identity/offset cannot remain flattened into a timeline event.  r6 introduces `Take { media_id, offset, name }` and a canonical `TrackEvent` containing a take list plus an active-take index.  Timeline `start/duration/rate` remain event properties.

### Linked audio/video grouping is event-level, not media-level

The shipped `Group Video and Audio Events.cs` searches video/audio `TrackEvent`s and groups events only when their timeline Start and End match and their active takes reference the same Media.  A `TrackEventGroup` is then created and populated.

KoraLo consequence: linked A/V remains an explicit event-group relationship.  Sharing a MediaItem alone does not imply a permanent link.

### Splitting grouped events requires explicit group handling

The shipped `Repair and Smooth unwanted Section.cs` records the group size, splits each member, then explicitly creates another `TrackEventGroup` and moves one side of the split into it.  The script comment describes this as splitting one group into two.

KoraLo consequence: r6 no longer leaves both halves of a linked A/V split under one group id.  The left side keeps one group and the right side receives a separate group id, so later group-aware edits operate on the corresponding side only.

### Crossfade/transition behavior is tied to event fades and overlap

`Export EDL.js` derives dissolve length from the next event's `FadeIn.Length`.  `Repair and Smooth unwanted Section.cs` moves the following event to create an overlap and assigns a transition to that event's `FadeIn` for video.

KoraLo consequence: automatic crossfade rendering treats overlap as a fade-in on the later event and a corresponding fade-out on the earlier event.  Dedicated Transition objects/effect instances remain future work.

### Public TrackEvent/Take surface includes additional editing state

Managed metadata exposes names including `Takes`, `ActiveTake`, `FadeIn`, `FadeOut`, `PlaybackRate`, `Loop`, `SnapOffset`, `Take.Offset`, and `Take.AvailableLength`, plus take add/remove/active-take operations.

KoraLo consequence in r6: multi-take state, active take, event loop, snap offset, and playback rate live in the event/take model.  Further fade-curve/interpolation details still require observation/testing before implementation.

## Independent KoraLo behavior added in r6

The following choices are KoraLo implementation decisions informed by the model above; they should not be read as claims about undocumented VEGAS internals:

- timeline left trim advances every Take offset by the same source delta so alternate takes stay synchronized;
- ordinary Slip changes the active Take; `Slip All Takes` applies the same delta to every Take;
- group-aware vertical moves preserve relative track-kind position (video events move among video tracks, audio among audio tracks);
- Quantize to Frames rounds edit boundaries to the current project frame grid;
- split with no explicit selection cuts events intersecting the edit cursor;
- looped events may extend beyond finite source duration and wrap source time in preview/render.

Each behavior above has native regression coverage so it can be changed deliberately if later observation shows a semantic mismatch.

## Still to research

- exact take-offset behavior for every trim variant when alternate takes have unequal available ranges;
- event heal / close gaps / smart split;
- Post-Edit Ripple command boundaries and all affected-track cases;
- time selection / loop region semantics;
- fade curve types and transition ownership;
- audio event channel mapping / resample modes;
- Pan/Crop coordinate system, keyframe interpolation, masks and workspace behavior;
- exact renderer/template persistence and project-range render semantics.
