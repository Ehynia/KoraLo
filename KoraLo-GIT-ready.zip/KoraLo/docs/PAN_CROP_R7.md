# Event Pan/Crop — r7

KoraLo r7 adds the first compositor-side event motion editor. The workflow is inspired by observable professional NLE behavior, while the implementation is independent C++20 code.

## Data model

`TrackEvent` owns `VideoMotion`. `VideoMotion` is composed of four independently animated parameters:

- normalized `center_x`;
- normalized `center_y`;
- `zoom` (1.0 = full project frame, larger values zoom in);
- `rotation` in degrees.

Each parameter owns its own `Keyframe` list through `AnimatedDouble`. Keyframe times are event-local timeline seconds. Linear and hold interpolation are represented in the core model; the r7 UI creates linear keys.

## Interaction

A `P/C` button is drawn on video events. It opens the native `Video Event Pan/Crop` editor:

- drag the visible frame to pan;
- drag a corner to zoom;
- use +/- rotation controls;
- scrub the event-local keyframe timeline;
- add/delete/reset keys;
- the first edit away from time zero automatically preserves the default state at time zero.

Pan/Crop drags are transaction based. During the pointer gesture only a temporary `VideoMotionSample` changes. The Project is changed once on mouse-up, producing one undo entry.

## Split semantics

Splitting an event also splits its motion animation. KoraLo samples the motion at the split time, puts that state at the end of the left event and at local time zero of the right event, and shifts later keys into the right event. This preserves visual continuity while keeping both resulting events independently editable.

## Preview and render

The async preview request now optionally carries a sampled event motion state, and the FFmpeg preview filter applies zoom/crop/rotation before returning the frame.

The final render graph builds time-dependent FFmpeg expressions from the parameter-owned keyframes, so Center, Zoom and Rotation animate during final render rather than existing only in the editor UI.

## Current limits

This is the first compositor node, not the final compositor architecture. r7 still lacks masks, per-corner perspective, Track Motion, Bézier interpolation, independent width/height crop, safe-area overlays, spatial snapping and GPU execution. Those should layer on the same parameter/keyframe model rather than creating new timeline-only special cases.
