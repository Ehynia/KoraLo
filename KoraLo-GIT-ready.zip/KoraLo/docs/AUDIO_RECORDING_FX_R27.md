# r27 — Audio recording and Audio FX

Revision: `2026-10-02-audio-recording-fx-r27`

## Recording workflow

The timeline toolbar exposes **REC**. Starting recording pauses normal playback, chooses the selected audio track (or the first audio track), and creates an audio track if none exists. The playhead advances while capture is active. Clicking **REC/STOP** again finalizes the capture and inserts the resulting media as a normal audio TrackEvent at the original cursor position.

Saved projects place recordings in a sibling `Recordings/` directory. Unsaved projects use a KoraLo recording folder in the OS temporary directory. Capture is shell-free through the platform process layer and FFmpeg input backends: DirectShow on Windows; PulseAudio with ALSA fallback on Linux.

KoraLo deliberately captures headerless PCM16 during the live process and writes the WAV RIFF container itself on stop. This prevents a force-terminated FFmpeg process from being the owner of the final WAV header. The native media regression constructs raw PCM, finalizes it through this path, then probes the WAV again.

## Native Audio FX

Audio FX are independent from Video FX and can live on an audio Event or an Audio Track. r27 includes:

- Echo / Delay
- Room Reverb
- Chorus
- Flanger
- Compressor
- Limiter
- Noise Gate
- 3-band EQ
- High Pass
- Low Pass
- Distortion
- Tremolo
- Stereo Width
- Gain

The same ordered effect chain is serialized in `.kora` v13 and consumed by both realtime audio preview and final render. Parameter changes participate in Undo/Redo. VEGAS Noise Gate, Track EQ and Track Compressor identities can be mapped to disabled native equivalents, but original private parameter blobs are not guessed.

## Validation and limits

Linux Release build and native/media regressions pass. The final GUI smoke verifies the Audio FX browser and REC control. The CI/Xvfb environment has no physical microphone device, so actual hardware input capture cannot be claimed as end-to-end validated here. The next audio architecture step remains a native low-latency mixer/master clock, device selection, input monitoring, buses/sends and automation.
