# KoraLo r11 — timeline, media preflight, FX drag and render presets

This revision is a clean-room KoraLo implementation informed by observable NLE workflow. It does not copy proprietary VEGAS implementation code.

## Timeline

- The native editing horizon is capped at 12 hours (43,200 seconds).
- Add/move/nudge/insert/overwrite/ripple operations are constrained to the horizon.
- A persistent horizontal scrollbar represents the visible window within the 12-hour timeline.
- Middle-mouse drag pans time; Ctrl+wheel zooms around the pointer; Shift+wheel scrolls horizontally; normal wheel scrolls tracks.

## Pan/Crop

- Event-local Pan/Crop now exposes an orange rotation handle.
- Rotation drag is transactional and writes the same parameter-owned keyframe model as Pan/Zoom.

## Startup/media preflight

- Startup performs a lightweight system check: CPU thread count, FFmpeg/FFprobe/FFplay, GPU backend and temp-folder writability.
- Imported media is probed once, then representative thumbnail frames and audio envelopes are queued asynchronously.
- Render As performs the same cache warmup/preflight before starting the background render.

## Video FX

- FX rows can be dragged directly from Video FX and dropped on a video TrackEvent.
- The drop creates one undo transaction and the effect is immediately part of preview/render.

## Render As

- Render As is now a native preset panel instead of immediately opening a filename dialog.
- Presets include 1080p30/60, 1440p60 and UHD 2160p30/60 plus a high-bitrate editing preset.
- Width, height, frame rate, video bitrate, audio bitrate and GPU encoding can be changed before each render.
- GPU encode retains CPU fallback.
