# Anime Restore filter pack — r22

The supplied Anime Line Restore V45 script is treated as user-provided algorithm/reference material. KoraLo does not embed or execute its Python runtime. The visual stages are represented as ordinary native KoraLo effects so they can be reordered, bypassed, saved, undone and eventually accelerated by the compositor.

Implemented filters:

- Anime Line Restore — line strength, detector threshold, width, edge hardness, original-line color pull, max luma.
- Anime Vector Colors — saturation, contrast, fill smoothing, color levels, original blend.
- Anime Text Restore — text threshold and text boost.
- Anime Paper Texture — texture amount and warmth.
- Anime Detail Sharpen — final detail amount.
- Anime Deinterlace — preview interpolation and final `bwdif` render path.

The GUI defaults mirror the supplied Gradio controls: line strength 0.65, threshold 22, line width 0.8, sharpening 0.5, original blend 0.45, saturation 1.25, contrast 1.10, flatness 0.65, 48 color levels, paper texture 0.015, warmth 0.04, text threshold 0.10 and boost 0.20.

Not represented as fake stateless filters:

- character isolation via rembg/u2net — needs the planned AnalysisJob/model/cache layer;
- temporal confirmation — needs previous-frame state and compositor prefetch;
- IVTC — changes source cadence/duration and therefore belongs in media/source preparation, not a normal Event FX.

Realtime preview runs on the already-decoded RGB frame inside KoraLo. Final render currently uses compatible FFmpeg graph approximations for the line/color/text stages and exact standard filters where available (for example `bwdif` and `unsharp`). A future native GPU compositor should make preview/export use the exact same kernels.
