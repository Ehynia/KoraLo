# KoraLo r45 — CUDA + FSR / GPU Stage 1

Дата: 2026-10-10. Ревизия: `2026-10-10-r45-cuda-fsr-fallback-fixes`.

## Что реализовано

- *Опциональная* сборка CUDA посредством `KORALO_ENABLE_CUDA=ON` и найденного NVIDIA CUDA Toolkit. Без toolkit используется portable CPU stub. Не нужно CUDA SDK на ПК конечного пользователя, если приложение собрано с CUDA runtime (но NVIDIA драйвер и совместимая видеокарта нужны).
- FSR 1-совместимая **EASU + RCAS адаптация KoraLo**: CUDA kernels плюс сохранённый CPU fallback. Это **не FSR 2/3** и не гарантия побайтной идентичности CUDA и CPU.
- Частично GPU-ускорен **Anime V45 spatial pipeline**: большие двухпроходные Gaussian Blur и morphology (min/max). Только при включённом GPU, ≥1280×720 и наличии CUDA; иначе прежний CPU.
- Разрешение GPU определяется *для конкретного export job*, глобальный GPU-off не игнорируется. Scope ограничен кадром worker'а, иначе одна задача могла влиять на другую.
- CUDA failures (no driver, нет памяти, ошибка выполнения) оставляют CPU-рендер рабочим; FSR GPU/CPU backend decision фиксируется в render-control log и в диагностике.
- GPU-энкодер FFmpeg (NVENC при наличии) уже поддерживался ранее и сохранён; при ошибке — software encoder fallback.

## Исправление FSR «кадр 13»

Сообщение `FSR/native source decode failed at frame 13` сообщает **номер кадра, на котором декодер неожиданно достиг EOF**, а не «CUDA Error 13». Раньше FFmpeg дополнял источник лишь на секунду (`tpad=...:stop_duration=1`). Если клип продлён дальше реального видео, этого могло не хватать. Теперь последний кадр повторяется до точно необходимого числа кадров: `tpad=stop_mode=clone:stop=-1` с явным `-frames:v N`. Текст ошибки содержит `frame N/total` и исходную ошибку pipe. Это исправление предотвращает конкретный класс обрывов; точную причину сообщения на ПК пользователя можно установить только по его логу.

## Где ещё CPU-only

- Полный Anime V45: edge maps, tone/color curves, paper procedural texture, mask processing, текстовые участки, композиция, Pan/Crop — остаются на CPU (частично многопоточном). Их нельзя честно назвать перенесёнными на GPU.
- Видеодекодирование зависит от FFmpeg/драйвера; не весь pipeline zero-copy. CUDA FSR и пространственные операции принимают кадры из RAM и возвращают их туда, что добавляет PCIe transfers.
- Новые CUDA kernels не проверены на реальной NVIDIA GPU в данной Linux-среде — нет `nvcc`, NVIDIA-драйвера и CUDA-устройства. Это **исходная реализация с тестируемым CPU fallback**, а не сертифицированная Windows CUDA-сборка.

## Windows / MSVC

1. Установить Visual Studio 2022 C++ Build Tools + Windows SDK + NVIDIA CUDA Toolkit, совместимый с версией MSVC.
2. Убедиться, что `nvcc --version` доступен в Developer PowerShell.
3. Пример сборки:

   ```powershell
   cmake -S . -B build-win-cuda -G "Visual Studio 17 2022" -A x64 -DKORALO_ENABLE_CUDA=ON -DKORALO_BUILD_TESTS=ON -DCMAKE_CUDA_ARCHITECTURES="75;86"
   cmake --build build-win-cuda --config Release --parallel
   ctest --test-dir build-win-cuda -C Release --output-on-failure -R "gpu_fsr|export_improvements|frame_worker"
   ```

4. `CMAKE_CUDA_ARCHITECTURES` нужно настроить под свою модель GPU и поддержку выбранного CUDA Toolkit. CMake сообщает, нашёлся ли CUDA compiler.
5. Без CUDA Toolkit сборка остаётся CPU-compatible; NVENC может работать через FFmpeg независимо от сборки собственных CUDA kernels.

## Проверки

- Linux Release: пересобран `koralo_core`, FSR native/export, новый `koralo_gpu_fsr_tests`, worker-pool regression.
- Кадры: CPU против GPU-request fallback (MAE < 3) и корректные alpha/размер, проверка `NativeCudaScope`.
- End-to-end: клип длительностью 3 секунды с исходником ровно **один кадр**, FSR 64×36 → 128×72, без преждевременного EOF.

Не выполнено: runtime/parity тесты **на настоящей NVIDIA GPU под Windows**, GPU perf benchmark 1080p/4K. Их нужно выполнить на целевом ПК.
