# KoraLo r45 — Streaming Export + Audio Sync Fix

Ревизия: `2026-10-09-r45-streaming-export-audio-sync`.

## Многокадровый экспорт: вторая итерация

В `src/media/native_export.inc` удалён цикл временных `.rgba` партий, отдельных `.mkv`-сегментов FFV1 и финального concat. Один FFmpeg encoder получает обработанные RGBA кадры по **stdin pipe** всё время работы с данным клипом. Декодер остаётся последовательным, а `OrderedFrameWorkers` одновременно обрабатывает до заданного количества кадров в независимых потоках и отдаёт их по порядку. Один FFV1 encoder работает одновременно с обработкой следующих кадров. Файлы raw batch более не создаются; готовый MKV публикуется только после завершения encoder, проверки exit code и заголовка Matroska.

`src/platform/process.*`: добавлены `ReadPipeProcess::write_stdin_chunk` и `close_stdin` для потоковой передачи крупных бинарных данных. В POSIX потоке записи локально блокируется SIGPIPE; если encoder упал, ошибка записи возвращается, а приложение не завершается сигналом. Windows использует `WriteFile` и корректную передачу stdin через `CreateProcessW`. Нет оболочки shell.

## Аудио во время монтажа

В `src/ui/editor_app.cpp` исправлен seek во время Play: drag плейхеда теперь не оставляет запущенный `ffplay` звучать со старого таймкода. При начале scrubbing старый audio preview выключается, при движении обновляются playback wall-anchor и video preview, а после отпускания мыши `ffplay` синхронизируется один раз с новым временем. Не создаётся новый audio process при каждом пикселе перемещения мыши.

Изменение громкости/панорамы трека во время Play теперь обновляет audio preview. В `src/media/audio_preview_timing.hpp` ограничивается диапазон non-loop аудио реальной продолжительностью источника. Это препятствует попыткам заново запускать звук, когда timeline event длиннее звукового файла. Loop и playback rate учитываются отдельно.

## Проверки

- `koralo_export_parallel_tests`: PASS, сравнение кадров serial/parallel побайтно.
- `koralo_export_improvements_tests`: PASS, FSR + paper, совместимый экспорт аудио/видео, отказ при повреждённом encoder, корректная отмена и сохранность предыдущего файла.
- `koralo_frame_worker_tests`: PASS.
- `koralo_media_concurrency_tests`: PASS.
- `koralo_stream_pipe_tests`: PASS, 16 записанных RGBA кадров → один FFV1 MKV с 16 кадрами; EOF; сбой дочернего FFmpeg не убивает основной процесс.
- `koralo_audio_preview_timing_tests`: PASS, clipping на концах, rate, loop и вне клипа.
- GUI, CLI и OFX scanner: Linux Debug build/link PASS.

Короткий локальный serial vs 4-worker тест (160×90, Anime): serial 2.03 с, parallel 0.94 с на одном прогоне. Это не benchmark для 1080p; скорость на Windows и реальном проекте нужно отдельно измерить.

## Что не решено

В `MediaEngine` пока остаётся **несколько `ffplay` процессов** для одновременных аудиоклипов. Поэтому точный sample-accurate A/V sync при сложном миксе, эффектах/задержках или нестандартных звуковых устройствах ещё не гарантирован. Следующий архитектурный этап — единый native audio mixer с master audio clock и синхронизацией видео по нему.

FFV1 остаётся как **один lossless промежуточный файл на native-clip**; дополнительный composition/final-encode при сложном render graph пока сохраняется. В данной ревизии устранены тысячи коротких сегментов и concat внутри bake, но не весь промежуточный export graph.
