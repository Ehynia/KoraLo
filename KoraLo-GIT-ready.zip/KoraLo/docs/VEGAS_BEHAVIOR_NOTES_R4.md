# VEGAS behavior notes used for KoraLo r4

These notes are clean-room behavior observations from the supplied screenshots and the public scripting/object-model research already collected for the project. They are not a copy of VEGAS implementation code.

## Main command surface

The supplied VEGAS 17 screenshots show a conventional top menu split into File, Edit, View, Insert, Tools, Options and Help. KoraLo r4 introduces the same *workflow categories* but wires them only to KoraLo's own commands and models.

Current KoraLo mappings:

- File: New, Open, Save, Save As, Import Media, Render As, Project Properties, Exit.
- Edit: Undo, Redo, Cut, Copy, Paste, Delete, Split at Cursor.
- View: Project Media, Video FX, Transitions, Video Preview, Trimmer.
- Insert: Video Track, Audio Track, Marker.
- Tools: Create Proxy, Render As, Media Diagnostics.
- Options: Snapping, Automatic Crossfades, Ripple mode, Preferences.
- Help: Keyboard Shortcuts, About.

Unsupported VEGAS commands are deliberately not exposed as fake menu entries yet.

## Preferences / Project Properties

The screenshots separate application preferences from per-project properties. KoraLo now follows that separation:

- Preferences: preview quality, realtime audio-preview enable/disable, snapping and automatic crossfades, plus backend/font status.
- Project Properties: width, height, frame rate, sample rate and common HD/UHD templates. Applying changes is one undoable Project transaction.

The current project settings model is intentionally smaller than VEGAS. Pixel format, field order, color-management transforms, deinterlace/resample policies and other advanced settings remain future model work.

## Render As

The supplied Render As screenshot reinforces the existing architecture decision that renderers/templates belong above the encode backend. KoraLo still uses its current simple MP4 path in r4; Renderer/RenderTemplate objects remain a later milestone rather than hard-coding VEGAS template names.

## Event Pan/Crop

The supplied Event Pan/Crop screenshot confirms that spatial event transforms need their own parameter/keyframe model and should not be baked into timeline dragging. KoraLo will implement this on top of the planned compositor node graph (`transform`, `crop`, `opacity`) and parameter-owned keyframes rather than copying VEGAS UI/internal implementation.
