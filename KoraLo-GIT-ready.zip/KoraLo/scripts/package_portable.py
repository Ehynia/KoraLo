#!/usr/bin/env python3
"""Package prebuilt, trusted KoraLo and FFmpeg binaries. No downloads.
Python is a developer packaging tool; the editor has no Python dependency.
"""
import argparse, hashlib, json, re, shutil, subprocess
from pathlib import Path
SOURCE=Path(__file__).resolve().parents[1]
def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def script(target,text):
    target.write_text(text,encoding='utf-8',newline='\n');target.chmod(0o755)
def dependencies(binary):
    result=subprocess.run(['ldd',str(binary)],check=True,capture_output=True,text=True)
    if 'not found' in result.stdout:raise RuntimeError('Missing dependency: '+result.stdout)
    found={}
    for line in result.stdout.splitlines():
        match=re.match(r'\s*(\S+)\s+=>\s+(/.*?)\s+\(0x',line)
        if match:found[match[1]]=Path(match[2]);continue
        match=re.match(r'\s*(/.*?)\s+\(0x',line)
        if match:path=Path(match[1]);found[path.name]=path
    return found
def linux(build,ffmpeg,out):
    binaries=[build/'KoraLo',build/'koralo-cli',build/'koralo-ofx-scanner'];tools=[ffmpeg/name for name in ['ffmpeg','ffprobe','ffplay']];libs={}
    for binary in binaries+tools:
        if not binary.is_file():raise RuntimeError('Missing binary: '+str(binary))
        for name,path in dependencies(binary).items():
            if name in libs and libs[name].resolve()!=path.resolve():raise RuntimeError('Conflicting library: '+name)
            libs[name]=path
    if 'ld-linux-x86-64.so.2' not in libs:raise RuntimeError('Linux x86_64 loader required')
    for binary in binaries:copy(binary,out/binary.name)
    for name,path in sorted(libs.items()):copy(path.resolve(),out/'lib'/name)
    for binary in tools:
        copy(binary,out/'bin'/(binary.name+'.real'))
        script(out/'bin'/binary.name,'''#!/bin/sh
set -eu
SELF=$0
case "$SELF" in /*) ;; *) SELF="$PWD/$SELF" ;; esac
BIN=$(CDPATH= cd -- "${SELF%/*}" && pwd -P)
exec "$BIN/../lib/ld-linux-x86-64.so.2" --library-path "$BIN/../lib" "$BIN/TOOL.real" "$@"
'''.replace('TOOL',binary.name))
    script(out/'run.sh','''#!/bin/sh
set -eu
SELF=$0
case "$SELF" in /*) ;; *) SELF="$PWD/$SELF" ;; esac
ROOT=$(CDPATH= cd -- "${SELF%/*}" && pwd -P)
export KORALO_APP_DIR="$ROOT"
export KORALO_FFMPEG_DIR="$ROOT/bin"
APP=KoraLo
if [ "${1:-}" = --cli ]; then APP=koralo-cli; shift; fi
exec "$ROOT/lib/ld-linux-x86-64.so.2" --library-path "$ROOT/lib" "$ROOT/$APP" "$@"
''')
    script(out/'doctor.sh','''#!/bin/sh
set -eu
SELF=$0
case "$SELF" in /*) ;; *) SELF="$PWD/$SELF" ;; esac
exec "${SELF%/*}/run.sh" --cli doctor
''')
    for notice in sorted(Path('/usr/share/doc').glob('*/copyright')):
        if notice.is_file():copy(notice,out/'licenses'/'linux-distribution'/notice.parent.name/'copyright')
    common=Path('/usr/share/common-licenses')
    if common.is_dir():shutil.copytree(common,out/'licenses'/'common-licenses',symlinks=False)
    return sorted(libs)
def windows(build,ffmpeg,out):
    for name in ['KoraLo.exe','koralo-cli.exe','koralo-ofx-scanner.exe']:copy(build/name,out/name)
    for name in ['ffmpeg.exe','ffprobe.exe','ffplay.exe']:copy(ffmpeg/name,out/'bin'/name)
    (out/'run.bat').write_text('@echo off\r\n"%~dp0KoraLo.exe" %*\r\n',encoding='ascii',newline='')
    (out/'doctor.bat').write_text('@echo off\r\n"%~dp0koralo-cli.exe" doctor\r\npause\r\n',encoding='ascii',newline='')
    return []
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform',choices=['linux','windows'],required=True)
    for name in ['build-dir','ffmpeg-dir','output']:parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--notices-dir',type=Path)
    args=parser.parse_args();out=args.output.resolve()
    if out.exists():raise RuntimeError('Output must be a new directory')
    out.mkdir(parents=True)
    try:
        libs=(linux if args.platform=='linux' else windows)(args.build_dir.resolve(),args.ffmpeg_dir.resolve(),out)
        shutil.copytree(SOURCE/'locales',out/'locales');shutil.copytree(SOURCE/'licenses',out/'licenses'/'KoraLo')
        copy(SOURCE/'assets/icons/fontawesome/LICENSE-fontawesome.txt',out/'licenses'/'FontAwesome.txt')
        for name in ['LICENSE','THIRD_PARTY_NOTICES.md','BUILD_REVISION.txt']:copy(SOURCE/name,out/name)
        if args.notices_dir:shutil.copytree(args.notices_dir,out/'licenses'/'ffmpeg',symlinks=False)
        (out/'portable.flag').write_text('Store data and caches beside the editor.\n',encoding='ascii')
        manifest={'platform':args.platform,'revision':(SOURCE/'BUILD_REVISION.txt').read_text().strip(),'libraries':libs,'files':{}}
        for file in sorted(out.rglob('*')):
            if file.is_file():
                digest=hashlib.sha256()
                with file.open('rb') as stream:
                    for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
                manifest['files'][file.relative_to(out).as_posix()]=digest.hexdigest()
        (out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(json.dumps({'platform':args.platform,'files':len(manifest['files']),'libraries':len(libs),'output':str(out)}))
    except BaseException:shutil.rmtree(out);raise
if __name__=='__main__':main()
