# Build & test KoraLo on Windows 10/11 x64 using Visual Studio 2022.
# Does NOT execute KoraLo.exe or install application-level dependencies.
param(
    [string]$Configuration = "Release",
    [int]$Jobs = 2,
    [switch]$SkipTests
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
$build = Join-Path $root "build-windows-native"
$destination = Join-Path $root "out\KoraLo"
function Assert-Exit([string]$phase) {
    if ($LASTEXITCODE -ne 0) { throw "$phase failed (exit code $LASTEXITCODE)" }
}
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    throw "Install Visual Studio 2022 Desktop development with C++ and CMake first."
}
Write-Host "KoraLo Windows x64: configuring..."
& cmake -S $root -B $build -G "Visual Studio 17 2022" -A x64 -DKORALO_BUILD_GUI=ON -DKORALO_BUILD_CLI=ON -DKORALO_BUILD_TESTS=ON
Assert-Exit "Configure"
Write-Host "Compiling with $Jobs parallel build jobs..."
& cmake --build $build --config $Configuration --parallel $Jobs
Assert-Exit "Build"
if (-not $SkipTests) {
    Write-Host "Running Windows native regression tests..."
    & ctest --test-dir $build -C $Configuration --output-on-failure --timeout 240 -E 'koralo_long_project_stability_tests'
    Assert-Exit "CTest"
}
Write-Host "Installing to $destination..."
& cmake --install $build --config $Configuration --prefix $destination
Assert-Exit "Install"
Write-Host "Windows build completed at $destination"
Write-Host "FFmpeg required: provide ffmpeg.exe, ffprobe.exe and ffplay.exe in bin/ or PATH."
Write-Host "The GUI has NOT been started. For diagnostics run: $build\$Configuration\koralo-cli.exe doctor"
