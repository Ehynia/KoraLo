#pragma once
#ifdef _WIN32
#include "../ui/opengl_canvas.hpp"
#include <memory>
#include <windows.h>
namespace koralo {
class WglHost {
public:
  OpenGlCanvas *begin(HWND window, int w, int h) {
    if (!enabled_)
      return nullptr;
    if (!attempted_) {
      attempted_ = true;
      window_ = window;
      library_ = LoadLibraryW(L"opengl32.dll");
      if (!library_)
        return nullptr;
      create_ = reinterpret_cast<decltype(create_)>(
          GetProcAddress(library_, "wglCreateContext"));
      current_ = reinterpret_cast<decltype(current_)>(
          GetProcAddress(library_, "wglMakeCurrent"));
      destroy_ = reinterpret_cast<decltype(destroy_)>(
          GetProcAddress(library_, "wglDeleteContext"));
      if (!create_ || !current_ || !destroy_)
        return nullptr;
      dc_ = GetDC(window_);
      PIXELFORMATDESCRIPTOR desc{};
      desc.nSize = sizeof(desc);
      desc.nVersion = 1;
      desc.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
      desc.iPixelType = PFD_TYPE_RGBA;
      desc.cColorBits = 32;
      desc.cAlphaBits = 8;
      desc.iLayerType = PFD_MAIN_PLANE;
      int format = ChoosePixelFormat(dc_, &desc);
      if (!format || !SetPixelFormat(dc_, format, &desc))
        return nullptr;
      context_ = create_(dc_);
      if (!context_ || !current_(dc_, context_))
        return nullptr;
      canvas_ = std::make_unique<OpenGlCanvas>();
      if (!canvas_->initialize([&](const char *n) {
            return reinterpret_cast<void *>(GetProcAddress(library_, n));
          })) {
        canvas_.reset();
        return nullptr;
      }
      // The Microsoft GDI Generic ICD is a software 1.1 implementation.
      // Preserve the native CPU fallback rather than label it as GPU.
      if (canvas_->renderer().find("GDI Generic") != std::string::npos) {
        canvas_.reset();
        return nullptr;
      }
    }
    if (!canvas_ || !current_(dc_, context_))
      return nullptr;
    canvas_->begin(w, h);
    return canvas_.get();
  }
  bool finish() {
    if (!canvas_)
      return false;
    bool ok = canvas_->finish();
    if (ok)
      ok = SwapBuffers(dc_) != FALSE;
    if (!ok)
      enabled_ = false;
    return ok;
  }
  std::string label() const {
    return enabled_ && canvas_ ? canvas_->renderer() : "CPU · GDI";
  }
  bool enable(bool enabled) {
    enabled_ = enabled;
    return enabled_ && (!attempted_ || bool(canvas_));
  }
  void reset() {
    if (context_) {
      current_(dc_, context_);
      canvas_.reset();
      current_(nullptr, nullptr);
      destroy_(context_);
      context_ = nullptr;
    }
    if (dc_) {
      ReleaseDC(window_, dc_);
      dc_ = nullptr;
    }
    if (library_) {
      FreeLibrary(library_);
      library_ = nullptr;
    }
  }
  ~WglHost() { reset(); }

private:
  bool enabled_ = interface_gpu_requested(), attempted_ = false;
  HWND window_ = nullptr;
  HDC dc_ = nullptr;
  HMODULE library_ = nullptr;
  HGLRC context_ = nullptr;
  HGLRC(WINAPI *create_)(HDC) = nullptr;
  BOOL(WINAPI *current_)(HDC, HGLRC) = nullptr;
  BOOL(WINAPI *destroy_)(HGLRC) = nullptr;
  std::unique_ptr<OpenGlCanvas> canvas_;
};
} // namespace koralo
#endif
