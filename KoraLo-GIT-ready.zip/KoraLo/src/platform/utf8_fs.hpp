#pragma once

#include <filesystem>
#include <string>

namespace koralo::utf8_fs {
// C++20 std::filesystem::path::string() uses the active ANSI codepage on
// Windows, not UTF-8. All paths crossing the OFX JSON IPC boundary are UTF-8.
inline std::filesystem::path from_utf8(const std::string &text) {
  // C++20 char8_t path construction selects UTF-8 on Windows, independent
  // of the user's ANSI system codepage (and avoids deprecated u8path).
  std::u8string bytes;
  bytes.reserve(text.size());
  for (unsigned char c : text)
    bytes.push_back(static_cast<char8_t>(c));
  return std::filesystem::path(bytes);
}
inline std::string to_utf8(const std::filesystem::path &path) {
  const auto bytes = path.u8string();
  return std::string(bytes.begin(), bytes.end());
}
} // namespace koralo::utf8_fs
