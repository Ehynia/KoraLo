#include "process.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <system_error>
#include <thread>
#include <utility>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <spawn.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

#ifndef _WIN32
extern char **environ;
#endif
namespace koralo {

#ifdef _WIN32
namespace {
std::wstring utf8_to_wide(const std::string &value) {
  if (value.empty())
    return {};
  const int needed =
      MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value.data(),
                          static_cast<int>(value.size()), nullptr, 0);
  if (needed <= 0)
    return {};
  std::wstring out(static_cast<std::size_t>(needed), L'\0');
  if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value.data(),
                          static_cast<int>(value.size()), out.data(),
                          needed) <= 0)
    return {};
  return out;
}

std::string wide_to_utf8(const std::wstring &value) {
  if (value.empty())
    return {};
  const int needed = WideCharToMultiByte(
      CP_UTF8, WC_ERR_INVALID_CHARS, value.data(),
      static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
  if (needed <= 0)
    return {};
  std::string out(static_cast<std::size_t>(needed), '\0');
  if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(),
                          static_cast<int>(value.size()), out.data(), needed,
                          nullptr, nullptr) <= 0)
    return {};
  return out;
}

std::wstring quote_windows_argument(const std::wstring &arg) {
  if (!arg.empty() && arg.find_first_of(L" \t\n\v\"") == std::wstring::npos)
    return arg;

  std::wstring out;
  out.push_back(L'"');
  std::size_t slashes = 0;
  for (wchar_t ch : arg) {
    if (ch == L'\\') {
      ++slashes;
      continue;
    }
    if (ch == L'"') {
      out.append(slashes * 2 + 1, L'\\');
      out.push_back(L'"');
      slashes = 0;
      continue;
    }
    out.append(slashes, L'\\');
    slashes = 0;
    out.push_back(ch);
  }
  out.append(slashes * 2, L'\\');
  out.push_back(L'"');
  return out;
}

std::string windows_error_message(DWORD code) {
  wchar_t *buffer = nullptr;
  const DWORD n = FormatMessageW(
      FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
          FORMAT_MESSAGE_IGNORE_INSERTS,
      nullptr, code, 0, reinterpret_cast<wchar_t *>(&buffer), 0, nullptr);
  std::string result;
  if (n && buffer)
    result = wide_to_utf8(std::wstring(buffer, n));
  if (buffer)
    LocalFree(buffer);
  return result;
}
} // namespace
#endif

std::filesystem::path path_from_utf8(const std::string &value) {
#ifdef _WIN32
  return std::filesystem::path(utf8_to_wide(value));
#else
  return std::filesystem::path(value);
#endif
}

std::string path_to_utf8(const std::filesystem::path &value) {
#ifdef _WIN32
  return wide_to_utf8(value.native());
#else
  return value.string();
#endif
}

namespace {
std::filesystem::path startup_executable;
}
std::filesystem::path current_executable_path() {
  if (!startup_executable.empty())
    return startup_executable;
#ifdef _WIN32
  std::vector<wchar_t> b(32768);
  auto n = GetModuleFileNameW(nullptr, b.data(), static_cast<DWORD>(b.size()));
  return n && n < b.size() ? std::filesystem::path(std::wstring(b.data(), n))
                           : std::filesystem::path{};
#else
  std::array<char, 4096> b{};
  auto n = readlink("/proc/self/exe", b.data(), b.size());
  return n > 0 && static_cast<std::size_t>(n) < b.size()
             ? std::filesystem::path(std::string(b.data(), n))
             : std::filesystem::path{};
#endif
}
std::string environment_utf8(const char *key) {
#ifdef _WIN32
  auto k = utf8_to_wide(key);
  DWORD n = GetEnvironmentVariableW(k.c_str(), nullptr, 0);
  if (!n)
    return {};
  std::wstring b(n, L'\0');
  DWORD actual = GetEnvironmentVariableW(k.c_str(), b.data(), n);
  if (!actual || actual >= n)
    return {};
  b.resize(actual);
  return wide_to_utf8(b);
#else
  auto value = std::getenv(key);
  return value ? value : "";
#endif
}
bool is_executable_file(const std::filesystem::path &path) {
  std::error_code ec;
  if (!std::filesystem::is_regular_file(path, ec))
    return false;
#ifdef _WIN32
  return true;
#else
  return access(path.c_str(), X_OK) == 0;
#endif
}
std::string find_executable_on_path(const std::string &name) {
  auto value = environment_utf8("PATH");
#ifdef _WIN32
  constexpr char separator = ';';
#else
  constexpr char separator = ':';
#endif
  std::size_t start = 0;
  while (start < value.size()) {
    auto end = value.find(separator, start);
    auto part =
        value.substr(start, end == std::string::npos ? end : end - start);
    if (part.size() > 1 && part.front() == '"' && part.back() == '"')
      part = part.substr(1, part.size() - 2);
    auto candidate = path_from_utf8(part) / path_from_utf8(name);
    if (!part.empty() && is_executable_file(candidate)) {
      std::error_code ec;
      auto absolute = std::filesystem::absolute(candidate, ec);
      return path_to_utf8(ec ? candidate : absolute);
    }
    if (end == std::string::npos)
      break;
    start = end + 1;
  }
  return {};
}
void initialize_executable_path(const std::string &argv0) {
  auto path = path_from_utf8(argv0);
  if (!path.has_parent_path())
    path = path_from_utf8(find_executable_on_path(argv0));
  std::error_code ec;
  if (!path.empty() && is_executable_file(path)) {
    auto resolved = std::filesystem::canonical(path, ec);
    if (!ec)
      startup_executable = resolved;
  }
}
std::filesystem::path app_install_directory() {
  auto override = path_from_utf8(environment_utf8("KORALO_APP_DIR"));
  std::error_code ec;
  if (override.is_absolute() && std::filesystem::is_directory(override, ec))
    return override;
  return current_executable_path().parent_path();
}
bool atomic_replace_file(const std::filesystem::path &from,
                         const std::filesystem::path &to, std::string *error) {
#ifdef _WIN32
  HANDLE file =
      CreateFileW(from.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr,
                  OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (file == INVALID_HANDLE_VALUE) {
    if (error)
      *error = windows_error_message(GetLastError());
    return false;
  }
  bool ok = FlushFileBuffers(file);
  auto code = GetLastError();
  CloseHandle(file);
  if (!ok) {
    if (error)
      *error = windows_error_message(code);
    return false;
  }
  if (MoveFileExW(from.c_str(), to.c_str(),
                  MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
    return true;
  if (error)
    *error = windows_error_message(GetLastError());
  return false;
#else
  int fd = open(from.c_str(), O_RDONLY | O_CLOEXEC);
  if (fd < 0) {
    if (error)
      *error = std::strerror(errno);
    return false;
  }
  int rc;
  do {
    rc = fsync(fd);
  } while (rc < 0 && errno == EINTR);
  int code = errno;
  close(fd);
  if (rc < 0) {
    if (error)
      *error = std::strerror(code);
    return false;
  }
  std::error_code ec;
  std::filesystem::rename(from, to, ec);
  if (ec) {
    if (error)
      *error = ec.message();
    return false;
  }
  auto parent = to.parent_path();
  if (parent.empty())
    parent = ".";
  fd = open(parent.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
  if (fd >= 0) {
    fsync(fd);
    close(fd);
  }
  return true;
#endif
}
namespace {
bool invalid(const std::string &exe, const std::vector<std::string> &args) {
  return exe.empty() || exe.find('\0') != std::string::npos ||
         std::any_of(args.begin(), args.end(), [](const auto &arg) {
           return arg.find('\0') != std::string::npos;
         });
}
bool spawn(const std::string &exe, const std::vector<std::string> &args,
           std::uintptr_t &native, std::intptr_t *reader,
           std::intptr_t *writer, bool capture, std::string *error) {
#ifdef _WIN32
  auto wide = utf8_to_wide(exe);
  std::wstring command = quote_windows_argument(wide);
  for (const auto &arg : args) {
    auto w = utf8_to_wide(arg);
    if (!arg.empty() && w.empty()) {
      if (error)
        *error = "Invalid UTF-8 argument";
      return false;
    }
    command += L" " + quote_windows_argument(w);
  }
  SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
  HANDLE rd = nullptr, wr = nullptr;
  HANDLE stdin_rd = nullptr, stdin_wr = nullptr;
  // Raw frames are hundreds of KiB or more. A small default pipe forces
  // repeated empty-pipe polls between chunks on Windows. Reserve enough for
  // a preview frame; text/progress capture needs only a modest buffer.
  const DWORD pipe_capacity = capture ? 64u * 1024u : 1024u * 1024u;
  if (reader && !CreatePipe(&rd, &wr, &sa, pipe_capacity)) {
    if (error)
      *error = windows_error_message(GetLastError());
    return false;
  }
  if (rd)
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
  if (writer && !CreatePipe(&stdin_rd, &stdin_wr, &sa, 64u * 1024u)) {
    if (rd)
      CloseHandle(rd);
    if (wr)
      CloseHandle(wr);
    if (error)
      *error = windows_error_message(GetLastError());
    return false;
  }
  if (stdin_wr)
    SetHandleInformation(stdin_wr, HANDLE_FLAG_INHERIT, 0);
  HANDLE null = CreateFileW(L"NUL", GENERIC_READ | GENERIC_WRITE,
                            FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (null == INVALID_HANDLE_VALUE) {
    if (rd)
      CloseHandle(rd);
    if (wr)
      CloseHandle(wr);
    if (stdin_rd)
      CloseHandle(stdin_rd);
    if (stdin_wr)
      CloseHandle(stdin_wr);
    if (error)
      *error = windows_error_message(GetLastError());
    return false;
  }
  STARTUPINFOEXW si{};
  si.StartupInfo.cb = sizeof(si);
  si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
  si.StartupInfo.hStdInput = stdin_rd ? stdin_rd : null;
  si.StartupInfo.hStdOutput = wr ? wr : null;
  si.StartupInfo.hStdError = wr && capture ? wr : null;
  SIZE_T size = 0;
  InitializeProcThreadAttributeList(nullptr, 1, 0, &size);
  std::vector<unsigned char> attributes(size);
  si.lpAttributeList =
      reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(attributes.data());
  bool initialized =
      InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &size);
  // STARTF_USESTDHANDLES requires *every* standard handle to be present in
  // PROC_THREAD_ATTRIBUTE_HANDLE_LIST, including the NUL sink used when a
  // stream is not captured.  Omitting NUL caused CreateProcessW failures for
  // FFmpeg encoders (stdin pipe, but no stdout pipe) on Windows.
  std::array<HANDLE, 3> handles{};
  DWORD handle_count = 0;
  for (HANDLE h : {si.StartupInfo.hStdInput, si.StartupInfo.hStdOutput,
                   si.StartupInfo.hStdError}) {
    if (std::find(handles.begin(), handles.begin() + handle_count, h) ==
        handles.begin() + handle_count)
      handles[handle_count++] = h;
  }
  bool updated = initialized &&
                 UpdateProcThreadAttribute(
                     si.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
                     handles.data(), handle_count * sizeof(HANDLE), nullptr,
                     nullptr);
  DWORD code = updated ? ERROR_SUCCESS : GetLastError();
  PROCESS_INFORMATION pi{};
  bool ok = updated &&
            CreateProcessW(wide.c_str(), command.data(), nullptr, nullptr, TRUE,
                           CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT,
                           nullptr, nullptr, &si.StartupInfo, &pi);
  if (!ok && updated)
    code = GetLastError();
  if (initialized)
    DeleteProcThreadAttributeList(si.lpAttributeList);
  if (wr)
    CloseHandle(wr);
  if (stdin_rd)
    CloseHandle(stdin_rd);
  CloseHandle(null);
  if (!ok) {
    if (rd)
      CloseHandle(rd);
    if (stdin_wr)
      CloseHandle(stdin_wr);
    if (error)
      *error = windows_error_message(code);
    return false;
  }
  CloseHandle(pi.hThread);
  native = reinterpret_cast<std::uintptr_t>(pi.hProcess);
  if (reader)
    *reader = reinterpret_cast<std::intptr_t>(rd);
  if (writer)
    *writer = reinterpret_cast<std::intptr_t>(stdin_wr);
  return true;
#else
  int fds[2]{-1, -1};
  int infds[2]{-1, -1};
  if (reader && pipe2(fds, O_CLOEXEC) < 0) {
    if (error)
      *error = std::strerror(errno);
    return false;
  }
  if (writer && pipe2(infds, O_CLOEXEC) < 0) {
    if (reader) {
      close(fds[0]);
      close(fds[1]);
    }
    if (error)
      *error = std::strerror(errno);
    return false;
  }
  std::vector<char *> argv;
  argv.push_back(const_cast<char *>(exe.c_str()));
  for (const auto &arg : args)
    argv.push_back(const_cast<char *>(arg.c_str()));
  argv.push_back(nullptr);
  posix_spawn_file_actions_t actions;
  posix_spawnattr_t attr;
  int rc = posix_spawn_file_actions_init(&actions);
  if (rc) {
    if (reader) {
      close(fds[0]);
      close(fds[1]);
    }
    if (writer) {
      close(infds[0]);
      close(infds[1]);
    }
    if (error)
      *error = std::strerror(rc);
    return false;
  }
  rc = posix_spawnattr_init(&attr);
  if (rc) {
    posix_spawn_file_actions_destroy(&actions);
    if (reader) {
      close(fds[0]);
      close(fds[1]);
    }
    if (writer) {
      close(infds[0]);
      close(infds[1]);
    }
    if (error)
      *error = std::strerror(rc);
    return false;
  }
  auto check = [&](int n) {
    if (!rc && n)
      rc = n;
  };
  if (writer) {
    check(posix_spawn_file_actions_adddup2(&actions, infds[0], 0));
    check(posix_spawn_file_actions_addclose(&actions, infds[0]));
    check(posix_spawn_file_actions_addclose(&actions, infds[1]));
  } else {
    check(posix_spawn_file_actions_addopen(&actions, 0, "/dev/null", O_RDONLY,
                                           0));
  }
  if (reader) {
    check(posix_spawn_file_actions_adddup2(&actions, fds[1], 1));
    if (capture)
      check(posix_spawn_file_actions_adddup2(&actions, fds[1], 2));
    else
      check(posix_spawn_file_actions_addopen(&actions, 2, "/dev/null", O_WRONLY,
                                             0));
    check(posix_spawn_file_actions_addclose(&actions, fds[0]));
    check(posix_spawn_file_actions_addclose(&actions, fds[1]));
  } else {
    check(posix_spawn_file_actions_addopen(&actions, 1, "/dev/null", O_WRONLY,
                                           0));
    check(posix_spawn_file_actions_addopen(&actions, 2, "/dev/null", O_WRONLY,
                                           0));
  }
  check(posix_spawnattr_setpgroup(&attr, 0));
  sigset_t defaults;
  sigemptyset(&defaults);
  sigaddset(&defaults, SIGPIPE);
  check(posix_spawnattr_setsigdefault(&attr, &defaults));
  check(posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP |
                                            POSIX_SPAWN_SETSIGDEF));
  pid_t pid = 0;
  if (!rc)
    rc = posix_spawnp(&pid, exe.c_str(), &actions, &attr, argv.data(), environ);
  posix_spawn_file_actions_destroy(&actions);
  posix_spawnattr_destroy(&attr);
  if (reader)
    close(fds[1]);
  if (writer)
    close(infds[0]);
  if (rc) {
    if (reader)
      close(fds[0]);
    if (writer)
      close(infds[1]);
    if (error)
      *error = std::strerror(rc);
    return false;
  }
  native = pid;
  if (reader)
    *reader = fds[0];
  if (writer)
    *writer = infds[1];
  return true;
#endif
}

bool write_pipe_chunk(std::intptr_t writer, std::string_view input,
                      std::string *error, const std::atomic<bool>* cancel) {
  if (writer == -1) { if(error)*error="Closed process stdin"; return false; }
#ifdef _WIN32
  HANDLE handle = reinterpret_cast<HANDLE>(writer);
  std::size_t done=0;
  while(done<input.size()) {
    if(cancel&&cancel->load()) { if(error)*error="Render cancelled"; return false; }
    DWORD count=static_cast<DWORD>(std::min<std::size_t>(input.size()-done,65536));
    DWORD wrote=0;
    if(!WriteFile(handle,input.data()+done,count,&wrote,nullptr)||!wrote) {
      if(error)*error=windows_error_message(GetLastError());return false;
    }
    done+=wrote;
  }
#else
  // A failing encoder closes stdin; Linux would otherwise kill KoraLo with
  // SIGPIPE. Block it only on the calling thread, without changing the app's
  // global signal dispositions or other workers.
  sigset_t blocked, prior, preexisting;
  sigemptyset(&blocked);sigaddset(&blocked,SIGPIPE);
  const bool masked=pthread_sigmask(SIG_BLOCK,&blocked,&prior)==0;
  sigpending(&preexisting);
  std::size_t done=0;int failure=0;
  while(done<input.size()) {
    if(cancel&&cancel->load()) { failure=ECANCELED;break; }
    pollfd waitfd{static_cast<int>(writer),POLLOUT,0};
    int ready=poll(&waitfd,1,100);
    if(ready<0&&errno==EINTR)continue;
    if(ready<0){failure=errno;break;}
    if(ready==0)continue;
    const auto n=write(static_cast<int>(writer),input.data()+done,
                       std::min<std::size_t>(input.size()-done,65536));
    if(n<0&&errno==EINTR)continue;
    if(n<=0){failure=n<0?errno:EIO;break;}
    done+=static_cast<std::size_t>(n);
  }
  if(masked) {
    if(failure==EPIPE&&!sigismember(&preexisting,SIGPIPE)) {
      timespec zero{0,0};siginfo_t info{};
      sigtimedwait(&blocked,&info,&zero);
    }
    pthread_sigmask(SIG_SETMASK,&prior,nullptr);
  }
  if(failure){if(error)*error=failure==ECANCELED?"Render cancelled":std::strerror(failure);return false;}
#endif
  return true;
}

bool write_and_close_pipe(std::intptr_t writer, std::string_view input,
                          std::string *error) {
  if (writer == -1)
    return input.empty();
#ifdef _WIN32
  HANDLE handle = reinterpret_cast<HANDLE>(writer);
  std::size_t done = 0;
  while (done < input.size()) {
    const DWORD chunk = static_cast<DWORD>(
        std::min<std::size_t>(input.size() - done, 64u * 1024u));
    DWORD wrote = 0;
    if (!WriteFile(handle, input.data() + done, chunk, &wrote, nullptr)) {
      const DWORD code = GetLastError();
      CloseHandle(handle);
      if (error)
        *error = windows_error_message(code);
      return false;
    }
    if (!wrote)
      break;
    done += wrote;
  }
  CloseHandle(handle);
#else
  const int fd = static_cast<int>(writer);
  std::size_t done = 0;
  while (done < input.size()) {
    const auto n = write(fd, input.data() + done, input.size() - done);
    if (n < 0 && errno == EINTR)
      continue;
    if (n < 0) {
      const int code = errno;
      close(fd);
      if (error)
        *error = std::strerror(code);
      return false;
    }
    if (!n)
      break;
    done += static_cast<std::size_t>(n);
  }
  close(fd);
#endif
  if (input.size() && done != input.size()) {
    if (error)
      *error = "short write to process stdin";
    return false;
  }
  return true;
}
bool poll_child(std::uintptr_t &native, int *code = nullptr) {
  if (!native)
    return false;
#ifdef _WIN32
  auto h = reinterpret_cast<HANDLE>(native);
  if (WaitForSingleObject(h, 0) == WAIT_TIMEOUT)
    return true;
  DWORD status = 0;
  if (code && GetExitCodeProcess(h, &status))
    *code = status;
  CloseHandle(h);
#else
  int status = 0;
  auto rc = waitpid(static_cast<pid_t>(native), &status, WNOHANG);
  if (rc == 0 || (rc < 0 && errno == EINTR))
    return true;
  if (code && rc > 0)
    *code = WIFEXITED(status)     ? WEXITSTATUS(status)
            : WIFSIGNALED(status) ? 128 + WTERMSIG(status)
                                  : -1;
#endif
  native = 0;
  return false;
}
void terminate_child(std::uintptr_t &native, int *code = nullptr) {
  if (!poll_child(native, code))
    return;
#ifdef _WIN32
  auto h = reinterpret_cast<HANDLE>(native);
  TerminateProcess(h, 1);
  WaitForSingleObject(h, 1000);
  poll_child(native, code);
#else
  auto pid = static_cast<pid_t>(native);
  kill(-pid, SIGTERM);
  for (int i = 0; i < 20; ++i) {
    if (!poll_child(native, code))
      return;
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  kill(-pid, SIGKILL);
  int status = 0;
  while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {
  }
  if (code)
    *code = WIFSIGNALED(status) ? 128 + WTERMSIG(status) : -1;
  native = 0;
#endif
}
} // namespace
ReadPipeProcess::~ReadPipeProcess() { terminate(); }
ReadPipeProcess::ReadPipeProcess(ReadPipeProcess &&other) noexcept
    : native_(std::exchange(other.native_, 0)),
      read_native_(std::exchange(other.read_native_, -1)),
      write_native_(std::exchange(other.write_native_, -1)),
      exit_code_(other.exit_code_) {}
ReadPipeProcess &ReadPipeProcess::operator=(ReadPipeProcess &&other) noexcept {
  if (this != &other) {
    terminate();
    native_ = std::exchange(other.native_, 0);
    read_native_ = std::exchange(other.read_native_, -1);
    write_native_ = std::exchange(other.write_native_, -1);
    exit_code_ = other.exit_code_;
  }
  return *this;
}
bool ReadPipeProcess::start(const std::string &exe,
                            const std::vector<std::string> &args,
                            std::string *error, bool capture,
                            bool open_stdin) {
  terminate();
  exit_code_ = -1;
  if (invalid(exe, args)) {
    if (error)
      *error = "Invalid executable or NUL argument";
    return false;
  }
  return spawn(exe, args, native_, &read_native_,
               open_stdin ? &write_native_ : nullptr, capture, error);
}
bool ReadPipeProcess::write_stdin_and_close(std::string_view input,
                                            std::string *error) {
  const auto writer = std::exchange(write_native_, -1);
  return write_and_close_pipe(writer, input, error);
}
bool ReadPipeProcess::write_stdin_chunk(std::string_view input,
                                        std::string *error,
                                        const std::atomic<bool>* cancel) {
  return write_pipe_chunk(write_native_, input, error, cancel);
}
void ReadPipeProcess::close_stdin() {
  const auto writer=std::exchange(write_native_,-1);
  if(writer==-1)return;
#ifdef _WIN32
  CloseHandle(reinterpret_cast<HANDLE>(writer));
#else
  close(static_cast<int>(writer));
#endif
}
int ReadPipeProcess::read_some(void *data, std::size_t bytes, int timeout,
                               const std::atomic<bool> *cancel,
                               std::string *error) {
  if (!bytes)
    return 0;
  if (read_native_ == -1) {
    if (error)
      *error = "Closed process pipe";
    return -1;
  }
  auto began = std::chrono::steady_clock::now();
  for (;;) {
    if (cancel && cancel->load()) {
      if (error)
        *error = "process cancelled";
      return -1;
    }
    if (timeout > 0 && std::chrono::duration_cast<std::chrono::milliseconds>(
                           std::chrono::steady_clock::now() - began)
                               .count() >= timeout) {
      if (error)
        *error = "process timed out";
      return -1;
    }
#ifdef _WIN32
    auto h = reinterpret_cast<HANDLE>(read_native_);
    DWORD count = 0;
    if (!PeekNamedPipe(h, nullptr, 0, nullptr, &count, nullptr)) {
      if (GetLastError() == ERROR_BROKEN_PIPE)
        return 0;
      if (error)
        *error = windows_error_message(GetLastError());
      return -1;
    }
    if (count) {
      DWORD got = 0;
      if (ReadFile(h, data,
                   static_cast<DWORD>(
                       std::min<std::size_t>({bytes, count, 1048576})),
                   &got, nullptr))
        return got;
      if (GetLastError() == ERROR_BROKEN_PIPE)
        return 0;
      if (error)
        *error = windows_error_message(GetLastError());
      return -1;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
#else
    pollfd fd{static_cast<int>(read_native_), POLLIN, 0};
    int rc = poll(&fd, 1, 25);
    if (rc < 0) {
      if (errno == EINTR)
        continue;
      if (error)
        *error = std::strerror(errno);
      return -1;
    }
    if (rc > 0) {
      auto n = read(fd.fd, data, std::min<std::size_t>(bytes, 1048576));
      if (n < 0 && errno == EINTR)
        continue;
      if (n < 0 && error)
        *error = std::strerror(errno);
      return static_cast<int>(n);
    }
#endif
  }
}
bool ReadPipeProcess::read_exact(void *data, std::size_t bytes,
                                 std::string *error,
                                 const std::atomic<bool> *cancel, int timeout) {
  auto began = std::chrono::steady_clock::now();
  std::size_t done = 0;
  while (done < bytes) {
    int left = timeout;
    if (timeout > 0) {
      auto used = std::chrono::duration_cast<std::chrono::milliseconds>(
                      std::chrono::steady_clock::now() - began)
                      .count();
      if (used >= timeout) {
        if (error)
          *error = "process timed out";
        return false;
      }
      left = timeout - static_cast<int>(used);
    }
    int n = read_some(static_cast<char *>(data) + done, bytes - done, left,
                      cancel, error);
    if (n <= 0) {
      if (!n && error)
        *error = "decoder reached end of stream";
      return false;
    }
    done += n;
  }
  return true;
}
bool ReadPipeProcess::running() { return poll_child(native_, &exit_code_); }
void ReadPipeProcess::terminate() {
  terminate_child(native_, &exit_code_);
  if (read_native_ != -1) {
#ifdef _WIN32
    CloseHandle(reinterpret_cast<HANDLE>(read_native_));
#else
    close(static_cast<int>(read_native_));
#endif
    read_native_ = -1;
  }
  if (write_native_ != -1) {
#ifdef _WIN32
    CloseHandle(reinterpret_cast<HANDLE>(write_native_));
#else
    close(static_cast<int>(write_native_));
#endif
    write_native_ = -1;
  }
}
ProcessResult run_process(const std::string &exe,
                          const std::vector<std::string> &args,
                          const ProcessOptions &options) {
  ProcessResult result;
  ReadPipeProcess child;
  if (options.cancel && options.cancel->load()) {
    result.cancelled = true;
    return result;
  }
  if (!child.start(exe, args, &result.output, options.capture_stderr,
                   !options.input.empty()))
    return result;
  result.started = true;
  if (!options.input.empty()) {
    std::string input_error;
    if (!child.write_stdin_and_close(options.input, &input_error)) {
      child.terminate();
      result.output = std::move(input_error);
      result.exit_code = child.exit_code();
      return result;
    }
  }
  auto began = std::chrono::steady_clock::now();
  auto remaining = [&]() {
    if (options.cancel && options.cancel->load()) {
      result.cancelled = true;
      return -1;
    }
    if (options.timeout_ms <= 0)
      return 0;
    auto used = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - began)
                    .count();
    if (used >= options.timeout_ms) {
      result.timed_out = true;
      return -1;
    }
    return options.timeout_ms - static_cast<int>(used);
  };
  std::array<char, 4096> b{};
  std::string error;
  for (;;) {
    int wait = remaining();
    if (wait < 0)
      break;
    int n = child.read_some(b.data(), b.size(), wait, options.cancel, &error);
    if (n <= 0) {
      if (n < 0) {
        remaining();
        if (error == "process timed out")
          result.timed_out = true;
      }
      break;
    }
    std::string_view chunk(b.data(), n);
    if (options.on_output)
      options.on_output(chunk);
    if (options.max_output_bytes) {
      result.output.append(chunk);
      if (result.output.size() > options.max_output_bytes)
        result.output.erase(0, result.output.size() - options.max_output_bytes);
    }
  }
  if (!error.empty() || result.cancelled || result.timed_out)
    child.terminate();
  else
    while (child.running()) {
      if (remaining() < 0) {
        child.terminate();
        break;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
  result.exit_code = child.exit_code();
  if (result.cancelled)
    result.output += "\nprocess cancelled";
  else if (result.timed_out)
    result.output += "\nprocess timed out";
  else if (!error.empty())
    result.output += '\n' + error;
  return result;
}
DetachedProcess::~DetachedProcess() { terminate(); }
DetachedProcess::DetachedProcess(DetachedProcess &&other) noexcept
    : native_(std::exchange(other.native_, 0)) {}
DetachedProcess &DetachedProcess::operator=(DetachedProcess &&other) noexcept {
  if (this != &other) {
    terminate();
    native_ = std::exchange(other.native_, 0);
  }
  return *this;
}
bool DetachedProcess::start(const std::string &exe,
                            const std::vector<std::string> &args,
                            std::string *error) {
  terminate();
  if (invalid(exe, args)) {
    if (error)
      *error = "Invalid executable or NUL argument";
    return false;
  }
  return spawn(exe, args, native_, nullptr, nullptr, false, error);
}
bool DetachedProcess::running() { return poll_child(native_); }
void DetachedProcess::terminate() { terminate_child(native_); }
} // namespace koralo
