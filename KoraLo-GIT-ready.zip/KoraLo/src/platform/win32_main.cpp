#ifdef _WIN32
#define NOMINMAX
#include "../ui/editor_app.hpp"
#include "../ui/inter_atlas.hpp"
#include <windows.h>
#include "resource.h"
#include <windowsx.h>
#include "wgl_host.hpp"
#include <cwchar>
#include <commdlg.h>
#include <shellapi.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <array>
#include <limits>

using namespace koralo;

namespace {
COLORREF cr(Color c){return RGB(c.r,c.g,c.b);} 
std::string wide_to_utf8(const std::wstring&w){if(w.empty())return{};int n=WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr);return s;}
std::wstring utf8_to_wide(const std::string&s){if(s.empty())return{};int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring w(n,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),w.data(),n);return w;}

std::uint32_t next_utf8_codepoint(const std::string& text,std::size_t& i){
    if(i>=text.size())return 0;const auto c0=static_cast<unsigned char>(text[i++]);if(c0<0x80)return c0;
    auto cont=[&]()->unsigned char{return i<text.size()?static_cast<unsigned char>(text[i++]):0;};
    if((c0&0xe0)==0xc0){const auto c1=cont();return ((c0&0x1f)<<6)|(c1&0x3f);}
    if((c0&0xf0)==0xe0){const auto c1=cont(),c2=cont();return ((c0&0x0f)<<12)|((c1&0x3f)<<6)|(c2&0x3f);}
    if((c0&0xf8)==0xf0){const auto c1=cont(),c2=cont(),c3=cont();return ((c0&0x07)<<18)|((c1&0x3f)<<12)|((c2&0x3f)<<6)|(c3&0x3f);}
    return '?';
}

struct GdiAlphaTile {
    HDC dc=nullptr;
    HBITMAP bitmap=nullptr;
    HGDIOBJ old=nullptr;
};

std::unordered_map<COLORREF,HBRUSH> g_brush_cache;
std::unordered_map<std::uint64_t,HPEN> g_pen_cache;
std::unordered_map<int,HFONT> g_font_cache;
std::unordered_map<int,bool> g_font_inter_exact;
std::unordered_map<std::uint32_t,GdiAlphaTile> g_alpha_tile_cache;

HBRUSH cached_brush(Color c){
    const COLORREF key=cr(c);auto it=g_brush_cache.find(key);if(it!=g_brush_cache.end())return it->second;
    HBRUSH value=CreateSolidBrush(key);g_brush_cache[key]=value;return value;
}
HPEN cached_pen(Color c,int thickness){
    const std::uint64_t key=(static_cast<std::uint64_t>(static_cast<unsigned>(thickness))<<32)|static_cast<std::uint64_t>(cr(c));
    auto it=g_pen_cache.find(key);if(it!=g_pen_cache.end())return it->second;HPEN value=CreatePen(PS_SOLID,thickness,cr(c));g_pen_cache[key]=value;return value;
}
HFONT cached_font(int size,bool bold){
    const int key=size*2+(bold?1:0);auto it=g_font_cache.find(key);if(it!=g_font_cache.end())return it->second;
    HFONT value=CreateFontW(-size,0,0,0,bold?FW_SEMIBOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_SWISS,L"Inter");
    g_font_cache[key]=value;return value;
}
bool font_is_inter(HDC dc,int size,bool bold){
    const int key=size*2+(bold?1:0);auto it=g_font_inter_exact.find(key);if(it!=g_font_inter_exact.end())return it->second;
    HFONT f=cached_font(size,bold);HGDIOBJ old=SelectObject(dc,f);wchar_t face[LF_FACESIZE]{};GetTextFaceW(dc,LF_FACESIZE,face);SelectObject(dc,old);
    const bool exact=_wcsicmp(face,L"Inter")==0;g_font_inter_exact[key]=exact;return exact;
}
GdiAlphaTile* cached_alpha_tile(HDC reference,Color c){
    const std::uint32_t key=(static_cast<std::uint32_t>(c.a)<<24)|(static_cast<std::uint32_t>(c.r)<<16)|(static_cast<std::uint32_t>(c.g)<<8)|c.b;
    auto it=g_alpha_tile_cache.find(key);if(it!=g_alpha_tile_cache.end())return &it->second;
    BITMAPINFO bmi{};bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bmi.bmiHeader.biWidth=1;bmi.bmiHeader.biHeight=-1;bmi.bmiHeader.biPlanes=1;bmi.bmiHeader.biBitCount=32;bmi.bmiHeader.biCompression=BI_RGB;
    void* bits=nullptr;HBITMAP bmp=CreateDIBSection(reference,&bmi,DIB_RGB_COLORS,&bits,nullptr,0);if(!bmp||!bits)return nullptr;
    const unsigned a=c.a;auto* px=static_cast<unsigned char*>(bits);px[0]=static_cast<unsigned char>((c.b*a+127)/255);px[1]=static_cast<unsigned char>((c.g*a+127)/255);px[2]=static_cast<unsigned char>((c.r*a+127)/255);px[3]=c.a;
    HDC mem=CreateCompatibleDC(reference);if(!mem){DeleteObject(bmp);return nullptr;}HGDIOBJ old=SelectObject(mem,bmp);
    auto [inserted,_]=g_alpha_tile_cache.emplace(key,GdiAlphaTile{mem,bmp,old});return &inserted->second;
}

struct GdiImageCacheEntry {
    const std::uint8_t* data=nullptr;std::size_t size=0;int width=0,height=0;std::uint32_t signature=0;std::uint64_t stamp=0;std::vector<unsigned char> bgra;
};
std::array<GdiImageCacheEntry,24> g_image_cache{};
std::uint64_t g_image_cache_clock=0;
std::uint32_t frame_signature(const Frame& f){
    if(f.rgb.empty())return 0;const std::size_t n=f.rgb.size();std::uint32_t h=2166136261u;
    constexpr std::size_t samples=16;for(std::size_t i=0;i<samples;++i){const std::size_t pos=(n-1)*i/(samples-1);h^=f.rgb[pos];h*=16777619u;}
    h^=static_cast<std::uint32_t>(n);h*=16777619u;return h;
}
const std::vector<unsigned char>& cached_bgra(const Frame& f){
    const auto sig=frame_signature(f);GdiImageCacheEntry* best=nullptr;
    for(auto& e:g_image_cache){if(e.data==f.rgb.data()&&e.size==f.rgb.size()&&e.width==f.width&&e.height==f.height&&e.signature==sig){e.stamp=++g_image_cache_clock;return e.bgra;}if(!best||e.stamp<best->stamp)best=&e;}
    best->data=f.rgb.data();best->size=f.rgb.size();best->width=f.width;best->height=f.height;best->signature=sig;best->stamp=++g_image_cache_clock;
    const std::size_t total_px = static_cast<std::size_t>(std::max(0, f.width)) * std::max(0, f.height);
    const std::size_t available_px = f.rgb.size() / 3;
    const std::size_t n = std::min(total_px, available_px);
    best->bgra.assign(total_px * 4, 0);
    for(std::size_t p = 0; p < n; ++p){
        best->bgra[p * 4] = f.rgb[p * 3 + 2];
        best->bgra[p * 4 + 1] = f.rgb[p * 3 + 1];
        best->bgra[p * 4 + 2] = f.rgb[p * 3];
        best->bgra[p * 4 + 3] = 0;
    }
    return best->bgra;
}

struct GdiScaledImageCacheEntry {
    const std::uint8_t* data=nullptr;std::size_t size=0;int src_w=0,src_h=0,dst_w=0,dst_h=0;std::uint32_t signature=0;std::uint64_t stamp=0;HDC dc=nullptr;HBITMAP bitmap=nullptr;HGDIOBJ old=nullptr;
    void reset(){if(dc&&old)SelectObject(dc,old);if(bitmap)DeleteObject(bitmap);if(dc)DeleteDC(dc);dc=nullptr;bitmap=nullptr;old=nullptr;data=nullptr;size=0;src_w=src_h=dst_w=dst_h=0;signature=0;stamp=0;}
};
std::array<GdiScaledImageCacheEntry,12> g_scaled_image_cache{};
std::uint64_t g_scaled_image_clock=0;
GdiScaledImageCacheEntry* cached_scaled_image(HDC reference,const Frame& f,int ow,int oh){
    const auto sig=frame_signature(f);GdiScaledImageCacheEntry* best=nullptr;
    for(auto& e:g_scaled_image_cache){if(e.dc&&e.data==f.rgb.data()&&e.size==f.rgb.size()&&e.src_w==f.width&&e.src_h==f.height&&e.dst_w==ow&&e.dst_h==oh&&e.signature==sig){e.stamp=++g_scaled_image_clock;return &e;}if(!best||e.stamp<best->stamp)best=&e;}
    if(!best)return nullptr;best->reset();best->dc=CreateCompatibleDC(reference);if(!best->dc)return nullptr;
    BITMAPINFO out_bmi{};out_bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);out_bmi.bmiHeader.biWidth=ow;out_bmi.bmiHeader.biHeight=-oh;out_bmi.bmiHeader.biPlanes=1;out_bmi.bmiHeader.biBitCount=32;out_bmi.bmiHeader.biCompression=BI_RGB;void* out_bits=nullptr;
    best->bitmap=CreateDIBSection(reference,&out_bmi,DIB_RGB_COLORS,&out_bits,nullptr,0);if(!best->bitmap){DeleteDC(best->dc);best->dc=nullptr;return nullptr;}best->old=SelectObject(best->dc,best->bitmap);
    const auto& bgr=cached_bgra(f);BITMAPINFO src_bmi{};src_bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);src_bmi.bmiHeader.biWidth=f.width;src_bmi.bmiHeader.biHeight=-f.height;src_bmi.bmiHeader.biPlanes=1;src_bmi.bmiHeader.biBitCount=32;src_bmi.bmiHeader.biCompression=BI_RGB;
    SetStretchBltMode(best->dc,HALFTONE);SetBrushOrgEx(best->dc,0,0,nullptr);StretchDIBits(best->dc,0,0,ow,oh,0,0,f.width,f.height,bgr.data(),&src_bmi,DIB_RGB_COLORS,SRCCOPY);GdiFlush();
    best->data=f.rgb.data();best->size=f.rgb.size();best->src_w=f.width;best->src_h=f.height;best->dst_w=ow;best->dst_h=oh;best->signature=sig;best->stamp=++g_scaled_image_clock;return best;
}

void release_gdi_caches(){
    for(auto& e:g_scaled_image_cache)e.reset();
    for(auto& [_,v]:g_alpha_tile_cache){if(v.dc&&v.old)SelectObject(v.dc,v.old);if(v.bitmap)DeleteObject(v.bitmap);if(v.dc)DeleteDC(v.dc);}g_alpha_tile_cache.clear();
    for(auto& [_,v]:g_brush_cache)DeleteObject(v);g_brush_cache.clear();for(auto& [_,v]:g_pen_cache)DeleteObject(v);g_pen_cache.clear();for(auto& [_,v]:g_font_cache)DeleteObject(v);g_font_cache.clear();g_font_inter_exact.clear();
}

class GdiCanvas final:public Canvas{
public:
    GdiCanvas(HDC dc,int w,int h,std::uint32_t* pixels=nullptr,int stride_pixels=0)
        :dc_(dc),w_(w),h_(h),pixels_(pixels),stride_(stride_pixels>0?stride_pixels:w){SetBkMode(dc_,TRANSPARENT);}
    ~GdiCanvas() override = default;
    int width()const override{return w_;}int height()const override{return h_;}
    void fill_rect(Rect r,Color c)override{
        if(r.w<=0||r.h<=0||c.a==0)return;
        r=clipped(r);if(r.w<=0||r.h<=0)return;
        if(pixels_){
            const std::uint32_t src=(static_cast<std::uint32_t>(c.r)<<16)|(static_cast<std::uint32_t>(c.g)<<8)|c.b;
            if(c.a==255){
                for(int y=r.y;y<r.y+r.h;++y){auto* row=pixels_+static_cast<std::size_t>(y)*stride_+r.x;std::fill(row,row+r.w,src);}return;
            }
            const unsigned a=c.a,ia=255u-a;
            for(int y=r.y;y<r.y+r.h;++y){
                auto* row=pixels_+static_cast<std::size_t>(y)*stride_+r.x;
                for(int x=0;x<r.w;++x){const std::uint32_t d=row[x];const unsigned db=d&255u,dg=(d>>8)&255u,dr=(d>>16)&255u;
                    const unsigned ob=(static_cast<unsigned>(c.b)*a+db*ia+127u)/255u;
                    const unsigned og=(static_cast<unsigned>(c.g)*a+dg*ia+127u)/255u;
                    const unsigned orr=(static_cast<unsigned>(c.r)*a+dr*ia+127u)/255u;
                    row[x]=(orr<<16)|(og<<8)|ob;
                }
            }return;
        }
        if(c.a==255){RECT rr{r.x,r.y,r.x+r.w,r.y+r.h};FillRect(dc_,&rr,cached_brush(c));return;}
        GdiAlphaTile* tile=cached_alpha_tile(dc_,c);if(!tile)return;BLENDFUNCTION bf{AC_SRC_OVER,0,255,AC_SRC_ALPHA};AlphaBlend(dc_,r.x,r.y,r.w,r.h,tile->dc,0,0,1,1,bf);
    }
    void stroke_rect(Rect r,Color c,int t=1)override{
        if(pixels_){const int th=std::max(1,t);fill_rect({r.x,r.y,r.w,th},c);fill_rect({r.x,r.y+r.h-th,r.w,th},c);fill_rect({r.x,r.y,th,r.h},c);fill_rect({r.x+r.w-th,r.y,th,r.h},c);return;}
        HPEN p=cached_pen(c,t);HGDIOBJ old=SelectObject(dc_,p);HGDIOBJ oldb=SelectObject(dc_,GetStockObject(HOLLOW_BRUSH));Rectangle(dc_,r.x,r.y,r.x+r.w,r.y+r.h);SelectObject(dc_,oldb);SelectObject(dc_,old);
    }
    void line(int x1,int y1,int x2,int y2,Color c,int t=1)override{
        if(pixels_){const int th=std::max(1,t);if(y1==y2){fill_rect({std::min(x1,x2),y1-th/2,std::abs(x2-x1)+1,th},c);return;}if(x1==x2){fill_rect({x1-th/2,std::min(y1,y2),th,std::abs(y2-y1)+1},c);return;}
            int dx=std::abs(x2-x1),sx=x1<x2?1:-1,dy=-std::abs(y2-y1),sy=y1<y2?1:-1,err=dx+dy;for(;;){fill_rect({x1-th/2,y1-th/2,th,th},c);if(x1==x2&&y1==y2)break;const int e2=2*err;if(e2>=dy){err+=dy;x1+=sx;}if(e2<=dx){err+=dx;y1+=sy;}}return;}
        HPEN p=cached_pen(c,t);HGDIOBJ old=SelectObject(dc_,p);MoveToEx(dc_,x1,y1,nullptr);LineTo(dc_,x2,y2);SelectObject(dc_,old);
    }
    void text(int x,int y,const std::string&v,Color c,int size=12,bool bold=false)override{
        if(!pixels_&&font_is_inter(dc_,size,bold)){
            HFONT f=cached_font(size,bold);HGDIOBJ old=SelectObject(dc_,f);auto w=utf8_to_wide(v);SetTextColor(dc_,cr(c));TextOutW(dc_,x,y-size+2,w.c_str(),(int)w.size());SelectObject(dc_,old);return;
        }
        int pen=x;std::size_t pos=0;while(pos<v.size()){
            const std::uint32_t cp=next_utf8_codepoint(v,pos);const auto* glyph=inter_atlas::find(cp,size,bold);if(!glyph)glyph=inter_atlas::find('?',size,bold);if(!glyph)continue;
            const int gx=pen+glyph->left,gy=y+glyph->top;
            for(int row=0;row<glyph->height;++row){for(int col=0;col<glyph->width;++col){const auto level=inter_atlas::kPixels[glyph->offset+static_cast<std::size_t>(row)*glyph->width+col];if(level==0)continue;
                    const unsigned coverage=static_cast<unsigned>(level)*17u;const unsigned alpha=(static_cast<unsigned>(c.a)*coverage+127u)/255u;if(alpha==0)continue;
                    if(pixels_)blend_pixel(gx+col,gy+row,c,alpha);else{Color cc=c;cc.a=static_cast<std::uint8_t>(alpha);fill_rect({gx+col,gy+row,1,1},cc);}
                }}pen+=glyph->advance;
        }
    }
    int text_width(const std::string&v,int size=12,bool bold=false)override{
        if(!pixels_&&font_is_inter(dc_,size,bold)){HFONT f=cached_font(size,bold);HGDIOBJ old=SelectObject(dc_,f);auto w=utf8_to_wide(v);SIZE sz{};GetTextExtentPoint32W(dc_,w.c_str(),(int)w.size(),&sz);SelectObject(dc_,old);return sz.cx;}
        int width=0;std::size_t pos=0;while(pos<v.size()){const std::uint32_t cp=next_utf8_codepoint(v,pos);const auto* glyph=inter_atlas::find(cp,size,bold);if(!glyph)glyph=inter_atlas::find('?',size,bold);if(glyph)width+=glyph->advance;}return width;
    }
    void image(Rect dst,const Frame& f)override{
        if(f.rgb.empty()||f.width<=0||f.height<=0||dst.w<=0||dst.h<=0)return;double scale=std::min(dst.w/(double)f.width,dst.h/(double)f.height);int ow=std::max(1,(int)std::lround(f.width*scale)),oh=std::max(1,(int)std::lround(f.height*scale));
        const int dx=dst.x+(dst.w-ow)/2,dy=dst.y+(dst.h-oh)/2;
        if(auto* cached=cached_scaled_image(dc_,f,ow,oh);cached&&cached->dc){BitBlt(dc_,dx,dy,ow,oh,cached->dc,0,0,SRCCOPY);if(pixels_)GdiFlush();return;}
        const auto& bgr=cached_bgra(f);BITMAPINFO bmi{};bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bmi.bmiHeader.biWidth=f.width;bmi.bmiHeader.biHeight=-f.height;bmi.bmiHeader.biPlanes=1;bmi.bmiHeader.biBitCount=32;bmi.bmiHeader.biCompression=BI_RGB;
        SetStretchBltMode(dc_,HALFTONE);SetBrushOrgEx(dc_,0,0,nullptr);StretchDIBits(dc_,dx,dy,ow,oh,0,0,f.width,f.height,bgr.data(),&bmi,DIB_RGB_COLORS,SRCCOPY);if(pixels_)GdiFlush();
    }
    void push_clip(Rect r)override{
        Rect effective=r;if(!software_clips_.empty())effective=intersect_rect(software_clips_.back(),effective);else effective=intersect_rect({0,0,w_,h_},effective);
        software_clips_.push_back(effective);int saved=SaveDC(dc_);clip_stack_.push_back(saved);IntersectClipRect(dc_,effective.x,effective.y,effective.x+effective.w,effective.y+effective.h);
    }
    void pop_clip()override{if(clip_stack_.empty())return;int saved=clip_stack_.back();clip_stack_.pop_back();RestoreDC(dc_,saved);if(!software_clips_.empty())software_clips_.pop_back();}
private:
    static Rect intersect_rect(Rect a,Rect b){const int x1=std::max(a.x,b.x),y1=std::max(a.y,b.y),x2=std::min(a.x+a.w,b.x+b.w),y2=std::min(a.y+a.h,b.y+b.h);return{x1,y1,std::max(0,x2-x1),std::max(0,y2-y1)};}
    Rect clipped(Rect r)const{return intersect_rect(r,software_clips_.empty()?Rect{0,0,w_,h_}:software_clips_.back());}
    void blend_pixel(int x,int y,Color c,unsigned a){
        if(!pixels_||x<0||y<0||x>=w_||y>=h_)return;if(!software_clips_.empty()&&!software_clips_.back().contains(x,y))return;
        auto& d=pixels_[static_cast<std::size_t>(y)*stride_+x];const unsigned ia=255u-a,db=d&255u,dg=(d>>8)&255u,dr=(d>>16)&255u;
        const unsigned ob=(static_cast<unsigned>(c.b)*a+db*ia+127u)/255u,og=(static_cast<unsigned>(c.g)*a+dg*ia+127u)/255u,orr=(static_cast<unsigned>(c.r)*a+dr*ia+127u)/255u;d=(orr<<16)|(og<<8)|ob;
    }
    HDC dc_;int w_,h_;std::uint32_t* pixels_=nullptr;int stride_=0;std::vector<int> clip_stack_;std::vector<Rect> software_clips_;
};

WglHost g_ui_gpu;
class WinServices final:public PlatformServices{
public:
    explicit WinServices(HWND h):hwnd_(h){}
    std::vector<std::string> open_media_files()override{
        wchar_t buf[65536]{};OPENFILENAMEW ofn{sizeof(ofn)};ofn.hwndOwner=hwnd_;ofn.lpstrFile=buf;ofn.nMaxFile=65536;ofn.lpstrFilter=L"Media Files\0*.mp4;*.mov;*.mkv;*.avi;*.wmv;*.asf;*.webm;*.wav;*.mp3;*.flac;*.aac;*.m4a;*.ogg;*.png;*.jpg;*.jpeg;*.bmp;*.webp;*.tif;*.tiff\0All Files\0*.*\0";ofn.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_ALLOWMULTISELECT;if(!GetOpenFileNameW(&ofn))return{};std::vector<std::string>out;std::wstring first=buf;wchar_t*p=buf+first.size()+1;if(*p==0){out.push_back(wide_to_utf8(first));return out;}std::wstring dir=first;while(*p){std::wstring name=p;out.push_back(wide_to_utf8(dir+L"\\"+name));p+=name.size()+1;}return out;
    }
    std::string open_project_file()override{return file_dialog(false,L"KoraLo / VEGAS Projects\0*.kora;*.veg\0KoraLo Project\0*.kora\0VEGAS Project\0*.veg\0All Files\0*.*\0",L"");}
    std::string save_project_file(const std::string&s)override{return file_dialog(true,L"KoraLo Project\0*.kora\0",utf8_to_wide(s));}
    std::string save_render_file(const std::string&s)override{return file_dialog(true,L"MP4 Video\0*.mp4\0",utf8_to_wide(s));}
    void show_message(const std::string&t,const std::string&m,bool error=false)override{MessageBoxW(hwnd_,utf8_to_wide(m).c_str(),utf8_to_wide(t).c_str(),MB_OK|(error?MB_ICONERROR:MB_ICONINFORMATION));}
    SaveChangesChoice ask_save_changes(const std::string& project_name)override{
        const std::wstring message=L"Save changes to "+utf8_to_wide(project_name)+L" before closing?";
        const int result=MessageBoxW(hwnd_,message.c_str(),L"KoraLo",MB_YESNOCANCEL|MB_ICONQUESTION|MB_DEFBUTTON1);
        if(result==IDYES)return SaveChangesChoice::Save;
        if(result==IDNO)return SaveChangesChoice::Discard;
        return SaveChangesChoice::Cancel;
    }
    void set_title(const std::string&t)override{SetWindowTextW(hwnd_,utf8_to_wide(t).c_str());}
    void request_redraw()override{InvalidateRect(hwnd_,nullptr,FALSE);}
    std::string interface_renderer()const override{return g_ui_gpu.label();}
    bool set_interface_gpu_enabled(bool enabled)override{InvalidateRect(hwnd_,nullptr,FALSE);return g_ui_gpu.enable(enabled);}
    std::string executable_dir() const override{wchar_t buf[32768]{};DWORD n=GetModuleFileNameW(nullptr,buf,32768);if(n==0||n>=32768)return{};std::wstring full(buf,n);const auto slash=full.find_last_of(L"\\/");return wide_to_utf8(slash==std::wstring::npos?std::wstring{}:full.substr(0,slash));}
private:
    std::string file_dialog(bool save,const wchar_t*filter,const std::wstring&suggest){wchar_t buf[MAX_PATH]{};if(!suggest.empty()){std::wcsncpy(buf,suggest.c_str(),MAX_PATH-1);buf[MAX_PATH-1]=0;}OPENFILENAMEW ofn{sizeof(ofn)};ofn.hwndOwner=hwnd_;ofn.lpstrFile=buf;ofn.nMaxFile=MAX_PATH;ofn.lpstrFilter=filter;ofn.Flags=OFN_EXPLORER|(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST);bool ok=save?GetSaveFileNameW(&ofn):GetOpenFileNameW(&ofn);return ok?wide_to_utf8(buf):std::string{};}
    HWND hwnd_;
};

struct BackBuffer {
    HDC dc=nullptr;
    HBITMAP bitmap=nullptr;
    HGDIOBJ old_bitmap=nullptr;
    std::uint32_t* pixels=nullptr;
    int width=0,height=0;
    bool ensure(HDC reference,int w,int h){
        if(dc&&bitmap&&pixels&&width==w&&height==h)return true;
        reset();
        dc=CreateCompatibleDC(reference);if(!dc)return false;
        BITMAPINFO bmi{};bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bmi.bmiHeader.biWidth=w;bmi.bmiHeader.biHeight=-h;bmi.bmiHeader.biPlanes=1;bmi.bmiHeader.biBitCount=32;bmi.bmiHeader.biCompression=BI_RGB;
        void* bits=nullptr;bitmap=CreateDIBSection(reference,&bmi,DIB_RGB_COLORS,&bits,nullptr,0);if(!bitmap||!bits){if(bitmap)DeleteObject(bitmap);DeleteDC(dc);dc=nullptr;bitmap=nullptr;return false;}
        old_bitmap=SelectObject(dc,bitmap);pixels=static_cast<std::uint32_t*>(bits);width=w;height=h;return true;
    }
    void reset(){
        if(dc&&old_bitmap)SelectObject(dc,old_bitmap);
        if(bitmap)DeleteObject(bitmap);
        if(dc)DeleteDC(dc);
        dc=nullptr;bitmap=nullptr;old_bitmap=nullptr;pixels=nullptr;width=height=0;
    }
};

EditorApp* g_app=nullptr;WinServices* g_services=nullptr;BackBuffer g_back_buffer;
HBITMAP g_splash_bitmap=nullptr;
std::string g_splash_status="Starting KoraLo...";
double g_splash_progress=0.05;

LRESULT CALLBACK splash_wndproc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
    switch(msg){
        case WM_ERASEBKGND:return 1;
        case WM_PAINT:{
            PAINTSTRUCT ps{};HDC dc=BeginPaint(h,&ps);RECT r{};GetClientRect(h,&r);
            HBRUSH bg=CreateSolidBrush(RGB(3,8,12));FillRect(dc,&r,bg);DeleteObject(bg);
            if(g_splash_bitmap){
                BITMAP bm{};GetObjectW(g_splash_bitmap,sizeof(bm),&bm);
                HDC mem=CreateCompatibleDC(dc);HGDIOBJ old=SelectObject(mem,g_splash_bitmap);
                SetStretchBltMode(dc,HALFTONE);
                int cw=static_cast<int>(r.right-r.left);
                int ch=static_cast<int>(r.bottom-r.top);
                if(cw < 1) cw = 1;
                if(ch < 1) ch = 1;
                const double scale=std::min(cw/static_cast<double>(bm.bmWidth),ch/static_cast<double>(bm.bmHeight));
                const int dw=std::max(1,static_cast<int>(bm.bmWidth*scale));
                const int dh=std::max(1,static_cast<int>(bm.bmHeight*scale));
                const int dx=(cw-dw)/2,dy=(ch-dh)/2;
                StretchBlt(dc,dx,dy,dw,dh,mem,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);
                SelectObject(mem,old);DeleteDC(mem);
            }
            const int panel_h=58;RECT panel{0,std::max(0,static_cast<int>(r.bottom)-panel_h),r.right,r.bottom};HBRUSH pb=CreateSolidBrush(RGB(8,12,18));FillRect(dc,&panel,pb);DeleteObject(pb);
            const int margin=24,bar_y=static_cast<int>(r.bottom)-18,bar_w=std::max(1,static_cast<int>(r.right)-margin*2);RECT track{margin,bar_y,margin+bar_w,bar_y+7};HBRUSH tb=CreateSolidBrush(RGB(30,36,45));FillRect(dc,&track,tb);DeleteObject(tb);
            RECT fill{margin,bar_y,margin+static_cast<int>(bar_w*std::clamp(g_splash_progress,0.0,1.0)),bar_y+7};HBRUSH fb=CreateSolidBrush(RGB(70,120,210));FillRect(dc,&fill,fb);DeleteObject(fb);
            GdiCanvas splash_canvas(dc,std::max(1,static_cast<int>(r.right)),std::max(1,static_cast<int>(r.bottom)));splash_canvas.text(margin,static_cast<int>(r.bottom)-25,g_splash_status,Color{225,230,238},15,false);
            EndPaint(h,&ps);return 0;
        }
    }
    return DefWindowProcW(h,msg,wp,lp);
}

HWND create_splash(HINSTANCE inst){
    g_splash_bitmap=static_cast<HBITMAP>(LoadImageW(inst,MAKEINTRESOURCEW(IDB_KORALO_SPLASH),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION));
    if(!g_splash_bitmap)return nullptr;
    WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=splash_wndproc;wc.hInstance=inst;wc.lpszClassName=L"KoraLoSplash";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);
    wc.hIcon=static_cast<HICON>(LoadImageW(inst,MAKEINTRESOURCEW(IDI_KORALO_ICON),IMAGE_ICON,32,32,LR_DEFAULTCOLOR));
    RegisterClassExW(&wc);
    BITMAP bm{};GetObjectW(g_splash_bitmap,sizeof(bm),&bm);
    const int sw=GetSystemMetrics(SM_CXSCREEN),sh=GetSystemMetrics(SM_CYSCREEN);
    const int splash_w=static_cast<int>(bm.bmWidth);
    const int splash_h=static_cast<int>(bm.bmHeight);
    int x=(sw-splash_w)/2;
    int y=(sh-splash_h)/2;
    if(x < 0) x = 0;
    if(y < 0) y = 0;
    HWND splash=CreateWindowExW(WS_EX_TOOLWINDOW|WS_EX_TOPMOST,wc.lpszClassName,L"KoraLo",WS_POPUP,x,y,splash_w,splash_h,nullptr,nullptr,inst,nullptr);
    if(splash){ShowWindow(splash,SW_SHOWNORMAL);UpdateWindow(splash);}
    return splash;
}


void update_splash(HWND splash,const std::string& status,double progress){
    g_splash_status=status;g_splash_progress=std::clamp(progress,0.0,1.0);
    if(splash){InvalidateRect(splash,nullptr,FALSE);UpdateWindow(splash);}
}
void destroy_splash(HWND splash){
    if(splash)DestroyWindow(splash);
    if(g_splash_bitmap){DeleteObject(g_splash_bitmap);g_splash_bitmap=nullptr;}
}
double dpi_scale_for_window(HWND h){
    using GetDpiForWindowFn=UINT (WINAPI*)(HWND);
    auto* user32=GetModuleHandleW(L"user32.dll");
    auto get_dpi=reinterpret_cast<GetDpiForWindowFn>(GetProcAddress(user32,"GetDpiForWindow"));
    UINT dpi=get_dpi?get_dpi(h):0;
    if(dpi==0){HDC dc=GetDC(h);if(dc){dpi=static_cast<UINT>(GetDeviceCaps(dc,LOGPIXELSX));ReleaseDC(h,dc);}}
    if(dpi==0)dpi=96;
    return std::clamp(static_cast<double>(dpi)/96.0,1.0,2.5);
}

void enable_per_monitor_dpi_awareness(){
    using SetDpiContextFn=BOOL (WINAPI*)(DPI_AWARENESS_CONTEXT);
    auto* user32=GetModuleHandleW(L"user32.dll");
    auto set_context=reinterpret_cast<SetDpiContextFn>(GetProcAddress(user32,"SetProcessDpiAwarenessContext"));
    if(!set_context||!set_context(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2))SetProcessDPIAware();
}

Key key_from_wp(WPARAM w){switch(w){case 'B':return Key::B;case VK_DELETE:return Key::Delete;case VK_SPACE:return Key::Space;case VK_LEFT:return Key::Left;case VK_RIGHT:return Key::Right;case 'S':return Key::S;case 'Z':return Key::Z;case 'Y':return Key::Y;case 'I':return Key::I;case 'O':return Key::O;case 'M':return Key::M;case 'N':return Key::N;case 'C':return Key::C;case 'V':return Key::V;case 'X':return Key::X;case 'L':return Key::L;case VK_ESCAPE:return Key::Escape;case VK_RETURN:return Key::Enter;case VK_BACK:return Key::Backspace;case VK_F1:return Key::F1;case VK_OEM_PLUS:return Key::Plus;case VK_OEM_MINUS:return Key::Minus;default:return Key::Unknown;}}
bool down(int vk){return(GetKeyState(vk)&0x8000)!=0;}

LRESULT CALLBACK wndproc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
    if(!g_app)return DefWindowProcW(h,msg,wp,lp);
    switch(msg){
        case WM_CLOSE:g_app->request_close();if(g_app->wants_close())DestroyWindow(h);return 0;
        case WM_DESTROY:g_ui_gpu.reset();g_back_buffer.reset();release_gdi_caches();PostQuitMessage(0);return 0;
        case WM_ERASEBKGND:return 1;
        case WM_DPICHANGED:{
            g_app->set_ui_scale(static_cast<double>(HIWORD(wp))/96.0);
            if(const RECT* suggested=reinterpret_cast<const RECT*>(lp)){
                SetWindowPos(h,nullptr,suggested->left,suggested->top,suggested->right-suggested->left,suggested->bottom-suggested->top,SWP_NOZORDER|SWP_NOACTIVATE);
            }
            InvalidateRect(h,nullptr,FALSE);
            return 0;
        }
        case WM_PAINT:{
            PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT r{};GetClientRect(h,&r);
            int w=static_cast<int>(r.right-r.left);
            int height=static_cast<int>(r.bottom-r.top);
            if(w < 1) w = 1;
            if(height < 1) height = 1;
            bool painted=false;if(auto* canvas=g_ui_gpu.begin(h,w,height)){g_app->draw(*canvas);painted=g_ui_gpu.finish();}
            if(!painted&&g_back_buffer.ensure(dc,w,height)){
                GdiCanvas c(g_back_buffer.dc,w,height,g_back_buffer.pixels,g_back_buffer.width);g_app->draw(c);
                BitBlt(dc,0,0,w,height,g_back_buffer.dc,0,0,SRCCOPY);
            }else if(!painted){
                GdiCanvas c(dc,w,height);g_app->draw(c);
            }
            EndPaint(h,&ps);return 0;
        }
        case WM_LBUTTONDOWN:SetCapture(h);g_app->mouse_down(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),1,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_LBUTTONUP:ReleaseCapture();g_app->mouse_up(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),1,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_MBUTTONDOWN:SetCapture(h);g_app->mouse_down(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),2,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_MBUTTONUP:ReleaseCapture();g_app->mouse_up(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),2,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_RBUTTONDOWN:g_app->mouse_down(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),3,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_RBUTTONUP:g_app->mouse_up(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),3,down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_MOUSEMOVE:g_app->mouse_move(GET_X_LPARAM(lp),GET_Y_LPARAM(lp),down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_MOUSEWHEEL:{POINT p{GET_X_LPARAM(lp),GET_Y_LPARAM(lp)};ScreenToClient(h,&p);g_app->mouse_wheel(p.x,p.y,GET_WHEEL_DELTA_WPARAM(wp)>0?1:-1,down(VK_CONTROL),down(VK_SHIFT));return 0;}
        case WM_KEYDOWN:g_app->key_down(key_from_wp(wp),down(VK_CONTROL),down(VK_SHIFT),down(VK_MENU));return 0;
        case WM_CHAR:{if(!down(VK_CONTROL)&&wp>=32){wchar_t ch=static_cast<wchar_t>(wp);g_app->text_input(wide_to_utf8(std::wstring(1,ch)));}return 0;}
        case WM_DROPFILES:{HDROP drop=(HDROP)wp;UINT n=DragQueryFileW(drop,0xFFFFFFFF,nullptr,0);POINT pt;DragQueryPoint(drop,&pt);for(UINT i=0;i<n;++i){wchar_t b[MAX_PATH];DragQueryFileW(drop,i,b,MAX_PATH);g_app->file_dropped(wide_to_utf8(b),pt.x,pt.y);}DragFinish(drop);return 0;}
    }
    return DefWindowProcW(h,msg,wp,lp);
}
}

int WINAPI wWinMain(HINSTANCE inst,HINSTANCE,LPWSTR,int show){
    // Per-monitor DPI awareness keeps custom-drawn UI coordinates stable and
    // prevents resolution-based double scaling on 1440p/4K displays.
    enable_per_monitor_dpi_awareness();
    const auto splash_started=std::chrono::steady_clock::now();
    HWND splash=create_splash(inst);
    update_splash(splash,"Loading native resources...",0.12);

    HICON icon_big=static_cast<HICON>(LoadImageW(inst,MAKEINTRESOURCEW(IDI_KORALO_ICON),IMAGE_ICON,32,32,LR_DEFAULTCOLOR));
    HICON icon_small=static_cast<HICON>(LoadImageW(inst,MAKEINTRESOURCEW(IDI_KORALO_ICON),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));
    WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=wndproc;wc.hInstance=inst;wc.lpszClassName=L"KoraLoNative";wc.style=CS_OWNDC|CS_HREDRAW|CS_VREDRAW;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=icon_big;wc.hIconSm=icon_small;
    if(!RegisterClassExW(&wc)){destroy_splash(splash);return 2;}
    const int desktop_w=GetSystemMetrics(SM_CXSCREEN),desktop_h=GetSystemMetrics(SM_CYSCREEN);const int initial_w=std::clamp(static_cast<int>(desktop_w*0.86),1200,std::max(1200,desktop_w-80));const int initial_h=std::clamp(static_cast<int>(desktop_h*0.84),720,std::max(720,desktop_h-80));
    HWND h=CreateWindowExW(0,wc.lpszClassName,L"KoraLo Native",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,initial_w,initial_h,nullptr,nullptr,inst,nullptr);
    if(!h){destroy_splash(splash);return 2;}
    SendMessageW(h,WM_SETICON,ICON_BIG,reinterpret_cast<LPARAM>(icon_big));
    SendMessageW(h,WM_SETICON,ICON_SMALL,reinterpret_cast<LPARAM>(icon_small));
    DragAcceptFiles(h,TRUE);
    WinServices services(h);update_splash(splash,"Checking FFmpeg, GPU and audio devices...",0.35);
    EditorApp app(services);g_services=&services;g_app=&app;app.set_ui_scale(dpi_scale_for_window(h));
    update_splash(splash,"System check complete — preparing editor...",0.88);

    // Keep a fast startup visible without delaying a genuinely slow initialization.
    MSG preload{};
    while(splash&&std::chrono::steady_clock::now()-splash_started<std::chrono::milliseconds(650)){
        while(PeekMessageW(&preload,nullptr,0,0,PM_REMOVE)){TranslateMessage(&preload);DispatchMessageW(&preload);}
        std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
    destroy_splash(splash);
    ShowWindow(h,show);UpdateWindow(h);
    MSG msg{};bool running=true;while(running){
        while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){running=false;break;}TranslateMessage(&msg);DispatchMessageW(&msg);}
        if(!running)break;
        app.tick();
        // Wait for input or the next editor tick. Unlike an unconditional Sleep,
        // this returns immediately when tick() invalidates the window for a UI
        // animation/preview frame, so animations are not delayed by an extra 8 ms.
        MsgWaitForMultipleObjectsEx(0,nullptr,8,QS_ALLINPUT,MWMO_INPUTAVAILABLE);
    }
    g_app=nullptr;return 0;
}
#endif
