#pragma once

#define IDI_KORALO_ICON 101
#define IDB_KORALO_SPLASH 102
