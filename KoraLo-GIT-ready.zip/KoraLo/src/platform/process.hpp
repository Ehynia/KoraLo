#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <string>
#include <string_view>
#include <vector>

namespace koralo {

struct ProcessResult {
  bool started = false;
  bool cancelled = false;
  bool timed_out = false;
  int exit_code = -1;
  std::string output;
};

struct ProcessOptions {
  int timeout_ms = 60000;
  const std::atomic<bool> *cancel = nullptr;
  std::size_t max_output_bytes = 8 * 1024 * 1024;
  // Optional bytes written to the child's stdin before stdout is consumed.
  // Intended for small request/response helper protocols (for example OFX
  // scanner JSONL), not bulk media streaming.
  std::string input;
  // run_process historically merged stderr into stdout. Keep that default for
  // command-line tools, but protocol helpers can disable it so diagnostics can
  // never corrupt machine-readable stdout.
  bool capture_stderr = true;
  std::function<void(std::string_view)> on_output;
};
// KoraLo stores paths as UTF-8 strings. These helpers are the only conversion
// boundary needed by native filesystem/process APIs.
std::filesystem::path path_from_utf8(const std::string &value);
std::string path_to_utf8(const std::filesystem::path &value);

std::filesystem::path current_executable_path();
void initialize_executable_path(const std::string &argv0);
std::filesystem::path app_install_directory();
std::string environment_utf8(const char *name);
bool is_executable_file(const std::filesystem::path &path);
bool atomic_replace_file(const std::filesystem::path &from,
                         const std::filesystem::path &to,
                         std::string *error = nullptr);
std::string find_executable_on_path(const std::string &name);

// Launches executable directly (no command shell) and captures stdout+stderr.
// Arguments are passed as individual argv entries, so spaces, quotes and
// non-ASCII paths do not need shell escaping.
ProcessResult run_process(const std::string &executable,
                          const std::vector<std::string> &arguments,
                          const ProcessOptions &options = {});

// Shell-free child process with a binary stdout pipe. Used by the realtime
// preview decoder so FFmpeg stays alive across consecutive frames instead of
// paying process-start and temporary-file overhead for every frame.
class ReadPipeProcess {
public:
  ReadPipeProcess() = default;
  ~ReadPipeProcess();
  ReadPipeProcess(const ReadPipeProcess &) = delete;
  ReadPipeProcess &operator=(const ReadPipeProcess &) = delete;
  ReadPipeProcess(ReadPipeProcess &&other) noexcept;
  ReadPipeProcess &operator=(ReadPipeProcess &&other) noexcept;

  bool start(const std::string &executable,
             const std::vector<std::string> &arguments,
             std::string *error = nullptr, bool capture_stderr = false,
             bool open_stdin = false);
  bool write_stdin_and_close(std::string_view input,
                             std::string *error = nullptr);
  // Bulk binary encoder input. Unlike the small JSONL helper, the stdin pipe
  // stays open between calls, so FFmpeg can encode frames continuously.
  bool write_stdin_chunk(std::string_view input, std::string *error = nullptr,
                         const std::atomic<bool>* cancel = nullptr);
  void close_stdin();
  int read_some(void *data, std::size_t bytes, int timeout_ms = 10000,
                const std::atomic<bool> *cancel = nullptr,
                std::string *error = nullptr);
  bool read_exact(void *data, std::size_t bytes, std::string *error = nullptr,
                  const std::atomic<bool> *cancel = nullptr,
                  int timeout_ms = 10000);
  int exit_code() const { return exit_code_; }
  void terminate();
  bool running();

private:
  std::uintptr_t native_ = 0;
  std::intptr_t read_native_ = -1;
  std::intptr_t write_native_ = -1;
  int exit_code_ = -1;
};

// Small shell-free process handle used for realtime helper processes such as
// ffplay audio preview. The child is terminated automatically on destruction.
class DetachedProcess {
public:
  DetachedProcess() = default;
  ~DetachedProcess();
  DetachedProcess(const DetachedProcess &) = delete;
  DetachedProcess &operator=(const DetachedProcess &) = delete;
  DetachedProcess(DetachedProcess &&other) noexcept;
  DetachedProcess &operator=(DetachedProcess &&other) noexcept;

  bool start(const std::string &executable,
             const std::vector<std::string> &arguments,
             std::string *error = nullptr);
  void terminate();
  bool running();

private:
  std::uintptr_t native_ = 0;
};

} // namespace koralo
