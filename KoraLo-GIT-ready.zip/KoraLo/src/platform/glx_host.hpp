#pragma once
#ifndef _WIN32
#include "../ui/opengl_canvas.hpp"
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <dlfcn.h>
#include <memory>
namespace koralo {
class GlxHost {
public:
  XVisualInfo *choose(Display *display, int screen) {
    d_ = display;
    enabled_ = interface_gpu_requested();
    if (!enabled_)
      return nullptr;
    int opcode = 0, event = 0, error = 0;
    if (!XQueryExtension(d_, "GLX", &opcode, &event, &error))
      return nullptr;
    library_ = dlopen("libGL.so.1", RTLD_NOW | RTLD_LOCAL);
    if (!library_)
      return nullptr;
    choose_ =
        reinterpret_cast<decltype(choose_)>(dlsym(library_, "glXChooseVisual"));
    create_ = reinterpret_cast<decltype(create_)>(
        dlsym(library_, "glXCreateContext"));
    current_ =
        reinterpret_cast<decltype(current_)>(dlsym(library_, "glXMakeCurrent"));
    swap_ =
        reinterpret_cast<decltype(swap_)>(dlsym(library_, "glXSwapBuffers"));
    destroy_ = reinterpret_cast<decltype(destroy_)>(
        dlsym(library_, "glXDestroyContext"));
    if (!choose_ || !create_ || !current_ || !swap_ || !destroy_)
      return nullptr;
    int attributes[] = {4, 5, 8, 8, 9, 8, 10, 8, 0};
    visual_ = choose_(d_, screen, attributes);
    return visual_;
  }
  bool initialize(Window window) {
    window_ = window;
    if (!visual_)
      return false;
    creation_error_ = false;
    XSync(d_, False);
    auto previous = XSetErrorHandler([](Display *, XErrorEvent *) {
      creation_error_ = true;
      return 0;
    });
    context_ = create_(d_, visual_, nullptr, True);
    bool ok = context_ && current_(d_, window_, context_);
    XSync(d_, False);
    XSetErrorHandler(previous);
    if (!ok || creation_error_)
      return false;
    canvas_ = std::make_unique<OpenGlCanvas>();
    if (!canvas_->initialize(
            [&](const char *n) { return dlsym(library_, n); })) {
      canvas_.reset();
      return false;
    }
    return true;
  }
  OpenGlCanvas *begin(int w, int h) {
    if (!enabled_ || !canvas_ || !current_(d_, window_, context_))
      return nullptr;
    canvas_->begin(w, h);
    return canvas_.get();
  }
  bool finish() {
    if (!canvas_)
      return false;
    bool ok = canvas_->finish();
    if (ok)
      swap_(d_, window_);
    else
      enabled_ = false;
    return ok;
  }
  std::string label() const {
    return enabled_ && canvas_ ? canvas_->renderer() : "CPU · X11";
  }
  bool enable(bool enabled) {
    enabled_ = enabled && bool(canvas_);
    return enabled_;
  }
  void reset() {
    if (context_) {
      current_(d_, window_, context_);
      canvas_.reset();
      current_(d_, 0, nullptr);
      destroy_(d_, context_);
      context_ = nullptr;
    }
    if (visual_) {
      XFree(visual_);
      visual_ = nullptr;
    }
    if (library_) {
      dlclose(library_);
      library_ = nullptr;
    }
  }
  ~GlxHost() { reset(); }

private:
  inline static bool creation_error_ = false;
  Display *d_ = nullptr;
  Window window_ = 0;
  void *library_ = nullptr;
  XVisualInfo *visual_ = nullptr;
  void *context_ = nullptr;
  bool enabled_ = true;
  XVisualInfo *(*choose_)(Display *, int, int *) = nullptr;
  void *(*create_)(Display *, XVisualInfo *, void *, Bool) = nullptr;
  Bool (*current_)(Display *, unsigned long, void *) = nullptr;
  void (*swap_)(Display *, unsigned long) = nullptr;
  void (*destroy_)(Display *, void *) = nullptr;
  std::unique_ptr<OpenGlCanvas> canvas_;
};
} // namespace koralo
#endif
