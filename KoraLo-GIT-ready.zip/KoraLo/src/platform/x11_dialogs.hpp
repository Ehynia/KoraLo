// Included after XCanvas in x11_main.cpp. No external dialog runtime.
class NativeDialog {
public:
  NativeDialog(Display *display, Window parent, const std::string &title,
               int width, int height)
      : d(display), w(width), h(height) {
    int screen = DefaultScreen(d);
    window =
        XCreateSimpleWindow(d, RootWindow(d, screen), 20, 20, w, h, 0, 0, 0);
    XStoreName(d, window, title.c_str());
    XSetTransientForHint(d, window, parent);
    XSizeHints hints{};
    hints.flags = PMinSize | PMaxSize;
    hints.min_width = hints.max_width = w;
    hints.min_height = hints.max_height = h;
    XSetWMNormalHints(d, window, &hints);
    close_atom = XInternAtom(d, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(d, window, &close_atom, 1);
    XSelectInput(d, window,
                 ExposureMask | KeyPressMask | ButtonPressMask |
                     StructureNotifyMask);
    gc = XCreateGC(d, window, 0, nullptr);
    im = XOpenIM(d, nullptr, nullptr, nullptr);
    if (im)
      ic = XCreateIC(im, XNInputStyle, XIMPreeditNothing | XIMStatusNothing,
                     XNClientWindow, window, XNFocusWindow, window, nullptr);
    XMapRaised(d, window);
    if (ic)
      XSetICFocus(ic);
    XFlush(d);
  }
  ~NativeDialog() {
    if (ic)
      XDestroyIC(ic);
    if (im)
      XCloseIM(im);
    XFreeGC(d, gc);
    XDestroyWindow(d, window);
    XFlush(d);
  }
  XEvent next() {
    XEvent e{};
    XIfEvent(
        d, &e,
        [](Display *, XEvent *event, XPointer pointer) -> Bool {
          return event->xany.window == *reinterpret_cast<Window *>(pointer);
        },
        reinterpret_cast<XPointer>(&window));
    return e;
  }
  bool closed(const XEvent &e) {
    return e.type == ClientMessage &&
           static_cast<Atom>(e.xclient.data.l[0]) == close_atom;
  }
  std::string input(XEvent &e, KeySym &key) {
    char bytes[1024]{};
    int count;
    if (ic) {
      Status status{};
      count =
          Xutf8LookupString(ic, &e.xkey, bytes, sizeof(bytes), &key, &status);
      if (status == XBufferOverflow)
        return {};
    } else
      count = XLookupString(&e.xkey, bytes, sizeof(bytes), &key, nullptr);
    return count > 0 ? std::string(bytes, count) : std::string{};
  }
  XCanvas canvas() { return XCanvas(d, window, gc, w, h); }
  Display *d;
  Window window{};
  GC gc{};
  int w, h;
  Atom close_atom{};
  XIM im{};
  XIC ic{};
};
int native_message(Display *d, Window parent, const std::string &title,
                   const std::string &message,
                   const std::vector<std::string> &options) {
  NativeDialog dialog(d, parent, title, 720, 440);
  std::vector<std::string> lines;
  auto measure = dialog.canvas();
  std::istringstream stream(message);
  std::string line;
  while (std::getline(stream, line)) {
    std::string part;
    for (std::size_t i = 0; i < line.size();) {
      auto begin = i;
      next_utf8_codepoint(line, i);
      auto character = line.substr(begin, i - begin);
      if (!part.empty() && measure.text_width(part + character, 13) > 670) {
        lines.push_back(part);
        part.clear();
      }
      part += character;
    }
    lines.push_back(part);
  }
  std::size_t scroll = 0;
  bool paint = true;
  for (;;) {
    if (paint) {
      auto c = dialog.canvas();
      c.fill_rect({0, 0, 720, 440}, theme::panel);
      c.text(20, 30, title, theme::text, 16, true);
      for (std::size_t i = 0; i < 16 && scroll + i < lines.size(); ++i)
        c.text(20, 62 + static_cast<int>(i) * 19, lines[scroll + i],
               theme::text, 13);
      for (std::size_t i = 0; i < options.size(); ++i) {
        int x = 700 - static_cast<int>(options.size() - i) * 116;
        c.fill_rect({x, 392, 108, 32}, theme::raised);
        c.text(x + 12, 413, options[i], theme::text, 13);
      }
      XFlush(d);
      paint = false;
    }
    auto e = dialog.next();
    if (dialog.closed(e))
      return static_cast<int>(options.size()) - 1;
    if (e.type == ButtonPress) {
      if (e.xbutton.button == 4 && scroll > 0)
        --scroll;
      if (e.xbutton.button == 5 && scroll + 16 < lines.size())
        ++scroll;
      if (e.xbutton.button == 1 && e.xbutton.y >= 392 && e.xbutton.y < 424)
        for (std::size_t i = 0; i < options.size(); ++i) {
          int x = 700 - static_cast<int>(options.size() - i) * 116;
          if (e.xbutton.x >= x && e.xbutton.x < x + 108)
            return static_cast<int>(i);
        }
    }
    if (e.type == KeyPress) {
      KeySym key{};
      dialog.input(e, key);
      if (key == XK_Escape)
        return static_cast<int>(options.size()) - 1;
      if (key == XK_Return)
        return 0;
      if (options.size() == 3) {
        if (key == XK_s || key == XK_S)
          return 0;
        if (key == XK_d || key == XK_D)
          return 1;
        if (key == XK_c || key == XK_C)
          return 2;
      }
      if (key == XK_Up && scroll > 0)
        --scroll;
      if (key == XK_Down && scroll + 16 < lines.size())
        ++scroll;
    }
    paint = true;
  }
}
std::vector<std::string>
native_choose_files(Display *d, Window parent, const std::string &title,
                    bool save, const std::string &suggested,
                    const std::vector<std::string> &extensions, bool multiple) {
  namespace fs = std::filesystem;
  NativeDialog dialog(d, parent, title, 760, 550);
  static fs::path previous;
  std::error_code ec;
  fs::path directory = previous.empty() ? fs::current_path(ec) : previous;
  if (ec || !fs::is_directory(directory, ec))
    directory = temporary_directory();
  struct Entry {
    fs::path path;
    bool directory;
  };
  std::vector<Entry> entries;
  std::set<std::size_t> selected;
  std::size_t scroll = 0;
  std::string filename = save ? suggested : std::string{}, status;
  bool field = true, select_all = save, paint = true;
  auto allowed = [&](const fs::path &path) {
    auto ext = path_to_utf8(path.extension());
    for (auto &c : ext)
      c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return extensions.empty() || std::find(extensions.begin(), extensions.end(),
                                           ext) != extensions.end();
  };
  auto refresh = [&]() {
    entries.clear();
    selected.clear();
    scroll = 0;
    ec.clear();
    fs::directory_iterator it(
        directory, fs::directory_options::skip_permission_denied, ec),
        end;
    while (!ec && it != end) {
      auto item = *it;
      std::error_code error;
      bool is_dir = item.is_directory(error);
      if (!error &&
          (is_dir || (item.is_regular_file(error) && allowed(item.path()))))
        entries.push_back({item.path(), is_dir});
      it.increment(ec);
    }
    std::sort(entries.begin(), entries.end(),
              [](const Entry &a, const Entry &b) {
                return a.directory != b.directory
                           ? a.directory > b.directory
                           : a.path.filename() < b.path.filename();
              });
    status = ec ? ec.message()
                : "Enter a path, or select files. Ctrl+click: multiple. Esc: "
                  "cancel.";
    paint = true;
  };
  refresh();
  auto accept = [&]() -> std::vector<std::string> {
    if (!field && !selected.empty() && entries[*selected.begin()].directory) {
      directory = entries[*selected.begin()].path;
      filename.clear();
      refresh();
      return {};
    }
    std::vector<std::string> result;
    if (!save && multiple && !field && !selected.empty())
      for (auto index : selected)
        if (!entries[index].directory)
          result.push_back(path_to_utf8(entries[index].path));
    if (!result.empty()) {
      previous = directory;
      return result;
    }
    auto path = path_from_utf8(filename);
    if (path.empty()) {
      status = "Select a file or enter its path.";
      return {};
    }
    if (path.is_relative())
      path = directory / path;
    path = path.lexically_normal();
    ec.clear();
    if (fs::is_directory(path, ec)) {
      directory = path;
      filename.clear();
      refresh();
      return {};
    }
    if (save && path.extension().empty() && !extensions.empty())
      path += path_from_utf8(extensions.front());
    if (!save && (!fs::is_regular_file(path, ec) || !allowed(path))) {
      status = "File does not exist or has an unsupported extension.";
      return {};
    }
    if (save) {
      if (!fs::is_directory(path.parent_path(), ec)) {
        status = "Destination directory does not exist.";
        return {};
      }
      if (fs::exists(path, ec) &&
          native_message(d, dialog.window, "Replace file?",
                         path_to_utf8(path) + "\nReplace this file?",
                         {"Replace", "Cancel"}) != 0)
        return {};
    }
    previous = path.parent_path();
    return {path_to_utf8(path)};
  };
  Time last_click = 0;
  std::size_t last_row = static_cast<std::size_t>(-1);
  for (;;) {
    if (paint) {
      auto c = dialog.canvas();
      c.fill_rect({0, 0, 760, 550}, theme::panel);
      c.text(16, 28, title, theme::text, 16, true);
      c.fill_rect({16, 42, 80, 32}, theme::raised);
      c.text(29, 63, "Up", theme::text, 13);
      c.push_clip({104, 42, 640, 32});
      c.text(112, 64, path_to_utf8(directory), theme::text, 13);
      c.pop_clip();
      c.push_clip({16, 88, 728, 360});
      for (std::size_t row = 0; row < 15 && scroll + row < entries.size();
           ++row) {
        auto index = scroll + row;
        int y = 88 + static_cast<int>(row) * 24;
        if (selected.contains(index))
          c.fill_rect({16, y, 728, 24}, theme::accent2);
        c.text(24, y + 17,
               (entries[index].directory ? "[Folder] " : "         ") +
                   path_to_utf8(entries[index].path.filename()),
               theme::text, 13);
      }
      c.pop_clip();
      c.fill_rect({16, 458, 490, 32}, theme::bg);
      c.stroke_rect({16, 458, 490, 32}, field ? theme::accent : theme::border);
      c.push_clip({22, 462, 478, 25});
      c.text(24, 480, filename, theme::text, 13);
      c.pop_clip();
      c.fill_rect({516, 458, 110, 32}, theme::accent2);
      c.text(532, 480, save ? "Save" : "Open", theme::text, 13);
      c.fill_rect({634, 458, 110, 32}, theme::raised);
      c.text(649, 480, "Cancel", theme::text, 13);
      c.push_clip({16, 502, 728, 40});
      c.text(16, 520, status, theme::dim, 12);
      c.pop_clip();
      XFlush(d);
      paint = false;
    }
    auto e = dialog.next();
    if (dialog.closed(e))
      return {};
    if (e.type == ButtonPress) {
      if (e.xbutton.button == 4 && scroll > 0)
        --scroll;
      if (e.xbutton.button == 5 && scroll + 15 < entries.size())
        ++scroll;
      if (e.xbutton.button == 1) {
        int x = e.xbutton.x, y = e.xbutton.y;
        if (x < 96 && y >= 42 && y < 74) {
          directory = directory.parent_path();
          filename.clear();
          refresh();
        } else if (y >= 88 && y < 448) {
          auto index = scroll + static_cast<std::size_t>((y - 88) / 24);
          if (index < entries.size()) {
            bool ctrl = multiple && !save && (e.xbutton.state & ControlMask);
            if (!ctrl)
              selected.clear();
            if (ctrl && selected.contains(index))
              selected.erase(index);
            else
              selected.insert(index);
            field = false;
            filename = path_to_utf8(entries[index].path.filename());
            if (index == last_row && e.xbutton.time - last_click < 350) {
              auto result = accept();
              if (!result.empty())
                return result;
            }
            last_row = index;
            last_click = e.xbutton.time;
          }
        } else if (y >= 458 && y < 490) {
          if (x < 506) {
            field = true;
            select_all = true;
          } else if (x < 626) {
            auto result = accept();
            if (!result.empty())
              return result;
          } else
            return {};
        }
      }
    }
    if (e.type == KeyPress) {
      KeySym key{};
      auto input = dialog.input(e, key);
      bool ctrl = e.xkey.state & ControlMask;
      if (key == XK_Escape)
        return {};
      if (key == XK_Return || key == XK_KP_Enter) {
        auto result = accept();
        if (!result.empty())
          return result;
      } else if (key == XK_Tab) {
        field = !field;
        select_all = true;
      } else if (!field && (key == XK_Up || key == XK_Down) &&
                 !entries.empty()) {
        auto index = selected.empty() ? 0 : *selected.begin();
        if (key == XK_Up && index > 0)
          --index;
        if (key == XK_Down && index + 1 < entries.size())
          ++index;
        selected = {index};
        if (index < scroll)
          scroll = index;
        if (index >= scroll + 15)
          scroll = index - 14;
        filename = path_to_utf8(entries[index].path.filename());
      } else if (field) {
        if (ctrl && (key == XK_a || key == XK_A))
          select_all = true;
        else if (key == XK_BackSpace) {
          if (select_all) {
            filename.clear();
            select_all = false;
          } else if (!filename.empty()) {
            auto pos = filename.size() - 1;
            while (pos > 0 &&
                   (static_cast<unsigned char>(filename[pos]) & 0xc0) == 0x80)
              --pos;
            filename.erase(pos);
          }
        } else if (!ctrl && !input.empty() &&
                   static_cast<unsigned char>(input.front()) >= 32 &&
                   filename.size() + input.size() < 4096) {
          if (select_all) {
            filename.clear();
            select_all = false;
          }
          filename += input;
        }
      }
    }
    paint = true;
  }
}
