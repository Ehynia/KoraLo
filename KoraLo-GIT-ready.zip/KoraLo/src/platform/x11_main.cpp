#ifndef _WIN32
#include "../ui/editor_app.hpp"
#include "../ui/inter_atlas.hpp"
#include "process.hpp"
#include "app_paths.hpp"
#include "glx_host.hpp"
#include <clocale>
#include <set>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#ifdef KORALO_HAVE_XRENDER
#include <X11/extensions/Xrender.h>
#endif
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <unordered_map>
#include <unistd.h>

using namespace koralo;

namespace {
unsigned long pixel(Color c){return (static_cast<unsigned long>(c.r)<<16)|(static_cast<unsigned long>(c.g)<<8)|c.b;}
std::unordered_map<int,XFontStruct*> g_ui_fonts;
std::vector<std::string> split(const std::string&s,char sep){std::vector<std::string>o;std::string c;for(char ch:s){if(ch==sep){if(!c.empty())o.push_back(c);c.clear();}else c+=ch;}if(!c.empty())o.push_back(c);return o;}
std::string tool_path(const char* name){return find_executable_on_path(name);}
std::string run_capture(const std::string& exe,const std::vector<std::string>& args){if(exe.empty())return{};auto r=run_process(exe,args);if(!r.started||r.exit_code!=0)return{};while(!r.output.empty()&&(r.output.back()=='\n'||r.output.back()=='\r'))r.output.pop_back();return r.output;}

std::uint32_t next_utf8_codepoint(const std::string& text,std::size_t& i){
    if(i>=text.size())return 0;const auto c0=static_cast<unsigned char>(text[i++]);if(c0<0x80)return c0;
    auto cont=[&]()->unsigned char{return i<text.size()?static_cast<unsigned char>(text[i++]):0;};
    if((c0&0xe0)==0xc0){const auto c1=cont();return ((c0&0x1f)<<6)|(c1&0x3f);}
    if((c0&0xf0)==0xe0){const auto c1=cont(),c2=cont();return ((c0&0x0f)<<12)|((c1&0x3f)<<6)|(c2&0x3f);}
    if((c0&0xf8)==0xf0){const auto c1=cont(),c2=cont(),c3=cont();return ((c0&0x07)<<18)|((c1&0x3f)<<12)|((c2&0x3f)<<6)|(c3&0x3f);}
    return '?';
}


std::string uri_decode(std::string s){
    std::string o; o.reserve(s.size());
    for(std::size_t i=0;i<s.size();++i){
        if(s[i]=='%'&&i+2<s.size()){
            auto hex=[](char c)->int{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};
            int a=hex(s[i+1]),b=hex(s[i+2]); if(a>=0&&b>=0){o.push_back(static_cast<char>((a<<4)|b));i+=2;continue;}
        }
        if(s[i]!='\r')o.push_back(s[i]);
    }
    return o;
}
std::vector<std::string> parse_uri_list(const std::string& data){
    std::vector<std::string> out; std::istringstream ss(data); std::string line;
    while(std::getline(ss,line)){
        if(line.empty()||line[0]=='#')continue;
        if(line.rfind("file://",0)==0){line=line.substr(7); if(line.rfind("localhost/",0)==0)line=line.substr(9); line=uri_decode(line); if(!line.empty()&&line[0]!='/')line='/'+line; out.push_back(line);}
    }
    return out;
}

class XCanvas final: public Canvas{
public:
    XCanvas(Display*d,Drawable w,GC gc,int ww,int hh,Visual* visual=nullptr,int depth=0):d_(d),w_(w),gc_(gc),ww_(ww),hh_(hh),visual_(visual?visual:DefaultVisual(d,DefaultScreen(d))),depth_(depth?depth:DefaultDepth(d,DefaultScreen(d))){const char half[2]={0x1,0x2};const char dense[2]={0x3,0x1};stipple50_=XCreateBitmapFromData(d_,w_,half,2,2);stipple75_=XCreateBitmapFromData(d_,w_,dense,2,2);
#ifdef KORALO_HAVE_XRENDER
        if(auto* fmt=XRenderFindVisualFormat(d_,visual_))picture_=XRenderCreatePicture(d_,w_,fmt,0,nullptr);
#endif
    }
    ~XCanvas() override{
#ifdef KORALO_HAVE_XRENDER
        if(picture_)XRenderFreePicture(d_,picture_);
#endif
        if(stipple50_)XFreePixmap(d_,stipple50_);if(stipple75_)XFreePixmap(d_,stipple75_);
    }
    int width()const override{return ww_;}int height()const override{return hh_;}
    void fill_rect(Rect r,Color c)override{if(r.w<=0||r.h<=0||c.a==0)return;
#ifdef KORALO_HAVE_XRENDER
        if(c.a<255&&picture_){XRenderColor rc{static_cast<unsigned short>(c.r*257u*c.a/255u),static_cast<unsigned short>(c.g*257u*c.a/255u),static_cast<unsigned short>(c.b*257u*c.a/255u),static_cast<unsigned short>(c.a*257u)};XRenderFillRectangle(d_,PictOpOver,picture_,&rc,r.x,r.y,static_cast<unsigned>(r.w),static_cast<unsigned>(r.h));return;}
#endif
        XSetForeground(d_,gc_,pixel(c));if(c.a<255){Pixmap st=c.a>165?stipple75_:stipple50_;if(st){XSetStipple(d_,gc_,st);XSetFillStyle(d_,gc_,FillStippled);XFillRectangle(d_,w_,gc_,r.x,r.y,r.w,r.h);XSetFillStyle(d_,gc_,FillSolid);return;}}XFillRectangle(d_,w_,gc_,r.x,r.y,r.w,r.h);}
    void stroke_rect(Rect r,Color c,int t=1)override{if(r.w<=0||r.h<=0)return;XSetForeground(d_,gc_,pixel(c));XSetLineAttributes(d_,gc_,t,LineSolid,CapButt,JoinMiter);XDrawRectangle(d_,w_,gc_,r.x,r.y,std::max(0,r.w-1),std::max(0,r.h-1));}
    void line(int x1,int y1,int x2,int y2,Color c,int t=1)override{XSetForeground(d_,gc_,pixel(c));XSetLineAttributes(d_,gc_,t,LineSolid,CapButt,JoinMiter);XDrawLine(d_,w_,gc_,x1,y1,x2,y2);}
    void text(int x,int y,const std::string&v,Color c,int size=12,bool bold=false)override{
        int pen=x;std::size_t pos=0;
        while(pos<v.size()){const std::uint32_t cp=next_utf8_codepoint(v,pos);const auto* glyph=inter_atlas::find(cp,size,bold);if(!glyph)glyph=inter_atlas::find('?',size,bold);if(!glyph)continue;
            const int gx=pen+glyph->left,gy=y+glyph->top;
            for(int row=0;row<glyph->height;++row){int col=0;while(col<glyph->width){const auto level=inter_atlas::kPixels[glyph->offset+static_cast<std::size_t>(row)*glyph->width+col];if(level==0){++col;continue;}const int begin=col;while(col<glyph->width&&inter_atlas::kPixels[glyph->offset+static_cast<std::size_t>(row)*glyph->width+col]==level)++col;Color cc=c;const int alpha=level*17;cc.a=static_cast<std::uint8_t>((static_cast<unsigned>(c.a)*alpha)/255u);fill_rect({gx+begin,gy+row,col-begin,1},cc);}}
            pen+=glyph->advance;
        }
    }
    int text_width(const std::string&v,int size=12,bool bold=false)override{int width=0;std::size_t pos=0;while(pos<v.size()){const std::uint32_t cp=next_utf8_codepoint(v,pos);const auto* glyph=inter_atlas::find(cp,size,bold);if(!glyph)glyph=inter_atlas::find('?',size,bold);if(glyph)width+=glyph->advance;}return width;}
    void image(Rect dst,const Frame& f)override{
        if(f.rgb.empty()||f.width<=0||f.height<=0||dst.w<=0||dst.h<=0)return;
        // Letterbox using nearest-neighbour CPU scaling into native 32-bit BGRX.
        double scale=std::min(dst.w/static_cast<double>(f.width),dst.h/static_cast<double>(f.height));int ow=std::max(1,static_cast<int>(f.width*scale)),oh=std::max(1,static_cast<int>(f.height*scale));int ox=dst.x+(dst.w-ow)/2,oy=dst.y+(dst.h-oh)/2;
        auto* data=(char*)std::malloc(static_cast<std::size_t>(ow)*oh*4);if(!data)return;
        for(int y=0;y<oh;++y){int sy=std::clamp(static_cast<int>(y/scale),0,f.height-1);for(int x=0;x<ow;++x){int sx=std::clamp(static_cast<int>(x/scale),0,f.width-1);auto si=(static_cast<std::size_t>(sy)*f.width+sx)*3;auto di=(static_cast<std::size_t>(y)*ow+x)*4;data[di+0]=static_cast<char>(f.rgb[si+2]);data[di+1]=static_cast<char>(f.rgb[si+1]);data[di+2]=static_cast<char>(f.rgb[si+0]);data[di+3]=0;}}
        XImage* img=XCreateImage(d_,visual_,depth_,ZPixmap,0,data,ow,oh,32,0);if(img){XPutImage(d_,w_,gc_,img,0,0,ox,oy,ow,oh);XDestroyImage(img);}else std::free(data);
    }
    void push_clip(Rect r)override{
        if(!clips_.empty()){const Rect p=clips_.back();const int x1=std::max(p.x,r.x),y1=std::max(p.y,r.y),x2=std::min(p.x+p.w,r.x+r.w),y2=std::min(p.y+p.h,r.y+r.h);r={x1,y1,std::max(0,x2-x1),std::max(0,y2-y1)};}
        clips_.push_back(r);XRectangle xr{static_cast<short>(r.x),static_cast<short>(r.y),static_cast<unsigned short>(std::max(0,r.w)),static_cast<unsigned short>(std::max(0,r.h))};XSetClipRectangles(d_,gc_,0,0,&xr,1,Unsorted);
#ifdef KORALO_HAVE_XRENDER
        if(picture_)XRenderSetPictureClipRectangles(d_,picture_,0,0,&xr,1);
#endif
    }
    void pop_clip()override{if(clips_.empty())return;clips_.pop_back();if(clips_.empty()){XSetClipMask(d_,gc_,None);
#ifdef KORALO_HAVE_XRENDER
        if(picture_){XRenderPictureAttributes attrs{};attrs.clip_mask=None;XRenderChangePicture(d_,picture_,CPClipMask,&attrs);}
#endif
        }else{const Rect&r=clips_.back();XRectangle xr{static_cast<short>(r.x),static_cast<short>(r.y),static_cast<unsigned short>(std::max(0,r.w)),static_cast<unsigned short>(std::max(0,r.h))};XSetClipRectangles(d_,gc_,0,0,&xr,1,Unsorted);
#ifdef KORALO_HAVE_XRENDER
        if(picture_)XRenderSetPictureClipRectangles(d_,picture_,0,0,&xr,1);
#endif
        }}
private:
    XFontStruct* font(int size,bool bold){
        size=std::clamp(size,8,36);const int key=size*2+(bold?1:0);auto it=g_ui_fonts.find(key);if(it!=g_ui_fonts.end())return it->second;
        // Prefer Inter for every KoraLo-drawn text surface.  Some minimal
        // X11 servers expose only core XLFD fonts, so keep deterministic sans
        // fallbacks instead of silently switching different widgets to
        // unrelated families.
        const std::array<std::string,4> families={"inter","inter variable","dejavu sans","helvetica"};
        XFontStruct* value=nullptr;
        for(const auto& family:families){
            const std::string pattern="-*-"+family+"-"+std::string(bold?"bold":"medium")+"-r-normal--"+std::to_string(size)+"-*-*-*-*-*-*-*";
            value=XLoadQueryFont(d_,pattern.c_str());if(value)break;
        }
        if(!value)value=XLoadQueryFont(d_,bold?"9x15bold":"9x15");if(!value)value=XLoadQueryFont(d_,"fixed");g_ui_fonts[key]=value;return value;
    }
    Display*d_;Drawable w_;GC gc_;int ww_,hh_;Visual* visual_;int depth_;Pixmap stipple50_=0,stipple75_=0;
#ifdef KORALO_HAVE_XRENDER
    Picture picture_=0;
#endif
    std::vector<Rect> clips_;
};

#include "x11_dialogs.hpp"
class XServices final:public PlatformServices{
public:
    XServices(Display* d,Window w,GlxHost& gpu):d_(d),w_(w),gpu_(gpu){}
    std::vector<std::string> open_media_files()override{return native_choose_files(d_,w_,"Import Media",false,"",{},true);}
    std::string open_project_file()override{return choose("Open KoraLo / VEGAS Project",false,"",{".kora",".veg"});}
    std::string save_project_file(const std::string& name)override{return choose("Save KoraLo Project",true,name,{".kora"});}
    std::string save_render_file(const std::string& name)override{return choose("Render As",true,name,{".mp4"});}
    void show_message(const std::string& title,const std::string& text,bool=false)override{native_message(d_,w_,title,text,{"OK"});redraw_=true;}
    SaveChangesChoice ask_save_changes(const std::string& name)override{
        int choice=native_message(d_,w_,"Unsaved changes","Save changes to "+name+"?",{"Save","Discard","Cancel"});redraw_=true;
        return choice==0?SaveChangesChoice::Save:choice==1?SaveChangesChoice::Discard:SaveChangesChoice::Cancel;
    }
    void set_title(const std::string& title)override{XStoreName(d_,w_,title.c_str());}
    void request_redraw()override{redraw_=true;}
    std::string executable_dir()const override{return path_to_utf8(app_install_directory());}
    std::string interface_renderer()const override{return gpu_.label();}
    bool set_interface_gpu_enabled(bool enabled)override{redraw_=true;return gpu_.enable(enabled);}
    bool consume_redraw(){bool value=redraw_;redraw_=false;return value;}
private:
    std::string choose(const std::string& title,bool save,const std::string& name,const std::vector<std::string>& extensions){auto paths=native_choose_files(d_,w_,title,save,name,extensions,false);redraw_=true;return paths.empty()?std::string{}:paths.front();}
    Display* d_;Window w_;GlxHost& gpu_;bool redraw_=true;
};

Key map_key(KeySym k){switch(k){case XK_b:case XK_B:return Key::B;case XK_Delete:return Key::Delete;case XK_space:return Key::Space;case XK_Left:return Key::Left;case XK_Right:return Key::Right;case XK_s:case XK_S:return Key::S;case XK_z:case XK_Z:return Key::Z;case XK_y:case XK_Y:return Key::Y;case XK_i:case XK_I:return Key::I;case XK_o:case XK_O:return Key::O;case XK_m:case XK_M:return Key::M;case XK_n:case XK_N:return Key::N;case XK_c:case XK_C:return Key::C;case XK_v:case XK_V:return Key::V;case XK_x:case XK_X:return Key::X;case XK_l:case XK_L:return Key::L;case XK_Escape:return Key::Escape;case XK_Return:return Key::Enter;case XK_BackSpace:return Key::Backspace;case XK_F1:return Key::F1;case XK_plus:case XK_equal:return Key::Plus;case XK_minus:return Key::Minus;default:return Key::Unknown;}}
}

int main(int argc,char**argv){
    initialize_executable_path(argv[0]);std::setlocale(LC_CTYPE,"");XSetLocaleModifiers("");
    Display*d=XOpenDisplay(nullptr);if(!d){std::cerr<<"KoraLo: cannot open X display\n";return 2;}int screen=DefaultScreen(d);unsigned long black=BlackPixel(d,screen);
    const int screen_w=DisplayWidth(d,screen),screen_h=DisplayHeight(d,screen);const int initial_w=std::clamp(static_cast<int>(screen_w*0.86),1200,std::max(1200,screen_w-80));const int initial_h=std::clamp(static_cast<int>(screen_h*0.84),720,std::max(720,screen_h-80));
    GlxHost gpu;XVisualInfo* gl_visual=gpu.choose(d,screen);Visual* visual=gl_visual?gl_visual->visual:DefaultVisual(d,screen);int window_depth=gl_visual?gl_visual->depth:DefaultDepth(d,screen);
    Colormap colormap=XCreateColormap(d,RootWindow(d,screen),visual,AllocNone);XSetWindowAttributes attributes{};attributes.colormap=colormap;attributes.background_pixel=black;attributes.border_pixel=black;
    Window w=XCreateWindow(d,RootWindow(d,screen),40,32,initial_w,initial_h,0,window_depth,InputOutput,visual,CWColormap|CWBackPixel|CWBorderPixel,&attributes);gpu.initialize(w);

    Atom xdndAware=XInternAtom(d,"XdndAware",False),xdndEnter=XInternAtom(d,"XdndEnter",False),xdndPosition=XInternAtom(d,"XdndPosition",False),xdndStatus=XInternAtom(d,"XdndStatus",False),xdndDrop=XInternAtom(d,"XdndDrop",False),xdndFinished=XInternAtom(d,"XdndFinished",False),xdndSelection=XInternAtom(d,"XdndSelection",False),xdndActionCopy=XInternAtom(d,"XdndActionCopy",False),textUriList=XInternAtom(d,"text/uri-list",False),xdndProp=XInternAtom(d,"KORALO_XDND",False);
    unsigned long xdndVersion=5; XChangeProperty(d,w,xdndAware,XA_ATOM,32,PropModeReplace,reinterpret_cast<unsigned char*>(&xdndVersion),1);
    Window xdndSource=0; int xdndX=0,xdndY=0;
    XSelectInput(d,w,ExposureMask|StructureNotifyMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask|KeyPressMask);
    Atom wmDelete=XInternAtom(d,"WM_DELETE_WINDOW",False);XSetWMProtocols(d,w,&wmDelete,1);XMapWindow(d,w);GC gc=XCreateGC(d,w,0,nullptr);
    // Best-effort native Inter selection. Core X11 installations do not
    // always expose fontconfig fonts through XLFD, so keep the normal X11
    // fallback when the family is not registered with the X server.
    if(XFontStruct* ui_font=XLoadQueryFont(d,"-*-open sans-medium-r-normal--12-*-*-*-*-*-*-*"))XSetFont(d,gc,ui_font->fid);else if(XFontStruct* ui_font=XLoadQueryFont(d,"-*-opensans-medium-r-normal--12-*-*-*-*-*-*-*"))XSetFont(d,gc,ui_font->fid);
    XServices services(d,w,gpu);EditorApp app(services);int ww=initial_w,hh=initial_h;bool running=true;bool redraw=true;Pixmap backbuffer=0;int back_w=0,back_h=0;
    // Command-line media import is useful on minimal X11 installations without a file picker.
    for(int i=1;i<argc;++i)app.file_dropped(argv[i],400,650);
    while(running&&!app.wants_close()){
        while(XPending(d)){
            XEvent e;XNextEvent(d,&e);
            bool ctrl=false,shift=false,alt=false;
            if(e.type==ClientMessage&&static_cast<Atom>(e.xclient.data.l[0])==wmDelete){app.request_close();if(app.wants_close())running=false;break;}
            if(e.type==ClientMessage&&e.xclient.message_type==xdndEnter){xdndSource=static_cast<Window>(e.xclient.data.l[0]);}
            else if(e.type==ClientMessage&&e.xclient.message_type==xdndPosition){
                xdndSource=static_cast<Window>(e.xclient.data.l[0]); int rx=static_cast<short>((e.xclient.data.l[2]>>16)&0xffff),ry=static_cast<short>(e.xclient.data.l[2]&0xffff); Window child=0; XTranslateCoordinates(d,RootWindow(d,screen),w,rx,ry,&xdndX,&xdndY,&child);
                XClientMessageEvent reply{};reply.type=ClientMessage;reply.display=d;reply.window=xdndSource;reply.message_type=xdndStatus;reply.format=32;reply.data.l[0]=static_cast<long>(w);reply.data.l[1]=1;reply.data.l[4]=static_cast<long>(xdndActionCopy);XSendEvent(d,xdndSource,False,NoEventMask,reinterpret_cast<XEvent*>(&reply));XFlush(d);
            }
            else if(e.type==ClientMessage&&e.xclient.message_type==xdndDrop){
                Time tm=e.xclient.data.l[2]?static_cast<Time>(e.xclient.data.l[2]):CurrentTime;XConvertSelection(d,xdndSelection,textUriList,xdndProp,w,tm);
            }
            else if(e.type==SelectionNotify&&e.xselection.selection==xdndSelection){
                Atom actual{};int format=0;unsigned long count=0,after=0;unsigned char*data=nullptr;
                if(e.xselection.property!=None&&XGetWindowProperty(d,w,xdndProp,0,1024*1024,True,AnyPropertyType,&actual,&format,&count,&after,&data)==Success&&data){std::string payload(reinterpret_cast<char*>(data),count);XFree(data);for(auto&path:parse_uri_list(payload))app.file_dropped(path,xdndX,xdndY);}
                if(xdndSource){XClientMessageEvent fin{};fin.type=ClientMessage;fin.display=d;fin.window=xdndSource;fin.message_type=xdndFinished;fin.format=32;fin.data.l[0]=static_cast<long>(w);fin.data.l[1]=1;fin.data.l[2]=static_cast<long>(xdndActionCopy);XSendEvent(d,xdndSource,False,NoEventMask,reinterpret_cast<XEvent*>(&fin));XFlush(d);}xdndSource=0;redraw=true;
            }
            else if(e.type==ConfigureNotify){ww=e.xconfigure.width;hh=e.xconfigure.height;redraw=true;}
            else if(e.type==Expose)redraw=true;
            else if(e.type==ButtonPress){ctrl=e.xbutton.state&ControlMask;shift=e.xbutton.state&ShiftMask;alt=e.xbutton.state&Mod1Mask;if(e.xbutton.button==4||e.xbutton.button==5)app.mouse_wheel(e.xbutton.x,e.xbutton.y,e.xbutton.button==4?1:-1,ctrl,shift);else app.mouse_down(e.xbutton.x,e.xbutton.y,e.xbutton.button,ctrl,shift,alt);redraw=true;}
            else if(e.type==ButtonRelease){ctrl=e.xbutton.state&ControlMask;shift=e.xbutton.state&ShiftMask;alt=e.xbutton.state&Mod1Mask;if(e.xbutton.button!=4&&e.xbutton.button!=5)app.mouse_up(e.xbutton.x,e.xbutton.y,e.xbutton.button,ctrl,shift,alt);redraw=true;}
            else if(e.type==MotionNotify){ctrl=e.xmotion.state&ControlMask;shift=e.xmotion.state&ShiftMask;alt=e.xmotion.state&Mod1Mask;app.mouse_move(e.xmotion.x,e.xmotion.y,ctrl,shift,alt);}
            else if(e.type==KeyPress){KeySym ks=0;char textbuf[64]{};int textlen=XLookupString(&e.xkey,textbuf,sizeof(textbuf),&ks,nullptr);ctrl=e.xkey.state&ControlMask;shift=e.xkey.state&ShiftMask;alt=e.xkey.state&Mod1Mask;app.key_down(map_key(ks),ctrl,shift,alt);if(!ctrl&&!alt&&textlen>0)app.text_input(std::string(textbuf,static_cast<std::size_t>(textlen)));redraw=true;}
        }
        app.tick();redraw=redraw||services.consume_redraw();
        if(redraw){
            bool painted=false;if(auto* canvas=gpu.begin(ww,hh)){app.draw(*canvas);painted=gpu.finish();}
            if(!painted){
            if(!backbuffer||back_w!=ww||back_h!=hh){if(backbuffer)XFreePixmap(d,backbuffer);backbuffer=XCreatePixmap(d,w,std::max(1,ww),std::max(1,hh),window_depth);back_w=ww;back_h=hh;}
            Drawable target=backbuffer?static_cast<Drawable>(backbuffer):static_cast<Drawable>(w);
            XCanvas canvas(d,target,gc,ww,hh,visual,window_depth);app.draw(canvas);
            if(backbuffer)XCopyArea(d,backbuffer,w,gc,0,0,static_cast<unsigned>(std::max(1,ww)),static_cast<unsigned>(std::max(1,hh)),0,0);
            }
            XFlush(d);redraw=false;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
    gpu.reset();if(backbuffer)XFreePixmap(d,backbuffer);for(auto& [_,font]:g_ui_fonts)if(font)XFreeFont(d,font);g_ui_fonts.clear();XFreeGC(d,gc);XDestroyWindow(d,w);XFreeColormap(d,colormap);XCloseDisplay(d);return 0;
}
#endif
