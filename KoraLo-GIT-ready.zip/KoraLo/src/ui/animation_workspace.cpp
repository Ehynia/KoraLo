#include "../media/paint_mask.hpp"
#include "editor_app.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <sstream>
namespace koralo {
namespace {
std::string num(double v, int precision = 2) {
  std::ostringstream out;
  out << std::fixed << std::setprecision(precision) << v;
  return out.str();
}
void panel(Canvas &c, Rect r) {
  c.fill_rect(r, theme::panel);
  c.stroke_rect(r, theme::borderSoft);
}
void diamond(Canvas &c, int x, int y, Color color, int size = 4) {
  for (int i = -size; i <= size; ++i)
    c.fill_rect(
        {x - size + std::abs(i), y + i, 2 * (size - std::abs(i)) + 1, 1},
        color);
}
void circle(Canvas &c, int x, int y, int r, Color color) {
  for (int i = 0; i < 40; ++i) {
    const double a = i * 6.283185307179586 / 40,
                 b = (i + 1) * 6.283185307179586 / 40;
    c.line(x + int(std::cos(a) * r), y + int(std::sin(a) * r),
           x + int(std::cos(b) * r), y + int(std::sin(b) * r), color);
  }
}
double bounded(int property, double v) {
  if (property == 2)
    return std::clamp(v, .01, 20.0);
  if (property == 3)
    return std::clamp(v, -3600.0, 3600.0);
  if (property == 0 || property == 1)
    return std::clamp(v, -2.0, 3.0);
  if (property == 8 || property == 9)
    return std::clamp(v, .01, 1.0);
  return std::clamp(v, 0.0, 1.0);
}
Rect shape_bounds(const VectorShape &s, double t, Rect canvas) {
  auto points = flatten_vector_path(s, t, 16, double(canvas.w) / canvas.h);
  double l = 1, r = 0, top = 1, bottom = 0;
  for (const auto &p : points) {
    l = std::min(l, p.x);
    r = std::max(r, p.x);
    top = std::min(top, p.y);
    bottom = std::max(bottom, p.y);
  }
  return {canvas.x + int(l * canvas.w) - 4, canvas.y + int(top * canvas.h) - 4,
          std::max(8, int((r - l) * canvas.w) + 8),
          std::max(8, int((bottom - top) * canvas.h) + 8)};
}
Keyframe *segment(AnimatedDouble *c, double t, int *index = nullptr) {
  if (!c || c->keys.size() < 2)
    return nullptr;
  int i = 0;
  while (i + 2 < int(c->keys.size()) && c->keys[std::size_t(i + 1)].time <= t)
    ++i;
  if (index)
    *index = i;
  return &c->keys[std::size_t(i)];
}
} // namespace
MediaItem *EditorApp::animation_media() {
  auto *m = project_.media_by_id(animation_media_id_);
  return m && m->generated_vector.enabled ? m : nullptr;
}
AnimatedDouble *EditorApp::animation_channel(int p) {
  auto *m = animation_media();
  if (!m)
    return nullptr;
  if (p >= 5)
    return scene_channel(m->generated_vector, p);
  auto *s = m->generated_vector.shape(animation_shape_id_);
  return s ? vector_channel(*s, p) : nullptr;
}
double EditorApp::animation_duration() const {
  auto *m = project_.media_by_id(animation_media_id_);
  return m ? std::max(.001, m->duration) : 6;
}
void EditorApp::animation_sync_selection() {
  if (!animation_media()) {
    auto *candidate = project_.media_by_id(edit_.selected_media);
    if (!candidate || !candidate->generated_vector.enabled) {
      candidate = nullptr;
      for (auto &item : project_.media)
        if (item.generated_vector.enabled) {
          candidate = &item;
          break;
        }
    }
    if (candidate) {
      animation_media_id_ = candidate->id;
      animation_clip_id_ = animation_shape_id_ = 0;
      animation_time_ = 0;
      for (const auto &event : project_.clips)
        if (event.media_id() == candidate->id) {
          animation_clip_id_ = event.id;
          break;
        }
    }
  }
  if (auto *clip = project_.clip_by_id(edit_.selection.primary_clip())) {
    auto *m = project_.media_by_id(clip->media_id());
    if (m && m->generated_vector.enabled) {
      if (animation_media_id_ != m->id) {
        animation_media_id_ = m->id;
        animation_shape_id_ = m->generated_vector.shapes.empty()
                                  ? 0
                                  : m->generated_vector.shapes.back().id;
        animation_node_ = -1;
      }
      animation_clip_id_ = clip->id;
    }
  }
  auto *m = animation_media();
  if (!m) {
    animation_media_id_ = animation_clip_id_ = animation_shape_id_ = 0;
    return;
  }
  if (!m->generated_vector.shape(animation_shape_id_))
    animation_shape_id_ = m->generated_vector.shapes.empty()
                              ? 0
                              : m->generated_vector.shapes.back().id;
  if (playing_) {
    if (auto *c = project_.clip_by_id(animation_clip_id_)) {
      double t = c->source_offset() + (playhead_ - c->start) * c->rate;
      if (c->loop)
        t = std::fmod(std::max(0.0, t), animation_duration());
      animation_time_ = std::clamp(t, 0.0, animation_duration());
    }
  }
}
void EditorApp::animation_create_scene() {
  pause_playback(false);
  undo_.begin(project_);
  MediaItem m;
  m.name = tr("animation.scene_name", "Vector animation");
  m.duration = 6;
  m.width = project_.settings.width;
  m.height = project_.settings.height;
  m.fps = project_.settings.fps;
  m.has_video = true;
  m.video_codec = "koralo.vector";
  m.path = "generated:vector";
  m.generated_vector.enabled = true;
  auto circle_shape = make_vector_ellipse(1);
  circle_shape.name = tr("animation.shape.ellipse", "Ellipse");
  circle_shape.x.default_value = .62;
  circle_shape.y.default_value = .46;
  for (auto &n : circle_shape.nodes) {
    n.point.y *= double(m.width) / m.height;
    n.in.y *= double(m.width) / m.height;
    n.out.y *= double(m.width) / m.height;
  }
  auto ribbon = make_vector_ribbon(2);
  ribbon.name = tr("animation.shape.path", "Path") + " 01";
  ribbon.x.set_key(0, .42, KeyframeInterpolation::Smooth);
  ribbon.x.set_key(3, .55, KeyframeInterpolation::Smooth);
  ribbon.x.set_key(6, .42, KeyframeInterpolation::Smooth);
  ribbon.rotation.set_key(0, -7, KeyframeInterpolation::Smooth);
  ribbon.rotation.set_key(3, 7, KeyframeInterpolation::Smooth);
  ribbon.rotation.set_key(6, -7, KeyframeInterpolation::Smooth);
  m.generated_vector.shapes = {circle_shape, ribbon};
  m.generated_vector.next_shape_id = 3;
  animation_media_id_ = project_.add_media(std::move(m)).id;
  const int tid = project_.add_track(TrackKind::Video, tr("workspace.animation", "Animation")).id;
  animation_clip_id_ =
      project_.add_clip(animation_media_id_, tid, playhead_, 0, 6).id;
  selected_track_id_ = tid;
  edit_.selection.select_clip(project_, animation_clip_id_,
                              SelectionOperation::Replace, false);
  edit_.selected_media = animation_media_id_;
  animation_shape_id_ = 2;
  animation_time_ = 0;
  animation_workspace_ = true;
  preview_tab_ = PreviewTab::VideoPreview;
  if (undo_.commit(project_))
    mark_dirty();
  animation_changed(true);
  set_status(tr("animation.status.scene_created",
                "Scene created: paths, keyframes, mask and crop are saved in .kora"));
}
void EditorApp::animation_seek(double t) {
  animation_time_ =
      std::clamp(std::round(t * project_.settings.fps) / project_.settings.fps,
                 0.0, animation_duration());
  if (auto *c = project_.clip_by_id(animation_clip_id_))
    set_playhead(c->start +
                     std::max(0.0, animation_time_ - c->source_offset()) /
                         std::max(.01, c->rate),
                 true);
  else
    request_preview(true);
  services_.request_redraw();
}
void EditorApp::animation_assign(AnimatedDouble &c, double value) {
  value = bounded(animation_property_, value);
  if (animation_autokey_ && !c.has_key(animation_time_) &&
      c.keys.size() >= 2048) {
    set_status(tr("animation.status.key_limit", "Keyframe channel limit reached"));
    return;
  }
  if (animation_autokey_ || c.has_key(animation_time_)) {
    const auto existing =
        std::find_if(c.keys.begin(), c.keys.end(), [&](const auto &key) {
          return std::abs(key.time - animation_time_) < 1e-6;
        });
    c.set_key(animation_time_, value,
              existing == c.keys.end() ? KeyframeInterpolation::Smooth
                                       : existing->interpolation);
  } else if (c.keys.empty())
    c.default_value = value;
  else {
    const double delta = value - c.value_at(animation_time_);
    c.default_value += delta;
    for (auto &k : c.keys)
      k.value = bounded(animation_property_, k.value + delta);
  }
}
void EditorApp::animation_changed(bool final) {
  if (final) {
    animation_preview_pending_ = false;
    engine_.clear_composite_cache();
    request_preview(true);
  } else
    animation_preview_pending_ = true;
  services_.request_redraw();
}
void EditorApp::draw_animation_workspace(Canvas &c) {
  animation_sync_selection();
  animation_key_hits_.clear();
  auto *m = animation_media();
  auto *scene = m ? &m->generated_vector : nullptr;
  auto *selected = scene ? scene->shape(animation_shape_id_) : nullptr;
  auto *clip = project_.clip_by_id(animation_clip_id_);
  auto *track = clip ? project_.track_by_id(clip->track_id) : nullptr;
  const bool editable =
      scene && (!clip || !clip->locked) && (!track || !track->locked);
  const std::array<std::string, 10> labels = {
      tr("animation.property.position_x", "Position X"),
      tr("animation.property.position_y", "Position Y"),
      tr("animation.property.scale", "Scale"),
      tr("animation.property.rotation", "Rotation"),
      tr("animation.property.opacity", "Opacity"),
      tr("animation.property.mask", "Mask"),
      tr("animation.property.crop_x", "Crop X"),
      tr("animation.property.crop_y", "Crop Y"),
      tr("animation.property.frame_width", "Frame width"),
      tr("animation.property.frame_height", "Frame height")};
  const std::array<std::pair<std::string, const char *>, 5> tools = {
      {{tr("animation.tool.select", "Select"), "mouse-pointer"},
       {tr("animation.tool.pen", "Pen"), "brush"},
       {tr("animation.tool.nodes", "Nodes"), "move"},
       {tr("animation.tool.brush", "Brush"), "brush"},
       {tr("animation.tool.crop", "Crop"), "crop"}}};
  Rect button_clip{};
  auto btn = [&](Rect r, std::string id, std::string title, bool active = false,
                 bool enabled = true, std::string icon = {}) {
    Button b{r,      std::move(id), std::move(title),
             active, enabled,       std::move(icon)};
    if (button_clip.w == 0 ||
        button_clip.contains(r.x + r.w / 2, r.y + r.h / 2))
      buttons_.push_back(b);
    draw_button(c, b);
  };
  panel(c, layout_.tools);
  for (int i = 0; i < 5; ++i) {
    btn({5, layout_.tools.y + 68 + i * 39, 30, 30},
        "anim_tool:" + std::to_string(i), "",
        animation_tool_ == AnimationTool(i), editable,
        tools[std::size_t(i)].second);
  }
  panel(c, layout_.bin);
  animation_layers_ = layout_.bin;
  c.text(layout_.bin.x + 12, layout_.bin.y + 22, tr("animation.layers", "Layers"), theme::text, 12, true);
  btn({layout_.bin.x + layout_.bin.w - 108, layout_.bin.y + 7, 96, 24},
      "anim_new", tr("animation.new_scene", "New scene"));
  btn({layout_.bin.x + 66, layout_.bin.y + 7, 32, 24}, "anim_scene_next", ">",
      false, bool(scene));
  const int lx = layout_.bin.x + 8, ly = layout_.bin.y + 42;
  btn({lx, ly, 66, 23}, "anim_rect", tr("animation.add_rectangle", "Rectangle"), false, editable);
  btn({lx + 70, ly, 65, 23}, "anim_ellipse", tr("animation.add_ellipse", "Ellipse"), false, editable);
  btn({lx + 139, ly, 63, 23}, "anim_path", tr("animation.add_path", "Path"), false, editable);
  if (scene) {
    c.push_clip({lx, ly + 32, layout_.bin.w - 16, layout_.bin.h - 120});
    int row = 0;
    for (auto it = scene->shapes.rbegin(); it != scene->shapes.rend();
         ++it, ++row) {
      const int y = ly + 34 + row * 35 - animation_layer_scroll_;
      if (y + 32 < ly + 32 || y > layout_.bin.y + layout_.bin.h - 56)
        continue;
      const bool active = it->id == animation_shape_id_;
      btn({lx, y, layout_.bin.w - 76, 29},
          "anim_layer:" + std::to_string(it->id), it->name, active, true,
          "curves");
      btn({layout_.bin.x + layout_.bin.w - 63, y, 24, 29},
          "anim_visible:" + std::to_string(it->id), it->visible ? "V" : "−",
          false, editable);
      btn({layout_.bin.x + layout_.bin.w - 35, y, 24, 29},
          "anim_lock:" + std::to_string(it->id), "", it->locked, editable,
          it->locked ? "lock" : "unlock");
    }
    c.pop_clip();
  }
  const int bottom = layout_.bin.y + layout_.bin.h - 38;
  btn({lx, bottom, 64, 24}, "anim_duplicate", tr("animation.duplicate", "Duplicate"), false,
      editable && selected && !selected->locked);
  btn({lx + 69, bottom, 35, 24}, "anim_up", "↑", false, editable && selected);
  btn({lx + 108, bottom, 35, 24}, "anim_down", "↓", false,
      editable && selected);
  btn({lx + 147, bottom, 57, 24}, "anim_delete", tr("common.remove", "Remove"), false,
      editable && selected && !selected->locked);
  panel(c, layout_.preview);
  const int px = layout_.preview.x, py = layout_.preview.y;
  for (int i = 0; i < 5; ++i)
    btn({px + 8 + i * 73, py + 7, 69, 24}, "anim_tool:" + std::to_string(i),
        tools[std::size_t(i)].first, animation_tool_ == AnimationTool(i),
        editable);
  c.text(px + layout_.preview.w - 60, py + 24, tr("animation.fit", "Fit"), theme::dim, 8);
  Rect viewport{px + 9, py + 40, layout_.preview.w - 18,
                std::max(1, layout_.preview.h - 93)};
  c.fill_rect(viewport, {20, 20, 20});
  const double ratio =
      double(project_.settings.width) / std::max(1, project_.settings.height);
  int cw = viewport.w, ch = int(cw / ratio);
  if (ch > viewport.h) {
    ch = viewport.h;
    cw = int(ch * ratio);
  }
  animation_canvas_ = {viewport.x + (viewport.w - cw) / 2,
                       viewport.y + (viewport.h - ch) / 2, std::max(1, cw),
                       std::max(1, ch)};
  c.fill_rect(animation_canvas_, {24, 27, 28});
  if (m && !preview_frame_.rgb.empty())
    c.image(animation_canvas_, preview_frame_);
  else {
    c.text(px + 24, py + 90, tr("animation.empty", "Create a scene or select a vector clip"),
           theme::dim, 10);
    c.text(px + 24, py + 118, tr("animation.workflow_hint", "Pen → Nodes → Keys → Mask → Crop"),
           theme::dim2, 9);
  }
  c.stroke_rect(animation_canvas_, theme::border);
  c.push_clip(animation_canvas_);
  if (selected && selected->visible) {
    const auto bounds =
        shape_bounds(*selected, animation_time_, animation_canvas_);
    c.stroke_rect(bounds, theme::accent);
    for (const int x : {bounds.x, bounds.x + bounds.w - 1})
      for (const int y : {bounds.y, bounds.y + bounds.h - 1})
        c.fill_rect({x - 3, y - 3, 6, 6}, theme::accent);
    if (animation_tool_ == AnimationTool::Nodes ||
        animation_tool_ == AnimationTool::Pen)
      for (std::size_t i = 0; i < selected->nodes.size(); ++i) {
        const auto &n = selected->nodes[i];
        const auto a = transform_vector_point(
            *selected, n.point, animation_time_,
            double(animation_canvas_.w) / animation_canvas_.h);
        const int ax = animation_canvas_.x + int(a.x * animation_canvas_.w),
                  ay = animation_canvas_.y + int(a.y * animation_canvas_.h);
        for (const auto tangent : {n.in, n.out}) {
          if (std::hypot(tangent.x, tangent.y) < .001)
            continue;
          const auto t = transform_vector_point(
              *selected, {n.point.x + tangent.x, n.point.y + tangent.y},
              animation_time_,
              double(animation_canvas_.w) / animation_canvas_.h);
          const int tx = animation_canvas_.x + int(t.x * animation_canvas_.w),
                    ty = animation_canvas_.y + int(t.y * animation_canvas_.h);
          c.line(ax, ay, tx, ty, theme::accent);
          circle(c, tx, ty, 3, theme::accent);
        }
        c.fill_rect({ax - 3, ay - 3, 7, 7},
                    int(i) == animation_node_ ? theme::text : theme::accent);
      }
    if (selected->x.keys.size() > 1 || selected->y.keys.size() > 1) {
      VectorPoint previous{};
      for (int i = 0; i <= 30; ++i) {
        double t = animation_duration() * i / 30;
        VectorPoint p{selected->x.value_at(t), selected->y.value_at(t)};
        if (i && i % 2)
          c.line(animation_canvas_.x + int(previous.x * animation_canvas_.w),
                 animation_canvas_.y + int(previous.y * animation_canvas_.h),
                 animation_canvas_.x + int(p.x * animation_canvas_.w),
                 animation_canvas_.y + int(p.y * animation_canvas_.h),
                 Color{76, 207, 192, 115});
        previous = p;
      }
    }
  }
  if (scene && scene->crop_enabled) {
    Rect r{animation_canvas_.x + int(scene->crop_x.value_at(animation_time_) *
                                     animation_canvas_.w),
           animation_canvas_.y + int(scene->crop_y.value_at(animation_time_) *
                                     animation_canvas_.h),
           int(scene->crop_w.value_at(animation_time_) * animation_canvas_.w),
           int(scene->crop_h.value_at(animation_time_) * animation_canvas_.h)};
    c.stroke_rect(r, {228, 228, 228});
    for (int i = 1; i <= 2; ++i) {
      c.line(r.x + r.w * i / 3, r.y, r.x + r.w * i / 3, r.y + r.h,
             Color{228, 228, 228, 70});
      c.line(r.x, r.y + r.h * i / 3, r.x + r.w, r.y + r.h * i / 3,
             Color{228, 228, 228, 70});
    }
    for (const int x : {r.x, r.x + r.w})
      for (const int y : {r.y, r.y + r.h})
        c.fill_rect({x - 3, y - 3, 6, 6}, theme::text);
  }
  if (animation_tool_ == AnimationTool::Brush &&
      animation_canvas_.contains(mouse_x_, mouse_y_))
    circle(c, mouse_x_, mouse_y_,
           std::max(2, int(paint_radius_ *
                           std::min(animation_canvas_.w, animation_canvas_.h))),
           theme::accent);
  c.pop_clip();
  const int transport = py + layout_.preview.h - 38;
  btn({px + 12, transport, 48, 25}, "anim_start", "|<", false, bool(m));
  btn({px + 66, transport, 32, 25}, "anim_play", "",
      playing_, bool(m), playing_ ? "pause" : "play");
  c.text(px + 115, transport + 18, timecode(animation_time_), theme::accent, 11,
         true);
  c.text(px + layout_.preview.w - 126, transport + 18,
         tr("animation.scene", "Scene") + " · " + num(animation_duration(), 1) + " " + tr("unit.seconds_short", "s"), theme::dim2, 8);
  if (layout_.inspector.w) {
    const auto r = layout_.inspector;
    panel(c, r);
    c.text(r.x + 12, r.y + 22, tr("ui.properties", "Properties"), theme::text, 12, true);
    btn({r.x + r.w - 105, r.y + 7, 94, 25}, "anim_autokey", tr("animation.autokey", "Auto key"),
        animation_autokey_, editable);
    button_clip = {r.x + 2, r.y + 38, r.w - 4, r.h - 40};
    c.push_clip(button_clip);
    inspector_content_height_ = 452;
    int y = r.y + 43 - inspector_scroll_;
    for (int p = 0; p < 5; ++p, y += 29) {
      auto *channel = animation_channel(p);
      const double v = channel ? channel->value_at(animation_time_) : 0;
      btn({r.x + 8, y, 115, 23}, "anim_property:" + std::to_string(p),
          labels[std::size_t(p)], animation_property_ == p,
          editable && selected && !selected->locked);
      c.text(r.x + 129, y + 16,
             num(p == 2 || p == 4 ? v * 100 : v, p == 3 ? 1 : 2), theme::text,
             9);
      btn({r.x + r.w - 62, y, 24, 23}, "anim_minus:" + std::to_string(p), "−",
          false, editable && selected && !selected->locked);
      btn({r.x + r.w - 34, y, 24, 23}, "anim_plus:" + std::to_string(p), "+",
          false, editable && selected && !selected->locked);
    }
    c.text(r.x + 12, y + 18, tr("animation.fill_stroke", "Fill / Stroke"), theme::dim, 9, true);
    btn({r.x + 12, y + 27, 66, 24}, "anim_fill", tr("animation.fill", "Fill"),
        selected && selected->fill_enabled,
        editable && selected && !selected->locked);
    for (int i = 0; i < 4; ++i)
      btn({r.x + 85 + i * 32, y + 27, 27, 24},
          "anim_color:" + std::to_string(i),
          i == 0 ? "W" : (i == 1 ? "T" : (i == 2 ? "V" : "R")), false,
          editable && selected && !selected->locked);
    y += 61;
    btn({r.x + 12, y, 92, 23}, "anim_stroke_down", tr("animation.stroke_down", "Stroke −"), false,
        editable && selected && !selected->locked);
    btn({r.x + 109, y, 91, 23}, "anim_stroke_up", tr("animation.stroke_up", "Stroke +"), false,
        editable && selected && !selected->locked);
    y += 34;
    c.text(r.x + 12, y + 14, tr("animation.brush_mask", "Brush mask"), theme::text, 10, true);
    btn({r.x + 12, y + 24, 28, 23}, "brush_down", "−", false, editable);
    btn({r.x + 44, y + 24, 28, 23}, "brush_up", "+", false, editable);
    c.text(r.x + 84, y + 40,
           num(paint_radius_ *
                   std::min(project_.settings.width, project_.settings.height),
               0) +
               " px",
           theme::dim, 9);
    btn({r.x + r.w - 90, y + 24, 77, 23}, "brush_hardness",
        num(paint_hardness_ * 100, 0) + "%", false, editable);
    y += 58;
    btn({r.x + 12, y, 89, 23}, "anim_clear_mask", tr("animation.clear", "Clear"), false, editable);
    btn({r.x + 107, y, 88, 23}, "anim_property:5", tr("animation.mask_strength", "Mask strength"),
        animation_property_ == 5, editable);
    y += 34;
    btn({r.x + 12, y, 91, 23}, "anim_crop", tr("animation.crop", "Crop"),
        scene && scene->crop_enabled, editable);
    btn({r.x + 109, y, 86, 23}, "anim_crop_reset", tr("common.reset", "Reset"), false, editable);
    btn({r.x + 12, y + 29, 183, 23}, "anim_crop_ratio",
        animation_crop_ratio_ == 0
            ? tr("animation.crop_ratio.free", "Frame: free")
            : (animation_crop_ratio_ == 1
                   ? tr("animation.crop_ratio.16_9", "Frame: 16:9")
                   : (animation_crop_ratio_ == 2 ? tr("animation.crop_ratio.1_1", "Frame: 1:1")
                                                 : tr("animation.crop_ratio.project", "Frame: project"))),
        false, editable);
    c.pop_clip();
    button_clip = {};
  }
  const auto timeline = layout_.timeline;
  panel(c, timeline);
  c.text(12, timeline.y + 23, tr("animation.keyframes", "Keyframes"), theme::text, 12, true);
  const int curve_w = std::clamp(timeline.w / 4, 240, 360), header_w = 172,
            row_h = 23;
  animation_keyline_ = {header_w, timeline.y + 50,
                        std::max(1, timeline.w - header_w - curve_w - 18),
                        std::max(1, timeline.h - 66)};
  const double duration = animation_duration();
  for (int i = 0; i <= 10; ++i) {
    const int x = animation_keyline_.x + animation_keyline_.w * i / 10;
    c.line(x, timeline.y + 32, x, timeline.y + 45, theme::dim2);
    c.text(x + 2, timeline.y + 31, num(duration * i / 10, 1) + " " + tr("unit.seconds_short", "s"),
           theme::dim2, 8);
  }
  c.push_clip({0, animation_keyline_.y,
               animation_keyline_.x + animation_keyline_.w,
               animation_keyline_.h});
  for (int p = 0; p < 10; ++p) {
    const int y = animation_keyline_.y + p * row_h - animation_key_scroll_;
    if (y + row_h < animation_keyline_.y ||
        y > animation_keyline_.y + animation_keyline_.h)
      continue;
    btn({6, y + 1, header_w - 14, row_h - 2},
        "anim_property:" + std::to_string(p), labels[std::size_t(p)],
        animation_property_ == p, bool(animation_channel(p)));
    c.line(animation_keyline_.x, y + row_h / 2,
           animation_keyline_.x + animation_keyline_.w, y + row_h / 2,
           theme::borderSoft);
    auto *channel = animation_channel(p);
    if (channel)
      for (const auto &k : channel->keys) {
        const int x = animation_keyline_.x +
                      int(k.time / duration * animation_keyline_.w);
        diamond(c, x, y + row_h / 2,
                p >= 5 ? Color{178, 151, 220} : theme::accent);
        animation_key_hits_.push_back(
            {{x - 7, y + row_h / 2 - 7, 15, 15}, p, k.time});
      }
  }
  const int playx = animation_keyline_.x +
                    int(animation_time_ / duration * animation_keyline_.w);
  c.line(playx, animation_keyline_.y, playx,
         animation_keyline_.y + animation_keyline_.h, theme::accent);
  c.pop_clip();
  const int gx = timeline.w - curve_w + 6, gy = timeline.y + 9;
  btn({gx, gy, 76, 24}, "anim_key_add", tr("animation.key_add", "+ Key"), false,
      bool(animation_channel(animation_property_)) && editable);
  btn({gx + 80, gy, 76, 24}, "anim_key_delete", tr("animation.key_delete_short", "Delete"), false,
      bool(animation_channel(animation_property_)) && editable);
  btn({gx + 160, gy, 72, 24}, "anim_key_prev", tr("animation.key_prev", "< Key"), false,
      bool(animation_channel(animation_property_)));
  btn({gx + 236, gy, std::max(48, curve_w - 250), 24}, "anim_key_next",
      tr("animation.key_next", "Key >"), false, bool(animation_channel(animation_property_)));
  for (int i = 0; i < 3; ++i)
    btn({gx + i * (curve_w - 18) / 3, gy + 31, (curve_w - 26) / 3, 23},
        "anim_interpolation:" + std::to_string(i),
        i == 0 ? tr("animation.interpolation.linear", "Linear") : (i == 1 ? tr("animation.interpolation.hold", "Hold") : tr("animation.interpolation.smooth", "Smooth")), false,
        editable && animation_channel(animation_property_));
  animation_curve_ = {gx + 14, gy + 70, curve_w - 42,
                      std::max(45, timeline.h - 107)};
  c.fill_rect(animation_curve_, theme::bg);
  for (int i = 0; i <= 4; ++i) {
    const int x = animation_curve_.x + animation_curve_.w * i / 4,
              y = animation_curve_.y + animation_curve_.h * i / 4;
    c.line(x, animation_curve_.y, x, animation_curve_.y + animation_curve_.h,
           theme::borderSoft);
    c.line(animation_curve_.x, y, animation_curve_.x + animation_curve_.w, y,
           theme::borderSoft);
  }
  if (auto *channel = animation_channel(animation_property_))
    c.text(gx + 14, gy + 65,
           std::string(labels[std::size_t(animation_property_)]) + " = " +
               num(channel->value_at(animation_time_)),
           theme::dim, 9);
  auto *key = segment(animation_channel(animation_property_), animation_time_,
                      &animation_curve_segment_);
  if (key) {
    for (int i = 0; i < 60; ++i) {
      const double x0 = i / 60.0, x1 = (i + 1) / 60.0;
      c.line(animation_curve_.x + int(x0 * animation_curve_.w),
             animation_curve_.y + animation_curve_.h -
                 int(keyframe_easing(*key, x0) * animation_curve_.h),
             animation_curve_.x + int(x1 * animation_curve_.w),
             animation_curve_.y + animation_curve_.h -
                 int(keyframe_easing(*key, x1) * animation_curve_.h),
             theme::accent, 2);
    }
    if (key->interpolation == KeyframeInterpolation::Smooth) {
      const int x1 = animation_curve_.x + int(key->x1 * animation_curve_.w),
                y1 = animation_curve_.y + animation_curve_.h -
                     int(key->y1 * animation_curve_.h),
                x2 = animation_curve_.x + int(key->x2 * animation_curve_.w),
                y2 = animation_curve_.y + animation_curve_.h -
                     int(key->y2 * animation_curve_.h);
      c.line(animation_curve_.x, animation_curve_.y + animation_curve_.h, x1,
             y1, theme::dim2);
      c.line(animation_curve_.x + animation_curve_.w, animation_curve_.y, x2,
             y2, theme::dim2);
      circle(c, x1, y1, 5, theme::text);
      circle(c, x2, y2, 5, theme::text);
    }
  } else
    c.text(animation_curve_.x + 8, animation_curve_.y + 23,
           tr("animation.curve.need_two_keys", "Add two keyframes"), theme::dim, 9);
  c.text(gx + 8, timeline.y + timeline.h - 8,
         tr("animation.curve.drag_hint", "Curves: drag the round handles"), theme::dim2, 8);
}
bool EditorApp::dispatch_animation_button(const std::string &id) {
  if (id == "workspace_animation") {
    if (paint_drag_)
      finish_paint();
    pause_playback(false);
    animation_workspace_ = true;
    animation_sync_selection();
    preview_tab_ = PreviewTab::VideoPreview;
    request_preview(true);
    set_status(tr("animation.status.workspace", "Animation: vectors, keyframes, brush mask and crop"));
    return true;
  }
  if (id == "workspace_edit") {
    animation_finish_drag();
    animation_workspace_ = false;
    request_preview(true);
    return true;
  }
  if (id == "interface_gpu") {
    interface_gpu_enabled_ = !interface_gpu_enabled_;
    services_.set_interface_gpu_enabled(interface_gpu_enabled_);
    set_status(tr("status.interface", "Interface:") + " " + services_.interface_renderer());
    return true;
  }
  if (id.rfind("anim_", 0) != 0)
    return false;
  if (id == "anim_new") {
    animation_create_scene();
    return true;
  }
  if (id == "anim_scene_next") {
    animation_finish_drag();
    pause_playback(false);
    auto it = std::find_if(
        project_.media.begin(), project_.media.end(),
        [&](const auto &item) { return item.id == animation_media_id_; });
    for (std::size_t n = 0; n < project_.media.size(); ++n) {
      if (it == project_.media.end() || ++it == project_.media.end())
        it = project_.media.begin();
      if (!it->generated_vector.enabled)
        continue;
      animation_media_id_ = it->id;
      animation_clip_id_ = animation_shape_id_ = 0;
      edit_.selection.clear();
      for (const auto &event : project_.clips)
        if (event.media_id() == it->id) {
          animation_clip_id_ = event.id;
          edit_.selection.select_clip(project_, event.id,
                                      SelectionOperation::Replace, false);
          break;
        }
      edit_.selected_media = it->id;
      animation_sync_selection();
      animation_seek(0);
      set_status(it->name);
      break;
    }
    return true;
  }
  auto *m = animation_media();
  if (!m)
    return true;
  auto &scene = m->generated_vector;
  auto *selected = scene.shape(animation_shape_id_);
  if (id == "anim_start") {
    pause_playback(false);
    animation_seek(0);
    return true;
  }
  if (id == "anim_play") {
    if (playing_)
      pause_playback(false);
    else {
      if (animation_time_ >= animation_duration() - 1e-5)
        animation_seek(0);
      start_playback();
    }
    return true;
  }
  if (id.rfind("anim_tool:", 0) == 0) {
    animation_tool_ =
        AnimationTool(std::clamp(std::atoi(id.c_str() + 10), 0, 4));
    pause_playback(false);
    return true;
  }
  if (id.rfind("anim_layer:", 0) == 0) {
    animation_shape_id_ = std::atoi(id.c_str() + 11);
    animation_node_ = -1;
    return true;
  }
  if (id.rfind("anim_property:", 0) == 0) {
    animation_property_ = std::clamp(std::atoi(id.c_str() + 14), 0, 9);
    return true;
  }
  if (id == "anim_key_prev" || id == "anim_key_next") {
    auto *channel = animation_channel(animation_property_);
    if (channel) {
      double t = id == "anim_key_next" ? animation_duration() : 0;
      for (const auto &k : channel->keys) {
        if (id == "anim_key_next" && k.time > animation_time_ + 1e-6)
          t = std::min(t, k.time);
        if (id == "anim_key_prev" && k.time < animation_time_ - 1e-6)
          t = std::max(t, k.time);
      }
      pause_playback(false);
      animation_seek(t);
    }
    return true;
  }
  auto *clip = project_.clip_by_id(animation_clip_id_);
  auto *track = clip ? project_.track_by_id(clip->track_id) : nullptr;
  if ((clip && clip->locked) || (track && track->locked)) {
    set_status(tr("animation.status.locked", "Scene is locked"));
    return true;
  }
  if (id == "anim_crop_ratio") {
    animation_crop_ratio_ = (animation_crop_ratio_ + 1) % 4;
    services_.request_redraw();
    return true;
  }
  if (id == "anim_autokey") {
    animation_autokey_ = !animation_autokey_;
    return true;
  }
  const bool shape_command =
      id == "anim_delete" || id == "anim_duplicate" || id == "anim_fill" ||
      id.rfind("anim_plus:", 0) == 0 || id.rfind("anim_minus:", 0) == 0 ||
      id.rfind("anim_color:", 0) == 0 || id.rfind("anim_stroke_", 0) == 0;
  if ((shape_command || (animation_property_ < 5 &&
                         (id == "anim_key_add" || id == "anim_key_delete" ||
                          id.rfind("anim_interpolation:", 0) == 0))) &&
      (!selected || selected->locked))
    return true;
  undo_.begin(project_);
  if (id == "anim_rect" || id == "anim_ellipse" || id == "anim_path") {
    if (scene.shapes.size() < 128) {
      VectorShape s = id == "anim_rect"
                          ? make_vector_rectangle(scene.next_shape_id++)
                          : (id == "anim_ellipse"
                                 ? make_vector_ellipse(scene.next_shape_id++)
                                 : VectorShape{});
      if (id == "anim_path") {
        s.id = scene.next_shape_id++;
        s.name = tr("animation.shape.path", "Path") + " " + std::to_string(s.id);
        s.closed = false;
        s.fill_enabled = false;
        s.stroke_width = .008;
        animation_tool_ = AnimationTool::Pen;
      }
      if (id == "anim_rect")
        s.name = tr("animation.shape.rectangle", "Rectangle");
      else if (id == "anim_ellipse")
        s.name = tr("animation.shape.ellipse", "Ellipse");
      animation_shape_id_ = s.id;
      scene.shapes.push_back(std::move(s));
      animation_node_ = -1;
    }
  } else if (id == "anim_duplicate" && selected && scene.shapes.size() < 128) {
    VectorShape copy = *selected;
    copy.id = scene.next_shape_id++;
    copy.name += " " + tr("animation.copy_suffix", "copy");
    copy.x.default_value += .03;
    for (auto &k : copy.x.keys)
      k.value += .03;
    animation_shape_id_ = copy.id;
    scene.shapes.push_back(std::move(copy));
  } else if (id == "anim_delete" && selected) {
    scene.shapes.erase(std::remove_if(scene.shapes.begin(), scene.shapes.end(),
                                      [&](const auto &s) {
                                        return s.id == animation_shape_id_;
                                      }),
                       scene.shapes.end());
    animation_shape_id_ = scene.shapes.empty() ? 0 : scene.shapes.back().id;
  } else if (id == "anim_up" || id == "anim_down") {
    auto it = std::find_if(
        scene.shapes.begin(), scene.shapes.end(),
        [&](const auto &s) { return s.id == animation_shape_id_; });
    if (it != scene.shapes.end()) {
      if (id == "anim_up" && std::next(it) != scene.shapes.end())
        std::iter_swap(it, std::next(it));
      if (id == "anim_down" && it != scene.shapes.begin())
        std::iter_swap(it, std::prev(it));
    }
  } else if (id.rfind("anim_visible:", 0) == 0) {
    if (auto *s = scene.shape(std::atoi(id.c_str() + 13)))
      s->visible = !s->visible;
  } else if (id.rfind("anim_lock:", 0) == 0) {
    if (auto *s = scene.shape(std::atoi(id.c_str() + 10)))
      s->locked = !s->locked;
  } else if (id == "anim_fill" && selected)
    selected->fill_enabled = !selected->fill_enabled;
  else if (id.rfind("anim_color:", 0) == 0 && selected) {
    const std::array<VectorColor, 4> colors = {{{1, 1, 1, 1},
                                                {.3, .81, .75, 1},
                                                {.7, .59, .86, 1},
                                                {.91, .32, .38, 1}}};
    selected->fill =
        colors[std::size_t(std::clamp(std::atoi(id.c_str() + 11), 0, 3))];
  } else if (id == "anim_stroke_up" && selected)
    selected->stroke_width = std::min(.05, selected->stroke_width + .001);
  else if (id == "anim_stroke_down" && selected)
    selected->stroke_width = std::max(0.0, selected->stroke_width - .001);
  else if (id == "anim_clear_mask")
    scene.mask_strokes.clear();
  else if (id == "anim_crop")
    scene.crop_enabled = !scene.crop_enabled;
  else if (id == "anim_crop_reset") {
    scene.crop_enabled = false;
    scene.crop_x = {0, {}};
    scene.crop_y = {0, {}};
    scene.crop_w = {1, {}};
    scene.crop_h = {1, {}};
  } else if (id.rfind("anim_plus:", 0) == 0 ||
             id.rfind("anim_minus:", 0) == 0) {
    const bool plus = id.rfind("anim_plus:", 0) == 0;
    const int prop = std::atoi(id.c_str() + (plus ? 10 : 11));
    animation_property_ = std::clamp(prop, 0, 9);
    if (auto *channel = animation_channel(animation_property_)) {
      const double step =
          animation_property_ == 3 ? 5 : (animation_property_ == 2 ? .05 : .02);
      animation_assign(*channel, channel->value_at(animation_time_) +
                                     (plus ? step : -step));
    }
  } else if (id == "anim_key_add") {
    if (auto *channel = animation_channel(animation_property_);
        channel &&
        (channel->has_key(animation_time_) || channel->keys.size() < 2048))
      channel->set_key(animation_time_, channel->value_at(animation_time_),
                       KeyframeInterpolation::Smooth);
  } else if (id == "anim_key_delete") {
    if (auto *channel = animation_channel(animation_property_))
      channel->erase_key(animation_time_, .5 / project_.settings.fps);
  } else if (id.rfind("anim_interpolation:", 0) == 0) {
    auto *channel = animation_channel(animation_property_);
    auto *key = segment(channel, animation_time_);
    if (!key && channel && !channel->keys.empty())
      key = &channel->keys.back();
    if (key)
      key->interpolation =
          KeyframeInterpolation(std::clamp(std::atoi(id.c_str() + 19), 0, 2));
  } else {
    undo_.cancel();
    return true;
  }
  if (undo_.commit(project_)) {
    mark_dirty();
    animation_changed(true);
  } else
    undo_.cancel();
  return true;
}
bool EditorApp::animation_mouse_down(int x, int y, bool shift) {
  if (!animation_workspace_ || dialog_ != DialogMode::None ||
      active_menu_ != MainMenu::None)
    return false;
  auto *m = animation_media();
  if (!m)
    return false;
  auto &scene = m->generated_vector;
  auto *clip = project_.clip_by_id(animation_clip_id_);
  auto *track = clip ? project_.track_by_id(clip->track_id) : nullptr;
  const bool editable = (!clip || !clip->locked) && (!track || !track->locked);
  auto begin = [&](AnimationDrag drag) {
    pause_playback(false);
    animation_drag_ = drag;
    animation_before_ = scene;
    undo_.begin(project_);
  };
  for (const auto &hit : animation_key_hits_)
    if (hit.r.contains(x, y)) {
      animation_property_ = hit.property;
      animation_seek(hit.time);
      const auto *shape = scene.shape(animation_shape_id_);
      if (editable && (hit.property >= 5 || (shape && !shape->locked))) {
        begin(AnimationDrag::Key);
        animation_drag_key_time_ = hit.time;
      }
      return true;
    }
  if (animation_keyline_.contains(x, y)) {
    pause_playback(false);
    animation_seek(double(x - animation_keyline_.x) / animation_keyline_.w *
                   animation_duration());
    return true;
  }
  const auto *channel_shape = scene.shape(animation_shape_id_);
  const Rect curve_hit{animation_curve_.x - 10, animation_curve_.y - 10,
                       animation_curve_.w + 20, animation_curve_.h + 20};
  if (curve_hit.contains(x, y) && editable &&
      (animation_property_ >= 5 || (channel_shape && !channel_shape->locked))) {
    auto *k = segment(animation_channel(animation_property_), animation_time_,
                      &animation_curve_segment_);
    if (k && k->interpolation == KeyframeInterpolation::Smooth) {
      const int x1 = animation_curve_.x + int(k->x1 * animation_curve_.w),
                y1 = animation_curve_.y + animation_curve_.h -
                     int(k->y1 * animation_curve_.h),
                x2 = animation_curve_.x + int(k->x2 * animation_curve_.w),
                y2 = animation_curve_.y + animation_curve_.h -
                     int(k->y2 * animation_curve_.h);
      if (std::hypot(double(x - x1), double(y - y1)) < 10) {
        begin(AnimationDrag::CurveIn);
        return true;
      }
      if (std::hypot(double(x - x2), double(y - y2)) < 10) {
        begin(AnimationDrag::CurveOut);
        return true;
      }
    }
    return true;
  }
  if (!animation_canvas_.contains(x, y))
    return false;
  if (!editable)
    return true;
  VectorPoint p{double(x - animation_canvas_.x) / animation_canvas_.w,
                double(y - animation_canvas_.y) / animation_canvas_.h};
  auto *selected = scene.shape(animation_shape_id_);
  if (animation_tool_ == AnimationTool::Brush) {
    if (scene.mask_strokes.size() > 239900 ||
        std::count(scene.mask_strokes.begin(), scene.mask_strokes.end(),
                   '\n') >= 4096) {
      set_status(tr("animation.status.mask_limit", "Mask stroke limit reached"));
      return true;
    }
    begin(AnimationDrag::Brush);
    animation_drag_origin_ = p;
    animation_brush_segments_ =
        int(std::count(scene.mask_strokes.begin(), scene.mask_strokes.end(),
                       '\n')) +
        1;
    scene.mask_strokes += encode_brush_stroke(
        {p.x, p.y, p.x, p.y, paint_radius_, paint_hardness_, !shift});
    animation_changed();
    return true;
  }
  if (animation_tool_ == AnimationTool::Crop) {
    begin(AnimationDrag::Crop);
    animation_drag_origin_ = p;
    return true;
  }
  if (selected && !selected->locked &&
      (animation_tool_ == AnimationTool::Pen ||
       animation_tool_ == AnimationTool::Nodes)) {
    double best = 10;
    int index = -1;
    AnimationDrag kind = AnimationDrag::Node;
    for (std::size_t i = 0; i < selected->nodes.size(); ++i) {
      const auto &n = selected->nodes[i];
      const std::array<VectorPoint, 3> pts = {
          n.point,
          {n.point.x + n.in.x, n.point.y + n.in.y},
          {n.point.x + n.out.x, n.point.y + n.out.y}};
      for (int j = 0; j < 3; ++j) {
        const auto q = transform_vector_point(
            *selected, pts[std::size_t(j)], animation_time_,
            double(animation_canvas_.w) / animation_canvas_.h);
        const double distance =
            std::hypot(q.x * animation_canvas_.w + animation_canvas_.x - x,
                       q.y * animation_canvas_.h + animation_canvas_.y - y);
        if (distance < best) {
          best = distance;
          index = int(i);
          kind = j == 0 ? AnimationDrag::Node
                        : (j == 1 ? AnimationDrag::TangentIn
                                  : AnimationDrag::TangentOut);
        }
      }
    }
    if (index >= 0) {
      animation_node_ = index;
      begin(kind);
      return true;
    }
    if (animation_tool_ == AnimationTool::Pen && selected->nodes.size() < 512) {
      begin(AnimationDrag::TangentOut);
      selected->nodes.push_back(
          {inverse_vector_point(*selected, p, animation_time_,
                                double(animation_canvas_.w) /
                                    animation_canvas_.h),
           {},
           {}});
      animation_node_ = int(selected->nodes.size()) - 1;
      animation_changed();
      return true;
    }
  }
  if (selected && !selected->locked &&
      animation_tool_ == AnimationTool::Select) {
    auto bounds = shape_bounds(*selected, animation_time_, animation_canvas_);
    for (int hx : {bounds.x, bounds.x + bounds.w - 1})
      for (int hy : {bounds.y, bounds.y + bounds.h - 1})
        if (std::hypot(double(x - hx), double(y - hy)) < 10) {
          begin(AnimationDrag::Resize);
          animation_drag_origin_ = p;
          return true;
        }
  }
  for (auto it = scene.shapes.rbegin(); it != scene.shapes.rend(); ++it)
    if (it->visible &&
        shape_bounds(*it, animation_time_, animation_canvas_).contains(x, y)) {
      animation_shape_id_ = it->id;
      animation_node_ = -1;
      if (!it->locked) {
        begin(AnimationDrag::Move);
        animation_drag_origin_ = p;
      }
      services_.request_redraw();
      return true;
    }
  animation_node_ = -1;
  return true;
}
bool EditorApp::animation_mouse_move(int x, int y, bool shift) {
  if (!animation_workspace_)
    return false;
  if (animation_tool_ == AnimationTool::Brush)
    services_.request_redraw();
  if (animation_drag_ == AnimationDrag::Idle)
    return false;
  auto *m = animation_media();
  if (!m)
    return true;
  auto &scene = m->generated_vector;
  auto *selected = scene.shape(animation_shape_id_);
  VectorPoint p{std::clamp(double(x - animation_canvas_.x) /
                               std::max(1, animation_canvas_.w),
                           0.0, 1.0),
                std::clamp(double(y - animation_canvas_.y) /
                               std::max(1, animation_canvas_.h),
                           0.0, 1.0)};
  if (animation_drag_ == AnimationDrag::Move && selected) {
    auto *original = animation_before_.shape(animation_shape_id_);
    if (original) {
      int keep = animation_property_;
      animation_property_ = 0;
      animation_assign(selected->x, original->x.value_at(animation_time_) +
                                        p.x - animation_drag_origin_.x);
      animation_property_ = 1;
      animation_assign(selected->y, original->y.value_at(animation_time_) +
                                        p.y - animation_drag_origin_.y);
      animation_property_ = keep;
    }
  } else if (animation_drag_ == AnimationDrag::Resize && selected) {
    auto *original = animation_before_.shape(animation_shape_id_);
    if (original) {
      const double cx = original->x.value_at(animation_time_),
                   cy = original->y.value_at(animation_time_),
                   aspect = double(animation_canvas_.w) / animation_canvas_.h;
      const double start = std::hypot((animation_drag_origin_.x - cx) * aspect,
                                      animation_drag_origin_.y - cy),
                   now = std::hypot((p.x - cx) * aspect, p.y - cy);
      if (start > .001) {
        const int keep = animation_property_;
        animation_property_ = 2;
        animation_assign(selected->scale,
                         original->scale.value_at(animation_time_) * now /
                             start);
        animation_property_ = keep;
      }
    }
  } else if ((animation_drag_ == AnimationDrag::Node ||
              animation_drag_ == AnimationDrag::TangentIn ||
              animation_drag_ == AnimationDrag::TangentOut) &&
             selected && animation_node_ >= 0 &&
             animation_node_ < int(selected->nodes.size())) {
    auto &n = selected->nodes[std::size_t(animation_node_)];
    auto local =
        inverse_vector_point(*selected, p, animation_time_,
                             double(animation_canvas_.w) / animation_canvas_.h);
    if (animation_drag_ == AnimationDrag::Node)
      n.point = local;
    else {
      auto tangent = VectorPoint{local.x - n.point.x, local.y - n.point.y};
      if (animation_drag_ == AnimationDrag::TangentIn)
        n.in = tangent;
      else
        n.out = tangent;
      if (!shift) {
        if (animation_drag_ == AnimationDrag::TangentIn)
          n.out = {-tangent.x, -tangent.y};
        else
          n.in = {-tangent.x, -tangent.y};
      }
    }
  } else if (animation_drag_ == AnimationDrag::Brush) {
    if (scene.mask_strokes.size() < 239900 &&
        animation_brush_segments_ < 4096 &&
        std::hypot(p.x - animation_drag_origin_.x,
                   p.y - animation_drag_origin_.y) > .001) {
      scene.mask_strokes += encode_brush_stroke(
          {animation_drag_origin_.x, animation_drag_origin_.y, p.x, p.y,
           paint_radius_, paint_hardness_, !shift});
      animation_drag_origin_ = p;
      ++animation_brush_segments_;
    }
  } else if (animation_drag_ == AnimationDrag::Crop) {
    if (std::hypot(p.x - animation_drag_origin_.x,
                   p.y - animation_drag_origin_.y) > .003) {
      scene.crop_enabled = true;
      int keep = animation_property_;
      double w = std::max(.01, std::abs(p.x - animation_drag_origin_.x)),
             h = std::max(.01, std::abs(p.y - animation_drag_origin_.y));
      const double aspect = double(animation_canvas_.w) / animation_canvas_.h;
      if (shift || animation_crop_ratio_ != 0) {
        const double target = shift || animation_crop_ratio_ == 3
                                  ? aspect
                                  : (animation_crop_ratio_ == 1 ? 16.0 / 9 : 1);
        h = w * aspect / target;
        const double maxw = p.x >= animation_drag_origin_.x
                                ? 1 - animation_drag_origin_.x
                                : animation_drag_origin_.x,
                     maxh = p.y >= animation_drag_origin_.y
                                ? 1 - animation_drag_origin_.y
                                : animation_drag_origin_.y;
        const double fit = std::min({1.0, maxw / w, maxh / h});
        w *= fit;
        h *= fit;
      }
      const double values[] = {
          p.x >= animation_drag_origin_.x ? animation_drag_origin_.x
                                          : animation_drag_origin_.x - w,
          p.y >= animation_drag_origin_.y ? animation_drag_origin_.y
                                          : animation_drag_origin_.y - h,
          w, h};
      for (int i = 0; i < 4; ++i) {
        animation_property_ = i + 6;
        animation_assign(*scene_channel(scene, i + 6), values[i]);
      }
      animation_property_ = keep;
    }
  } else if (animation_drag_ == AnimationDrag::Key) {
    const double time = std::clamp(
        std::round(double(x - animation_keyline_.x) / animation_keyline_.w *
                   animation_duration() * project_.settings.fps) /
            project_.settings.fps,
        0.0, animation_duration());
    auto *original = animation_property_ >= 5
                         ? scene_channel(animation_before_, animation_property_)
                         : (animation_before_.shape(animation_shape_id_)
                                ? vector_channel(*animation_before_.shape(
                                                     animation_shape_id_),
                                                 animation_property_)
                                : nullptr);
    auto *channel = animation_channel(animation_property_);
    if (original && channel) {
      *channel = *original;
      const auto it = std::find_if(
          channel->keys.begin(), channel->keys.end(), [&](const auto &k) {
            return std::abs(k.time - animation_drag_key_time_) < 1e-6;
          });
      if (it != channel->keys.end()) {
        Keyframe key = *it;
        channel->erase_key(animation_drag_key_time_);
        channel->erase_key(time);
        key.time = time;
        channel->keys.push_back(key);
        std::sort(channel->keys.begin(), channel->keys.end(),
                  [](const auto &a, const auto &b) { return a.time < b.time; });
        animation_time_ = time;
      }
    }
  } else if (animation_drag_ == AnimationDrag::CurveIn ||
             animation_drag_ == AnimationDrag::CurveOut) {
    auto *channel = animation_channel(animation_property_);
    if (channel && animation_curve_segment_ >= 0 &&
        animation_curve_segment_ < int(channel->keys.size())) {
      auto &k = channel->keys[std::size_t(animation_curve_segment_)];
      const double cx = std::clamp(double(x - animation_curve_.x) /
                                       animation_curve_.w,
                                   0.0, 1.0),
                   cy = std::clamp(1 - double(y - animation_curve_.y) /
                                           animation_curve_.h,
                                   0.0, 1.0);
      if (animation_drag_ == AnimationDrag::CurveIn) {
        k.x1 = std::min(cx, k.x2);
        k.y1 = cy;
      } else {
        k.x2 = std::max(cx, k.x1);
        k.y2 = cy;
      }
    }
  }
  animation_changed();
  return true;
}
bool EditorApp::animation_mouse_up(int x, int y, bool shift) {
  if (animation_drag_ == AnimationDrag::Idle)
    return false;
  animation_mouse_move(x, y, shift);
  animation_finish_drag();
  return true;
}
void EditorApp::animation_finish_drag(bool cancel) {
  if (animation_drag_ == AnimationDrag::Idle)
    return;
  animation_drag_ = AnimationDrag::Idle;
  if (cancel) {
    if (auto *m = animation_media())
      m->generated_vector = animation_before_;
    undo_.cancel();
    set_status(tr("animation.status.cancelled", "Animation change cancelled"));
  } else if (undo_.commit(project_)) {
    mark_dirty();
    set_status(tr("animation.status.updated", "Animation updated · Ctrl+Z to undo"));
  } else
    undo_.cancel();
  animation_before_ = {};
  animation_changed(true);
}
bool EditorApp::animation_key(Key key, bool ctrl, bool shift) {
  if (!animation_workspace_ || dialog_ != DialogMode::None)
    return false;
  if (key == Key::Escape) {
    if (animation_drag_ != AnimationDrag::Idle)
      animation_finish_drag(true);
    else {
      animation_tool_ = AnimationTool::Select;
      pause_playback(false);
    }
    return true;
  }
  if (animation_drag_ != AnimationDrag::Idle)
    return true;
  if (ctrl)
    return false;
  if (key == Key::Space) {
    dispatch_animation_button("anim_play");
    return true;
  }
  if (key == Key::Left || key == Key::Right) {
    pause_playback(false);
    animation_seek(animation_time_ + (key == Key::Right ? 1 : -1) *
                                         (shift ? 10 : 1) /
                                         project_.settings.fps);
    return true;
  }
  if (key == Key::Plus || key == Key::Minus) {
    dispatch_animation_button(
        std::string(key == Key::Plus ? "anim_plus:" : "anim_minus:") +
        std::to_string(animation_property_));
    return true;
  }
  if (key == Key::B) {
    animation_tool_ = AnimationTool::Brush;
    pause_playback(false);
    return true;
  }
  if (key == Key::V) {
    animation_tool_ = AnimationTool::Select;
    return true;
  }
  auto *event = project_.clip_by_id(animation_clip_id_);
  auto *track = event ? project_.track_by_id(event->track_id) : nullptr;
  if ((key == Key::Delete || key == Key::Enter) &&
      ((event && event->locked) || (track && track->locked)))
    return true;
  if (key == Key::Delete) {
    auto *m = animation_media();
    auto *s = m ? m->generated_vector.shape(animation_shape_id_) : nullptr;
    if (s && animation_tool_ == AnimationTool::Nodes && animation_node_ >= 0 &&
        animation_node_ < int(s->nodes.size()) && !s->locked) {
      undo_.begin(project_);
      s->nodes.erase(s->nodes.begin() + animation_node_);
      animation_node_ = -1;
      if (undo_.commit(project_))
        mark_dirty();
      animation_changed(true);
    } else
      dispatch_animation_button("anim_delete");
    return true;
  }
  if (key == Key::Enter) {
    if (auto *m = animation_media())
      if (auto *s = m->generated_vector.shape(animation_shape_id_);
          s && !s->locked && s->nodes.size() > 2) {
        undo_.begin(project_);
        s->closed = !s->closed;
        s->fill_enabled = s->closed;
        if (undo_.commit(project_))
          mark_dirty();
        animation_changed(true);
      }
    return true;
  }
  if (key == Key::Space || key == Key::Left || key == Key::Right)
    return false;
  return true;
}
} // namespace koralo
