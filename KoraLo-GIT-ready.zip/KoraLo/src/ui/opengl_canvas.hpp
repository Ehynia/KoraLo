#pragma once
#include "canvas.hpp"
#include <functional>
#include <memory>
namespace koralo {
// Context creation remains in the native platform entry point. No GL SDK or
// third-party DLL is needed: the installed OS graphics driver supplies GL.
class OpenGlCanvas final : public Canvas {
public:
  OpenGlCanvas();
  ~OpenGlCanvas() override;
  bool initialize(const std::function<void *(const char *)> &resolver);
  void begin(int width, int height);
  bool finish();
  std::string renderer() const;
  std::uint64_t draw_calls() const;
  std::uint64_t texture_uploads() const;
  int width() const override;
  int height() const override;
  void fill_rect(Rect, Color) override;
  void stroke_rect(Rect, Color, int thickness = 1) override;
  void line(int, int, int, int, Color, int thickness = 1) override;
  void text(int, int, const std::string &, Color, int size = 12,
            bool bold = false) override;
  int text_width(const std::string &, int size = 12,
                 bool bold = false) override;
  void image(Rect, const Frame &) override;
  void push_clip(Rect) override;
  void pop_clip() override;

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
bool interface_gpu_requested();
} // namespace koralo
