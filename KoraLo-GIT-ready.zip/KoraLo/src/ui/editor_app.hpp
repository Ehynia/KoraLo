#pragma once
#include "canvas.hpp"
#include "platform_services.hpp"
#include "localization.hpp"
#include "../core/edit_controller.hpp"
#include "../core/vegas_importer.hpp"
#include "../media/media_engine.hpp"
#include "../plugins/ofx_host.hpp"
#include <atomic>
#include <chrono>
#include <future>
#include <functional>
#include <optional>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>

namespace koralo {

enum class Key {
    Unknown, B, Delete, Space, Left, Right, S, Z, Y, I, O, M, N, C, V, X, L,
    Escape, Plus, Minus, Enter, Backspace, F1
};

class EditorApp {
public:
    explicit EditorApp(PlatformServices& services);
    ~EditorApp();

    void draw(Canvas& c);
    void set_ui_scale(double scale);
    void tick();
    void mouse_down(int x,int y,int button,bool ctrl,bool shift,bool alt);
    void mouse_move(int x,int y,bool ctrl,bool shift,bool alt);
    void mouse_up(int x,int y,int button,bool ctrl,bool shift,bool alt);
    void mouse_wheel(int x,int y,double delta,bool ctrl,bool shift);
    void key_down(Key key,bool ctrl,bool shift,bool alt);
    void text_input(const std::string& text);
    void file_dropped(const std::string& path,int x,int y);

    bool wants_close() const { return wants_close_; }
    void request_close();

private:
    enum class BinTab { ProjectMedia, Generators, VideoFx, AudioFx, Transitions };
    enum class MediaView { Grid, List };
    enum class MediaFilter { All, Audio, Video, Stills };
    enum class PreviewTab { VideoPreview, Trimmer };
    enum class PreviewQuality { Draft, Preview, Good, Best };
    enum class ToolMode { Select, Split, PaintMask };
    Rect paint_viewport_{};
    bool paint_drag_=false;
    int paint_clip_=0,paint_effect_=0,paint_count_=0;
    double paint_x_=0,paint_y_=0,paint_radius_=0.06,paint_hardness_=0.75;
    std::vector<EffectInstance> paint_before_;
    void paint_segment(int x,int y,bool restore);
    void finish_paint(bool cancel=false);
    enum class MainMenu { None, File, Edit, View, Insert, Tools, Options, Help };
    enum class DialogMode { None, ProjectProperties, Preferences, PanCrop, RenderAs, EffectEditor, TextEditor };
    enum class ContextMenuKind { None, Event, Timeline, Media, Track, AnimationKey, PanCropKey };

    struct ContextMenuItem {
        std::string id;
        std::string key;
        std::string fallback;
        std::string shortcut;
        bool enabled=true;
        bool separator=false;
    };
    struct ContextMenuState {
        ContextMenuKind kind=ContextMenuKind::None;
        int x=0,y=0;
        int clip_id=0;
        int media_id=0;
        int track_id=0;
        int property=-1;
        double time=0.0;
        Rect panel{};
        std::vector<ContextMenuItem> items;
        bool open() const { return kind!=ContextMenuKind::None; }
        void clear(){ kind=ContextMenuKind::None;x=y=clip_id=media_id=track_id=0;property=-1;time=0.0;panel={};items.clear(); }
    };

    struct Button {
        Rect r;
        std::string id,label;
        bool active=false;
        bool enabled=true;
        std::string icon;
        Button()=default;
        Button(Rect rr,std::string iid,std::string text={},bool is_active=false,bool is_enabled=true,std::string glyph={})
            :r(rr),id(std::move(iid)),label(std::move(text)),active(is_active),enabled(is_enabled),icon(std::move(glyph)){}
    };
    enum class SliderKind { None, TrackLevel, TrackPan };
    struct SliderDrag {
        SliderKind kind=SliderKind::None;
        int track_id=0;
        double value=0.0;
        bool active() const { return kind!=SliderKind::None; }
        void clear(){ kind=SliderKind::None;track_id=0;value=0.0; }
    };
    struct AudioGainDrag {
        bool active=false;
        int clip_id=0;
        int top=0,bottom=0;
        double gain=1.0;
        void clear(){ active=false;clip_id=0;top=bottom=0;gain=1.0; }
    };
    enum class PanCropDragKind { None, Move, Resize, Rotation };
    struct PanCropDrag {
        PanCropDragKind kind=PanCropDragKind::None;
        int origin_x=0,origin_y=0;
        VideoMotionSample start;
        VideoMotionSample preview;
        bool active() const { return kind!=PanCropDragKind::None; }
        void clear(){ kind=PanCropDragKind::None;origin_x=origin_y=0; }
    };

    struct EffectDrag {
        bool active=false;
        bool moved=false;
        int origin_x=0,origin_y=0,current_x=0,current_y=0;
        std::string definition_id;
        void clear(){active=false;moved=false;origin_x=origin_y=current_x=current_y=0;definition_id.clear();}
    };
    struct EffectSliderHit {
        Rect r{};
        int effect_id=0;
        std::string parameter_id;
        double min_value=0.0,max_value=1.0,value=0.0;
    };
    struct EffectParamDrag {
        bool active=false;
        int clip_id=0,effect_id=0;
        std::string parameter_id;
        Rect r{};
        double min_value=0.0,max_value=1.0,start_value=0.0,value=0.0;
        void clear(){active=false;clip_id=effect_id=0;parameter_id.clear();r={};min_value=0.0;max_value=1.0;start_value=value=0.0;}
    };
    struct TimelinePanDrag {
        bool active=false;
        int origin_x=0;
        double origin_scroll=0.0;
        void clear(){active=false;origin_x=0;origin_scroll=0.0;}
    };
    struct HScrollDrag {
        bool active=false;
        int grab_offset=0;
        void clear(){active=false;grab_offset=0;}
    };
    struct RenderPreset {
        std::string name;
        int width=1920,height=1080;
        double fps=30.0;
        int video_kbps=12000,audio_kbps=192;
        bool gpu=true;
    };
    struct BinRow { Rect r; int media_id=0; };
    struct Layout {
        Rect menubar, document, toolbar, tools, bin, preview, inspector, timeline, status;
        TimelineGeometry timeline_geo;
    };

    void rebuild_layout(int w,int h);
    void draw_menubar(Canvas& c);
    void draw_menu_overlay(Canvas& c);
    void draw_modal(Canvas& c);
    void draw_pan_crop(Canvas& c);
    void draw_render_as(Canvas& c);
    void draw_effect_editor(Canvas& c);
    void draw_text_editor(Canvas& c);
    void draw_toolbar(Canvas& c);
    void draw_document(Canvas& c);
    void draw_tools(Canvas& c);
    void draw_inspector(Canvas& c);
    bool dispatch_inspector_button(const std::string& id);
    int inspector_tab_=0;
    int inspector_scroll_=0;
    int inspector_content_height_=0;
    void draw_animation_workspace(Canvas&);
    bool dispatch_animation_button(const std::string&);
    bool animation_mouse_down(int,int,bool);
    bool animation_mouse_move(int,int,bool);
    bool animation_mouse_up(int,int,bool);
    bool animation_key(Key,bool,bool);
    void animation_sync_selection();
    void animation_create_scene();
    void animation_seek(double);
    void animation_assign(AnimatedDouble&,double);
    void animation_changed(bool final=false);
    void animation_finish_drag(bool cancel=false);
    MediaItem* animation_media();
    AnimatedDouble* animation_channel(int property);
    double animation_duration()const;
    void draw_bin(Canvas& c);
    void draw_preview(Canvas& c);
    void draw_timeline(Canvas& c);
    void draw_status(Canvas& c);
    void draw_context_menu(Canvas& c);
    void draw_button(Canvas& c,const Button& b);
    void draw_clip(Canvas& c,const Clip& clip,const Track& track,int y,int h,const ClipVisualOverride* ov=nullptr);
    void dispatch_button(const std::string& id);
    bool dispatch_context_button(const std::string& id);
    bool dispatch_modal_button(const std::string& id);
    bool dispatch_edit_button(const std::string& id);
    bool dispatch_workspace_button(const std::string& id);
    bool dispatch_fx_button(const std::string& id);
    bool dispatch_track_button(const std::string& id);
    void commit_project_toggle(const std::function<void()>& fn);
    void open_context_menu(int x,int y);
    void close_context_menu();
    void open_media_in_trimmer(int media_id,double source_time=0.0);
    std::string tr(std::string_view key,std::string_view fallback={}) const;
    std::string current_language_name() const;
    void cycle_language(int direction);

    void import_paths(const std::vector<std::string>& paths);
    void add_media_to_timeline(int media_id,double at,int track_id=0);
    void request_preview(bool force=false);
    void start_playback();
    void pause_playback(bool stopped=false);
    void resync_audio_preview(bool force=false);
    void toggle_audio_recording();
    void stop_audio_recording(bool commit=true);
    void set_playhead(double t,bool force_preview=false);
    void step_preview(int frames);
    void new_project();
    bool confirm_project_replace();
    void recover_latest_autosave();
    void collect_project();
    void relink_missing_media();
    void open_project();
    void open_project_path(const std::string& path);
    bool import_vegas_project(const std::string& path);
    void save_project(bool save_as=false);
    void render_as();
    void begin_render_with_preset();
    void run_system_check(bool show_dialog=false);
    void refresh_ofx_plugins(bool show_status=false);
    void clamp_timeline_scroll();
    bool drop_effect_on_timeline(const std::string& definition_id,int x,int y);
    void create_proxy_for_selected();
    void update_title();
    void mark_dirty();
    void set_status(std::string s);
    void show_project_settings();
    void show_help();
    void add_marker();
    void set_source_in();
    void set_source_out();
    void insert_from_trimmer(bool overwrite);
    void open_pan_crop(int clip_id);
    void open_effect_editor(int clip_id,int effect_id=0);
    void insert_text_event();
    void open_text_editor(int clip_id);
    void autosave_if_needed(bool force=false);
    std::string autosave_path() const;
    void remove_autosave();
    void sync_preview_settings_from_project();
    void commit_preview_project_settings();
    void pan_crop_set_key(const VideoMotionSample& sample);
    void set_bin_tab(BinTab tab);
    void set_media_filter(MediaFilter filter);
    bool media_visible(const MediaItem& media) const;
    bool visible_video_clip(const Clip& clip) const;
    int bin_row_at(int x,int y) const;
    std::optional<Button> button_at(int x,int y) const;
    std::string timecode(double seconds) const;
    std::string preview_quality_name() const;
    std::string preview_fps_name() const;

    enum class AnimationTool { Select, Pen, Nodes, Brush, Crop };
    enum class AnimationDrag { Idle, Move, Resize, Node, TangentIn, TangentOut, Brush, Crop, Key, CurveIn, CurveOut };
    bool animation_workspace_=false,animation_autokey_=true,animation_preview_pending_=false;
    int animation_media_id_=0,animation_clip_id_=0,animation_shape_id_=0,animation_property_=0,animation_node_=-1,animation_curve_segment_=-1;
    double animation_time_=0,animation_drag_key_time_=0;
    int animation_layer_scroll_=0,animation_key_scroll_=0,animation_brush_segments_=0,animation_crop_ratio_=0;
    AnimationTool animation_tool_=AnimationTool::Select;
    AnimationDrag animation_drag_=AnimationDrag::Idle;
    VectorScene animation_before_;
    VectorPoint animation_drag_origin_{};
    Rect animation_canvas_{},animation_keyline_{},animation_curve_{},animation_layers_{};
    struct AnimationKeyHit {Rect r;int property;double time;};
    std::vector<AnimationKeyHit> animation_key_hits_;
    std::chrono::steady_clock::time_point last_edit_preview_wall_{};
    bool paint_preview_pending_=false;
    int paint_total_segments_=0;
    bool interface_gpu_enabled_=true;
    PlatformServices& services_;
    Localization localization_;
    Project project_;
    UndoStack undo_;
    EditController edit_;
    ClipClipboard clipboard_;
    MediaEngine engine_;
    OfxHostRegistry ofx_registry_;
    Layout layout_;
    std::vector<Button> buttons_;
    std::vector<BinRow> bin_rows_;
    std::string status_="Ready";
    double playhead_=0.0;
    bool playing_=false;
    double play_speed_=1.0;
    std::chrono::steady_clock::time_point play_wall_{};
    double play_start_=0.0;
    std::chrono::steady_clock::time_point last_preview_request_wall_{};
    std::chrono::steady_clock::time_point last_audio_sync_wall_{};
    bool audio_warning_shown_=false;
    bool recording_audio_=false;
    int recording_track_id_=0;
    double recording_start_time_=0.0;
    std::string recording_raw_path_;
    std::string recording_wav_path_;
    std::chrono::steady_clock::time_point recording_wall_{};
    bool dirty_=false;
    bool wants_close_=false;
    std::chrono::steady_clock::time_point last_autosave_wall_{};
    std::string autosave_file_;
    bool mouse_down_=false;
    int mouse_x_=0,mouse_y_=0;
    double ui_scale_=1.0;
    bool ui_scale_explicit_=false;
    std::uint64_t preview_token_=0;
    std::uint64_t preview_epoch_=1;
    int preview_clip_id_=0,preview_background_clip_id_=0,preview_text_clip_id_=0;
    std::uint64_t shown_preview_token_=0;
    Frame preview_frame_;
    std::string preview_error_;
    int preview_media_id_=0;
    double preview_source_time_=-1.0;
    int source_media_id_=0;
    double source_time_=0.0;
    double source_in_=0.0,source_out_=-1.0;
    std::atomic<double> render_progress_{0.0};
    std::future<std::pair<bool,std::string>> render_future_;
    bool rendering_=false;
    bool render_finished_=false,render_succeeded_=false;
    bool render_fsr_=false;
    float render_fsr_sharpness_=.5f;
    std::string render_output_path_,render_result_message_;
    std::chrono::steady_clock::time_point render_started_{},render_redraw_{};
    double render_elapsed_=0;
    std::atomic<bool> render_cancel_{false};
    std::string autosave_session_=std::to_string(std::chrono::system_clock::now().time_since_epoch().count());
    std::vector<RenderPreset> render_presets_;
    int render_preset_index_=0;
    RenderPreset render_pending_{};
    std::string system_report_;

    BinTab bin_tab_=BinTab::ProjectMedia;
    MediaView media_view_=MediaView::Grid;
    MediaFilter media_filter_=MediaFilter::All;
    PreviewTab preview_tab_=PreviewTab::VideoPreview;
    PreviewQuality preview_quality_=PreviewQuality::Preview;
    int preview_fps_limit_=30;
    bool use_prepared_cache_=true;
    ToolMode tool_mode_=ToolMode::Select;
    MainMenu active_menu_=MainMenu::None;
    ContextMenuState context_menu_;
    DialogMode dialog_=DialogMode::None;
    ProjectSettings pending_project_settings_{};
    bool audio_preview_enabled_=true;
    bool gpu_enabled_=true;
    std::uint64_t thumbnail_revision_seen_=0;
    double meter_left_=0.0;
    double meter_right_=0.0;
    bool media_bins_expanded_=false;
    bool by_type_expanded_=true;
    bool tags_expanded_=false;
    SliderDrag slider_drag_;
    AudioGainDrag audio_gain_drag_;
    int pan_crop_clip_id_=0;
    double pan_crop_time_=0.0;
    Rect pan_crop_workspace_{};
    Rect pan_crop_keyline_{};
    PanCropDrag pan_crop_drag_;
    EffectDrag effect_drag_;
    std::vector<EffectSliderHit> fx_slider_hits_;
    EffectParamDrag fx_param_drag_;
    TimelinePanDrag timeline_pan_drag_;
    HScrollDrag timeline_hscroll_drag_;
    Rect timeline_hscroll_track_{};
    Rect timeline_hscroll_thumb_{};
    HScrollDrag timeline_vscroll_drag_;
    Rect timeline_vscroll_track_{};
    Rect timeline_vscroll_thumb_{};
    bool preview_fit_=true;
    bool search_editing_=false;
    std::string search_query_;
    bool fx_search_editing_=false;
    std::string fx_search_query_;
    std::string selected_fx_definition_="koralo.brightness_contrast";
    std::string selected_audio_fx_definition_="koralo.audio.echo";
    int selected_track_id_=0;
    int fx_editor_clip_id_=0;
    int fx_editor_effect_id_=0;
    int fx_parameter_scroll_=0;
    Rect fx_parameter_view_{};
    int text_editor_clip_id_=0;
    int text_editor_media_id_=0;
    GeneratedText text_editor_pending_{};
    bool text_editor_text_focus_=false;
    Rect text_editor_preview_{};
    bool text_position_drag_=false;
    bool fit_timeline_requested_=false;
    MediaPreparationProgress preparation_ui_{};
    std::unordered_map<std::string,float> ui_hover_anim_;
    std::unordered_map<std::string,float> ui_press_anim_;
    bool ui_animation_active_=false;
    double ui_anim_dt_=1.0/60.0;
    std::chrono::steady_clock::time_point last_ui_draw_wall_{};
    std::chrono::steady_clock::time_point last_ui_anim_redraw_{};
};

} // namespace koralo
