#include "editor_app.hpp"

#include <cstdlib>
#include <cmath>

namespace koralo {

namespace {
std::string short_name(const std::string& s,std::size_t n=48){
    std::size_t count=0,cut=0;
    for(std::size_t i=0;i<s.size();++i){
        if((static_cast<unsigned char>(s[i])&0xc0)==0x80)continue;
        if(count== (n>3?n-3:0))cut=i;
        ++count;
    }
    return count<=n?s:s.substr(0,cut)+"...";
}
}

bool EditorApp::dispatch_track_button(const std::string& id){
    enum class Command { None, Mute, Solo, Lock };
    Command command=Command::None;
    std::size_t prefix_length=0;
    if(id.rfind("track_mute:",0)==0){command=Command::Mute;prefix_length=11;}
    else if(id.rfind("track_solo:",0)==0){command=Command::Solo;prefix_length=11;}
    else if(id.rfind("track_lock:",0)==0){command=Command::Lock;prefix_length=11;}
    if(command==Command::None) return false;

    const int track_id=std::atoi(id.c_str()+static_cast<int>(prefix_length));
    Track* track=project_.track_by_id(track_id);
    if(!track) return true;
    undo_.begin(project_);
    if(command==Command::Mute) track->mute=!track->mute;
    else if(command==Command::Solo) track->solo=!track->solo;
    else track->locked=!track->locked;
    if(undo_.commit(project_)){
        selected_track_id_=track_id;
        mark_dirty();
        request_preview(true);
    }
    return true;
}

void EditorApp::dispatch_button(const std::string& id){
    context_menu_.clear();
    if(id.rfind("menu:",0)==0){
        const int raw=std::atoi(id.c_str()+5);
        const MainMenu requested=static_cast<MainMenu>(raw);
        active_menu_=active_menu_==requested?MainMenu::None:requested;
        services_.request_redraw();
        return;
    }
    active_menu_=MainMenu::None;
    if(dispatch_animation_button(id) || dispatch_modal_button(id) || dispatch_edit_button(id) || dispatch_fx_button(id) || dispatch_workspace_button(id) || dispatch_track_button(id)){
        services_.request_redraw();
        return;
    }
    services_.request_redraw();
}


bool EditorApp::dispatch_modal_button(const std::string& id){
    if(id=="settings"){ show_project_settings(); return true; }
    if(id=="preferences"){ dialog_=DialogMode::Preferences; active_menu_=MainMenu::None; return true; }
    if(id=="media_diagnostics"){ run_system_check(true); return true; }
    if(id=="ofx_rescan"){ refresh_ofx_plugins(true); return true; }
    if(id=="about"){
        services_.show_message(tr("about.title","About KoraLo"),tr("about.body","KoraLo Native 0.7\nClean-room C++20 NLE for Windows and Linux.\nAuthor: Ehynia."),false);
        return true;
    }
    if(id.rfind("pan_crop:",0)==0){ open_pan_crop(std::atoi(id.c_str()+9)); return true; }
    if(id=="pan_crop_close"){ pan_crop_drag_.clear(); undo_.cancel(); dialog_=DialogMode::None; set_status(tr("status.pan_crop_closed","Pan/Crop closed")); return true; }
    if(id=="pan_crop_add_key"){
        if(Clip* clip=project_.clip_by_id(pan_crop_clip_id_)) pan_crop_set_key(sample_motion(clip->video_motion,pan_crop_time_));
        return true;
    }
    if(id=="pan_crop_delete_key"){
        Clip* clip=project_.clip_by_id(pan_crop_clip_id_);
        if(!clip) return true;
        undo_.begin(project_);
        clip->video_motion.erase_key(pan_crop_time_);
        if(undo_.commit(project_)){
            mark_dirty(); engine_.clear_composite_cache(); request_preview(true); set_status(tr("status.pan_crop_key_deleted","Pan/Crop keyframe deleted"));
        }
        return true;
    }
    if(id=="pan_crop_time_zero"){
        pan_crop_time_=0.0;
        if(Clip* clip=project_.clip_by_id(pan_crop_clip_id_)) set_playhead(clip->start,true);
        return true;
    }
    if(id=="pan_crop_reset"){ pan_crop_set_key({0.5,0.5,1.0,0.0}); return true; }
    if(id=="pan_crop_rot_minus"||id=="pan_crop_rot_plus"){
        Clip* clip=project_.clip_by_id(pan_crop_clip_id_);
        if(!clip) return true;
        auto value=sample_motion(clip->video_motion,pan_crop_time_);
        value.rotation=std::clamp(value.rotation+(id=="pan_crop_rot_plus"?5.0:-5.0),-360.0,360.0);
        pan_crop_set_key(value);
        return true;
    }
    if(id=="fx_param_prev"||id=="fx_param_next"){fx_parameter_scroll_=std::max(0,fx_parameter_scroll_+(id=="fx_param_next"?1:-1));return true;}
    if(id=="fx_editor_clear_paint"){auto* clip=project_.clip_by_id(fx_editor_clip_id_);if(!clip)return true;auto it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){return e.id==fx_editor_effect_id_;});if(it==clip->video_effects.end())return true;undo_.begin(project_);if(auto* state=effect_parameter(*it,"strokes"))state->value=std::string{};if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);}return true;}
    if(id=="fx_editor_close"){fx_parameter_scroll_=0; dialog_=DialogMode::None; fx_editor_clip_id_=0; fx_editor_effect_id_=0; fx_slider_hits_.clear(); return true; }
    if(id=="fx_editor_open_pane"){ dialog_=DialogMode::None; bin_tab_=BinTab::VideoFx; fx_slider_hits_.clear(); set_status(tr("status.video_fx_pane","Video FX pane")); return true; }
    if(id.rfind("fx_editor_pick_def:",0)==0){ selected_fx_definition_=id.substr(19); return true; }
    if(id=="fx_editor_add"){
        Clip* clip=project_.clip_by_id(fx_editor_clip_id_); if(!clip) return true;
        const auto* definition=effect_definition(selected_fx_definition_); if(!definition) return true;
        if(selected_fx_definition_.rfind("ofx:",0)==0){set_status(tr("status.ofx_render_gated","OpenFX plug-in detected; third-party pixel rendering is not enabled in this beta host yet"));return true;}
        undo_.begin(project_);
        const int new_id=project_.next_id();
        clip->video_effects.push_back(make_effect_instance(selected_fx_definition_,new_id));
        if(undo_.commit(project_)){ fx_editor_effect_id_=new_id; mark_dirty(); engine_.clear_composite_cache(); request_preview(true); set_status(tr("status.added","Added")+" "+tr("catalog."+definition->name,definition->name)); }
        return true;
    }
    if(id.rfind("fx_editor_select_inst:",0)==0){ fx_editor_effect_id_=std::atoi(id.c_str()+22);fx_parameter_scroll_=0; request_preview(false); return true; }
    if(id=="fx_editor_toggle"||id=="fx_editor_remove"){
        Clip* clip=project_.clip_by_id(fx_editor_clip_id_); if(!clip) return true;
        auto it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){ return e.id==fx_editor_effect_id_; });
        if(it==clip->video_effects.end()) return true;
        const bool remove=id=="fx_editor_remove";
        undo_.begin(project_);
        if(remove){ clip->video_effects.erase(it); fx_editor_effect_id_=clip->video_effects.empty()?0:clip->video_effects.front().id; }
        else it->enabled=!it->enabled;
        if(undo_.commit(project_)){ mark_dirty(); engine_.clear_composite_cache(); request_preview(true); }
        return true;
    }
    if(id.rfind("fx_editor_bool:",0)==0){
        Clip* clip=project_.clip_by_id(fx_editor_clip_id_);if(!clip)return true;
        auto it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){return e.id==fx_editor_effect_id_;});if(it==clip->video_effects.end())return true;
        const std::string parameter_id=id.substr(15);auto* state=effect_parameter(*it,parameter_id);if(!state)return true;
        bool current=false;if(const auto* value=std::get_if<bool>(&state->value))current=*value;
        undo_.begin(project_);state->value=!current;state->animated=false;state->keys.clear();
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);}return true;
    }
    if(id.rfind("fx_editor_param_",0)==0){
        Clip* clip=project_.clip_by_id(fx_editor_clip_id_); if(!clip) return true;
        auto it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){ return e.id==fx_editor_effect_id_; });
        if(it==clip->video_effects.end()) return true;
        const bool up=id.rfind("fx_editor_param_up:",0)==0;
        const bool reset=id.rfind("fx_editor_param_reset:",0)==0;
        const std::string parameter_id=id.substr(reset?22: (up?19:21));
        const auto* definition=effect_definition(it->definition_id); if(!definition) return true;
        const auto pit=std::find_if(definition->parameters.begin(),definition->parameters.end(),[&](const ParameterDefinition& p){ return p.id==parameter_id; });
        if(pit==definition->parameters.end()) return true;
        const double fallback=std::holds_alternative<double>(pit->default_value)?std::get<double>(pit->default_value):0.0;
        const double current=effect_numeric(*it,parameter_id,0.0,fallback);
        double next=reset?fallback:(current+(up?pit->step:-pit->step));
        next=std::clamp(next,pit->min_value,pit->max_value);
        undo_.begin(project_);
        set_effect_numeric(*it,parameter_id,next);
        if(undo_.commit(project_)){ mark_dirty(); engine_.clear_composite_cache(); request_preview(true); }
        return true;
    }

    if(id=="text_focus"){text_editor_text_focus_=true;services_.request_redraw();return true;}
    if(id=="text_cancel"){dialog_=DialogMode::None;text_editor_text_focus_=false;text_editor_clip_id_=text_editor_media_id_=0;request_preview(true);return true;}
    if(id=="text_apply"){
        MediaItem* media=project_.media_by_id(text_editor_media_id_);if(!media)return true;
        undo_.begin(project_);media->generated_text=text_editor_pending_;media->generated_text.enabled=true;
        std::string title=media->generated_text.text;const auto nl=title.find('\n');if(nl!=std::string::npos)title=title.substr(0,nl);if(title.empty())title="Titles & Text";media->name="Titles & Text — "+short_name(title,28);
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);}
        dialog_=DialogMode::None;text_editor_text_focus_=false;text_editor_clip_id_=text_editor_media_id_=0;set_status(tr("status.text_updated","Titles & Text updated"));return true;
    }
    auto refresh_text_preview=[&](){request_preview(true);services_.request_redraw();};
    if(id=="text_size_down"){text_editor_pending_.font_size=std::max(8.0,text_editor_pending_.font_size-2.0);refresh_text_preview();return true;}
    if(id=="text_size_up"){text_editor_pending_.font_size=std::min(240.0,text_editor_pending_.font_size+2.0);refresh_text_preview();return true;}
    if(id=="text_bold"){text_editor_pending_.bold=!text_editor_pending_.bold;refresh_text_preview();return true;}
    if(id=="text_italic"){text_editor_pending_.italic=!text_editor_pending_.italic;refresh_text_preview();return true;}
    if(id=="text_align_left"||id=="text_align_center"||id=="text_align_right"){text_editor_pending_.alignment=id=="text_align_left"?0:(id=="text_align_center"?1:2);refresh_text_preview();return true;}
    if(id.rfind("text_color_",0)==0){
        if(id=="text_color_white"){text_editor_pending_.color_r=text_editor_pending_.color_g=text_editor_pending_.color_b=1.0;}
        else if(id=="text_color_yellow"){text_editor_pending_.color_r=.96;text_editor_pending_.color_g=.82;text_editor_pending_.color_b=.22;}
        else if(id=="text_color_cyan"){text_editor_pending_.color_r=.25;text_editor_pending_.color_g=.80;text_editor_pending_.color_b=.90;}
        else if(id=="text_color_red"){text_editor_pending_.color_r=.92;text_editor_pending_.color_g=.28;text_editor_pending_.color_b=.28;}
        else if(id=="text_color_green"){text_editor_pending_.color_r=.34;text_editor_pending_.color_g=.82;text_editor_pending_.color_b=.44;}
        else if(id=="text_color_black"){text_editor_pending_.color_r=text_editor_pending_.color_g=text_editor_pending_.color_b=.06;}
        refresh_text_preview();return true;
    }
    if(id=="text_scale_down"){text_editor_pending_.scale=std::max(.1,text_editor_pending_.scale-.05);refresh_text_preview();return true;}
    if(id=="text_scale_up"){text_editor_pending_.scale=std::min(6.0,text_editor_pending_.scale+.05);refresh_text_preview();return true;}
    if(id=="text_scale_reset"){text_editor_pending_.scale=1.0;refresh_text_preview();return true;}
    if(id=="text_x_left"||id=="text_x_right"){text_editor_pending_.location_x=std::clamp(text_editor_pending_.location_x+(id=="text_x_right"?.02:-.02),0.0,1.0);refresh_text_preview();return true;}
    if(id=="text_y_up"||id=="text_y_down"){text_editor_pending_.location_y=std::clamp(text_editor_pending_.location_y+(id=="text_y_down"?.02:-.02),0.0,1.0);refresh_text_preview();return true;}
    if(id=="text_anchor_cycle"){text_editor_pending_.anchor=(text_editor_pending_.anchor+1)%9;refresh_text_preview();return true;}
    if(id=="text_outline"){text_editor_pending_.outline=!text_editor_pending_.outline;refresh_text_preview();return true;}
    if(id=="text_shadow"){text_editor_pending_.shadow=!text_editor_pending_.shadow;refresh_text_preview();return true;}
    if(id=="text_animation"){text_editor_pending_.animation=text_editor_pending_.animation?0:1;refresh_text_preview();return true;}

    if(id=="render:stop"){if(rendering_)render_cancel_=true;return true;}
    if(id=="render:background"){dialog_=DialogMode::None;return true;}
    if(id=="render:close"){if(!rendering_){render_finished_=false;dialog_=DialogMode::None;}return true;}
    if(rendering_&&id.rfind("render:",0)==0)return true;
    if(id=="render:fsr"){render_fsr_=!render_fsr_;return true;}
    if(id=="render:sharp_down"){render_fsr_sharpness_=std::max(0.f,render_fsr_sharpness_-.1f);return true;}
    if(id=="render:sharp_up"){render_fsr_sharpness_=std::min(1.f,render_fsr_sharpness_+.1f);return true;}
    if(id=="render:size720"||id=="render:size1080"||id=="render:size2160"){
        const int height=id=="render:size720"?720:(id=="render:size1080"?1080:2160);
        render_pending_.height=height;
        render_pending_.width=std::clamp(int(std::lround(height*double(project_.settings.width)/std::max(1,project_.settings.height)))/2*2,2,7680);
        return true;
    }
    if(id=="render:cancel"){ dialog_=DialogMode::None; return true; }
    if(id=="render:preset_prev"||id=="render:preset_next"){
        if(!render_presets_.empty()){
            const int n=static_cast<int>(render_presets_.size());
            render_preset_index_=(render_preset_index_+(id=="render:preset_next"?1:-1)+n)%n;
            render_pending_=render_presets_[static_cast<std::size_t>(render_preset_index_)];
        }
        return true;
    }
    if(id=="render:width_down"){ render_pending_.width=std::max(320,render_pending_.width-160); return true; }
    if(id=="render:width_up"){ render_pending_.width=std::min(7680,render_pending_.width+160); return true; }
    if(id=="render:height_down"){ render_pending_.height=std::max(180,render_pending_.height-90); return true; }
    if(id=="render:height_up"){ render_pending_.height=std::min(4320,render_pending_.height+90); return true; }
    if(id=="render:fps_down"){ render_pending_.fps=std::max(1.0,render_pending_.fps-(render_pending_.fps>31.0?10.0:5.0)); return true; }
    if(id=="render:fps_up"){ render_pending_.fps=std::min(240.0,render_pending_.fps+(render_pending_.fps>=30.0?10.0:5.0)); return true; }
    if(id=="render:vbit_down"){ render_pending_.video_kbps=std::max(500,render_pending_.video_kbps-2000); return true; }
    if(id=="render:vbit_up"){ render_pending_.video_kbps=std::min(200000,render_pending_.video_kbps+2000); return true; }
    if(id=="render:abit_down"){ render_pending_.audio_kbps=std::max(64,render_pending_.audio_kbps-32); return true; }
    if(id=="render:abit_up"){ render_pending_.audio_kbps=std::min(1024,render_pending_.audio_kbps+32); return true; }
    if(id=="render:gpu"){ render_pending_.gpu=!render_pending_.gpu; return true; }
    if(id=="render:start"){ begin_render_with_preset(); return true; }

    if(id=="dialog:cancel"){ dialog_=DialogMode::None; return true; }
    if(id=="dialog:lang_prev"){ cycle_language(-1); return true; }
    if(id=="dialog:lang_next"){ cycle_language(1); return true; }
    if(id=="dialog:toggle_audio"){
        audio_preview_enabled_=!audio_preview_enabled_;
        if(!audio_preview_enabled_) engine_.stop_audio_preview();
        else if(playing_) resync_audio_preview(true);
        return true;
    }
    if(id=="dialog:snap"){ commit_project_toggle([&]{project_.snapping=!project_.snapping;}); return true; }
    if(id=="dialog:crossfade"){ commit_project_toggle([&]{project_.auto_crossfade=!project_.auto_crossfade;}); return true; }
    if(id=="dialog:quantize"){ commit_project_toggle([&]{project_.quantize_to_frames=!project_.quantize_to_frames;}); return true; }
    if(id=="dialog:ignore_grouping"){ commit_project_toggle([&]{project_.ignore_event_grouping=!project_.ignore_event_grouping;}); return true; }
    if(id=="dialog:slip_all"){ commit_project_toggle([&]{project_.slip_all_takes=!project_.slip_all_takes;}); return true; }
    if(id=="dialog:gpu"){
        engine_.set_gpu_enabled(!engine_.gpu_enabled());
        gpu_enabled_=engine_.gpu_enabled();
        set_status(tr("status.gpu_acceleration","GPU acceleration")+" "+(engine_.gpu_enabled()?tr("status.enabled_dash","enabled —"):tr("status.disabled_dash","disabled —"))+" "+engine_.gpu_backend().label);
        request_preview(true);
        return true;
    }
    if(id=="dialog:preview_quality"){
        if(dialog_==DialogMode::ProjectProperties){
            pending_project_settings_.preview_quality=(std::clamp(pending_project_settings_.preview_quality,0,3)+1)%4;
        }else{
            undo_.begin(project_);
            preview_quality_=preview_quality_==PreviewQuality::Draft?PreviewQuality::Preview:(preview_quality_==PreviewQuality::Preview?PreviewQuality::Good:(preview_quality_==PreviewQuality::Good?PreviewQuality::Best:PreviewQuality::Draft));
            commit_preview_project_settings();
            if(undo_.commit(project_)) mark_dirty(); else undo_.cancel();
            request_preview(true);
        }
        return true;
    }
    if(id=="dialog:preview_fps"){
        auto cycle_fps=[](int v){return v==15?24:(v==24?30:(v==30?60:15));};
        if(dialog_==DialogMode::ProjectProperties) pending_project_settings_.preview_fps_limit=cycle_fps(pending_project_settings_.preview_fps_limit);
        else{
            undo_.begin(project_);
            preview_fps_limit_=cycle_fps(preview_fps_limit_);
            commit_preview_project_settings();
            if(undo_.commit(project_)) mark_dirty(); else undo_.cancel();
            request_preview(true);
        }
        return true;
    }
    if(id=="dialog:prepared_cache"){
        if(dialog_==DialogMode::ProjectProperties) pending_project_settings_.use_prepared_cache=!pending_project_settings_.use_prepared_cache;
        else{
            undo_.begin(project_); use_prepared_cache_=!use_prepared_cache_; commit_preview_project_settings();
            if(undo_.commit(project_)) mark_dirty(); else undo_.cancel(); engine_.clear_cache(); request_preview(true);
        }
        return true;
    }
    if(id=="dialog:width_down"){ pending_project_settings_.width=std::max(320,pending_project_settings_.width-160); return true; }
    if(id=="dialog:width_up"){ pending_project_settings_.width=std::min(7680,pending_project_settings_.width+160); return true; }
    if(id=="dialog:height_down"){ pending_project_settings_.height=std::max(180,pending_project_settings_.height-90); return true; }
    if(id=="dialog:height_up"){ pending_project_settings_.height=std::min(4320,pending_project_settings_.height+90); return true; }
    if(id=="dialog:fps_cycle"){
        const double f=pending_project_settings_.fps;
        pending_project_settings_.fps=f<29.0?29.97:(f<45.0?59.94:(f<90.0?120.0:24.0));
        return true;
    }
    if(id=="dialog:sample_cycle"){
        pending_project_settings_.sample_rate=pending_project_settings_.sample_rate==44100?48000:(pending_project_settings_.sample_rate==48000?96000:44100);
        return true;
    }
    if(id=="dialog:preset_1080_30"){ pending_project_settings_.width=1920; pending_project_settings_.height=1080; pending_project_settings_.fps=29.97; return true; }
    if(id=="dialog:preset_1080_60"){ pending_project_settings_.width=1920; pending_project_settings_.height=1080; pending_project_settings_.fps=59.94; return true; }
    if(id=="dialog:preset_4k_30"){ pending_project_settings_.width=3840; pending_project_settings_.height=2160; pending_project_settings_.fps=29.97; return true; }
    if(id=="dialog:project_apply"){
        undo_.begin(project_);
        project_.settings=pending_project_settings_;
        sync_preview_settings_from_project();
        if(undo_.commit(project_)){ mark_dirty(); engine_.clear_cache(); request_preview(true); }
        dialog_=DialogMode::None;
        set_status(tr("status.project_properties_updated","Project properties updated"));
        return true;
    }
    return false;
}

bool EditorApp::dispatch_edit_button(const std::string& id){
    if(id=="cancel_render"){render_cancel_=true;set_status(tr("status.cancelling_render","Cancelling render..."));return true;}
    if(id=="recover"){recover_latest_autosave();return true;}
    if(id=="collect_project"){collect_project();return true;}
    if(id=="relink"){relink_missing_media();return true;}
    if(id=="new"){ new_project(); return true; }
    if(id=="open"){ open_project(); return true; }
    if(id=="save"){ save_project(false); return true; }
    if(id=="save_as"){ save_project(true); return true; }
    if(id=="exit"){ request_close(); return true; }
    if(id=="import"){ import_paths(services_.open_media_files()); return true; }
    if(id=="undo"){ if(undo_.undo(project_)){sync_preview_settings_from_project();mark_dirty();request_preview(true);} return true; }
    if(id=="redo"){ if(undo_.redo(project_)){sync_preview_settings_from_project();mark_dirty();request_preview(true);} return true; }
    if(id=="copy"){ if(edit_.copy_selected(project_,clipboard_)) set_status(tr("status.copied","Copied")+" "+std::to_string(clipboard_.clips.size())+" "+tr("status.events","event(s)")); return true; }
    if(id=="cut_clipboard"){ if(edit_.cut_selected(project_,undo_,clipboard_)){mark_dirty();request_preview(true);set_status(tr("status.cut_clipboard","Cut to KoraLo event clipboard"));} return true; }
    if(id=="paste"){ if(edit_.paste(project_,undo_,clipboard_,playhead_)){mark_dirty();request_preview(true);set_status(tr("status.pasted_cursor","Pasted at cursor"));} return true; }
    if(id=="split"){ if(edit_.split_selected(project_,undo_,playhead_)){mark_dirty();request_preview(true);} return true; }
    if(id=="delete"){ if(edit_.delete_selected(project_,undo_)){mark_dirty();request_preview(true);} return true; }
    if(id=="trim_start_cursor"){ if(edit_.trim_start_to_cursor(project_,undo_,playhead_)){mark_dirty();request_preview(true);set_status(tr("status.trim_start","Trimmed event start to cursor"));} return true; }
    if(id=="trim_end_cursor"){ if(edit_.trim_end_to_cursor(project_,undo_,playhead_)){mark_dirty();request_preview(true);set_status(tr("status.trim_end","Trimmed event end to cursor"));} return true; }
    if(id=="event_loop"){ if(edit_.toggle_loop_selected(project_,undo_)){mark_dirty();request_preview(true);set_status(tr("status.loop_toggled","Event loop toggled"));} return true; }
    if(id=="take_next"){ if(edit_.cycle_active_take(project_,undo_,1)){mark_dirty();request_preview(true);set_status(tr("status.next_take","Next take"));} return true; }
    if(id=="take_prev"){ if(edit_.cycle_active_take(project_,undo_,-1)){mark_dirty();request_preview(true);set_status(tr("status.prev_take","Previous take"));} return true; }
    if(id=="lock_selection"){ if(edit_.toggle_lock_selected(project_,undo_)){mark_dirty();set_status(tr("status.lock_toggled","Event lock toggled"));} return true; }
    if(id=="marker"){ add_marker(); return true; }
    if(id=="insert_text"){ insert_text_event(); return true; }
    if(id=="help"){ show_help(); return true; }
    if(id=="snap"){ commit_project_toggle([&]{project_.snapping=!project_.snapping;}); return true; }
    if(id=="quantize_frames"){ commit_project_toggle([&]{project_.quantize_to_frames=!project_.quantize_to_frames;}); return true; }
    if(id=="ignore_grouping"){ commit_project_toggle([&]{project_.ignore_event_grouping=!project_.ignore_event_grouping;edit_.selection.retain_existing(project_);}); return true; }
    if(id=="slip_all_takes"){ commit_project_toggle([&]{project_.slip_all_takes=!project_.slip_all_takes;}); return true; }
    if(id=="ripple"){
        commit_project_toggle([&]{project_.ripple=project_.ripple==RippleMode::Off?RippleMode::AffectedTrack:(project_.ripple==RippleMode::AffectedTrack?RippleMode::AllTracks:RippleMode::Off);});
        return true;
    }
    if(id=="add_video"){
        undo_.begin(project_); project_.add_track(TrackKind::Video); if(undo_.commit(project_)) mark_dirty(); return true;
    }
    if(id=="add_audio"){
        undo_.begin(project_); project_.add_track(TrackKind::Audio); if(undo_.commit(project_)) mark_dirty(); return true;
    }
    if(id=="render"){ render_as(); return true; }
    if(id=="proxy"){ create_proxy_for_selected(); return true; }
    if(id=="play"){ start_playback(); return true; }
    if(id=="pause"){ pause_playback(false); return true; }
    if(id=="stop"){ pause_playback(true); return true; }
    if(id=="step_back"){ step_preview(-1); return true; }
    if(id=="step_forward"){ step_preview(1); return true; }
    if(id=="record_audio"){ toggle_audio_recording(); return true; }
    if(id=="preview_settings"){ show_project_settings(); set_status(tr("status.preview_settings","Project preview settings")); return true; }
    if(id=="preview_quality"){
        undo_.begin(project_);
        preview_quality_=preview_quality_==PreviewQuality::Draft?PreviewQuality::Preview:(preview_quality_==PreviewQuality::Preview?PreviewQuality::Good:(preview_quality_==PreviewQuality::Good?PreviewQuality::Best:PreviewQuality::Draft));
        commit_preview_project_settings();
        if(undo_.commit(project_)) mark_dirty(); else undo_.cancel();
        request_preview(true); set_status(tr("status.preview_quality","Project preview quality:")+" "+preview_quality_name()); return true;
    }
    if(id=="preview_fit"){ preview_fit_=!preview_fit_; set_status(preview_fit_?tr("status.preview_fit","Preview: fit"):tr("status.preview_1_1","Preview: 1:1")); return true; }
    if(id=="preview_tab"){ preview_tab_=PreviewTab::VideoPreview; search_editing_=false; request_preview(true); return true; }
    if(id=="trimmer_tab"){
        preview_tab_=PreviewTab::Trimmer; search_editing_=false;
        if(edit_.selected_media!=source_media_id_){ source_media_id_=edit_.selected_media; source_time_=0; source_in_=0; source_out_=-1; }
        request_preview(true); return true;
    }
    if(id=="source_in"){ set_source_in(); return true; }
    if(id=="source_out"){ set_source_out(); return true; }
    if(id=="trimmer_insert"){ insert_from_trimmer(false); return true; }
    if(id=="trimmer_overwrite"){ insert_from_trimmer(true); return true; }
    if(id=="tool_mask"){tool_mode_=ToolMode::PaintMask;pause_playback(false);set_status(tr("status.mask_brush_hint","Mask brush: select a video clip and paint in the frame. Shift restores; Esc cancels the stroke"));return true;}
    if(id=="brush_down"){paint_radius_=std::max(.005,paint_radius_-.01);return true;}
    if(id=="brush_up"){paint_radius_=std::min(.3,paint_radius_+.01);return true;}
    if(id=="brush_hardness"){paint_hardness_=paint_hardness_>.8?.25:(paint_hardness_<.5?.75:1);return true;}
    if(id=="tool_select"){ tool_mode_=ToolMode::Select; set_status(tr("status.selection_tool","Selection tool")); return true; }
    if(id=="tool_split"){ tool_mode_=ToolMode::Split; set_status(tr("status.split_tool","Split tool: click an event to cut at pointer")); return true; }
    return false;
}

bool EditorApp::dispatch_fx_button(const std::string& id){
    if(id=="fx_search"){
        if(bin_tab_!=BinTab::VideoFx&&bin_tab_!=BinTab::AudioFx)bin_tab_=BinTab::VideoFx;
        fx_search_editing_=!fx_search_editing_; search_editing_=false;
        const bool audio=bin_tab_==BinTab::AudioFx;set_status(fx_search_editing_?(audio?tr("status.filter_audio_fx","Type to filter Audio FX"):tr("status.filter_video_fx","Type to filter Video FX")):(audio?tr("status.audio_fx_search_closed","Audio FX search closed"):tr("status.video_fx_search_closed","Video FX search closed"))); return true;
    }
    if(id.rfind("fx_select:",0)==0){
        selected_fx_definition_=id.substr(10); fx_search_editing_=false;
        const auto* definition=effect_definition(selected_fx_definition_);
        set_status(definition?tr("catalog."+definition->name,definition->name):"Video FX"); return true;
    }
    if(id=="fx_add_selected"){
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
        if(!clip) return true;
        const Track* track=project_.track_by_id(clip->track_id);
        const auto* definition=effect_definition(selected_fx_definition_);
        if(!track||track->kind!=TrackKind::Video||!definition) return true;
        if(selected_fx_definition_.rfind("ofx:",0)==0){set_status(tr("status.ofx_not_added","OFX/Boris FX detected — rendering host is still experimental, so the effect was not added"));return true;}
        undo_.begin(project_);
        clip->video_effects.push_back(make_effect_instance(selected_fx_definition_,project_.next_id()));
        if(undo_.commit(project_)){ mark_dirty(); engine_.clear_composite_cache(); request_preview(true); set_status(tr("status.added","Added")+" "+tr("catalog."+definition->name,definition->name)); }
        return true;
    }
    if(id.rfind("fx_add_event:",0)==0){
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
        if(!clip) return true;
        const Track* track=project_.track_by_id(clip->track_id);
        const std::string definition_id=id.substr(13);
        if(!track||track->kind!=TrackKind::Video||!effect_definition(definition_id)) return true;
        if(definition_id.rfind("ofx:",0)==0){set_status(tr("status.ofx_render_disabled","OFX/Boris FX rendering is not enabled in this beta host yet"));return true;}
        undo_.begin(project_);
        clip->video_effects.push_back(make_effect_instance(definition_id,project_.next_id()));
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.event_fx_added","Event FX added"));}
        return true;
    }
    if(id.rfind("fx_add_track:",0)==0){
        Track* track=project_.track_by_id(selected_track_id_);
        const std::string definition_id=id.substr(13);
        if(!track||track->kind!=TrackKind::Video||!effect_definition(definition_id)) return true;
        if(definition_id.rfind("ofx:",0)==0){set_status(tr("status.ofx_render_disabled","OFX/Boris FX rendering is not enabled in this beta host yet"));return true;}
        undo_.begin(project_);
        track->video_effects.push_back(make_effect_instance(definition_id,project_.next_id()));
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.track_fx_added","Track FX added"));}
        return true;
    }
    if(id.rfind("fx_editor_open_inst:",0)==0){
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
        if(!clip) return true;
        open_effect_editor(clip->id,std::atoi(id.c_str()+20));
        return true;
    }
    if(id.rfind("fx_toggle_event:",0)==0||id.rfind("fx_remove_event:",0)==0){
        const bool remove=id.rfind("fx_remove_event:",0)==0;
        const int instance_id=std::atoi(id.c_str()+16);
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
        if(!clip) return true;
        auto effect_it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& effect){return effect.id==instance_id;});
        if(effect_it==clip->video_effects.end()) return true;
        undo_.begin(project_);
        if(remove) clip->video_effects.erase(effect_it); else effect_it->enabled=!effect_it->enabled;
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);}
        return true;
    }
    if(id.rfind("audio_fx_select:",0)==0){selected_audio_fx_definition_=id.substr(16);fx_search_editing_=false;const auto* def=audio_effect_definition(selected_audio_fx_definition_);set_status(def?tr("catalog."+def->name,def->name):"Audio FX");return true;}
    if(id=="audio_fx_add_event"){
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());Track* track=clip?project_.track_by_id(clip->track_id):nullptr;const auto* def=audio_effect_definition(selected_audio_fx_definition_);if(!clip||!track||track->kind!=TrackKind::Audio||!def)return true;
        undo_.begin(project_);clip->audio_effects.push_back(make_audio_effect_instance(selected_audio_fx_definition_,project_.next_id()));if(undo_.commit(project_)){mark_dirty();if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}set_status(tr("status.added","Added")+" "+tr("catalog."+def->name,def->name)+" "+tr("status.to_audio_event","to audio event"));}return true;
    }
    if(id=="audio_fx_add_track"){
        Track* track=project_.track_by_id(selected_track_id_);if(!track||track->kind!=TrackKind::Audio){if(Clip* clip=project_.clip_by_id(edit_.selection.primary_clip()))track=project_.track_by_id(clip->track_id);}const auto* def=audio_effect_definition(selected_audio_fx_definition_);if(!track||track->kind!=TrackKind::Audio||!def)return true;
        selected_track_id_=track->id;undo_.begin(project_);track->audio_effects.push_back(make_audio_effect_instance(selected_audio_fx_definition_,project_.next_id()));if(undo_.commit(project_)){mark_dirty();if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}set_status(tr("status.added","Added")+" "+tr("catalog."+def->name,def->name)+" "+tr("status.to_audio_track","to audio track"));}return true;
    }
    if(id.rfind("audio_fx_toggle:",0)==0||id.rfind("audio_fx_remove:",0)==0){
        const bool remove=id.rfind("audio_fx_remove:",0)==0;const std::string rest=id.substr(remove?16:16);std::vector<std::string> parts;std::stringstream ss(rest);std::string part;while(std::getline(ss,part,':'))parts.push_back(part);if(parts.size()<3)return true;
        const int owner_id=std::atoi(parts[1].c_str()),effect_id=std::atoi(parts[2].c_str());std::vector<EffectInstance>* chain=nullptr;if(parts[0]=="event"){if(auto* c=project_.clip_by_id(owner_id))chain=&c->audio_effects;}else if(parts[0]=="track"){if(auto* t=project_.track_by_id(owner_id))chain=&t->audio_effects;}if(!chain)return true;
        auto it=std::find_if(chain->begin(),chain->end(),[&](const EffectInstance& e){return e.id==effect_id;});if(it==chain->end())return true;undo_.begin(project_);if(remove)chain->erase(it);else it->enabled=!it->enabled;if(undo_.commit(project_)){mark_dirty();if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}}return true;
    }
    if(id.rfind("audio_fx_param_down:",0)==0||id.rfind("audio_fx_param_up:",0)==0){
        const bool up=id.rfind("audio_fx_param_up:",0)==0;const std::string rest=id.substr(up?18:20);std::vector<std::string> parts;std::stringstream ss(rest);std::string part;while(std::getline(ss,part,':'))parts.push_back(part);if(parts.size()<4)return true;
        const int owner_id=std::atoi(parts[1].c_str()),effect_id=std::atoi(parts[2].c_str());const std::string param_id=parts[3];std::vector<EffectInstance>* chain=nullptr;if(parts[0]=="event"){if(auto* c=project_.clip_by_id(owner_id))chain=&c->audio_effects;}else if(parts[0]=="track"){if(auto* t=project_.track_by_id(owner_id))chain=&t->audio_effects;}if(!chain)return true;
        auto it=std::find_if(chain->begin(),chain->end(),[&](const EffectInstance& e){return e.id==effect_id;});if(it==chain->end())return true;const auto* def=audio_effect_definition(it->definition_id);if(!def)return true;const auto pd=std::find_if(def->parameters.begin(),def->parameters.end(),[&](const ParameterDefinition& p){return p.id==param_id;});if(pd==def->parameters.end())return true;const double fallback=std::holds_alternative<double>(pd->default_value)?std::get<double>(pd->default_value):0.0;const double current=effect_numeric(*it,param_id,0.0,fallback);
        undo_.begin(project_);set_effect_numeric(*it,param_id,current+(up?pd->step:-pd->step));if(undo_.commit(project_)){mark_dirty();if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}}return true;
    }
    if(id.rfind("fx_param_down:",0)==0||id.rfind("fx_param_up:",0)==0){
        const bool up=id.rfind("fx_param_up:",0)==0;
        const std::string rest=id.substr(up?12:14);
        const auto colon=rest.find(':');
        if(colon==std::string::npos) return true;
        const int instance_id=std::atoi(rest.substr(0,colon).c_str());
        const std::string parameter_id=rest.substr(colon+1);
        Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
        if(!clip) return true;
        auto effect_it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& effect){return effect.id==instance_id;});
        if(effect_it==clip->video_effects.end()) return true;
        const auto* definition=effect_definition(effect_it->definition_id);
        if(!definition) return true;
        const auto parameter_it=std::find_if(definition->parameters.begin(),definition->parameters.end(),[&](const ParameterDefinition& parameter){return parameter.id==parameter_id;});
        if(parameter_it==definition->parameters.end()) return true;
        const double current=effect_numeric(*effect_it,parameter_id,0.0,std::get<double>(parameter_it->default_value));
        undo_.begin(project_);
        set_effect_numeric(*effect_it,parameter_id,current+(up?parameter_it->step:-parameter_it->step));
        if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);}
        return true;
    }
    return false;
}

bool EditorApp::dispatch_workspace_button(const std::string& id){
    if(dispatch_inspector_button(id))return true;
    if(id=="bin_list"){media_view_=MediaView::List;set_bin_tab(BinTab::ProjectMedia);return true;}
    if(id=="bin_grid"){media_view_=MediaView::Grid;set_bin_tab(BinTab::ProjectMedia);return true;}
    if(id=="bin_search"){set_bin_tab(BinTab::ProjectMedia);search_editing_=!search_editing_;set_status(search_editing_?tr("status.media_search_hint","Type a media name; Enter accepts, Escape clears focus"):tr("status.media_search_closed","Media search closed"));return true;}
    if(id=="tree_media_bins"){media_bins_expanded_=!media_bins_expanded_;set_bin_tab(BinTab::ProjectMedia);set_status(media_bins_expanded_?tr("status.media_bins_expanded","Media Bins expanded"):tr("status.media_bins_collapsed","Media Bins collapsed"));return true;}
    if(id=="tree_by_type"){by_type_expanded_=!by_type_expanded_;set_bin_tab(BinTab::ProjectMedia);return true;}
    if(id=="tree_tags"){tags_expanded_=!tags_expanded_;set_bin_tab(BinTab::ProjectMedia);set_status(tags_expanded_?tr("status.tags_expanded","Tags expanded"):tr("status.tags_collapsed","Tags collapsed"));return true;}
    if(id=="tree_imported"||id=="tree_untagged"){set_media_filter(MediaFilter::All);return true;}
    if(id=="filter_all"){set_media_filter(MediaFilter::All);return true;}
    if(id=="filter_audio"){set_media_filter(MediaFilter::Audio);return true;}
    if(id=="filter_video"){set_media_filter(MediaFilter::Video);return true;}
    if(id=="filter_stills"){set_media_filter(MediaFilter::Stills);return true;}
    if(id=="tab_media"){set_bin_tab(BinTab::ProjectMedia);return true;}
    if(id=="tab_generators"){set_bin_tab(BinTab::Generators);return true;}
    if(id=="tab_vfx"){set_bin_tab(BinTab::VideoFx);return true;}
    if(id=="tab_afx"){set_bin_tab(BinTab::AudioFx);return true;}
    if(id=="tab_transitions"){set_bin_tab(BinTab::Transitions);return true;}
    if(id=="crossfade_toggle"){commit_project_toggle([&]{project_.auto_crossfade=!project_.auto_crossfade;});return true;}
    if(id=="fx_opacity_down"||id=="fx_opacity_reset"||id=="fx_opacity_up"){
        const auto clip_ids=edit_.selection.clips();
        if(clip_ids.empty()) return true;
        undo_.begin(project_);
        for(int clip_id:clip_ids){
            Clip* clip=project_.clip_by_id(clip_id);
            if(!clip) continue;
            if(id=="fx_opacity_down") clip->opacity=std::max(0.0,clip->opacity-0.1);
            else if(id=="fx_opacity_up") clip->opacity=std::min(1.0,clip->opacity+0.1);
            else clip->opacity=1.0;
        }
        if(undo_.commit(project_)){mark_dirty();request_preview(true);}
        return true;
    }
    if(id=="track_opacity_down"||id=="track_opacity_reset"||id=="track_opacity_up"){
        Track* track=project_.track_by_id(selected_track_id_);
        if(!track||track->kind!=TrackKind::Video) return true;
        undo_.begin(project_);
        if(id=="track_opacity_down") track->opacity=std::max(0.0,track->opacity-0.1);
        else if(id=="track_opacity_up") track->opacity=std::min(1.0,track->opacity+0.1);
        else track->opacity=1.0;
        if(undo_.commit(project_)){mark_dirty();request_preview(true);}
        return true;
    }
    if(id.rfind("text_edit:",0)==0){open_text_editor(std::atoi(id.c_str()+10));return true;}
    if(id.rfind("event_audio_fx:",0)==0){const int clip_id=std::atoi(id.c_str()+15);Clip* clip=project_.clip_by_id(clip_id);if(!clip)return true;const Track* track=project_.track_by_id(clip->track_id);if(!track||track->kind!=TrackKind::Audio)return true;edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,false);selected_track_id_=track->id;bin_tab_=BinTab::AudioFx;set_status(tr("context.event.audio_fx","Audio Event FX"));return true;}
    if(id.rfind("event_fx:",0)==0){
        const int clip_id=std::atoi(id.c_str()+9);
        Clip* clip=project_.clip_by_id(clip_id);
        if(!clip) return true;
        selected_track_id_=clip->track_id; open_effect_editor(clip_id);
        return true;
    }
    if(id.rfind("track_fx:",0)==0){selected_track_id_=std::atoi(id.c_str()+9);bin_tab_=BinTab::VideoFx;set_status(tr("status.video_track_fx","Video track compositing controls"));return true;}
    if(id.rfind("track_audio_fx:",0)==0){selected_track_id_=std::atoi(id.c_str()+15);bin_tab_=BinTab::AudioFx;set_status(tr("status.audio_track_fx","Audio track effects"));return true;}
    return false;
}


} // namespace koralo
