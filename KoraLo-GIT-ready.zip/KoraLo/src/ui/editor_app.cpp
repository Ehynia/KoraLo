#include "editor_app.hpp"
#include "../media/paint_mask.hpp"
#include "../media/vector_renderer.hpp"
#include "../platform/app_paths.hpp"
#include "icon_atlas.hpp"
#include "../platform/process.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <thread>

namespace koralo {
namespace fs = std::filesystem;

namespace {
std::string short_name(const std::string& s,std::size_t n=48){
    std::size_t count=0,cut=0;
    for(std::size_t i=0;i<s.size();++i){
        if((static_cast<unsigned char>(s[i])&0xc0)==0x80)continue;
        if(count== (n>3?n-3:0))cut=i;
        ++count;
    }
    return count<=n?s:s.substr(0,cut)+"...";
}
Rect motion_frame_rect(const Rect& base,const VideoMotionSample& sample){
    const double z=std::clamp(sample.zoom,1.0,8.0);
    const int w=std::max(8,static_cast<int>(std::lround(base.w/z)));
    const int h=std::max(8,static_cast<int>(std::lround(base.h/z)));
    const int travel_x=std::max(0,base.w-w),travel_y=std::max(0,base.h-h);
    return {base.x+static_cast<int>(std::lround(std::clamp(sample.center_x,0.0,1.0)*travel_x)),
            base.y+static_cast<int>(std::lround(std::clamp(sample.center_y,0.0,1.0)*travel_y)),w,h};
}
std::string motion_number(double value,int precision=3){std::ostringstream s;s<<std::fixed<<std::setprecision(precision)<<value;return s.str();}

std::string mapped_vegas_video_fx(const std::string& source_id){
    if(source_id.find("chromakeyer")!=std::string::npos)return "vegas.opaque.chromakeyer";
    if(source_id.find("bzmasking")!=std::string::npos)return "vegas.opaque.bzmasking";
    if(source_id.find("colorcorrectorsecondary")!=std::string::npos)return "vegas.opaque.colorcorrectorsecondary";
    if(source_id.find("colorcorrector")!=std::string::npos)return "vegas.opaque.colorcorrector";
    if(source_id.find("colorbalance")!=std::string::npos)return "vegas.opaque.colorbalance";
    if(source_id.find("cookiecutter")!=std::string::npos)return "vegas.opaque.cookiecutter";
    return {};
}

std::string lower_ascii(std::string value){for(char& ch:value)if(static_cast<unsigned char>(ch)<128)ch=static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));return value;}
std::vector<double> motion_key_times(const VideoMotion& motion){
    std::vector<double> times;
    auto add=[&](const AnimatedDouble& v){for(const auto& key:v.keys)times.push_back(key.time);};
    add(motion.center_x);add(motion.center_y);add(motion.zoom);add(motion.rotation);
    std::sort(times.begin(),times.end());
    times.erase(std::unique(times.begin(),times.end(),[](double a,double b){return std::abs(a-b)<1e-6;}),times.end());
    return times;
}


double preferred_ui_scale(int width,int height){
    const double density=std::min(width/1920.0,height/1080.0);
    if(density>=2.25)return 1.75;
    if(density>=1.65)return 1.50;
    if(density>=1.25)return 1.25;
    return 1.0;
}

class ScaledCanvas final : public Canvas {
public:
    ScaledCanvas(Canvas& base,double scale):base_(base),scale_(std::max(1.0,scale)){}
    int width() const override{return std::max(1,static_cast<int>(std::floor(base_.width()/scale_)));}
    int height() const override{return std::max(1,static_cast<int>(std::floor(base_.height()/scale_)));}
    void fill_rect(Rect r,Color c) override{base_.fill_rect(sr(r),c);}
    void stroke_rect(Rect r,Color c,int t=1) override{base_.stroke_rect(sr(r),c,st(t));}
    void line(int x1,int y1,int x2,int y2,Color c,int t=1) override{base_.line(edge(x1),edge(y1),edge(x2),edge(y2),c,st(t));}
    void text(int x,int y,const std::string& value,Color c,int size=12,bool bold=false) override{base_.text(edge(x),edge(y),value,c,std::max(1,scaled_size(size)),bold);}
    int text_width(const std::string& value,int size=12,bool bold=false) override{return std::max(0,static_cast<int>(std::lround(base_.text_width(value,std::max(1,scaled_size(size)),bold)/scale_)));}
    void image(Rect dst,const Frame& frame) override{base_.image(sr(dst),frame);}
    void push_clip(Rect r) override{base_.push_clip(sr(r));}
    void pop_clip() override{base_.pop_clip();}
private:
    // Map rectangle EDGES, not origin + independently rounded size. At 125/150%
    // DPI this guarantees adjacent one-pixel rows/columns share an exact physical
    // edge, eliminating the cracks that used to appear in icons/rounded UI.
    int edge(int v) const{return static_cast<int>(std::lround(static_cast<double>(v)*scale_));}
    int scaled_size(int v) const{return static_cast<int>(std::lround(static_cast<double>(v)*scale_));}
    int st(int v) const{return std::max(1,scaled_size(v));}
    Rect sr(Rect r) const{
        const int x1=edge(r.x),y1=edge(r.y),x2=edge(r.x+r.w),y2=edge(r.y+r.h);
        return {x1,y1,std::max(1,x2-x1),std::max(1,y2-y1)};
    }
    Canvas& base_;double scale_;
};

Color mix_color(Color a,Color b,double t){
    t=std::clamp(t,0.0,1.0);auto m=[&](int x,int y){return static_cast<int>(std::lround(x+(y-x)*t));};
    return Color{m(a.r,b.r),m(a.g,b.g),m(a.b,b.b),m(a.a,b.a)};
}

void fill_round_rect(Canvas& c,Rect r,Color color,int radius=7){
    if(r.w<=0||r.h<=0||color.a==0)return;
    radius=std::clamp(radius,0,std::min(r.w,r.h)/2);
    if(radius<=1){c.fill_rect(r,color);return;}
    if(r.h>2*radius)c.fill_rect({r.x,r.y+radius,r.w,r.h-2*radius},color);
    const double rr=static_cast<double>(radius)*radius;
    for(int i=0;i<radius;++i){
        const double dy=radius-(i+0.5);
        const double edge=radius-std::sqrt(std::max(0.0,rr-dy*dy));
        const int inset=std::clamp(static_cast<int>(std::ceil(edge)),0,radius);
        const int width=std::max(0,r.w-2*inset);
        if(width>0){c.fill_rect({r.x+inset,r.y+i,width,1},color);c.fill_rect({r.x+inset,r.y+r.h-1-i,width,1},color);}
        const int edge_px=inset-1;
        if(edge_px>=0){
            const double coverage=std::clamp(inset-edge,0.0,1.0);
            Color aa=color;aa.a=static_cast<std::uint8_t>(std::lround(color.a*coverage));
            if(aa.a){
                c.fill_rect({r.x+edge_px,r.y+i,1,1},aa);c.fill_rect({r.x+r.w-1-edge_px,r.y+i,1,1},aa);
                c.fill_rect({r.x+edge_px,r.y+r.h-1-i,1,1},aa);c.fill_rect({r.x+r.w-1-edge_px,r.y+r.h-1-i,1,1},aa);
            }
        }
    }
}

void draw_round_border(Canvas& c,Rect r,Color color,int radius=7){
    if(r.w<=1||r.h<=1)return;
    radius=std::clamp(radius,1,std::min(r.w,r.h)/2);
    c.line(r.x+radius,r.y,r.x+r.w-radius-1,r.y,color);
    c.line(r.x+radius,r.y+r.h-1,r.x+r.w-radius-1,r.y+r.h-1,color);
    c.line(r.x,r.y+radius,r.x,r.y+r.h-radius-1,color);
    c.line(r.x+r.w-1,r.y+radius,r.x+r.w-1,r.y+r.h-radius-1,color);
    for(int i=0;i<radius;++i){
        const double dy=radius-i-0.5;
        const int inset=std::max(0,radius-static_cast<int>(std::floor(std::sqrt(std::max(0.0,static_cast<double>(radius*radius)-dy*dy)))));
        if(i==0||inset!=std::max(0,radius-static_cast<int>(std::floor(std::sqrt(std::max(0.0,static_cast<double>(radius*radius)-std::pow(radius-(i>0?i-1:0)-0.5,2))))))){
            c.fill_rect({r.x+inset,r.y+i,1,1},color);c.fill_rect({r.x+r.w-1-inset,r.y+i,1,1},color);
            c.fill_rect({r.x+inset,r.y+r.h-1-i,1,1},color);c.fill_rect({r.x+r.w-1-inset,r.y+r.h-1-i,1,1},color);
        }
    }
}

void draw_card(Canvas& c,Rect r,Color fill=theme::panel2,int =8){
    c.fill_rect(r,fill);c.stroke_rect(r,theme::borderSoft);
}
}

EditorApp::EditorApp(PlatformServices& services)
    : services_(services), localization_({services.executable_dir(), "."}), project_(Project::make_default()), undo_(160) {
    render_presets_={
        {"YouTube / H.264 1080p30",1920,1080,29.97,12000,192,true},
        {"H.264 1080p60",1920,1080,59.94,18000,192,true},
        {"H.264 1440p60",2560,1440,59.94,32000,256,true},
        {"H.264 UHD 2160p30",3840,2160,29.97,45000,256,true},
        {"H.264 UHD 2160p60",3840,2160,59.94,68000,320,true},
        {"Editing / High Bitrate",project_.settings.width,project_.settings.height,project_.settings.fps,80000,320,false}
    };
    render_pending_=render_presets_.front();
    refresh_ofx_plugins(false);
    sync_preview_settings_from_project();
    status_=tr("status.ready","Ready");
    update_title();
    run_system_check(false);
}

EditorApp::~EditorApp() { render_cancel_=true;if(render_future_.valid())render_future_.wait(); if(recording_audio_)stop_audio_recording(false); engine_.stop_audio_preview(); }

std::string EditorApp::tr(std::string_view key,std::string_view fallback) const { return localization_.text(key,fallback); }

std::string EditorApp::current_language_name() const {
    for(const auto& lang:localization_.languages())if(lang.code==localization_.language_code())return lang.name;
    return localization_.language_code();
}

void EditorApp::cycle_language(int direction){
    const auto& langs=localization_.languages();if(langs.empty())return;
    std::size_t index=0;for(std::size_t i=0;i<langs.size();++i)if(langs[i].code==localization_.language_code()){index=i;break;}
    const int count=static_cast<int>(langs.size());int next=(static_cast<int>(index)+direction)%count;if(next<0)next+=count;
    if(localization_.set_language(langs[static_cast<std::size_t>(next)].code)){set_status(tr("status.language_changed","Language:")+" "+current_language_name());update_title();}
}

void EditorApp::sync_preview_settings_from_project(){
    preview_quality_=static_cast<PreviewQuality>(std::clamp(project_.settings.preview_quality,0,3));
    preview_fps_limit_=project_.settings.preview_fps_limit>0?project_.settings.preview_fps_limit:30;
    use_prepared_cache_=project_.settings.use_prepared_cache;
}

void EditorApp::commit_preview_project_settings(){
    project_.settings.preview_quality=std::clamp(static_cast<int>(preview_quality_),0,3);
    project_.settings.preview_fps_limit=std::max(1,preview_fps_limit_);
    project_.settings.use_prepared_cache=use_prepared_cache_;
}

void EditorApp::rebuild_layout(int w, int h) {
  constexpr int menu_h = 28, document_h = 29, toolbar_h = 34, status_h = 24,
                rail_w = 42, gap = 5;
  const int top_y = menu_h + document_h + toolbar_h + gap;
  const int available = std::max(1, h - top_y - status_h - gap * 2);
  const int upper_h =
      std::clamp(static_cast<int>(available * (animation_workspace_?.64:.55)), std::min(220, available),
                 std::max(std::min(220, available), available - 180));
  layout_.menubar = {0, 0, w, menu_h};
  layout_.document = {rail_w, menu_h, std::max(1, w - rail_w), document_h};
  layout_.toolbar = {rail_w, menu_h + document_h, std::max(1, w - rail_w),
                     toolbar_h};
  layout_.tools = {0, menu_h, rail_w, std::max(1, h - menu_h - status_h)};
  layout_.status = {0, h - status_h, w, status_h};
  const int content_w = std::max(1, w - rail_w - gap * 2);
  // At narrow logical widths collapse the dock, keeping the existing modal
  // properties/effects commands available without covering the timeline.
  const int dock_w = w >= 1120 ? std::clamp(w / 5, 238, 290) : 0;
  const bool effect_bin =
      bin_tab_ == BinTab::VideoFx || bin_tab_ == BinTab::AudioFx;
  const int left_w = animation_workspace_ ? 226 : effect_bin ? std::clamp(content_w * 2 / 5, 360, 460)
                                : std::clamp(content_w / 4, 240, 380);
  layout_.bin = {rail_w + gap, top_y, left_w, upper_h};
  const int preview_x = layout_.bin.x + left_w + gap;
  layout_.preview = {
      preview_x, top_y,
      std::max(1, w - preview_x - gap - dock_w - (dock_w ? gap : 0)), upper_h};
  layout_.inspector = {w - gap - dock_w, top_y, dock_w, upper_h};
  layout_.timeline = {rail_w, top_y + upper_h + gap, std::max(1, w - rail_w),
                      std::max(1, h - top_y - upper_h - status_h - gap * 2)};
  // Timeline code uses viewport width in its right-edge checks. Keep its
  // existing origin at zero and reserve the rail for the upper workspace.
  layout_.tools.h = upper_h + toolbar_h + document_h + gap;
  layout_.timeline = {0, layout_.timeline.y, w, layout_.timeline.h};
  layout_.timeline_geo.x = 0;
  layout_.timeline_geo.y = layout_.timeline.y + 38;
  layout_.timeline_geo.width = w;
  layout_.timeline_geo.height = std::max(1, layout_.timeline.h - 54);
  layout_.timeline_geo.header_w = 260;
  layout_.timeline_geo.ruler_h = 24;
  if (fit_timeline_requested_ && project_.duration() > 0.0) {
    const int content = std::max(1, w - layout_.timeline_geo.header_w - 18);
    layout_.timeline_geo.px_per_sec =
        std::clamp(content / std::max(0.001, project_.duration()), 8.0, 900.0);
    layout_.timeline_geo.scroll_sec = 0;
    layout_.timeline_geo.scroll_y = 0;
    fit_timeline_requested_ = false;
  }
  clamp_timeline_scroll();
}

void EditorApp::set_ui_scale(double scale){
    const double clamped=std::clamp(scale,1.0,2.5);
    ui_scale_explicit_=true;
    if(std::abs(ui_scale_-clamped)<=1e-6)return;
    ui_scale_=clamped;
    services_.request_redraw();
}

void EditorApp::draw(Canvas& physical){
    const auto now=std::chrono::steady_clock::now();
    if(last_ui_draw_wall_.time_since_epoch().count()!=0)ui_anim_dt_=std::clamp(std::chrono::duration<double>(now-last_ui_draw_wall_).count(),1.0/240.0,0.05);
    else ui_anim_dt_=1.0/60.0;
    last_ui_draw_wall_=now;ui_animation_active_=false;
    // Win32 supplies the actual per-monitor DPI scale via set_ui_scale().
    // Only platforms without an explicit DPI source fall back to a resolution-
    // based scale. Do not overwrite an explicit 125/150% Windows DPI value on
    // every paint; doing so reintroduced the 2K scaling cracks fixed in r34.
    if(!ui_scale_explicit_)ui_scale_=preferred_ui_scale(physical.width(),physical.height());
    ScaledCanvas c(physical,ui_scale_);
    rebuild_layout(c.width(),c.height());
    c.fill_rect({0,0,c.width(),c.height()},theme::bg);
    buttons_.clear();bin_rows_.clear();
    draw_menubar(c);draw_document(c);draw_toolbar(c);
    if(animation_workspace_)draw_animation_workspace(c);else{draw_tools(c);draw_bin(c);draw_preview(c);draw_inspector(c);draw_timeline(c);}
    draw_status(c);draw_menu_overlay(c);draw_modal(c);draw_context_menu(c);
}

void EditorApp::draw_menubar(Canvas& c){
    c.fill_rect(layout_.menubar,theme::panel);
    c.line(0,layout_.menubar.h-1,layout_.menubar.w,layout_.menubar.h-1,theme::borderSoft);
    struct Entry{std::string label;MainMenu menu;};
    const std::vector<Entry> entries={
        {tr("menu.file","File"),MainMenu::File},{tr("menu.edit","Edit"),MainMenu::Edit},{tr("menu.view","View"),MainMenu::View},
        {tr("menu.insert","Insert"),MainMenu::Insert},{tr("menu.tools","Tools"),MainMenu::Tools},{tr("menu.options","Options"),MainMenu::Options},{tr("menu.help","Help"),MainMenu::Help}};
    c.text(12,19,"KoraLo",theme::text,12,true);
    int x=92;
    for(const auto& e:entries){
        const int w=c.text_width(e.label,10)+20;Rect r{x,4,w,22};const bool active=active_menu_==e.menu;
        if(active)fill_round_rect(c,r,theme::raised,7);
        else if(r.contains(mouse_x_,mouse_y_))fill_round_rect(c,r,theme::panel3,7);
        std::string id="menu:"+std::to_string(static_cast<int>(e.menu));buttons_.push_back({r,id,e.label,active,true});
        c.text(x+10,19,e.label,active?Color{255,255,255}:theme::text,10,active);x+=w+2;
    }
}

void EditorApp::draw_menu_overlay(Canvas& c){
    if(active_menu_==MainMenu::None)return;
    struct Item{std::string label;std::string id;bool enabled;};
    std::vector<Item> items;
    switch(active_menu_){
        case MainMenu::File:items={{tr("menu.file.new","New Project"),"new",true},{tr("menu.file.open","Open..."),"open",true},{tr("menu.file.save","Save"),"save",true},{tr("menu.file.save_as","Save As..."),"save_as",true},{tr("menu.file.import","Import Media..."),"import",true},{tr("menu.file.recover","Recover Latest Autosave"),"recover",true},{tr("menu.file.collect","Collect Project with Media..."),"collect_project",!project_.media.empty()},{tr("menu.file.render","Render As..."),"render",!project_.clips.empty()},{tr("menu.file.properties","Project Properties..."),"settings",true},{tr("menu.file.exit","Exit"),"exit",true}};break;
        case MainMenu::Edit:items={{tr("menu.edit.undo","Undo"),"undo",undo_.can_undo()},{tr("menu.edit.redo","Redo"),"redo",undo_.can_redo()},{tr("menu.edit.cut","Cut"),"cut_clipboard",!edit_.selection.empty()},{tr("menu.edit.copy","Copy"),"copy",!edit_.selection.empty()},{tr("menu.edit.paste","Paste"),"paste",!clipboard_.empty()},{tr("menu.edit.delete","Delete"),"delete",!edit_.selection.empty()},{tr("menu.edit.trim_start","Trim Start to Cursor"),"trim_start_cursor",!edit_.selection.empty()},{tr("menu.edit.trim_end","Trim End to Cursor"),"trim_end_cursor",!edit_.selection.empty()},{tr("menu.edit.split","Split at Cursor"),"split",!project_.clips.empty()},{tr("menu.edit.loop","Loop Selected Events"),"event_loop",!edit_.selection.empty()},{tr("menu.edit.next_take","Next Take"),"take_next",!edit_.selection.empty()},{tr("menu.edit.prev_take","Previous Take"),"take_prev",!edit_.selection.empty()}};break;
        case MainMenu::View:items={{tr("menu.view.project_media","Project Media"),"tab_media",true},{tr("menu.view.video_fx","Video FX"),"tab_vfx",true},{tr("menu.view.audio_fx","Audio FX"),"tab_afx",true},{tr("menu.view.transitions","Transitions"),"tab_transitions",true},{tr("menu.view.preview","Video Preview"),"preview_tab",true},{tr("menu.view.trimmer","Trimmer"),"trimmer_tab",true}};break;
        case MainMenu::Insert:items={{tr("menu.insert.text","Text..."),"insert_text",true},{tr("menu.insert.generated_media","Generated Media..."),"insert_text",true},{tr("menu.insert.video_track","Video Track"),"add_video",true},{tr("menu.insert.audio_track","Audio Track"),"add_audio",true},{tr("menu.insert.record_audio","Record Audio..."),"record_audio",true},{tr("menu.insert.marker","Marker"),"marker",true}};break;
        case MainMenu::Tools:items={{tr("menu.tools.relink","Relink Missing Media..."),"relink",true},{tr("menu.tools.proxy","Create Proxy"),"proxy",edit_.selected_media!=0},{tr("menu.file.render","Render As..."),"render",!project_.clips.empty()},{tr("menu.tools.rescan_ofx","Rescan OpenFX / Boris FX"),"ofx_rescan",true},{tr("menu.tools.system","System Check / Diagnostics"),"media_diagnostics",true}};break;
        case MainMenu::Options:items={{tr("menu.options.interface_renderer","Interface renderer: GPU / CPU"),"interface_gpu",true},{project_.quantize_to_frames?tr("menu.options.disable_quantize","Disable Quantize to Frames"):tr("menu.options.enable_quantize","Enable Quantize to Frames"),"quantize_frames",true},{project_.snapping?tr("menu.options.disable_snapping","Disable Snapping"):tr("menu.options.enable_snapping","Enable Snapping"),"snap",true},{project_.auto_crossfade?tr("menu.options.disable_crossfades","Disable Automatic Crossfades"):tr("menu.options.enable_crossfades","Enable Automatic Crossfades"),"crossfade_toggle",true},{project_.ignore_event_grouping?tr("menu.options.enable_grouping","Enable Event Grouping"):tr("menu.options.ignore_grouping","Ignore Event Grouping"),"ignore_grouping",true},{project_.slip_all_takes?tr("menu.options.slip_active_take","Slip Active Take Only"):tr("menu.options.slip_all_takes","Slip All Takes"),"slip_all_takes",true},{tr("menu.options.cycle_ripple","Cycle Ripple Mode"),"ripple",true},{tr("menu.options.preferences","Preferences..."),"preferences",true}};break;
        case MainMenu::Help:items={{tr("menu.help.shortcuts","Keyboard Shortcuts"),"help",true},{tr("menu.help.about","About KoraLo"),"about",true}};break;
        default:break;
    }
    int origin_x=92;
    const std::vector<std::string> labels={tr("menu.file","File"),tr("menu.edit","Edit"),tr("menu.view","View"),tr("menu.insert","Insert"),tr("menu.tools","Tools"),tr("menu.options","Options"),tr("menu.help","Help")};
    if(active_menu_!=MainMenu::File)for(int i=0;i<static_cast<int>(active_menu_)-1;++i)origin_x+=c.text_width(labels[static_cast<std::size_t>(i)],10)+22;
    const int row_h=28,w=276;const int h=static_cast<int>(items.size())*row_h+10;Rect panel{origin_x,layout_.menubar.h+2,w,h};
    draw_card(c,panel,theme::panel2,10);
    int y=panel.y+5;
    for(const auto& item:items){Rect r{panel.x+5,y,w-10,row_h};buttons_.push_back({r,item.id,item.label,false,item.enabled});if(r.contains(mouse_x_,mouse_y_)&&item.enabled)fill_round_rect(c,r,theme::raised,7);c.text(r.x+10,r.y+18,item.label,item.enabled?theme::text:theme::dim2,9);y+=row_h;}
}

void EditorApp::draw_context_menu(Canvas& c){
    if(!context_menu_.open()||(dialog_!=DialogMode::None&&context_menu_.kind!=ContextMenuKind::PanCropKey))return;
    int width=318;
    for(const auto& item:context_menu_.items){
        if(item.separator)continue;
        width=std::max(width,c.text_width(tr(item.key,item.fallback),9)+c.text_width(item.shortcut,8)+54);
    }
    width=std::min(width,std::max(180,c.width()-8));
    int height=6;for(const auto& item:context_menu_.items)height+=item.separator?9:24;
    int x=std::clamp(context_menu_.x,2,std::max(2,c.width()-width-2));
    int y=std::clamp(context_menu_.y,layout_.menubar.h,std::max(layout_.menubar.h,c.height()-height-2));
    context_menu_.panel={x,y,width,height};
    draw_card(c,context_menu_.panel,theme::panel2,10);
    int yy=y+3;
    for(const auto& item:context_menu_.items){
        if(item.separator){c.line(x+12,yy+4,x+width-12,yy+4,theme::borderSoft);yy+=9;continue;}
        Rect row{x+3,yy,width-6,24};
        const std::string id="context:"+item.id;
        const std::string label=tr(item.key,item.fallback);
        buttons_.push_back({row,id,label,false,item.enabled});
        if(item.enabled&&row.contains(mouse_x_,mouse_y_))fill_round_rect(c,row,theme::raised,7);
        c.text(row.x+10,row.y+16,label,item.enabled?theme::text:theme::dim2,9);
        if(!item.shortcut.empty()){
            const int sw=c.text_width(item.shortcut,8);c.text(row.x+row.w-sw-10,row.y+16,item.shortcut,item.enabled?theme::dim:theme::dim2,8);
        }
        yy+=24;
    }
}

void EditorApp::close_context_menu(){ context_menu_.clear();services_.request_redraw(); }

void EditorApp::open_media_in_trimmer(int media_id,double source_time){
    const MediaItem* media=project_.media_by_id(media_id);if(!media)return;
    edit_.selected_media=media_id;source_media_id_=media_id;source_time_=std::clamp(source_time,0.0,std::max(0.0,media->duration));source_in_=0.0;source_out_=-1.0;preview_tab_=PreviewTab::Trimmer;set_bin_tab(BinTab::ProjectMedia);request_preview(true);
}

void EditorApp::open_context_menu(int x,int y){
    context_menu_.clear();active_menu_=MainMenu::None;
    auto add=[&](std::string id,std::string key,std::string fallback,std::string shortcut={},bool enabled=true){context_menu_.items.push_back({std::move(id),std::move(key),std::move(fallback),std::move(shortcut),enabled,false});};
    auto sep=[&]{context_menu_.items.push_back({{}, {}, {}, {}, false, true});};
    if(const int media_id=bin_row_at(x,y)){
        context_menu_.kind=ContextMenuKind::Media;context_menu_.x=x;context_menu_.y=y;context_menu_.media_id=media_id;edit_.selected_media=media_id;
        add("media_open_trimmer","context.media.open_trimmer","Open in Trimmer");
        add("media_add_timeline","context.media.add_timeline","Add to Timeline at Cursor","Enter");
        sep();add("media_proxy","context.media.proxy","Create Optimized Media / Proxy");
        set_status(tr("status.context_media","Project Media context menu"));return;
    }
    if(!layout_.timeline.contains(x,y))return;
    auto& g=layout_.timeline_geo;context_menu_.x=x;context_menu_.y=y;context_menu_.time=std::clamp(edit_.time_at(g,x),0.0,kTimelineMaxSeconds);
    if(y>=g.y+g.ruler_h){
        int edge=0;const int clip_id=edit_.hit_clip(project_,g,x,y,&edge);
        if(clip_id){
            Clip* clip=project_.clip_by_id(clip_id);if(!clip)return;
            if(!edit_.selection.contains(clip_id))edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,true);
            context_menu_.kind=ContextMenuKind::Event;context_menu_.clip_id=clip_id;context_menu_.media_id=clip->media_id();context_menu_.track_id=clip->track_id;
            const Track* track=project_.track_by_id(clip->track_id);
            const MediaItem* event_media=project_.media_by_id(clip->media_id());
            if(event_media&&event_media->generated_text.enabled)add("event_text","context.event.text","Edit Generated Text...");
            else add("event_open_trimmer","context.event.open_trimmer","Open in Trimmer");
            if(track&&track->kind==TrackKind::Video){add("event_pancrop","context.event.pancrop","Video Event Pan/Crop...");add("event_fx","context.event.fx","Video Event FX...");}
            if(track&&track->kind==TrackKind::Audio)add("event_audio_fx","context.event.audio_fx","Audio Event FX...");
            sep();add("event_cut","context.event.cut","Cut","Ctrl+X");add("event_copy","context.event.copy","Copy","Ctrl+C");add("event_delete","context.event.delete","Delete","Del");
            sep();add("event_trim_start","context.event.trim_start","Trim Start Here");add("event_trim_end","context.event.trim_end","Trim End Here");add("event_split","context.event.split","Split Here","S");
            sep();add("event_loop","context.event.loop","Loop Event");add("event_lock","context.event.lock","Lock / Unlock Event","Ctrl+L");
            bool linked_av=false;if(clip->group_id>0){bool has_video=false,has_audio=false;for(const Clip* member:project_.clips_in_group(clip->group_id)){const Track* mt=project_.track_by_id(member->track_id);if(mt&&mt->kind==TrackKind::Video)has_video=true;if(mt&&mt->kind==TrackKind::Audio)has_audio=true;}linked_av=has_video&&has_audio;}
            if(linked_av||(track&&track->kind==TrackKind::Video&&event_media&&event_media->has_audio)){sep();add("event_detach_audio","context.event.detach_audio","Detach Audio from Video");}
            if(clip->takes.size()>1){add("event_take_next","context.event.next_take","Next Take");add("event_take_prev","context.event.prev_take","Previous Take");}
            set_status(tr("status.context_event","Event context menu"));return;
        }
        if(x<g.x+g.header_w){
            const int track_id=edit_.track_at(project_,g,y);if(track_id){context_menu_.kind=ContextMenuKind::Track;context_menu_.track_id=track_id;const Track* track=project_.track_by_id(track_id);selected_track_id_=track_id;
                add("track_video","context.track.video","Insert Video Track");add("track_audio","context.track.audio","Insert Audio Track");sep();
                add("track_lock","context.track.lock","Lock / Unlock Track");add("track_mute","context.track.mute","Mute / Unmute Track");add("track_solo","context.track.solo","Solo / Unsolo Track");
                if(track&&track->kind==TrackKind::Video){sep();add("event_fx","context.event.fx","Video Event FX...",{},false);}
                if(track&&track->kind==TrackKind::Audio){sep();add("track_audio_fx","context.track.audio_fx","Audio Track FX...");}
                set_status(tr("status.context_track","Track context menu"));return;}
        }
    }
    context_menu_.kind=ContextMenuKind::Timeline;
    add("timeline_import","context.timeline.import","Import Media...");add("timeline_paste","context.timeline.paste","Paste Here","Ctrl+V",!clipboard_.empty());sep();
    add("timeline_video_track","context.timeline.video_track","Insert Video Track");add("timeline_audio_track","context.timeline.audio_track","Insert Audio Track");add("timeline_marker","context.timeline.marker","Add Marker Here","M");sep();
    add("timeline_preferences","context.timeline.preferences","Preferences...");
    set_status(tr("status.context_timeline","Timeline context menu"));
}

bool EditorApp::dispatch_context_button(const std::string& full_id){
    if(full_id.rfind("context:",0)!=0)return false;
    const std::string id=full_id.substr(8);const ContextMenuState state=context_menu_;
    auto finish=[&]{context_menu_.clear();services_.request_redraw();};
    if(id=="animation_key_delete"){
        auto* channel=animation_channel(state.property);
        if(channel){undo_.begin(project_);channel->erase_key(state.time,.5/project_.settings.fps);if(undo_.commit(project_)){mark_dirty();animation_property_=state.property;animation_seek(state.time);animation_changed(true);set_status(tr("status.keyframe_deleted","Keyframe deleted"));}else undo_.cancel();}
        finish();return true;
    }
    if(id=="pan_crop_key_delete"){
        Clip* clip=project_.clip_by_id(state.clip_id);
        if(clip){undo_.begin(project_);clip->video_motion.erase_key(state.time);if(undo_.commit(project_)){mark_dirty();pan_crop_time_=std::clamp(state.time,0.0,clip->duration);engine_.clear_composite_cache();request_preview(true);set_status(tr("status.pan_crop_key_deleted","Pan/Crop keyframe deleted"));}else undo_.cancel();}
        finish();return true;
    }
    if(id=="event_open_trimmer"){
        if(const Clip* clip=project_.clip_by_id(state.clip_id)){const double local=std::clamp(state.time-clip->start,0.0,clip->duration);open_media_in_trimmer(clip->media_id(),clip->source_offset()+local*clip->rate);}finish();return true;
    }
    if(id=="event_text"){open_text_editor(state.clip_id);finish();return true;}
    if(id=="event_pancrop"){open_pan_crop(state.clip_id);finish();return true;}
    if(id=="event_fx"){if(state.clip_id){if(Clip* clip=project_.clip_by_id(state.clip_id)){selected_track_id_=clip->track_id;open_effect_editor(clip->id);}}finish();return true;}
    if(id=="event_audio_fx"){if(state.clip_id){if(Clip* clip=project_.clip_by_id(state.clip_id)){selected_track_id_=clip->track_id;edit_.selection.select_clip(project_,clip->id,SelectionOperation::Replace,false);bin_tab_=BinTab::AudioFx;set_status(tr("context.event.audio_fx","Audio Event FX"));}}finish();return true;}
    if(id=="event_cut"){dispatch_edit_button("cut_clipboard");finish();return true;}
    if(id=="event_copy"){dispatch_edit_button("copy");finish();return true;}
    if(id=="event_delete"){dispatch_edit_button("delete");finish();return true;}
    if(id=="event_split"){if(edit_.split_selected(project_,undo_,state.time)){mark_dirty();request_preview(true);}finish();return true;}
    if(id=="event_trim_start"){if(edit_.trim_start_to_cursor(project_,undo_,state.time)){mark_dirty();request_preview(true);}finish();return true;}
    if(id=="event_trim_end"){if(edit_.trim_end_to_cursor(project_,undo_,state.time)){mark_dirty();request_preview(true);}finish();return true;}
    if(id=="event_loop"){dispatch_edit_button("event_loop");finish();return true;}
    if(id=="event_lock"){dispatch_edit_button("lock_selection");finish();return true;}
    if(id=="event_detach_audio"){
        undo_.begin(project_);if(project_.detach_audio(state.clip_id)&&undo_.commit(project_)){edit_.selection.select_clip(project_,state.clip_id,SelectionOperation::Replace,false);mark_dirty();set_status(tr("status.detached_audio","Audio detached from video"));request_preview(true);}else undo_.cancel();finish();return true;
    }
    if(id=="event_take_next"){dispatch_edit_button("take_next");finish();return true;}
    if(id=="event_take_prev"){dispatch_edit_button("take_prev");finish();return true;}
    if(id=="media_open_trimmer"){open_media_in_trimmer(state.media_id,0.0);finish();return true;}
    if(id=="media_add_timeline"){add_media_to_timeline(state.media_id,playhead_);finish();return true;}
    if(id=="media_proxy"){edit_.selected_media=state.media_id;create_proxy_for_selected();finish();return true;}
    if(id=="timeline_import"){import_paths(services_.open_media_files());finish();return true;}
    if(id=="timeline_paste"){set_playhead(state.time,false);dispatch_edit_button("paste");finish();return true;}
    if(id=="timeline_video_track"){dispatch_edit_button("add_video");finish();return true;}
    if(id=="timeline_audio_track"){dispatch_edit_button("add_audio");finish();return true;}
    if(id=="timeline_marker"){set_playhead(state.time,false);add_marker();finish();return true;}
    if(id=="timeline_preferences"){dialog_=DialogMode::Preferences;finish();return true;}
    if(id=="track_video"){dispatch_edit_button("add_video");finish();return true;}
    if(id=="track_audio"){dispatch_edit_button("add_audio");finish();return true;}
    if(id=="track_lock"){dispatch_track_button("track_lock:"+std::to_string(state.track_id));finish();return true;}
    if(id=="track_mute"){dispatch_track_button("track_mute:"+std::to_string(state.track_id));finish();return true;}
    if(id=="track_solo"){dispatch_track_button("track_solo:"+std::to_string(state.track_id));finish();return true;}
    if(id=="track_audio_fx"){selected_track_id_=state.track_id;bin_tab_=BinTab::AudioFx;set_status(tr("context.track.audio_fx","Audio Track FX"));finish();return true;}
    finish();return true;
}

void EditorApp::draw_modal(Canvas& c){
    if(dialog_==DialogMode::None)return;
    if(dialog_==DialogMode::PanCrop){draw_pan_crop(c);return;}
    if(dialog_==DialogMode::RenderAs){draw_render_as(c);return;}
    if(dialog_==DialogMode::EffectEditor){draw_effect_editor(c);return;}
    if(dialog_==DialogMode::TextEditor){draw_text_editor(c);return;}
    c.fill_rect({0,0,c.width(),c.height()},Color{5,8,12,170});
    const int w=520,h=dialog_==DialogMode::ProjectProperties?500:390;
    const int x=(c.width()-w)/2,y=(c.height()-h)/2;Rect panel{x,y,w,h};
    draw_card(c,panel,theme::panel2,12);
    fill_round_rect(c,{x+1,y+1,w-2,38},theme::panel3,11);c.fill_rect({x+1,y+20,w-2,19},theme::panel3);
    const std::string title=dialog_==DialogMode::ProjectProperties?tr("dialog.project_properties","Project Properties"):tr("dialog.preferences","Preferences");
    c.text(x+16,y+25,title,theme::text,11,true);

    auto light_button=[&](Rect r,std::string id,std::string label,bool active=false){
        Button b{r,std::move(id),std::move(label),active,true};buttons_.push_back(b);draw_button(c,b);
    };
    auto row_label=[&](int yy,const std::string& label,const std::string& value){
        c.text(x+24,y+yy,label,theme::dim,9);Rect field{x+178,y+yy-15,205,22};fill_round_rect(c,field,theme::panel,6);draw_round_border(c,field,theme::borderSoft,6);c.text(x+188,y+yy+1,value,theme::text,9,true);
    };
    auto section=[&](int yy,const std::string& label){c.text(x+20,y+yy,label,theme::text,9,true);c.line(x+18,y+yy+7,x+w-18,y+yy+7,theme::borderSoft);};

    if(dialog_==DialogMode::ProjectProperties){
        section(57,tr("project.video","Video"));
        row_label(91,tr("project.width","Width"),std::to_string(pending_project_settings_.width));
        light_button({x+392,y+76,42,22},"dialog:width_down","-");light_button({x+438,y+76,42,22},"dialog:width_up","+");
        row_label(123,tr("project.height","Height"),std::to_string(pending_project_settings_.height));
        light_button({x+392,y+108,42,22},"dialog:height_down","-");light_button({x+438,y+108,42,22},"dialog:height_up","+");
        std::ostringstream fps;fps<<std::fixed<<std::setprecision(3)<<pending_project_settings_.fps;row_label(155,tr("project.frame_rate","Frame rate"),fps.str()+" fps");
        light_button({x+392,y+140,88,22},"dialog:fps_cycle",tr("common.cycle","Cycle"));
        section(193,tr("project.templates","Templates"));
        light_button({x+24,y+214,142,28},"dialog:preset_1080_30","HD 1080p 30");
        light_button({x+174,y+214,142,28},"dialog:preset_1080_60","HD 1080p 60");
        light_button({x+324,y+214,142,28},"dialog:preset_4k_30","UHD 2160p 30");
        section(256,tr("project.preview","Preview"));
        auto pending_quality_name=[&](){
            switch(std::clamp(pending_project_settings_.preview_quality,0,3)){
                case 0:return tr("preview.quality.draft","Draft / 320x180");
                case 1:return tr("preview.quality.preview","Preview / 640x360");
                case 2:return tr("preview.quality.good","Good / 960x540");
                default:return tr("preview.quality.best","Best / Full");
            }
        };
        row_label(292,tr("project.preview_quality","Preview quality"),pending_quality_name());
        light_button({x+392,y+277,88,22},"dialog:preview_quality",tr("common.cycle","Cycle"));
        row_label(324,tr("project.preview_fps","Preview FPS"),std::to_string(pending_project_settings_.preview_fps_limit)+" fps");
        light_button({x+392,y+309,88,22},"dialog:preview_fps",tr("common.cycle","Cycle"));
        light_button({x+24,y+337,260,26},"dialog:prepared_cache",std::string(pending_project_settings_.use_prepared_cache?"[x] ":"[ ] ")+tr("project.use_optimized_cache","Use optimized media cache"),pending_project_settings_.use_prepared_cache);
        section(386,tr("project.audio","Audio"));
        row_label(424,tr("project.sample_rate","Sample rate"),std::to_string(pending_project_settings_.sample_rate)+" Hz");
        light_button({x+392,y+409,88,22},"dialog:sample_cycle",tr("common.cycle","Cycle"));
        light_button({x+w-188,y+h-42,78,26},"dialog:project_apply",tr("common.ok","OK"),true);
        light_button({x+w-100,y+h-42,78,26},"dialog:cancel",tr("common.cancel","Cancel"));
    }else{
        section(62,tr("preferences.application_editing","Application / Editing"));
        light_button({x+24,y+87,260,28},"dialog:toggle_audio",std::string(audio_preview_enabled_?"[x] ":"[ ] ")+tr("preferences.realtime_audio","Realtime audio preview"),audio_preview_enabled_);
        light_button({x+24,y+123,260,28},"dialog:snap",std::string(project_.snapping?"[x] ":"[ ] ")+tr("preferences.enable_snapping","Enable snapping"),project_.snapping);
        light_button({x+24,y+159,260,28},"dialog:crossfade",std::string(project_.auto_crossfade?"[x] ":"[ ] ")+tr("preferences.auto_crossfades","Automatic crossfades"),project_.auto_crossfade);
        light_button({x+24,y+195,260,28},"dialog:gpu",std::string(engine_.gpu_enabled()?"[x] ":"[ ] ")+tr("preferences.gpu_acceleration","GPU acceleration"),engine_.gpu_enabled());
        light_button({x+306,y+87,190,28},"dialog:quantize",std::string(project_.quantize_to_frames?"[x] ":"[ ] ")+tr("preferences.quantize_frames","Quantize to Frames"),project_.quantize_to_frames);
        light_button({x+306,y+123,190,28},"dialog:ignore_grouping",std::string(project_.ignore_event_grouping?"[x] ":"[ ] ")+tr("preferences.ignore_grouping","Ignore Event Grouping"),project_.ignore_event_grouping);
        light_button({x+306,y+159,190,28},"dialog:slip_all",std::string(project_.slip_all_takes?"[x] ":"[ ] ")+tr("preferences.slip_all_takes","Slip All Takes"),project_.slip_all_takes);
        c.text(x+24,y+244,tr("preferences.preview_note","Preview quality, preview FPS and optimized-cache policy live in Project Properties."),theme::dim,8);
        c.text(x+24,y+276,tr("dialog.language","Language"),theme::dim,9);
        fill_round_rect(c,{x+96,y+260,184,24},theme::panel,6);draw_round_border(c,{x+96,y+260,184,24},theme::borderSoft,6);c.text(x+106,y+277,current_language_name(),theme::text,9,true);
        light_button({x+286,y+260,32,24},"dialog:lang_prev","<");light_button({x+322,y+260,32,24},"dialog:lang_next",">");
        c.text(x+315,y+312,tr("preferences.gpu_backend","GPU backend"),theme::dim,9);c.text(x+315,y+331,short_name(engine_.gpu_backend().label,28),engine_.gpu_backend().decode_available||engine_.gpu_backend().encode_available?Color{124,210,151}:theme::dim,8,true);
        c.text(x+24,y+312,tr("preferences.audio_backend","Audio backend"),theme::dim,9);c.text(x+24,y+331,engine_.audio_preview_ready()?tr("preferences.ffplay_realtime","FFplay realtime preview"):tr("preferences.ffplay_missing","FFplay not found"),engine_.audio_preview_ready()?Color{124,210,151}:Color{232,120,120},8,true);
        light_button({x+w-100,y+h-36,78,26},"dialog:cancel",tr("common.close","Close"),true);
    }
}

void EditorApp::draw_pan_crop(Canvas& c){
    c.fill_rect({0,0,c.width(),c.height()},Color{8,8,8,150});
    Clip* clip=project_.clip_by_id(pan_crop_clip_id_);
    if(!clip){dialog_=DialogMode::None;pan_crop_clip_id_=0;return;}
    const int w=std::min(920,std::max(700,c.width()-70));
    const int h=std::min(650,std::max(520,c.height()-80));
    const int x=(c.width()-w)/2,y=(c.height()-h)/2;
    Rect panel{x,y,w,h};draw_card(c,panel,theme::panel2,12);
    fill_round_rect(c,{x+1,y+1,w-2,38},theme::panel3,11);c.fill_rect({x+1,y+20,w-2,19},theme::panel3);c.text(x+16,y+25,tr("pan_crop.title","Video Event Pan/Crop"),theme::text,11,true);
    Button close{{x+w-34,y+4,28,25},"pan_crop_close","X"};buttons_.push_back(close);draw_button(c,close);

    const MediaItem* media=project_.media_by_id(clip->media_id());
    draw_card(c,{x+10,y+48,216,h-150},theme::panel,9);
    c.text(x+18,y+64,tr("pan_crop.position","Position"),theme::text,10,true);
    VideoMotionSample sample=pan_crop_drag_.active()?pan_crop_drag_.preview:sample_motion(clip->video_motion,pan_crop_time_);
    auto row=[&](int yy,const std::string& label,const std::string& value){c.text(x+22,y+yy,label,Color{190,190,190},9);c.text(x+105,y+yy,value,Color{245,245,245},9,true);};
    row(91,tr("pan_crop.center_x","Center X"),motion_number(sample.center_x));row(116,tr("pan_crop.center_y","Center Y"),motion_number(sample.center_y));row(141,tr("pan_crop.zoom","Zoom"),motion_number(sample.zoom,2)+"x");row(166,tr("pan_crop.rotation","Rotation"),motion_number(sample.rotation,1)+" "+tr("unit.deg","deg"));
    c.text(x+18,y+202,tr("pan_crop.keyframe_interpolation","Keyframe interpolation"),theme::text,9,true);c.text(x+22,y+224,tr("animation.interpolation.linear","Linear"),Color{190,190,190},9);
    Button rotm{{x+20,y+248,58,22},"pan_crop_rot_minus","-5 "+tr("unit.deg","deg")};Button rotp{{x+84,y+248,58,22},"pan_crop_rot_plus","+5 "+tr("unit.deg","deg")};Button reset{{x+148,y+248,66,22},"pan_crop_reset",tr("common.reset","Reset")};
    for(auto b:{rotm,rotp,reset}){buttons_.push_back(b);draw_button(c,b);}
    c.text(x+18,y+300,tr("pan_crop.event","Event"),theme::text,9,true);c.text(x+22,y+321,short_name(media?media->name:tr("pan_crop.video_event","Video Event"),27),Color{180,180,180},8);
    c.text(x+22,y+342,tr("pan_crop.event_time","Event time")+"  "+timecode(pan_crop_time_)+" / "+timecode(clip->duration),Color{180,180,180},8);
    c.text(x+22,y+359,tr("pan_crop.timeline","Timeline")+"   "+timecode(clip->start+pan_crop_time_),Color{160,160,160},8);
    c.text(x+22,y+378,tr("pan_crop.hint_pan","Drag frame to pan"),Color{150,150,150},8);c.text(x+22,y+395,tr("pan_crop.hint_zoom","Drag a corner to zoom"),Color{150,150,150},8);c.text(x+22,y+412,tr("pan_crop.hint_rotate","Drag orange handle to rotate"),Color{150,150,150},8);

    Rect work{x+240,y+54,w-258,h-190};fill_round_rect(c,work,theme::bg,9);draw_round_border(c,work,theme::borderSoft,9);
    const double aspect=static_cast<double>(std::max(1,project_.settings.width))/std::max(1,project_.settings.height);
    int fw=work.w-36,fh=static_cast<int>(std::lround(fw/aspect));if(fh>work.h-36){fh=work.h-36;fw=static_cast<int>(std::lround(fh*aspect));}
    pan_crop_workspace_={work.x+(work.w-fw)/2,work.y+(work.h-fh)/2,fw,fh};
    c.fill_rect(pan_crop_workspace_,Color{17,17,17});
    // Pan/Crop must show the untransformed event source. Showing the project
    // preview here feeds the already-cropped/zoomed result back into the crop
    // editor and makes the frame appear to drift or magnify itself.
    bool source_drawn=false;
    if(media){
        const double source_time=std::max(0.0,clip->source_offset()+pan_crop_time_*clip->rate);
        if(media->generated_vector.enabled){if(auto source=engine_.vector_thumbnail(media->generated_vector,source_time,std::max(96,pan_crop_workspace_.w),std::max(54,pan_crop_workspace_.h))){c.image(pan_crop_workspace_,*source);source_drawn=true;}}
        else if(!media->path.empty()){const std::string source_path=!media->proxy_path.empty()&&fs::exists(path_from_utf8(media->proxy_path))?media->proxy_path:media->path;if(auto source=engine_.timeline_thumbnail(source_path,source_time,std::max(96,pan_crop_workspace_.w),std::max(54,pan_crop_workspace_.h))){c.image(pan_crop_workspace_,*source);source_drawn=true;}}
    }
    if(!source_drawn&&!preview_frame_.rgb.empty())c.image(pan_crop_workspace_,preview_frame_);
    for(int i=1;i<4;++i){const int gx=pan_crop_workspace_.x+pan_crop_workspace_.w*i/4,gy=pan_crop_workspace_.y+pan_crop_workspace_.h*i/4;c.line(gx,pan_crop_workspace_.y,gx,pan_crop_workspace_.y+pan_crop_workspace_.h,Color{75,75,75});c.line(pan_crop_workspace_.x,gy,pan_crop_workspace_.x+pan_crop_workspace_.w,gy,Color{75,75,75});}
    c.stroke_rect(pan_crop_workspace_,Color{145,145,145});
    const Rect frame=motion_frame_rect(pan_crop_workspace_,sample);c.stroke_rect(frame,Color{235,235,235},2);
    const int hs=7;const Rect handles[]={{frame.x-hs/2,frame.y-hs/2,hs,hs},{frame.x+frame.w-hs/2,frame.y-hs/2,hs,hs},{frame.x-hs/2,frame.y+frame.h-hs/2,hs,hs},{frame.x+frame.w-hs/2,frame.y+frame.h-hs/2,hs,hs}};
    for(auto handle:handles){c.fill_rect(handle,Color{245,245,245});c.stroke_rect(handle,Color{25,25,25});}
    const int cx=frame.x+frame.w/2,cy=frame.y+frame.h/2;c.line(cx-8,cy,cx+8,cy,Color{245,245,245});c.line(cx,cy-8,cx,cy+8,Color{245,245,245});
    const double rot_a=(sample.rotation-90.0)*3.14159265358979323846/180.0;
    const double rot_radius=std::max(30.0,frame.h*0.5+22.0);
    const int rx=cx+static_cast<int>(std::lround(std::cos(rot_a)*rot_radius)),ry=cy+static_cast<int>(std::lround(std::sin(rot_a)*rot_radius));
    c.line(cx,cy,rx,ry,theme::warning,1);c.fill_rect({rx-5,ry-5,11,11},theme::warning);c.stroke_rect({rx-5,ry-5,11,11},Color{30,30,30});

    const int key_y=y+h-116;draw_card(c,{x+10,key_y,w-20,100},theme::panel,9);
    c.text(x+18,key_y+20,tr("pan_crop.keyframes","Position / Zoom / Rotation keyframes"),theme::text,9,true);
    pan_crop_keyline_={x+240,key_y+34,w-270,34};fill_round_rect(c,pan_crop_keyline_,theme::bg,6);c.line(pan_crop_keyline_.x,pan_crop_keyline_.y+17,pan_crop_keyline_.x+pan_crop_keyline_.w,pan_crop_keyline_.y+17,Color{120,120,120});
    const double dur=std::max(1e-6,clip->duration);for(int i=0;i<=5;++i){int tx=pan_crop_keyline_.x+pan_crop_keyline_.w*i/5;c.line(tx,pan_crop_keyline_.y+12,tx,pan_crop_keyline_.y+22,Color{100,100,100});c.text(tx-6,pan_crop_keyline_.y+32,std::to_string(static_cast<int>(std::round(dur*i/5.0)))+"s",Color{130,130,130},7);}
    std::vector<double> key_times;auto gather=[&](const AnimatedDouble&a){for(const auto&k:a.keys)key_times.push_back(k.time);};gather(clip->video_motion.center_x);gather(clip->video_motion.center_y);gather(clip->video_motion.zoom);gather(clip->video_motion.rotation);std::sort(key_times.begin(),key_times.end());key_times.erase(std::unique(key_times.begin(),key_times.end(),[](double a,double b){return std::abs(a-b)<1e-6;}),key_times.end());
    for(double kt:key_times){const int kx=pan_crop_keyline_.x+static_cast<int>(std::lround(std::clamp(kt/dur,0.0,1.0)*pan_crop_keyline_.w));Rect diamond{kx-4,pan_crop_keyline_.y+13,8,8};c.fill_rect(diamond,theme::accent);}
    const int px=pan_crop_keyline_.x+static_cast<int>(std::lround(std::clamp(pan_crop_time_/dur,0.0,1.0)*pan_crop_keyline_.w));c.line(px,pan_crop_keyline_.y,px,pan_crop_keyline_.y+pan_crop_keyline_.h,theme::playhead,1);
    Button add{{x+18,key_y+61,78,24},"pan_crop_add_key",tr("animation.key_add","+ Key")};Button del{{x+102,key_y+61,88,24},"pan_crop_delete_key",tr("animation.key_delete","Delete Key"),false,clip->video_motion.has_key(pan_crop_time_)};Button home{{x+196,key_y+61,82,24},"pan_crop_time_zero",tr("pan_crop.time_zero","Time 0")};for(auto b:{add,del,home}){buttons_.push_back(b);draw_button(c,b);}
    c.text(x+w-205,key_y+79,tr("pan_crop.scrub_hint","Drag the key timeline to scrub"),Color{145,145,145},8);
}

void EditorApp::draw_effect_editor(Canvas& c){
    fx_slider_hits_.clear();
    c.fill_rect({0,0,c.width(),c.height()},Color{8,8,8,154});
    Clip* clip=project_.clip_by_id(fx_editor_clip_id_);
    if(!clip){dialog_=DialogMode::None;fx_editor_clip_id_=0;fx_editor_effect_id_=0;return;}
    const MediaItem* media=project_.media_by_id(clip->media_id());
    const int w=std::min(1080,std::max(860,c.width()-70));
    const int h=std::min(720,std::max(580,c.height()-70));
    const int x=(c.width()-w)/2,y=(c.height()-h)/2;
    Rect panel{x,y,w,h};
    draw_card(c,panel,theme::panel2,12);
    fill_round_rect(c,{x+1,y+1,w-2,40},theme::panel3,11);c.fill_rect({x+1,y+20,w-2,21},theme::panel3);
    c.text(x+16,y+26,tr("fx.title","Video Event FX"),theme::text,11,true);
    c.text(x+170,y+26,short_name(media?media->name:tr("fx.selected_event","Selected event"),34),theme::dim,9);
    Button close{{x+w-36,y+4,28,26},"fx_editor_close","",false,true,"xmark"};buttons_.push_back(close);draw_button(c,close);

    const Rect lib{x+12,y+48,250,h-60};
    const Rect right{x+274,y+48,w-286,h-60};
    draw_card(c,lib,theme::panel,9);
    draw_card(c,right,theme::panel,9);

    c.text(lib.x+10,lib.y+18,tr("fx.available","Available effects"),theme::text,10,true);
    c.text(lib.x+10,lib.y+35,tr("fx.choose_hint","Choose an effect and add it to the selected event."),theme::dim,8);
    int list_y=lib.y+46;
    const int lib_bottom=lib.y+lib.h-42;
    for(const auto* defp:available_effect_definitions()){
        if(!defp) continue;
        const auto& def=*defp;
        if(list_y+20>lib_bottom)break;
        const bool active=selected_fx_definition_==def.id;const bool external=def.id.rfind("ofx:",0)==0;
        Rect rr{lib.x+6,list_y,lib.w-12,20};
        if(active)fill_round_rect(c,rr,theme::accent2,6); else if(rr.contains(mouse_x_,mouse_y_)) fill_round_rect(c,rr,theme::raised,6);
        buttons_.push_back({rr,"fx_editor_pick_def:"+def.id,"",active,true});
        c.text(rr.x+6,rr.y+14,external?"OFX":"FX",active?Color{219,238,255}:Color{108,191,240},8,true);
        c.text(rr.x+(external?34:28),rr.y+14,short_name(tr("catalog."+def.name,def.name),external?20:24),active?Color{245,250,255}:theme::text,9);
        c.text(rr.x+rr.w-74,rr.y+14,short_name(tr("catalog."+def.category,def.category),10),theme::dim,8);
        list_y+=21;
    }
    Button add{{lib.x+10,lib.y+lib.h-30,110,22},"fx_editor_add",tr("common.add","Add"),false,true,"plus"};buttons_.push_back(add);draw_button(c,add);
    Button openpane{{lib.x+128,lib.y+lib.h-30,112,22},"fx_editor_open_pane",tr("fx.pane","FX Pane"),false,true,"sliders-h"};buttons_.push_back(openpane);draw_button(c,openpane);

    const int preview_h=std::clamp(right.h/2-8,200,320);
    Rect preview{right.x+10,right.y+10,std::max(220,right.w-20),preview_h};
    fill_round_rect(c,preview,theme::bg,8);draw_round_border(c,preview,theme::borderSoft,8);
    c.text(preview.x+10,preview.y+18,tr("fx.preview","Effect preview"),theme::dim,8,true);
    Rect viewport{preview.x+12,preview.y+28,preview.w-24,preview.h-40};
    c.fill_rect(viewport,Color{12,12,12});
    if(!preview_frame_.rgb.empty()) c.image(viewport,preview_frame_); else c.text(viewport.x+viewport.w/2-48,viewport.y+viewport.h/2,tr("ui.no_frame","No frame at cursor"),theme::dim,10);
    c.stroke_rect(viewport,Color{47,52,58});
    c.text(preview.x+10,preview.y+preview.h-8,tr("fx.preview_hint","Changes update the live project preview for this event."),theme::dim,8);

    c.text(right.x+12,preview.y+preview.h+20,tr("fx.chain","Effect chain"),theme::text,10,true);
    Rect chain{right.x+10,preview.y+preview.h+28,right.w*42/100,std::max(150,right.y+right.h-(preview.y+preview.h+40))};
    Rect inspector{chain.x+chain.w+12,chain.y,right.x+right.w-(chain.x+chain.w+22),chain.h};
    c.fill_rect(chain,Color{24,27,33});c.stroke_rect(chain,Color{53,60,68});
    c.fill_rect(inspector,Color{24,27,33});c.stroke_rect(inspector,Color{53,60,68});

    EffectInstance* selected_effect=nullptr;
    for(auto& effect:clip->video_effects) if(effect.id==fx_editor_effect_id_) { selected_effect=&effect; break; }
    if(!selected_effect && !clip->video_effects.empty()){
        fx_editor_effect_id_=clip->video_effects.front().id;
        selected_effect=&clip->video_effects.front();
    }

    int cy=chain.y+8;
    if(clip->video_effects.empty()){
        c.text(chain.x+10,chain.y+24,tr("fx.no_effects","No event effects yet."),theme::dim,9,true);
        c.text(chain.x+10,chain.y+42,tr("fx.add_hint","Pick an effect on the left and click Add."),theme::dim,8);
    }else{
        for(const auto& effect:clip->video_effects){
            if(cy+24>chain.y+chain.h-6)break;
            const auto* def=effect_definition(effect.definition_id);
            Rect rr{chain.x+6,cy,chain.w-12,22};
            const bool active=effect.id==fx_editor_effect_id_;
            if(active)c.fill_rect(rr,Color{56,77,104}); else if(rr.contains(mouse_x_,mouse_y_)) c.fill_rect(rr,Color{40,45,52});
            buttons_.push_back({rr,"fx_editor_select_inst:"+std::to_string(effect.id),"",active,true});
            c.text(rr.x+6,rr.y+15,effect.enabled?"ON":"OFF",effect.enabled?Color{131,220,162}:Color{170,110,110},8,true);
            c.text(rr.x+36,rr.y+15,short_name(def?tr("catalog."+def->name,def->name):effect.definition_id,24),active?Color{245,250,255}:theme::text,9,true);
            cy+=24;
        }
    }

    if(selected_effect){
        const auto* def=effect_definition(selected_effect->definition_id);
        c.text(inspector.x+10,inspector.y+18,def?tr("catalog."+def->name,def->name):tr("fx.effect","Effect"),theme::text,10,true);
        c.text(inspector.x+10,inspector.y+34,def?def->category:tr("fx.event_fx","Event FX"),theme::dim,8);
        Button tog{{inspector.x+10,inspector.y+44,92,20},"fx_editor_toggle",selected_effect->enabled?tr("common.enabled","Enabled"):tr("common.bypassed","Bypassed"),selected_effect->enabled,true,"power"};
        Button rem{{inspector.x+108,inspector.y+44,76,20},"fx_editor_remove",tr("common.remove","Remove"),false,true,"trash"};
        buttons_.push_back(tog);draw_button(c,tog);buttons_.push_back(rem);draw_button(c,rem);
        fx_parameter_view_=inspector;
        const int parameter_count=def?static_cast<int>(def->parameters.size()):0;
        fx_parameter_scroll_=std::clamp(fx_parameter_scroll_,0,std::max(0,parameter_count-1));
        int parameter_index=0;
        int py=inspector.y+76;
        if(def && def->parameters.empty()) c.text(inspector.x+10,py+12,tr("fx.no_parameters","This effect has no exposed parameters."),theme::dim,8);
        if(def){
            for(const auto& pd:def->parameters){
                if(parameter_index++<fx_parameter_scroll_)continue;
                if(py+46>inspector.y+inspector.h-32) break;
                if(selected_effect->definition_id=="koralo.paint_mask"&&pd.id=="strokes"){c.text(inspector.x+10,py+12,tr("fx.paint_hint","Draw in preview: B / Shift"),theme::text,8);Button clear{{inspector.x+10,py+22,100,22},"fx_editor_clear_paint",tr("fx.clear_mask","Clear mask"),false,true};buttons_.push_back(clear);draw_button(c,clear);py+=52;continue;}
                if(pd.type==EffectParameterType::Bool){
                    const auto* state=effect_parameter(*selected_effect,pd.id);
                    const bool value=state&&std::holds_alternative<bool>(state->value)?std::get<bool>(state->value):false;
                    c.text(inspector.x+10,py+13,short_name(tr("catalog."+pd.name,pd.name),22),theme::text,8,true);
                    Button toggle_bool{{inspector.x+inspector.w-78,py-2,68,20},"fx_editor_bool:"+pd.id,value?tr("common.on","On"):tr("common.off","Off"),value,true,"power"};
                    buttons_.push_back(toggle_bool);draw_button(c,toggle_bool);py+=30;continue;
                }
                if(pd.type!=EffectParameterType::Double){
                    c.text(inspector.x+10,py+12,short_name(tr("catalog."+pd.name,pd.name),20)+" "+tr("fx.coming_soon","(coming soon)"),theme::dim,8);
                    py+=24;
                    continue;
                }
                const double fallback=std::holds_alternative<double>(pd.default_value)?std::get<double>(pd.default_value):0.0;
                double value=effect_numeric(*selected_effect,pd.id,0.0,fallback);
                if(fx_param_drag_.active&&fx_param_drag_.effect_id==selected_effect->id&&fx_param_drag_.parameter_id==pd.id)value=fx_param_drag_.value;
                value=std::clamp(value,pd.min_value,pd.max_value);
                c.text(inspector.x+10,py+12,short_name(tr("catalog."+pd.name,pd.name),18),theme::text,8,true);
                const std::string numeric=motion_number(value,2);
                c.text(inspector.x+inspector.w-c.text_width(numeric,8)-42,py+12,numeric,Color{190,207,225},8,true);
                Button reset{{inspector.x+inspector.w-31,py-2,22,18},"fx_editor_param_reset:"+pd.id,"",false,true,"reset"};
                buttons_.push_back(reset);draw_button(c,reset);

                Rect slider{inspector.x+10,py+22,std::max(64,inspector.w-30),10};
                const double span=std::max(1e-12,pd.max_value-pd.min_value);
                const double u=std::clamp((value-pd.min_value)/span,0.0,1.0);
                c.fill_rect({slider.x,slider.y+3,slider.w,4},Color{47,55,65});
                c.fill_rect({slider.x,slider.y+3,static_cast<int>(std::lround(slider.w*u)),4},theme::accent);
                const int knob_x=slider.x+static_cast<int>(std::lround((slider.w-1)*u));
                c.fill_rect({knob_x-4,slider.y,9,10},Color{215,227,240});
                c.stroke_rect({knob_x-4,slider.y,9,10},Color{22,27,33});
                fx_slider_hits_.push_back({slider,selected_effect->id,pd.id,pd.min_value,pd.max_value,value});
                c.text(inspector.x+10,py+43,motion_number(pd.min_value,1),Color{100,111,124},7);
                const std::string max_label=motion_number(pd.max_value,1);
                c.text(inspector.x+inspector.w-c.text_width(max_label,7)-10,py+43,max_label,Color{100,111,124},7);
                py+=52;
            }
        }
        for(auto b:{Button{{inspector.x+10,inspector.y+inspector.h-26,28,20},"fx_param_prev","<",false,fx_parameter_scroll_>0},Button{{inspector.x+44,inspector.y+inspector.h-26,28,20},"fx_param_next",">",false,fx_parameter_scroll_+1<parameter_count}}){buttons_.push_back(b);draw_button(c,b);}
        c.text(inspector.x+80,inspector.y+inspector.h-12,std::to_string(fx_parameter_scroll_+1)+" / "+std::to_string(parameter_count),theme::dim,8);
    }else{
        c.text(inspector.x+10,inspector.y+22,tr("fx.select_hint","Select an effect in the chain to edit parameters."),theme::dim,9);
    }
}

void EditorApp::draw_text_editor(Canvas& c){
    Clip* clip=project_.clip_by_id(text_editor_clip_id_);MediaItem* media=project_.media_by_id(text_editor_media_id_);
    if(!clip||!media){dialog_=DialogMode::None;text_editor_clip_id_=text_editor_media_id_=0;return;}
    c.fill_rect({0,0,c.width(),c.height()},Color{5,8,12,170});
    const int w=std::min(1040,std::max(860,c.width()-70)),h=std::min(690,std::max(590,c.height()-70));
    const int x=(c.width()-w)/2,y=(c.height()-h)/2;Rect panel{x,y,w,h};draw_card(c,panel,theme::panel2,12);
    fill_round_rect(c,{x+1,y+1,w-2,42},theme::panel3,11);c.fill_rect({x+1,y+20,w-2,23},theme::panel3);c.text(x+16,y+27,tr("dialog.titles_text","KoraLo Titles & Text"),theme::text,11,true);c.text(x+184,y+27,tr("dialog.generated_media","Generated Media"),theme::dim,9);
    Button close{{x+w-36,y+5,28,26},"text_cancel","",false,true,"xmark"};buttons_.push_back(close);draw_button(c,close);
    const Rect left{x+12,y+50,410,h-104},right{x+434,y+50,w-446,h-104};draw_card(c,left,theme::panel,9);draw_card(c,right,theme::panel,9);
    c.text(left.x+12,left.y+20,tr("text.label.text","Text"),theme::text,10,true);
    Rect editor{left.x+12,left.y+30,left.w-24,112};fill_round_rect(c,editor,theme::bg,7);draw_round_border(c,editor,text_editor_text_focus_?theme::accent:theme::borderSoft,7);buttons_.push_back({editor,"text_focus","",text_editor_text_focus_,true});
    std::stringstream tss(text_editor_pending_.text);std::string line;int ty=editor.y+22;int shown=0;while(std::getline(tss,line)&&shown<5){c.text(editor.x+9,ty,short_name(line,48),theme::text,10,text_editor_pending_.bold);ty+=19;++shown;}if(text_editor_pending_.text.empty())c.text(editor.x+9,editor.y+24,tr("text.placeholder","Type text here..."),theme::dim,10);
    c.text(editor.x+9,editor.y+editor.h-8,text_editor_text_focus_?tr("text.typing_active","Typing active · Enter = new line"):tr("text.click_to_edit","Click to edit"),theme::dim2,8);
    auto label=[&](int yy,const std::string& name){c.text(left.x+12,left.y+yy,name,theme::dim,8,true);};
    auto btn=[&](Rect r,const std::string& id,const std::string& text,bool active=false,bool enabled=true,std::string icon={}){Button b{r,id,text,active,enabled,icon};buttons_.push_back(b);draw_button(c,b);};
    label(165,tr("text.label.font","FONT"));fill_round_rect(c,{left.x+12,left.y+174,210,24},theme::bg,6);draw_round_border(c,{left.x+12,left.y+174,210,24},theme::borderSoft,6);c.text(left.x+22,left.y+191,text_editor_pending_.font_family,theme::text,9,true);
    btn({left.x+230,left.y+174,34,24},"text_size_down","-");fill_round_rect(c,{left.x+268,left.y+174,62,24},theme::bg,6);draw_round_border(c,{left.x+268,left.y+174,62,24},theme::borderSoft,6);c.text(left.x+281,left.y+191,motion_number(text_editor_pending_.font_size,0),theme::text,9,true);btn({left.x+334,left.y+174,34,24},"text_size_up","+");
    btn({left.x+12,left.y+204,48,24},"text_bold","B",text_editor_pending_.bold);btn({left.x+64,left.y+204,48,24},"text_italic","I",text_editor_pending_.italic);btn({left.x+126,left.y+204,60,24},"text_align_left",tr("text.align_left","Left"),text_editor_pending_.alignment==0);btn({left.x+190,left.y+204,70,24},"text_align_center",tr("text.align_center","Center"),text_editor_pending_.alignment==1);btn({left.x+264,left.y+204,60,24},"text_align_right",tr("text.align_right","Right"),text_editor_pending_.alignment==2);
    label(246,tr("text.label.color","TEXT COLOR"));
    const std::array<std::pair<const char*,Color>,6> colors={{{"text_color_white",Color{245,245,245}},{"text_color_yellow",Color{245,210,55}},{"text_color_cyan",Color{64,205,230}},{"text_color_red",Color{235,75,75}},{"text_color_green",Color{88,210,112}},{"text_color_black",Color{20,20,20}}}};
    int cx=left.x+12;for(const auto& item:colors){Rect rr{cx,left.y+256,34,24};c.fill_rect(rr,item.second);c.stroke_rect(rr,Color{96,107,120});buttons_.push_back({rr,item.first,"",false,true});cx+=40;}
    label(300,tr("text.label.scale","SCALE"));btn({left.x+12,left.y+309,34,22},"text_scale_down","-");fill_round_rect(c,{left.x+50,left.y+309,86,22},theme::bg,6);draw_round_border(c,{left.x+50,left.y+309,86,22},theme::borderSoft,6);c.text(left.x+66,left.y+325,motion_number(text_editor_pending_.scale,2)+"x",theme::text,8,true);btn({left.x+140,left.y+309,34,22},"text_scale_up","+");btn({left.x+180,left.y+309,64,22},"text_scale_reset",tr("common.reset","Reset"));
    label(352,tr("text.label.location","LOCATION"));c.text(left.x+12,left.y+379,"X  "+motion_number(text_editor_pending_.location_x,2)+"    Y  "+motion_number(text_editor_pending_.location_y,2),theme::text,8,true);btn({left.x+204,left.y+359,34,22},"text_x_left","<");btn({left.x+242,left.y+359,34,22},"text_x_right",">");btn({left.x+280,left.y+359,34,22},"text_y_up",tr("common.up","Up"));btn({left.x+318,left.y+359,34,22},"text_y_down",tr("common.down","Down"));
    label(405,tr("text.label.anchor_style","ANCHOR / STYLE"));btn({left.x+12,left.y+414,112,22},"text_anchor_cycle",tr("text.anchor","Anchor:")+" "+(text_editor_pending_.anchor==4?tr("text.center","Center"):std::to_string(text_editor_pending_.anchor)));btn({left.x+132,left.y+414,82,22},"text_outline",tr("text.outline","Outline"),text_editor_pending_.outline);btn({left.x+220,left.y+414,82,22},"text_shadow",tr("text.shadow","Shadow"),text_editor_pending_.shadow);btn({left.x+308,left.y+414,78,22},"text_animation",text_editor_pending_.animation==0?tr("text.no_animation","No Anim"):tr("text.fade","Fade"),text_editor_pending_.animation!=0);
    c.text(left.x+12,left.y+460,tr("text.apply_note","Changes stay temporary until Apply."),theme::dim,8);

    c.text(right.x+12,right.y+20,tr("text.live_preview","Live Preview"),theme::text,10,true);Rect preview{right.x+12,right.y+32,right.w-24,std::max(250,right.h-120)};text_editor_preview_=preview;fill_round_rect(c,preview,theme::bg,8);draw_round_border(c,preview,theme::borderSoft,8);if(!preview_frame_.rgb.empty())c.image(preview,preview_frame_);else c.text(preview.x+preview.w/2-45,preview.y+preview.h/2,tr("text.no_preview_frame","No preview frame"),theme::dim,9);
    c.stroke_rect({preview.x+preview.w/20,preview.y+preview.h/20,preview.w*9/10,preview.h*9/10},Color{50,57,66});
    const int marker_x=preview.x+static_cast<int>(std::lround(std::clamp(text_editor_pending_.location_x,0.0,1.0)*preview.w));
    const int marker_y=preview.y+static_cast<int>(std::lround(std::clamp(text_editor_pending_.location_y,0.0,1.0)*preview.h));
    c.line(marker_x-7,marker_y,marker_x+7,marker_y,Color{118,190,255},1);c.line(marker_x,marker_y-7,marker_x,marker_y+7,Color{118,190,255},1);c.stroke_rect({marker_x-4,marker_y-4,9,9},Color{210,232,255});
    c.text(preview.x+10,preview.y+18,tr("text.drag_position","Drag in preview to position text"),Color{134,151,171},8,true);
    c.text(right.x+12,right.y+right.h-70,tr("ui.duration","Duration")+"  "+timecode(clip->duration)+"    "+tr("ui.project","Project")+"  "+std::to_string(project_.settings.width)+"x"+std::to_string(project_.settings.height),theme::dim,8);
    btn({right.x+right.w-184,right.y+right.h-40,80,28},"text_apply",tr("text.apply","Apply"),true);btn({right.x+right.w-96,right.y+right.h-40,80,28},"text_cancel",tr("text.cancel","Cancel"));
}

void EditorApp::draw_render_as(Canvas& c){
    c.fill_rect({0,0,c.width(),c.height()},Color{8,8,8,170});
    const bool progress_view=rendering_||render_finished_;
    const int w=std::min(780,c.width()-24),h=progress_view?384:std::min(568,c.height()-24);
    const int x=(c.width()-w)/2,y=(c.height()-h)/2;
    draw_card(c,{x,y,w,h},theme::panel2,12);
    auto button=[&](Rect r,std::string id,std::string label,bool active=false,bool enabled=true){Button bt{r,std::move(id),std::move(label),active,enabled};buttons_.push_back(bt);draw_button(c,bt);};
    c.push_clip({x+8,y+8,w-16,h-16});
    c.text(x+24,y+32,tr("render.title","Export video"),theme::text,14,true);
    c.text(x+24,y+54,progress_view?tr("render.job","Export job"):tr("render.subtitle","MP4 / H.264 + AAC"),theme::dim,9);
    if(progress_view){
        const double value=std::clamp(render_progress_.load(),0.0,1.0);
        const double elapsed=rendering_?std::chrono::duration<double>(std::chrono::steady_clock::now()-render_started_).count():render_elapsed_;
        auto duration=[](double seconds){const int total=int(std::max(0.0,seconds));return std::to_string(total/3600)+":"+(total/60%60<10?"0":"")+std::to_string(total/60%60)+":"+(total%60<10?"0":"")+std::to_string(total%60);};
        const std::string state=render_finished_?(render_succeeded_?tr("status.render_complete","Export complete"):(render_cancel_?tr("status.render_cancelled","Export cancelled"):tr("status.render_failed","Export failed"))):
            (render_cancel_?tr("status.cancelling_render","Cancelling..."):(render_fsr_?(value<.35?tr("render.stage.compose","Compositing and effects"):(value<.85?tr("render.stage.fsr","FSR 1 upscaling"):tr("render.stage.encode","Encoding output"))):tr("render.stage.process","Processing and encoding")));
        c.text(x+24,y+92,state,theme::text,12,true);
        std::ostringstream percent;percent<<std::fixed<<std::setprecision(1)<<value*100<<"%";
        c.text(x+w-150,y+96,percent.str(),render_finished_&&!render_succeeded_?theme::dim:theme::accent,24,true);
        fill_round_rect(c,{x+24,y+116,w-48,14},theme::bg,7);
        if(value>0)fill_round_rect(c,{x+24,y+116,std::max(1,int((w-48)*value)),14},theme::accent,7);
        c.text(x+24,y+163,tr("render.elapsed","Elapsed")+": "+duration(elapsed),theme::text,10);
        const bool estimate=rendering_&&!render_cancel_&&value>.02&&elapsed>=2;
        c.text(x+w/2,y+163,tr("render.remaining","Remaining (estimate)")+": "+(estimate?"~"+duration(elapsed*(1-value)/value):"—"),theme::dim,10);
        // Live Render Control panel: read-only atomics, no renderer locks on the UI thread.
        const auto control=engine_.render_control_status();
        fill_round_rect(c,{x+24,y+174,w-48,55},theme::bg,6);
        const std::string stage=control.state==2?tr("render.control.verifying","Checking output video"):
            control.state==3?tr("render.control.verified","Video verified"):control.state==4?tr("render.control.failed","Verification / render failed"):
            tr("render.control.title","Render Control / Auto workload");
        c.text(x+34,y+192,stage,theme::text,9,true);
        const std::string status_line=control.worker_cap?
            (tr("render.control.cpu","KoraLo CPU")+" "+std::to_string(control.process_cpu_percent)+"%   |   "+tr("render.control.workers","workers")+" "+
             std::to_string(control.workers)+"/"+std::to_string(control.worker_cap)+
             "   |   "+tr("render.control.ram","RAM free")+" "+(control.available_memory_mb?
                 std::to_string(control.available_memory_mb)+" MB":"--")):
            tr("render.control.ffmpeg","FFmpeg encoder manages CPU/GPU threads (separate process)");
        c.text(x+34,y+214,status_line,theme::dim,9);
        c.text(x+24,y+255,tr("render.destination","Output file"),theme::dim,9);
        c.text(x+24,y+278,short_name(render_output_path_,std::size_t(std::max(20,(w-48)/7))),theme::text,9);
        c.text(x+24,y+302,std::to_string(render_pending_.width)+" x "+std::to_string(render_pending_.height)+" / "+motion_number(render_pending_.fps,3)+" fps / "+std::to_string(render_pending_.video_kbps)+" kbps"+(render_fsr_?" / FSR 1":""),theme::dim,9);
        if(render_finished_&&!render_succeeded_)c.text(x+24,y+321,short_name(render_result_message_,80),theme::dim,8);
        if(rendering_){button({x+24,y+h-50,180,30},"render:background",tr("render.background","Continue in background"));button({x+w-204,y+h-50,180,30},"render:stop",tr("render.stop","Cancel export"),false,!render_cancel_);}
        else button({x+w-164,y+h-50,140,30},"render:close",tr("common.close","Close"),true);
        c.pop_clip();return;
    }
    c.text(x+24,y+86,tr("render.preset","Preset"),theme::dim,9);
    fill_round_rect(c,{x+24,y+96,w-140,30},theme::bg,6);
    c.text(x+34,y+116,short_name(render_pending_.name,54),theme::text,10,true);
    button({x+w-104,y+96,34,30},"render:preset_prev","<");button({x+w-62,y+96,34,30},"render:preset_next",">");
    const int left_width=w-290,right=x+w-244;
    auto value=[&](int row,const std::string& label,const std::string& text,const char* minus,const char* plus){
        c.text(x+24,y+row+10,label,theme::dim,9);
        fill_round_rect(c,{x+24,y+row+18,left_width-80,25},theme::bg,5);
        c.text(x+34,y+row+35,text,theme::text,10,true);
        button({x+24+left_width-72,y+row+18,30,25},minus,"-");button({x+24+left_width-36,y+row+18,30,25},plus,"+");
    };
    value(145,tr("project.width","Width"),std::to_string(render_pending_.width),"render:width_down","render:width_up");
    value(196,tr("project.height","Height"),std::to_string(render_pending_.height),"render:height_down","render:height_up");
    value(247,tr("project.frame_rate","Frame rate"),motion_number(render_pending_.fps,3)+" fps","render:fps_down","render:fps_up");
    value(298,tr("render.video_bitrate","Video bitrate"),std::to_string(render_pending_.video_kbps)+" kbps","render:vbit_down","render:vbit_up");
    value(349,tr("render.aac_bitrate","AAC bitrate"),std::to_string(render_pending_.audio_kbps)+" kbps","render:abit_down","render:abit_up");
    c.text(right,y+155,tr("render.output_size","Output size"),theme::dim,9);
    button({right,y+170,64,26},"render:size720","720p");button({right+72,y+170,64,26},"render:size1080","1080p");button({right+144,y+170,72,26},"render:size2160","2160p");
    button({right,y+214,216,28},"render:gpu",std::string(render_pending_.gpu?"[x] ":"[ ] ")+tr("render.gpu_encoder","GPU encoder"),render_pending_.gpu);
    c.text(right,y+262,short_name(engine_.gpu_backend().label,28),theme::dim,8);
    c.text(right,y+298,tr("render.project_size","Project resolution"),theme::dim,9);
    c.text(right,y+321,std::to_string(project_.settings.width)+" x "+std::to_string(project_.settings.height),theme::text,11,true);
    c.text(right,y+357,tr("render.duration","Duration")+": "+timecode(project_.duration()),theme::dim,9);
    c.line(x+24,y+405,x+w-24,y+405,theme::borderSoft);
    button({x+24,y+420,180,28},"render:fsr",std::string(render_fsr_?"[x] ":"[ ] ")+"FSR 1 (EASU + RCAS)",render_fsr_);
    c.text(x+220,y+438,tr("render.sharpness","Sharpness")+": "+std::to_string(int(std::lround(render_fsr_sharpness_*100)))+"%",theme::text,9);
    button({x+w-104,y+420,34,28},"render:sharp_down","-",false,render_fsr_);button({x+w-62,y+420,34,28},"render:sharp_up","+",false,render_fsr_);
    c.text(x+24,y+474,tr("render.fsr_hint","FSR: upscale from project resolution. CPU processing."),theme::dim,8);
    button({x+w-316,y+h-48,140,30},"render:cancel",tr("common.cancel","Cancel"));
    button({x+w-164,y+h-48,140,30},"render:start",tr("render.start","Render"),true);
    c.pop_clip();
}

void EditorApp::draw_button(Canvas& c,const Button& b){
    const bool hover=b.enabled&&b.r.contains(mouse_x_,mouse_y_);
    const bool pressed=hover&&mouse_down_&&b.enabled;
    auto& hv=ui_hover_anim_[b.id];auto& pv=ui_press_anim_[b.id];
    const double hover_step=1.0-std::exp(-ui_anim_dt_*20.0),press_step=1.0-std::exp(-ui_anim_dt_*30.0);
    hv=static_cast<float>(hv+(static_cast<double>(hover?1.0:0.0)-hv)*hover_step);
    pv=static_cast<float>(pv+(static_cast<double>(pressed?1.0:0.0)-pv)*press_step);
    if(std::abs(hv-(hover?1.0f:0.0f))>0.012f||std::abs(pv-(pressed?1.0f:0.0f))>0.012f)ui_animation_active_=true;

    const bool compact_icon=!b.icon.empty()&&b.label.empty()&&b.r.w<=38&&b.r.h<=38;
    Rect vr=b.r;vr.y+=static_cast<int>(std::lround(pv));
    const int radius=2;
    Color fill=b.active?mix_color(theme::accent2,theme::accent,hv):mix_color(theme::panel3,theme::raised,hv);
    if(!b.enabled)fill=Color{34,34,39};
    fill=mix_color(fill,theme::bg,pv*0.18);

    if(compact_icon&&!b.active){
        if(hv>0.01f){Color overlay=theme::raised;overlay.a=static_cast<std::uint8_t>(std::lround(205.0*hv));fill_round_rect(c,vr,overlay,radius);}
    }else{
        const int shadow_alpha=static_cast<int>(std::lround((1.0-pv)*22.0));
        if(b.enabled&&shadow_alpha>0)fill_round_rect(c,{vr.x,vr.y+1,vr.w,vr.h},Color{0,0,0,shadow_alpha},radius);
        fill_round_rect(c,vr,fill,radius);
    }
    if(b.active){Color border=mix_color(theme::accent,theme::accentHover,hv);draw_round_border(c,vr,border,radius);}
    else if(!compact_icon&&hv>0.12f){Color border=theme::border;border.a=static_cast<std::uint8_t>(std::lround(120+80*hv));draw_round_border(c,vr,border,radius);}

    Color base_text=!b.enabled?theme::dim2:(b.active?Color{255,255,255}:theme::dim);
    const Color text=b.enabled?mix_color(base_text,theme::text,hv):base_text;
    if(!b.icon.empty()){
        Rect ir{};
        const int icon_size=std::min(20,vr.h-4);
        if(!b.label.empty()&&vr.w>=52)ir={vr.x+8,vr.y+(vr.h-icon_size)/2,icon_size,icon_size};
        else ir={vr.x+(vr.w-icon_size)/2,vr.y+(vr.h-icon_size)/2,icon_size,icon_size};
        icons::draw(c,ir,b.icon,text);
        if(!b.label.empty()&&vr.w>=52){const int size=vr.h<=24?9:10;c.text(ir.x+ir.w+7,vr.y+(vr.h+size)/2-1,b.label,text,size,true);}
    }else{
        const int size=vr.h<=24?9:10;const int tw=c.text_width(b.label,size,true);c.text(vr.x+(vr.w-tw)/2,vr.y+(vr.h+size)/2-1,b.label,text,size,b.active);
    }
}

void EditorApp::draw_toolbar(Canvas& c){
    c.fill_rect(layout_.toolbar,theme::panel);
    c.line(0,layout_.toolbar.y+layout_.toolbar.h-1,layout_.toolbar.w,layout_.toolbar.y+layout_.toolbar.h-1,theme::borderSoft);
    int x=layout_.toolbar.x+8,y=layout_.toolbar.y+3,h=28;
    auto add=[&](std::string id,int w,bool active=false,bool enabled=true,std::string icon={}){
        Button b{{x,y,w,h},std::move(id),{},active,enabled,std::move(icon)};
        buttons_.push_back(b);draw_button(c,b);x+=w+4;
    };
    auto sep=[&]{c.line(x+1,layout_.toolbar.y+10,x+1,layout_.toolbar.y+30,theme::border);x+=10;};

    // Keep the main toolbar intentionally small. Commands that already have a
    // dedicated timeline/pane control live in their menu instead of appearing
    // twice here.
    add("new",30,false,true,"file");
    add("open",30,false,true,"folder-open");
    add("save",30,false,true,"save");
    sep();
    add("undo",30,false,undo_.can_undo(),"undo");
    add("redo",30,false,undo_.can_redo(),"redo");
    add("cut_clipboard",30,false,!edit_.selection.empty(),"cut");
    add("copy",30,false,!edit_.selection.empty(),"copy");
    add("paste",30,false,!clipboard_.empty(),"paste");
    sep();
    add("import",30,false,true,"import");
    add("render",30,false,!project_.clips.empty(),"export");

    if(!rendering_){
        Rect r{layout_.toolbar.x+layout_.toolbar.w-40,layout_.toolbar.y+3,30,27};
        Button export_button{r,"render","",true,!project_.clips.empty(),"export"};
        buttons_.push_back(export_button);draw_button(c,export_button);
    }
    if(rendering_){
        const int pw=110,px=std::max(x+8,layout_.toolbar.x+layout_.toolbar.w-pw-10);
        c.fill_rect({px,layout_.toolbar.y+13,pw,5},Color{24,24,24});
        c.fill_rect({px,layout_.toolbar.y+13,static_cast<int>(pw*render_progress_.load()),5},theme::accent);
        Rect cancel{px,layout_.toolbar.y+20,pw,20};buttons_.push_back({cancel,"cancel_render",tr("render.cancel_render","Cancel Render"),false,true});c.text(px+4,cancel.y+14,tr("render.cancel_render","Cancel Render"),theme::text,9);
    }
}

void EditorApp::draw_document(Canvas &c) {
  c.fill_rect(layout_.document, theme::bg);
  const int width = std::min(320, std::max(160, layout_.document.w - 150));
  Rect tab{layout_.document.x + 5, layout_.document.y + 2, width,
           layout_.document.h - 2};
  c.fill_rect(tab, theme::panel3);
  c.line(tab.x, tab.y + tab.h - 1, tab.x + tab.w, tab.y + tab.h - 1,
         theme::accent);
  c.push_clip(tab);
  c.text(tab.x + 12, tab.y + 18,
         (dirty_ ? "* " : "") + short_name(project_.name, 38), theme::text, 10,
         true);
  c.pop_clip();
  // A single-project editor: the tab saves the document rather than
  // presenting nonfunctional tab-close or multiple-document controls.
  buttons_.push_back({tab, "save", "", false, true});
  const int workspace_x=tab.x+tab.w+18;
  for(int i=0;i<2;++i){Button b{{workspace_x+i*110,tab.y+2,104,23},i==0?"workspace_edit":"workspace_animation",i==0?tr("workspace.edit","Edit"):tr("workspace.animation","Animation"),i==0?!animation_workspace_:animation_workspace_,true};buttons_.push_back(b);draw_button(c,b);}
  const std::string state =
      dirty_ ? tr("ui.modified", "Modified") : tr("ui.saved", "Saved");
  c.text(layout_.document.x + layout_.document.w - c.text_width(state, 9) - 14,
         tab.y + 18, state, dirty_ ? theme::warning : theme::dim, 9);
}

void EditorApp::draw_tools(Canvas &c) {
  c.fill_rect(layout_.tools, theme::panel);
  c.line(layout_.tools.w - 1, layout_.tools.y, layout_.tools.w - 1,
         layout_.tools.y + layout_.tools.h, theme::borderSoft);
  int y = layout_.toolbar.y + 3;
  const auto ids = edit_.selection.clips();
  const Clip *clip = ids.empty()
                         ? nullptr
                         : project_.clip_by_id(edit_.selection.primary_clip());
  const Track *track = clip ? project_.track_by_id(clip->track_id) : nullptr;
  auto add = [&](const std::string &id, const std::string &glyph,
                 bool active = false, bool enabled = true) {
    if (y + 28 > layout_.tools.y + layout_.tools.h)
      return;
    Button b{{5, y, 31, 28}, id, "", active, enabled, glyph};
    buttons_.push_back(b);
    draw_button(c, b);
    y += 34;
  };
  add("tool_select", "mouse-pointer", tool_mode_ == ToolMode::Select);
  add("tool_split", "cut", tool_mode_ == ToolMode::Split);
  add("tool_mask", "brush", tool_mode_ == ToolMode::PaintMask);
  c.line(9, y, 32, y, theme::borderSoft);
  y += 7;
  add("insert_text", "font");
  add(clip ? "pan_crop:" + std::to_string(clip->id) : "inspector_crop", "crop",
      false, track && track->kind == TrackKind::Video && !clip->locked);
  add("snap", "magnet", project_.snapping);
  add("lock_selection", "lock", clip && clip->locked, clip != nullptr);
  c.line(9, y, 32, y, theme::borderSoft);
  y += 7;
  add("timeline_zoom_in", "search-plus");
  add("timeline_zoom_out", "search-minus");
  add("timeline_fit", "compress", false, !project_.clips.empty());
}

void EditorApp::draw_inspector(Canvas &c) {
  const auto r = layout_.inspector;
  if (r.w == 0)
    return;
  draw_card(c, r, theme::panel);
  c.push_clip(r);
  int y = r.y + 5;
  bool inspector_header = true;
  auto button = [&](Rect rr, const std::string &id, const std::string &text,
                    bool active = false, bool enabled = true) {
    if (rr.y + rr.h > r.y + r.h - 4 || (!inspector_header && rr.y < r.y + 37))
      return;
    Button b{rr, id, text, active, enabled};
    buttons_.push_back(b);
    draw_button(c, b);
  };
  const int tabw = (r.w - 10) / 3;
  const std::array<std::string, 3> tabs = {tr("ui.properties", "Properties"),
                                           tr("ui.effects", "Effects"),
                                           tr("ui.history", "History")};
  for (int i = 0; i < 3; ++i)
    button({r.x + 5 + i * tabw, y, tabw - 2, 25},
           "inspector_tab:" + std::to_string(i), tabs[i], i == inspector_tab_);
  y += 40;
  inspector_header = false;
  const int content_top = r.y + 37;
  inspector_scroll_ =
      std::clamp(inspector_scroll_, 0,
                 std::max(0, inspector_content_height_ - (r.h - 37)));
  y -= inspector_scroll_;
  c.push_clip({r.x, content_top, r.w, std::max(1, r.h - 37)});
  auto finish = [&] {
    inspector_content_height_ =
        std::max(0, y + inspector_scroll_ - content_top + 8);
    c.pop_clip();
    c.pop_clip();
  };
  auto text = [&](const std::string &value, Color color = theme::text,
                  int size = 9, bool bold = false) {
    if (y + 3 < r.y + r.h)
      c.text(r.x + 12, y, value, color, size, bold);
    y += 21;
  };
  auto section = [&](const std::string &value) {
    y += 5;
    if (y + 3 < r.y + r.h) {
      c.line(r.x + 1, y - 13, r.x + r.w - 2, y - 13, theme::borderSoft);
      c.text(r.x + 12, y, value, theme::text, 9, true);
    }
    y += 23;
  };
  if (inspector_tab_ == 2) {
    text(tr("ui.document", "Document"), theme::dim);
    text(short_name(project_.name, 28), theme::text, 10, true);
    text(dirty_ ? tr("ui.modified", "Modified") : tr("ui.saved", "Saved"),
         dirty_ ? theme::warning : theme::dim);
    section(tr("ui.history", "History"));
    button({r.x + 12, y, r.w - 24, 27}, "undo", tr("menu.edit.undo", "Undo"),
           false, undo_.can_undo());
    y += 34;
    button({r.x + 12, y, r.w - 24, 27}, "redo", tr("menu.edit.redo", "Redo"),
           false, undo_.can_redo());
    y += 48;
    text(tr("ui.history_hint", "Ctrl+Z / Ctrl+Y"), theme::dim);
    finish();
    return;
  }
  auto ids = edit_.selection.clips();
  const Clip *clip = ids.empty()
                         ? nullptr
                         : project_.clip_by_id(edit_.selection.primary_clip());
  const MediaItem *media = clip ? project_.media_by_id(clip->media_id())
                                : project_.media_by_id(edit_.selected_media);
  if (media) {
    text(short_name(media->name, 28), theme::text, 10, true);
    text(std::to_string(media->width) + " × " + std::to_string(media->height) +
             " · " + motion_number(media->fps, 2) + " fps",
         theme::dim, 8);
  }
  if (!clip) {
    section(tr("ui.properties", "Properties"));
    text(tr("ui.select_clip", "Select a timeline clip"), theme::dim);
    button({r.x + 12, y, r.w - 24, 26}, "import",
           tr("menu.file.import", "Import Media..."));
    finish();
    return;
  }
  if (ids.size() > 1)
    text(tr("ui.first_selection", "Showing first selected clip"), theme::dim,
         8);
  text(tr("ui.start", "Start") + "  " + timecode(clip->start), theme::dim, 8);
  text(tr("ui.duration", "Duration") + "  " + timecode(clip->duration),
       theme::dim, 8);
  const Track *track = project_.track_by_id(clip->track_id);
  const bool video = track && track->kind == TrackKind::Video;
  const bool editable = !clip->locked && (!track || !track->locked);
  if (inspector_tab_ == 1) {
    section(tr("ui.effects", "Effects"));
    const auto &effects = video ? clip->video_effects : clip->audio_effects;
    if (effects.empty())
      text(tr("ui.no_effects", "No event effects"), theme::dim);
    for (const auto &effect : effects) {

      const auto *def = video ? effect_definition(effect.definition_id)
                              : audio_effect_definition(effect.definition_id);
      const std::string name = def ? tr("catalog."+def->name,def->name) : effect.definition_id;
      button({r.x + 12, y, 27, 23}, "inspector_fx:" + std::to_string(effect.id),
             effect.enabled ? "ON" : "OFF", effect.enabled, editable);
      button({r.x + 44, y, r.w - 56, 23},
             video ? "event_fx:" + std::to_string(clip->id)
                   : "event_audio_fx:" + std::to_string(clip->id),
             short_name(name, 23));
      y += 29;
    }
    button({r.x + 12, y, r.w - 24, 27},
           video ? "event_fx:" + std::to_string(clip->id)
                 : "event_audio_fx:" + std::to_string(clip->id),
           tr("ui.edit_effects", "Edit effects..."), false, editable);
    finish();
    return;
  }
  auto parameter = [&](const std::string &key, const std::string &label,
                       double value, int precision) {
    c.text(r.x + 12, y + 16, label, theme::dim, 9);
    Rect box{r.x + r.w - 122, y, 62, 23};
    c.fill_rect(box, theme::bg);
    c.stroke_rect(box, theme::borderSoft);
    c.text(box.x + 5, y + 16, motion_number(value, precision), theme::text, 9);
    button({r.x + r.w - 56, y, 21, 23}, "inspector_param:" + key + ":-", "-",
           false, editable);
    button({r.x + r.w - 31, y, 21, 23}, "inspector_param:" + key + ":+", "+",
           false, editable);
    y += 29;
  };
  section(video ? tr("ui.transform", "Transform") : tr("ui.audio", "Audio"));
  if (video) {
    const auto motion =
        sample_motion(clip->video_motion,
                      std::clamp(playhead_ - clip->start, 0.0, clip->duration));
    parameter("x", tr("ui.position_x", "Position X"), motion.center_x * 100, 1);
    parameter("y", tr("ui.position_y", "Position Y"), motion.center_y * 100, 1);
    parameter("zoom", tr("ui.scale", "Scale"), motion.zoom * 100, 0);
    parameter("rotation", tr("ui.rotation", "Rotation"), motion.rotation, 1);
    parameter("opacity", tr("ui.opacity", "Opacity"), clip->opacity * 100, 0);
    button({r.x + 12, y, r.w - 24, 26}, "pan_crop:" + std::to_string(clip->id),
           tr("ui.pan_crop_keys", "Pan/Crop · Keyframes"), false, editable);
    y += 34;
  } else
    parameter("gain", tr("ui.gain", "Gain"), clip->gain * 100, 0);
  button({r.x + 12, y, r.w - 24, 26},
         video ? "event_fx:" + std::to_string(clip->id)
               : "event_audio_fx:" + std::to_string(clip->id),
         tr("ui.edit_effects", "Edit effects..."), false, editable);
  finish();
}

bool EditorApp::dispatch_inspector_button(const std::string &id) {
  if (id.rfind("inspector_tab:", 0) == 0) {
    inspector_tab_ = std::clamp(std::atoi(id.c_str() + 14), 0, 2);
    inspector_scroll_ = 0;
    return true;
  }
  if (id == "timeline_zoom_in" || id == "timeline_zoom_out") {
    auto &g = layout_.timeline_geo;
    const double anchor = playhead_;
    const double old_x = (anchor - g.scroll_sec) * g.px_per_sec;
    g.px_per_sec = std::clamp(
        g.px_per_sec * (id == "timeline_zoom_in" ? 1.25 : 0.8), 8.0, 900.0);
    g.scroll_sec = std::max(0.0, anchor - old_x / g.px_per_sec);
    clamp_timeline_scroll();
    return true;
  }
  if (id == "timeline_fit") {
    fit_timeline_requested_ = true;
    return true;
  }
  if (id.rfind("inspector_param:", 0) != 0 && id.rfind("inspector_fx:", 0) != 0)
    return false;
  const auto ids = edit_.selection.clips();
  Clip *clip = ids.empty()
                   ? nullptr
                   : project_.clip_by_id(edit_.selection.primary_clip());
  if (!clip || clip->locked)
    return true;
  const auto *track = project_.track_by_id(clip->track_id);
  if (track && track->locked)
    return true;
  undo_.begin(project_);
  if (id.rfind("inspector_fx:", 0) == 0) {
    const int effect_id = std::atoi(id.c_str() + 13);
    for (auto *effects : {&clip->video_effects, &clip->audio_effects})
      for (auto &effect : *effects)
        if (effect.id == effect_id)
          effect.enabled = !effect.enabled;
  } else {
    const auto suffix = id.substr(16);
    const auto split = suffix.find(':');
    if (split == std::string::npos) {
      undo_.cancel();
      return true;
    }
    const auto key = suffix.substr(0, split);
    const double sign = suffix.substr(split + 1) == "+" ? 1.0 : -1.0;
    const double time =
        std::clamp(playhead_ - clip->start, 0.0, clip->duration);
    auto motion = sample_motion(clip->video_motion, time);
    bool transform = true;
    if (key == "x")
      motion.center_x = std::clamp(motion.center_x + sign * .01, 0.0, 1.0);
    else if (key == "y")
      motion.center_y = std::clamp(motion.center_y + sign * .01, 0.0, 1.0);
    else if (key == "zoom")
      motion.zoom = std::clamp(motion.zoom + sign * .05, 1.0, 8.0);
    else if (key == "rotation")
      motion.rotation = std::clamp(motion.rotation + sign, -360.0, 360.0);
    else if (key == "opacity") {
      clip->opacity = std::clamp(clip->opacity + sign * .05, 0.0, 1.0);
      transform = false;
    } else if (key == "gain") {
      clip->gain = std::clamp(clip->gain + sign * .05, 0.0, 4.0);
      transform = false;
    } else {
      undo_.cancel();
      return true;
    }
    if (transform)
      clip->video_motion.set_key(time, motion.center_x, motion.center_y,
                                 motion.zoom, motion.rotation);
  }
  if (undo_.commit(project_)) {
    mark_dirty();
    engine_.clear_composite_cache();
    request_preview(true);
    resync_audio_preview(true);
  }
  return true;
}

void EditorApp::draw_bin(Canvas& c){
    draw_card(c,layout_.bin,theme::panel,10);
    constexpr int pane_toolbar=34, tabs_h=30;
    const int tab_y=layout_.bin.y+pane_toolbar;
    const int top=tab_y+tabs_h;
    const int bottom=layout_.bin.y+layout_.bin.h-1;

    c.fill_rect({layout_.bin.x+1,layout_.bin.y+1,layout_.bin.w-2,pane_toolbar},theme::panel2);
    if(bin_tab_==BinTab::VideoFx||bin_tab_==BinTab::AudioFx){
        icons::draw(c,{layout_.bin.x+10,layout_.bin.y+10,13,13},"search",theme::dim);
        const int sx=layout_.bin.x+30,sw=std::max(100,layout_.bin.w-42);Rect search{sx,layout_.bin.y+6,sw,23};
        fill_round_rect(c,search,theme::bg,7);draw_round_border(c,search,fx_search_editing_?theme::accent:theme::borderSoft,7);
        buttons_.push_back({search,"fx_search","",fx_search_editing_,true});
        c.text(sx+6,layout_.bin.y+18,fx_search_query_.empty()?tr("ui.search_plugins","Search plug-ins"):short_name(fx_search_query_,48),fx_search_query_.empty()?theme::dim:theme::text,9);
    }else{
        int bx=layout_.bin.x+8;
        auto small=[&](std::string id,std::string icon,bool active=false){
            Button b{{bx,layout_.bin.y+5,28,24},std::move(id),{},active,true,std::move(icon)};buttons_.push_back(b);draw_button(c,b);bx+=32;
        };
        small("bin_list","list",media_view_==MediaView::List);
        small("bin_grid","th-large",media_view_==MediaView::Grid);
        small("bin_search","search",search_editing_||!search_query_.empty());
        if(search_editing_||!search_query_.empty()){
            const int sx=bx+3,sw=std::max(80,layout_.bin.w-(sx-layout_.bin.x)-10);
            Rect sr{sx,layout_.bin.y+7,sw,21};fill_round_rect(c,sr,theme::bg,7);draw_round_border(c,sr,search_editing_?theme::accent:theme::borderSoft,7);
            c.text(sx+5,layout_.bin.y+18,search_query_.empty()?tr("ui.search_placeholder","type to search..."):short_name(search_query_,32),search_query_.empty()?theme::dim:theme::text,9);
        }
    }

    if(bin_tab_==BinTab::ProjectMedia){
        const int tree_w=std::clamp(layout_.bin.w/3,110,150);
        c.fill_rect({layout_.bin.x+1,top,tree_w-1,bottom-top},theme::panel);
        c.line(layout_.bin.x+tree_w-1,top+6,layout_.bin.x+tree_w-1,bottom-6,theme::borderSoft);
        int tree_y=7;
        auto folder_row=[&](const std::string& id,const std::string& label,bool expanded,int indent=0,bool active=false){
            Rect r{layout_.bin.x+5+indent,top+tree_y,tree_w-10-indent,21};
            if(active)fill_round_rect(c,r,theme::raised,6);
            buttons_.push_back({r,id,"",active,true});
            icons::draw(c,{r.x+4,r.y+4,12,12},expanded?"caret-down":"caret-right",active?theme::text:Color{170,170,170});
            icons::draw(c,{r.x+22,r.y+3,14,14},expanded?"folder-open":"folder",theme::dim);
            c.push_clip(r);c.text(r.x+42,r.y+15,label,active?theme::text:Color{170,170,170},9,active);c.pop_clip();
            tree_y+=22;
        };
        auto leaf_row=[&](const std::string& id,const std::string& label,bool active,int indent=28,std::string icon={}){
            Rect r{layout_.bin.x+5+indent,top+tree_y,tree_w-10-indent,21};
            if(active)fill_round_rect(c,r,theme::raised,6);
            buttons_.push_back({r,id,"",active,true});
            if(!icon.empty())icons::draw(c,{r.x+4,r.y+3,14,14},icon,active?theme::text:Color{155,155,155});
            c.push_clip(r);c.text(r.x+(icon.empty()?7:24),r.y+15,label,active?theme::text:Color{170,170,170},9,active);c.pop_clip();
            tree_y+=21;
        };

        // Every visible Project Media tree row has an action. All Media is the
        // root filter; folders expand/collapse like an explorer tree.
        Rect all_row{layout_.bin.x+5,top+tree_y,tree_w-10,21};
        const bool all_active=media_filter_==MediaFilter::All;
        if(all_active)fill_round_rect(c,all_row,theme::raised,6);
        buttons_.push_back({all_row,"filter_all","",all_active,true});
        icons::draw(c,{all_row.x+4,all_row.y+4,12,12},"caret-down",all_active?theme::text:Color{170,170,170});
        icons::draw(c,{all_row.x+22,all_row.y+3,14,14},"film",theme::dim);
        c.text(all_row.x+42,all_row.y+15,tr("ui.all_media","All Media"),all_active?theme::text:Color{170,170,170},9,all_active);
        tree_y+=24;

        folder_row("tree_media_bins",tr("ui.media_bins","Media Bins"),media_bins_expanded_,16);
        if(media_bins_expanded_)leaf_row("tree_imported",tr("ui.imported","Imported"),media_filter_==MediaFilter::All,38,"film");

        folder_row("tree_by_type",tr("ui.by_type","By Type"),by_type_expanded_,16);
        if(by_type_expanded_){
            leaf_row("filter_audio",tr("ui.audio","Audio"),media_filter_==MediaFilter::Audio,38,"file-audio");
            leaf_row("filter_video",tr("ui.video","Video"),media_filter_==MediaFilter::Video,38,"film");
            leaf_row("filter_stills",tr("ui.stills","Stills"),media_filter_==MediaFilter::Stills,38,"file");
        }

        folder_row("tree_tags",tr("ui.tags","Tags"),tags_expanded_,16);
        if(tags_expanded_)leaf_row("tree_untagged",tr("ui.untagged","Untagged"),media_filter_==MediaFilter::All,38,"file");

        const int grid_x=layout_.bin.x+tree_w;
        const int grid_w=layout_.bin.w-tree_w;
        c.fill_rect({grid_x,top,grid_w,bottom-top},theme::panel2);
        int index=0;
        if(media_view_==MediaView::Grid){
            const int gap=8;
            const int card_w=std::clamp((grid_w-gap*3)/2,72,150);
            const int thumb_h=std::max(52,card_w*9/16);
            const int card_h=thumb_h+24;
            const int cols=std::max(1,(grid_w-gap)/(card_w+gap));
            for(const auto& m:project_.media){
                if(!media_visible(m))continue;
                const int col=index%cols,row=index/cols;
                const int x=grid_x+gap+col*(card_w+gap);
                const int y=top+gap+row*(card_h+gap);
                if(y+card_h>bottom-3)break;
                Rect card{x,y,card_w,card_h};bin_rows_.push_back({card,m.id});
                const bool selected=m.id==edit_.selected_media;
                Rect thumb{x,y,card_w,thumb_h};
                fill_round_rect(c,thumb,m.has_video?Color{43,47,54}:Color{40,40,45},7);
                draw_round_border(c,thumb,selected?theme::accent:theme::borderSoft,7);
                icons::draw(c,{x+card_w/2-9,y+std::max(3,thumb_h/2-9),18,18},m.has_video?"film":"file-audio",m.has_video?Color{120,132,142}:Color{118,118,118});
                if(m.generated_vector.enabled){if(auto frame=engine_.vector_thumbnail(m.generated_vector,.3,card_w,thumb_h))c.image(thumb,*frame);}
                else if(m.has_video&&!m.generated_text.enabled){
                    const auto& path=m.proxy_path.empty()?m.path:m.proxy_path;
                    if(auto frame=engine_.timeline_thumbnail(path,std::min(0.3,std::max(0.0,m.duration*.1)),card_w,thumb_h)){
                        c.push_clip(thumb);c.image(thumb,*frame);c.pop_clip();c.stroke_rect(thumb,selected?theme::accent:theme::borderSoft);
                    }
                }
                std::ostringstream dur;dur<<std::fixed<<std::setprecision(1)<<m.duration<<"s";
                const int dtw=c.text_width(dur.str(),8);c.fill_rect({x+card_w-dtw-8,y+thumb_h-14,dtw+6,12},Color{20,20,20});c.text(x+card_w-dtw-5,y+thumb_h-5,dur.str(),Color{210,210,210},8);
                c.text(x+2,y+card_h-6,short_name(m.name,static_cast<std::size_t>(std::max(10,card_w/7))),selected?theme::accent:theme::text,9);
                ++index;
            }
        }else{
            int yy=top+5;
            for(const auto& m:project_.media){
                if(!media_visible(m))continue;
                Rect row{grid_x+4,yy,grid_w-8,24};if(yy+24>bottom)break;
                const bool selected=m.id==edit_.selected_media;if(selected)fill_round_rect(c,row,theme::accent2,6);
                bin_rows_.push_back({row,m.id});c.text(row.x+6,row.y+16,short_name(m.name,42),selected?theme::accent:theme::text,9,selected);
                c.text(row.x+std::max(90,row.w-88),row.y+16,m.has_video?(m.has_audio?tr("ui.audio_video_short","A/V"):tr("ui.video","Video")):tr("ui.audio","Audio"),theme::dim,8);yy+=25;++index;
            }
        }
        if(index==0)c.text(grid_x+18,top+34,project_.media.empty()?tr("ui.import_hint","Import media"):tr("ui.no_matches","No matches"),theme::dim,10);
    }else{
        c.fill_rect({layout_.bin.x,top,layout_.bin.w,bottom-top},theme::panel2);
        const int px=layout_.bin.x+18, py=top+24;
        if(bin_tab_==BinTab::Generators){
            c.text(px,py,tr("ui.media_generators","Media Generators"),theme::text,11,true);
            Rect card{px,py+28,std::min(310,layout_.bin.w-36),126};draw_card(c,card,theme::panel3,10);
            c.fill_rect({card.x+12,card.y+13,94,68},Color{12,15,19});c.stroke_rect({card.x+12,card.y+13,94,68},Color{74,86,101});c.text(card.x+25,card.y+55,tr("ui.sample","Sample"),Color{239,242,247},16,true);
            c.text(card.x+120,card.y+30,tr("ui.titles_text","Titles & Text"),theme::text,10,true);c.text(card.x+120,card.y+49,tr("ui.native_titles_text","Inter · native generator"),theme::dim,8);
            c.text(card.x+120,card.y+66,tr("text.generator_features","Text / position / outline / shadow"),theme::dim,8);
            Button create{{card.x+120,card.y+82,126,24},"insert_text",tr("ui.create_at_cursor","Create at Cursor"),false,true,"plus"};buttons_.push_back(create);draw_button(c,create);
            c.text(px,py+174,tr("text.generator_editable_hint","Generated text stays editable after it is placed on the timeline."),theme::dim,9);
        }else if(bin_tab_==BinTab::VideoFx){
            const int list_w=std::clamp(layout_.bin.w*42/100,220,340);
            const int lx=layout_.bin.x+6,ly=top+6,list_bottom=bottom-6;
            c.fill_rect({lx,ly,list_w,list_bottom-ly},Color{28,28,28});c.stroke_rect({lx,ly,list_w,list_bottom-ly},Color{54,54,54});
            c.text(lx+8,ly+17,tr("fx.all","v  All"),theme::text,9,true);
            const std::string ofx_badge="OFX "+std::to_string(ofx_registry_.image_effect_count())+"  Boris "+std::to_string(ofx_registry_.boris_fx_count());
            c.text(lx+list_w-c.text_width(ofx_badge,8)-8,ly+17,ofx_badge,ofx_registry_.boris_fx_count()?Color{133,203,255}:theme::dim,8,true);
            int row=ly+25;
            std::string q=fx_search_query_;q=search_casefold(std::move(q));
            for(const auto* defp:available_effect_definitions()){
                if(!defp) continue;
        const auto& def=*defp;
                std::string hay=def.name+" "+tr("catalog."+def.name,def.name)+" "+tr("catalog."+def.category,def.category);hay=search_casefold(std::move(hay));
                if(!q.empty()&&hay.find(q)==std::string::npos)continue;
                if(row+20>list_bottom-4)break;
                const bool external=def.id.rfind("ofx:",0)==0;const bool active=selected_fx_definition_==def.id;Rect rr{lx+3,row,list_w-6,20};
                if(active)fill_round_rect(c,rr,theme::accent2,6);else if(rr.contains(mouse_x_,mouse_y_))fill_round_rect(c,rr,theme::raised,6);
                buttons_.push_back({rr,"fx_select:"+def.id,"",active,true});
                c.text(rr.x+5,rr.y+14,external?"OFX":"FX",active?Color{235,248,255}:Color{80,190,235},8,true);
                c.text(rr.x+(external?34:28),rr.y+14,short_name(tr("catalog."+def.name,def.name),30),active?Color{255,255,255}:theme::text,9);
                row+=20;
            }
            const int rx=lx+list_w+10,rw=layout_.bin.x+layout_.bin.w-rx-8;
            c.text(rx,ly+17,tr("fx.preset","Preset:"),theme::text,10,true);
            const EffectDefinition* selected=effect_definition(selected_fx_definition_);
            if(selected&&rw>80){
                Rect preset{rx+6,ly+30,std::min(130,rw-12),112};c.fill_rect(preset,Color{246,246,246});c.stroke_rect(preset,Color{85,85,85});
                Rect thumb{preset.x+9,preset.y+8,preset.w-18,68};c.fill_rect(thumb,Color{52,52,52});
                for(int i=0;i<thumb.w;i+=6){int v=45+(i*150/std::max(1,thumb.w));c.fill_rect({thumb.x+i,thumb.y,std::min(6,thumb.w-i),thumb.h},Color{v,110,std::min(235,v+55)});}
                c.text(preset.x+8,preset.y+93,tr("fx.default","(Default)"),Color{75,75,75},8);
                c.text(rx,ly+160,selected->name,theme::text,10,true);const bool selected_ofx=selected->id.rfind("ofx:",0)==0;c.text(rx,ly+178,selected->category+(selected_ofx?tr("fx.detected_plugin_suffix"," - detected host plug-in"):tr("fx.native_suffix"," - Native KoraLo FX")),theme::dim,8);
                const Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());
                Button add{{rx,ly+192,std::min(130,rw),22},"fx_add_selected",clip?tr("fx.add_to_event","Add to Event"):tr("fx.select_video_event","Select video event"),false,clip!=nullptr};buttons_.push_back(add);draw_button(c,add);
                if(clip){ Button editfx{{rx+std::min(136,rw-112),ly+192,std::min(106,std::max(80,rw-136)),22},"event_fx:"+std::to_string(clip->id),tr("fx.open_editor","Open Editor")};buttons_.push_back(editfx);draw_button(c,editfx);} 
                int chain_y=ly+224;
                if(clip){
                    c.text(rx,chain_y,tr("fx.event_chain","Event FX chain"),theme::text,9,true);chain_y+=17;
                    if(clip->video_effects.empty())c.text(rx,chain_y,tr("ui.no_effects","No event effects"),theme::dim,8);
                    for(const auto& effect:clip->video_effects){
                        if(chain_y+20>list_bottom)break;
                        const auto* def=effect_definition(effect.definition_id);const std::string name=def?tr("catalog."+def->name,def->name):effect.definition_id;Rect er{rx,chain_y,std::max(70,rw),19};
                        fill_round_rect(c,er,theme::panel3,5);c.text(er.x+5,er.y+13,short_name(name,24),effect.enabled?theme::text:theme::dim,8,true);
                        Button edit{{er.x+std::max(40,er.w-88),er.y+1,28,17},"fx_editor_open_inst:"+std::to_string(effect.id),tr("common.edit","Edit")};
                        Button toggle{{er.x+std::max(72,er.w-58),er.y+1,28,17},"fx_toggle_event:"+std::to_string(effect.id),effect.enabled?"ON":"OFF",effect.enabled,true};Button remove{{er.x+er.w-27,er.y+1,24,17},"fx_remove_event:"+std::to_string(effect.id),"X"};
                        buttons_.push_back(edit);draw_button(c,edit);buttons_.push_back(toggle);draw_button(c,toggle);buttons_.push_back(remove);draw_button(c,remove);chain_y+=21;
                        // Keep the browser useful after adding a plug-in: expose
                        // numeric parameters immediately, with real undoable
                        // changes instead of a decorative preset tile.
                        if(def&&effect.enabled){
                            for(const auto& pd:def->parameters){
                                if(pd.type!=EffectParameterType::Double||chain_y+18>list_bottom)continue;
                                const double value=effect_numeric(effect,pd.id,0.0,std::get<double>(pd.default_value));
                                c.text(rx+6,chain_y+12,short_name(tr("catalog."+pd.name,pd.name),12)+"  "+motion_number(value,2),theme::dim,8);
                                Button down{{rx+std::max(80,rw-54),chain_y,24,16},"fx_param_down:"+std::to_string(effect.id)+":"+pd.id,"-"};
                                Button up{{rx+std::max(106,rw-28),chain_y,24,16},"fx_param_up:"+std::to_string(effect.id)+":"+pd.id,"+"};
                                buttons_.push_back(down);draw_button(c,down);buttons_.push_back(up);draw_button(c,up);chain_y+=18;
                            }
                        }
                    }
                }
            }
        }else if(bin_tab_==BinTab::AudioFx){
            const int list_w=std::clamp(layout_.bin.w*42/100,220,340);
            const int lx=layout_.bin.x+6,ly=top+6,list_bottom=bottom-6;
            c.fill_rect({lx,ly,list_w,list_bottom-ly},Color{28,28,28});c.stroke_rect({lx,ly,list_w,list_bottom-ly},Color{54,54,54});
            c.text(lx+8,ly+17,tr("ui.audio_fx","Audio FX"),theme::text,9,true);
            int row=ly+25;std::string q=fx_search_query_;q=search_casefold(std::move(q));
            for(const auto* defp:available_audio_effect_definitions()){
                if(!defp)continue;
                const auto& def=*defp;std::string hay=def.name+" "+tr("catalog."+def.name,def.name)+" "+tr("catalog."+def.category,def.category);hay=search_casefold(std::move(hay));
                if(!q.empty()&&hay.find(q)==std::string::npos)continue;
                if(row+20>list_bottom-4)break;
                const bool active=selected_audio_fx_definition_==def.id;Rect rr{lx+3,row,list_w-6,20};if(active)fill_round_rect(c,rr,theme::accent2,6);else if(rr.contains(mouse_x_,mouse_y_))fill_round_rect(c,rr,theme::raised,6);
                buttons_.push_back({rr,"audio_fx_select:"+def.id,"",active,true});c.text(rr.x+5,rr.y+14,"AF",active?Color{235,248,255}:Color{190,136,235},8,true);c.text(rr.x+30,rr.y+14,short_name(tr("catalog."+def.name,def.name),29),active?Color{255,255,255}:theme::text,9);row+=20;
            }
            const int rx=lx+list_w+10,rw=layout_.bin.x+layout_.bin.w-rx-8;const EffectDefinition* selected=audio_effect_definition(selected_audio_fx_definition_);
            c.text(rx,ly+17,tr("audio_fx.effect","Audio effect"),theme::text,10,true);
            Clip* clip=project_.clip_by_id(edit_.selection.primary_clip());Track* clip_track=clip?project_.track_by_id(clip->track_id):nullptr;if(!clip_track||clip_track->kind!=TrackKind::Audio)clip=nullptr;
            Track* target_track=project_.track_by_id(selected_track_id_);if(!target_track||target_track->kind!=TrackKind::Audio)target_track=clip_track;
            if(selected){c.text(rx,ly+40,selected->name,theme::text,11,true);c.text(rx,ly+58,selected->category+tr("audio_fx.native_suffix"," · Native Audio FX"),theme::dim,8);
                Button add_event{{rx,ly+72,std::min(118,rw),24},"audio_fx_add_event",tr("audio_fx.add_to_event","Add to Event"),false,clip!=nullptr};buttons_.push_back(add_event);draw_button(c,add_event);
                Button add_track{{rx+124,ly+72,std::min(118,std::max(70,rw-124)),24},"audio_fx_add_track",tr("audio_fx.add_to_track","Add to Track"),false,target_track!=nullptr};buttons_.push_back(add_track);draw_button(c,add_track);
            }
            std::vector<EffectInstance>* chain=nullptr;std::string owner_prefix;int owner_id=0;int chain_y=ly+112;
            if(clip){chain=&clip->audio_effects;owner_prefix="event";owner_id=clip->id;c.text(rx,chain_y,tr("audio_fx.event_chain","Audio Event FX chain"),theme::text,9,true);}
            else if(target_track){chain=&target_track->audio_effects;owner_prefix="track";owner_id=target_track->id;c.text(rx,chain_y,tr("audio_fx.track_chain","Audio Track FX chain"),theme::text,9,true);}
            else c.text(rx,chain_y,tr("audio_fx.select_target","Select an audio event or track"),theme::dim,9);
            chain_y+=18;
            if(chain){if(chain->empty())c.text(rx,chain_y,tr("audio_fx.no_effects","No audio effects"),theme::dim,8);
                for(const auto& effect:*chain){if(chain_y+20>list_bottom)break;const auto* def=audio_effect_definition(effect.definition_id);Rect er{rx,chain_y,std::max(80,rw),19};fill_round_rect(c,er,theme::panel3,5);c.text(er.x+5,er.y+13,short_name(def?tr("catalog."+def->name,def->name):effect.definition_id,24),effect.enabled?theme::text:theme::dim,8,true);
                    Button tog{{er.x+std::max(72,er.w-58),er.y+1,28,17},"audio_fx_toggle:"+owner_prefix+":"+std::to_string(owner_id)+":"+std::to_string(effect.id),effect.enabled?"ON":"OFF",effect.enabled,true};Button rem{{er.x+er.w-27,er.y+1,24,17},"audio_fx_remove:"+owner_prefix+":"+std::to_string(owner_id)+":"+std::to_string(effect.id),"X"};buttons_.push_back(tog);draw_button(c,tog);buttons_.push_back(rem);draw_button(c,rem);chain_y+=21;
                    if(def&&effect.enabled)for(const auto& pd:def->parameters){if(pd.type!=EffectParameterType::Double||chain_y+18>list_bottom)continue;const double fallback=std::holds_alternative<double>(pd.default_value)?std::get<double>(pd.default_value):0.0;const double value=effect_numeric(effect,pd.id,0.0,fallback);c.text(rx+6,chain_y+12,short_name(tr("catalog."+pd.name,pd.name),12)+"  "+motion_number(value,2),theme::dim,8);Button down{{rx+std::max(80,rw-54),chain_y,24,16},"audio_fx_param_down:"+owner_prefix+":"+std::to_string(owner_id)+":"+std::to_string(effect.id)+":"+pd.id,"-"};Button up{{rx+std::max(106,rw-28),chain_y,24,16},"audio_fx_param_up:"+owner_prefix+":"+std::to_string(owner_id)+":"+std::to_string(effect.id)+":"+pd.id,"+"};buttons_.push_back(down);draw_button(c,down);buttons_.push_back(up);draw_button(c,up);chain_y+=18;}
                }
            }
        }else{
            c.text(px,py,tr("ui.transitions","Transitions"),theme::text,11,true);
            c.text(px,py+22,tr("transitions.auto_overlap","Automatic overlap transition"),theme::dim,9);
            Button autoCf{{px,py+36,124,24},"crossfade_toggle",project_.auto_crossfade?tr("transitions.auto_on","Auto crossfade ON"):tr("transitions.auto_off","Auto crossfade OFF"),project_.auto_crossfade,true};buttons_.push_back(autoCf);draw_button(c,autoCf);
        }
    }

    c.fill_rect({layout_.bin.x+1,tab_y,layout_.bin.w-2,tabs_h},theme::panel2);
    struct TabDef{std::string id,label;BinTab tab;};
    std::string l_media=tr("ui.media_short","Media");if(l_media.empty())l_media="Media";
    std::string l_text=tr("ui.text_short","Text");if(l_text.empty())l_text="Text";
    std::string l_trans=tr("ui.transitions","Transitions");if(l_trans.empty())l_trans="Transitions";
    const std::array<TabDef,5> tabs={{{"tab_media",l_media,BinTab::ProjectMedia},{"tab_generators",l_text,BinTab::Generators},{"tab_vfx","VFX",BinTab::VideoFx},{"tab_afx","AFX",BinTab::AudioFx},{"tab_transitions",l_trans,BinTab::Transitions}}};
    const int tab_width=std::max(36,(layout_.bin.w-10)/5);
    for(int i=0;i<5;++i){
        const auto& tab=tabs[i];const bool active=bin_tab_==tab.tab;Rect r{layout_.bin.x+5+i*tab_width,tab_y+3,tab_width,24};
        if(active){c.fill_rect(r,theme::raised);c.line(r.x,r.y+r.h-1,r.x+r.w,r.y+r.h-1,theme::accent);}
        buttons_.push_back({r,tab.id,tab.label,active,true});
        c.push_clip(r);
        const int tw=c.text_width(tab.label,8);
        const int tx=r.w>=tw+4?r.x+(r.w-tw)/2:r.x+2;
        c.text(tx,r.y+16,tab.label,active?theme::text:theme::dim,8,active);
        c.pop_clip();
    }
    if(edit_.drag.mode==DragMode::BinMedia){Rect ghost{mouse_x_-12,mouse_y_-14,210,28};c.fill_rect(ghost,Color{54,99,130});c.stroke_rect(ghost,theme::accent,2);if(auto*m=project_.media_by_id(edit_.drag.media_id))c.text(ghost.x+8,ghost.y+19,short_name(m->name,28),theme::text,9,true);}
}

void EditorApp::draw_preview(Canvas& c){
    draw_card(c,layout_.preview,theme::panel,10);
    constexpr int toolbar_h=34,tabs_h=30,controls_h=64,meter_w=64;
    const int main_w=std::max(120,layout_.preview.w-meter_w);
    c.fill_rect({layout_.preview.x+1,layout_.preview.y+1,main_w-1,toolbar_h},theme::panel2);
    Button pcfg{{layout_.preview.x+7,layout_.preview.y+5,28,24},"preview_settings","",false,true,"cog"};
    Button quality{{layout_.preview.x+41,layout_.preview.y+5,166,24},"preview_quality",preview_quality_name(),true,true};
    Button fit{{layout_.preview.x+main_w-36,layout_.preview.y+5,28,24},"preview_fit","",preview_fit_,true,"compress"};
    for(auto b:{pcfg,quality,fit}){buttons_.push_back(b);draw_button(c,b);}

    if(main_w>440){Button brush{{layout_.preview.x+214,layout_.preview.y+5,65,24},"tool_mask",tr("animation.tool.brush","Brush"),tool_mode_==ToolMode::PaintMask,true};buttons_.push_back(brush);draw_button(c,brush);if(tool_mode_==ToolMode::PaintMask){for(auto b:{Button{{layout_.preview.x+283,layout_.preview.y+5,24,24},"brush_down","-",false,true},Button{{layout_.preview.x+309,layout_.preview.y+5,24,24},"brush_up","+",false,true},Button{{layout_.preview.x+337,layout_.preview.y+5,66,24},"brush_hardness",std::to_string(int(paint_hardness_*100))+"%",false,true}}){buttons_.push_back(b);draw_button(c,b);}}}
    const int screen_y=layout_.preview.y+toolbar_h;
    const int controls_y=layout_.preview.y+layout_.preview.h-tabs_h-controls_h;
    Rect screen{layout_.preview.x+8,screen_y+7,main_w-16,std::max(30,controls_y-screen_y-14)};
    fill_round_rect(c,screen,Color{12,12,14},8);draw_round_border(c,screen,theme::borderSoft,8);
    if(!preview_frame_.rgb.empty()){
        if(preview_fit_)c.image(screen,preview_frame_);
        else{
            const int iw=std::min(screen.w,preview_frame_.width),ih=std::min(screen.h,preview_frame_.height);
            Rect native{screen.x+(screen.w-iw)/2,screen.y+(screen.h-ih)/2,iw,ih};c.image(native,preview_frame_);
        }
    }else c.text(screen.x+screen.w/2-52,screen.y+screen.h/2,tr("ui.no_frame","No frame at cursor"),theme::dim,10);
    paint_viewport_={};if(!preview_frame_.rgb.empty()){double scale=preview_fit_?std::min(double(screen.w)/preview_frame_.width,double(screen.h)/preview_frame_.height):std::min(1.0,std::min(double(screen.w)/preview_frame_.width,double(screen.h)/preview_frame_.height));int pw=int(preview_frame_.width*scale),ph=int(preview_frame_.height*scale);paint_viewport_={screen.x+(screen.w-pw)/2,screen.y+(screen.h-ph)/2,pw,ph};}
    if(tool_mode_==ToolMode::PaintMask&&paint_viewport_.contains(mouse_x_,mouse_y_)){int radius=std::max(2,int(paint_radius_*std::min(paint_viewport_.w,paint_viewport_.h)));c.stroke_rect({mouse_x_-radius,mouse_y_-radius,2*radius,2*radius},theme::accent);}
    if(screen.w>100&&screen.h>80)c.stroke_rect(screen,theme::borderSoft);

    c.fill_rect({layout_.preview.x+1,controls_y,main_w-1,controls_h},theme::panel2);
    const int by=controls_y+7;
    int bx=layout_.preview.x+std::max(6,main_w/2-92);
    Button back{{bx,by,32,26},"step_back","",false,true,"step-backward"};
    Button play{{bx+36,by,36,26},"play","",playing_,true,"play"};
    Button pause{{bx+76,by,36,26},"pause","",false,playing_,"pause"};Button stop{{bx+116,by,36,26},"stop","",false,playing_||playhead_>0.0,"stop"};Button forward{{bx+156,by,32,26},"step_forward","",false,true,"step-forward"};
    for(auto b:{back,play,pause,stop,forward}){buttons_.push_back(b);draw_button(c,b);}

    const double shown_time=preview_tab_==PreviewTab::Trimmer?source_time_:playhead_;
    const std::string tc=timecode(shown_time);const int tcw=c.text_width(tc,10,true)+14;
    Rect tcbox{layout_.preview.x+main_w/2-tcw/2,controls_y+38,tcw,20};fill_round_rect(c,tcbox,theme::bg,6);draw_round_border(c,tcbox,theme::borderSoft,6);c.text(tcbox.x+7,tcbox.y+14,tc,theme::text,10,true);
    if(preview_tab_==PreviewTab::Trimmer){
        const MediaItem* m=project_.media_by_id(edit_.selected_media);
        std::string range=tr("preview.in","In")+" "+timecode(source_in_)+"   "+tr("preview.out","Out")+" "+(source_out_>=0?timecode(source_out_):std::string("--:--:--:--"));
        c.text(layout_.preview.x+7,controls_y+55,short_name(m?m->name:tr("preview.no_source","No source selected"),28)+"  "+range,theme::dim,8);
        int rx=layout_.preview.x+main_w-178;
        Button in{{rx,controls_y+30,28,20},"source_in","I"};Button out{{rx+31,controls_y+30,28,20},"source_out","O"};
        Button ins{{rx+62,controls_y+30,52,20},"trimmer_insert",tr("preview.insert","Insert"),false,m!=nullptr};Button over{{rx+117,controls_y+30,58,20},"trimmer_overwrite",tr("preview.overwrite","Overwrite"),false,m!=nullptr};
        for(auto b:{in,out,ins,over}){buttons_.push_back(b);draw_button(c,b);}
    }else{
        c.text(layout_.preview.x+7,controls_y+54,this->tr("ui.project","Project")+": "+std::to_string(project_.settings.width)+"x"+std::to_string(project_.settings.height),theme::dim,8);
    }

    const int meter_x=layout_.preview.x+main_w;
    c.fill_rect({meter_x,layout_.preview.y+1,meter_w-1,layout_.preview.h-2},theme::panel2);c.line(meter_x,layout_.preview.y+8,meter_x,layout_.preview.y+layout_.preview.h-8,theme::borderSoft);
    c.text(meter_x+15,layout_.preview.y+18,tr("preview.master","Master"),theme::dim,8,true);
    const int meter_top=layout_.preview.y+35,meter_bottom=layout_.preview.y+layout_.preview.h-tabs_h-22;
    for(int ch=0;ch<2;++ch){
        const int mx=meter_x+18+ch*13;const int mh=std::max(1,meter_bottom-meter_top);
        c.fill_rect({mx,meter_top,7,mh},Color{17,17,17});
        // Display meters in a logarithmic-looking range: quiet material remains
        // visible while full-scale peaks still reach the top.
        const double linear=ch?meter_right_:meter_left_;
        const double display=linear<=1e-7?0.0:std::clamp((20.0*std::log10(linear)+60.0)/60.0,0.0,1.0);
        const int level=static_cast<int>(std::lround(mh*display));
        if(level>0)c.fill_rect({mx,meter_bottom-level,7,level},level>mh*0.88?Color{180,93,66}:Color{88,151,72});
        c.line(mx,meter_top+mh/5,mx+6,meter_top+mh/5,Color{160,80,60});
    }

    const int tabs_y=layout_.preview.y+layout_.preview.h-tabs_h;
    c.fill_rect({layout_.preview.x+1,tabs_y,main_w-1,tabs_h-1},theme::panel2);
    Rect pv{layout_.preview.x+6,tabs_y+4,98,tabs_h-8},tr{layout_.preview.x+108,tabs_y+4,72,tabs_h-8};
    const bool pva=preview_tab_==PreviewTab::VideoPreview,tra=preview_tab_==PreviewTab::Trimmer;
    if(pva)fill_round_rect(c,pv,theme::raised,7);
    if(tra)fill_round_rect(c,tr,theme::raised,7);
    std::string pv_txt=this->tr("ui.video_preview","Video Preview");if(pv_txt.empty())pv_txt="Video Preview";
    std::string tr_txt=this->tr("ui.trimmer","Trimmer");if(tr_txt.empty())tr_txt="Trimmer";
    buttons_.push_back({pv,"preview_tab",pv_txt,pva,true});buttons_.push_back({tr,"trimmer_tab",tr_txt,tra,true});
    c.text(pv.x+10,pv.y+15,pv_txt,pva?theme::text:theme::dim,9,pva);c.text(tr.x+10,tr.y+15,tr_txt,tra?theme::text:theme::dim,9,tra);
}

void EditorApp::draw_clip(Canvas& c,const Clip& clip,const Track& track,int y,int h,const ClipVisualOverride* ov){
    const double start=ov?ov->start:clip.start,dur=ov?ov->duration:clip.duration;
    const double fade_in=std::clamp(ov?ov->fade_in:clip.fade_in,0.0,std::max(0.0,dur));
    const double fade_out=std::clamp(ov?ov->fade_out:clip.fade_out,0.0,std::max(0.0,dur));
    const int x1=edit_.x_at(layout_.timeline_geo,start),x2=edit_.x_at(layout_.timeline_geo,start+dur);
    const int content_left=layout_.timeline_geo.x+layout_.timeline_geo.header_w;
    const int content_right=layout_.timeline_geo.x+layout_.timeline_geo.width;
    if(x2<=content_left||x1>=content_right)return;
    Rect r{x1,y+5,std::max(3,x2-x1),h-10};
    const bool sel=edit_.selection.contains(clip.id);
    Color base=track.kind==TrackKind::Video?(sel?theme::videoSel:theme::video):(sel?theme::audioSel:theme::audio);
    if(clip.muted)base=Color{62,67,74};
    if(clip.locked||track.locked)base=Color{58,58,62};
    fill_round_rect(c,{r.x+1,r.y+2,r.w,r.h},Color{0,0,0,50},7);
    fill_round_rect(c,r,base,2);draw_round_border(c,r,sel?theme::accent:theme::borderSoft,2);
    if(r.h>20){Rect cap{r.x+1,r.y+1,std::max(1,r.w-2),16};fill_round_rect(c,cap,Color{36,39,45},6);c.fill_rect({cap.x,cap.y+9,cap.w,7},Color{36,39,45});}
    auto*m=project_.media_by_id(clip.media_id());
    std::string event_name=m?m->name:tr("clip.event","Event");
    if(clip.takes.size()>1)event_name+=" ["+tr("clip.take","Take")+" "+std::to_string(clip.active_take+1)+"/"+std::to_string(clip.takes.size())+"]";
    if(clip.loop)event_name+=" ["+tr("clip.loop","Loop")+"]";
    if(r.w>42)c.text(r.x+5,r.y+12,short_name(event_name,static_cast<std::size_t>(std::max(8,(r.w-(track.kind==TrackKind::Video?28:0))/7))),Color{245,245,245},8,sel);
    if(track.kind==TrackKind::Video&&r.w>70){
        const int body_top=layout_.timeline_geo.y+layout_.timeline_geo.ruler_h,body_bottom=layout_.timeline_geo.y+layout_.timeline_geo.height;
        Button pc{{r.x+r.w-25,r.y+1,23,14},"pan_crop:"+std::to_string(clip.id),"P/C",clip.video_motion.enabled,true};
        if(pc.r.x>=content_left&&pc.r.x+pc.r.w<=content_right&&pc.r.y>=body_top&&pc.r.y+pc.r.h<=body_bottom){buttons_.push_back(pc);draw_button(c,pc);}
        if(r.w>102){Button fx{{r.x+r.w-52,r.y+1,24,14},"event_fx:"+std::to_string(clip.id),"FX",!clip.video_effects.empty(),true};if(fx.r.x>=content_left&&fx.r.x+fx.r.w<=content_right&&fx.r.y>=body_top&&fx.r.y+fx.r.h<=body_bottom){buttons_.push_back(fx);draw_button(c,fx);}}
    }
    if(track.kind==TrackKind::Video&&r.w>46&&r.h>32&&m&&m->generated_text.enabled){
        Rect body{r.x+3,r.y+19,std::max(1,r.w-6),std::max(12,r.h-24)};fill_round_rect(c,body,Color{22,22,26},5);draw_round_border(c,body,theme::borderSoft,5);
        const std::string sample=m->generated_text.text.empty()?tr("ui.titles_text","Titles & Text"):m->generated_text.text;const int tw=c.text_width(short_name(sample,28),10,m->generated_text.bold);
        c.text(body.x+std::max(5,(body.w-tw)/2),body.y+body.h/2+5,short_name(sample,28),Color{240,243,247},10,m->generated_text.bold);
        if(r.w>92){Button te{{r.x+r.w-82,r.y+1,27,14},"text_edit:"+std::to_string(clip.id),"TXT",true,true};buttons_.push_back(te);draw_button(c,te);}
    }else if(track.kind==TrackKind::Video&&r.w>46&&r.h>32&&m&&m->has_video){
        // Real source-frame filmstrip. Only visible tiles are requested, and a
        // dedicated MediaEngine thumbnail worker fills the cache asynchronously.
        const int lane_reserve=clip.video_motion.enabled?13:0;
        const int thumb_y=r.y+18,thumb_h=std::max(12,r.h-22-lane_reserve);
        const int tile_w=88;
        const int visible_left=std::max(r.x+2,layout_.timeline_geo.x+layout_.timeline_geo.header_w);
        const int visible_right=std::min(r.x+r.w-2,layout_.timeline_geo.x+layout_.timeline_geo.width);
        if(visible_right>visible_left&&thumb_h>=12){
            int tile_index=std::max(0,(visible_left-r.x)/tile_w);
            int xx=r.x+tile_index*tile_w;
            if(xx<visible_left){++tile_index;xx+=tile_w;}
            const double source_base=ov?ov->in_point:clip.source_offset();
            for(;xx<visible_right;xx+=tile_w,++tile_index){
                const int tw=std::min(tile_w,visible_right-xx);
                const double local=dur*std::clamp((xx+tw*0.5-r.x)/static_cast<double>(std::max(1,r.w)),0.0,1.0);
                double source=source_base+local*clip.rate;
                if(clip.loop&&m->duration>0.0)source=std::fmod(std::max(0.0,source),m->duration);
                Rect tile{xx,thumb_y,tw,thumb_h};
                if(auto frame=m->generated_vector.enabled?engine_.vector_thumbnail(m->generated_vector,source,96,54):engine_.timeline_thumbnail(!m->proxy_path.empty()&&fs::exists(path_from_utf8(m->proxy_path))?m->proxy_path:m->path,source,96,54))c.image(tile,*frame);
                else{c.fill_rect(tile,Color{46,72,88});c.line(tile.x,tile.y,tile.x+tile.w,tile.y+tile.h,Color{65,96,114});}
                c.line(tile.x+tile.w-1,tile.y,tile.x+tile.w-1,tile.y+tile.h,Color{35,55,68});
            }
        }
    }
    if(track.kind==TrackKind::Video&&clip.video_motion.enabled&&r.w>34&&r.h>38){
        const auto keys=motion_key_times(clip.video_motion);
        const int lane_h=11,lane_y=r.y+r.h-lane_h-2;
        fill_round_rect(c,{r.x+3,lane_y,std::max(1,r.w-6),lane_h},Color{35,42,49},4);
        // A thin zoom curve gives immediate timeline feedback that Pan/Crop is
        // animated; key diamonds show exact event-local keyframe positions.
        if(clip.duration>1e-9&&r.w>12){
            int last_x=r.x+3,last_y=lane_y+lane_h/2;
            const int samples=std::clamp(r.w/12,4,36);
            for(int i=0;i<=samples;++i){
                const double t=clip.duration*i/static_cast<double>(samples);const double z=sample_motion(clip.video_motion,t).zoom;
                const int xx=r.x+3+static_cast<int>((r.w-6)*i/static_cast<double>(samples));
                const int yy=lane_y+lane_h-2-static_cast<int>(std::clamp((z-1.0)/7.0,0.0,1.0)*(lane_h-4));
                if(i)c.line(last_x,last_y,xx,yy,Color{124,190,220});
                last_x=xx;last_y=yy;
            }
            for(double t:keys){
                const int xx=r.x+3+static_cast<int>((r.w-6)*std::clamp(t/clip.duration,0.0,1.0));const int cy=lane_y+lane_h/2;
                c.line(xx-3,cy,xx,cy-3,Color{245,210,86});c.line(xx,cy-3,xx+3,cy,Color{245,210,86});c.line(xx+3,cy,xx,cy+3,Color{245,210,86});c.line(xx,cy+3,xx-3,cy,Color{245,210,86});
            }
        }
        if(r.w>118)c.text(r.x+5,lane_y+9,"Pan/Crop  "+std::to_string(keys.size())+" key"+(keys.size()==1?"":"s"),Color{202,215,224},7);
    }
    if(track.kind==TrackKind::Audio&&r.w>30){
        if(r.w>86){Button afx{{r.x+r.w-42,r.y+1,38,14},"event_audio_fx:"+std::to_string(clip.id),"AFX",!clip.audio_effects.empty(),true};buttons_.push_back(afx);draw_button(c,afx);}
        const int top=r.y+18,bottom=r.y+r.h-4,mid=(top+bottom)/2;
        const int waveform_left=std::max(r.x+5,content_left);
        const int waveform_right=std::min(r.x+r.w-5,content_right);
        int first_i=std::max(0,(waveform_left-(r.x+5)+4)/5);
        int first_x=r.x+5+first_i*5;
        for(int xx=first_x,i=first_i;xx<waveform_right;xx+=5,++i){
            int room=std::max(3,(bottom-top)/2-2);int amp=2+((clip.id*17+i*13)%room);
            c.line(xx,mid-amp,xx,mid+amp,Color{194,160,214});
        }
        // Event gain envelope: drag this horizontal line vertically, just like
        // classic NLE event gain. 0 dB is near the upper third; downward drag
        // attenuates to -48 dB, upward drag allows up to +12 dB.
        const double shown_gain=(audio_gain_drag_.active&&audio_gain_drag_.clip_id==clip.id)?audio_gain_drag_.gain:clip.gain;
        const double gain_db=20.0*std::log10(std::max(0.0039810717,shown_gain));
        const double gain_u=std::clamp((12.0-gain_db)/60.0,0.0,1.0);
        const int gain_y=top+static_cast<int>(std::lround(gain_u*std::max(1,bottom-top)));
        c.line(waveform_left,gain_y,waveform_right,gain_y,Color{236,214,112},2);
        if(r.w>120)c.text(waveform_left+4,std::max(top+8,gain_y-3),motion_number(gain_db,1)+" dB",Color{250,226,130},7,true);
    }
    if(r.w>8&&dur>1e-9){
        // VEGAS-style event fades: the handle lives on the top edge and the
        // diagonal shows the actual fade duration. With a zero-length fade the
        // short corner mark keeps the handle discoverable.
        const int in_handle=std::clamp(edit_.x_at(layout_.timeline_geo,start+fade_in),r.x,r.x+r.w-1);
        const int out_handle=std::clamp(edit_.x_at(layout_.timeline_geo,start+dur-fade_out),r.x,r.x+r.w-1);
        const Color fade_color{232,232,232};
        if(fade_in>1e-9)c.line(r.x,r.y+r.h-1,in_handle,r.y,fade_color,1);
        else c.line(r.x,r.y,r.x+std::min(10,r.w-1),r.y+std::min(10,r.h-1),fade_color,1);
        if(fade_out>1e-9)c.line(out_handle,r.y,r.x+r.w-1,r.y+r.h-1,fade_color,1);
        else c.line(r.x+r.w-1,r.y,r.x+r.w-1-std::min(10,r.w-1),r.y+std::min(10,r.h-1),fade_color,1);
        c.fill_rect({in_handle-2,r.y,5,4},fade_color);
        c.fill_rect({out_handle-2,r.y,5,4},fade_color);
    }
    if(sel){c.fill_rect({r.x,r.y+7,3,std::max(1,r.h-14)},theme::accent);c.fill_rect({r.x+r.w-3,r.y+7,3,std::max(1,r.h-14)},theme::accent);}
    if(project_.auto_crossfade&&track.kind==TrackKind::Video){
        for(auto*other:project_.clips_on_track(track.id))if(other->id!=clip.id&&other->start<start+dur&&other->end()>start){
            const double a=std::max(start,other->start),b=std::min(start+dur,other->end());
            if(b>a)c.line(edit_.x_at(layout_.timeline_geo,a),r.y+r.h,edit_.x_at(layout_.timeline_geo,b),r.y,Color{220,220,220},1);
        }
    }
}

void EditorApp::draw_timeline(Canvas& c){
    auto& g=layout_.timeline_geo;
    c.fill_rect(layout_.timeline,theme::panel);c.line(0,layout_.timeline.y,layout_.timeline.w,layout_.timeline.y,theme::borderSoft);
    const int toolbar_y=layout_.timeline.y;
    c.fill_rect({layout_.timeline.x,toolbar_y,layout_.timeline.w,38},theme::panel2);
    c.line(0,toolbar_y+37,layout_.timeline.w,toolbar_y+37,theme::borderSoft);
    int bx=8;
    auto tbutton=[&](std::string id,std::string label,int w,bool active=false,bool enabled=true,std::string icon={}){Button b{{bx,toolbar_y+6,w,26},std::move(id),std::move(label),active,enabled,std::move(icon)};buttons_.push_back(b);draw_button(c,b);bx+=w+4;};
    tbutton("tool_select","",28,tool_mode_==ToolMode::Select,true,"mouse-pointer");tbutton("tool_split","",28,tool_mode_==ToolMode::Split,true,"cut");tbutton("lock_selection","",28,false,!edit_.selection.empty(),"lock");tbutton("snap","",28,project_.snapping,true,"magnet");tbutton("ripple","",28,project_.ripple!=RippleMode::Off,true,"arrows-alt-h");tbutton("add_video","",28,false,true,"film");tbutton("add_audio","",28,false,true,"file-audio");tbutton("record_audio","",28,recording_audio_,true,"volume-up");
    const std::string master=timecode(playhead_);
    const int mtw=c.text_width(master,15,true)+18;
    Rect master_box{layout_.timeline.w-mtw-12,toolbar_y+5,mtw,28};fill_round_rect(c,master_box,theme::bg,7);draw_round_border(c,master_box,theme::borderSoft,7);
    c.text(master_box.x+9,master_box.y+20,master,theme::accent,15,true);

    c.fill_rect({g.x,g.y,g.width,g.ruler_h},theme::ruler);
    c.fill_rect({g.x,g.y,g.header_w,g.ruler_h},theme::panel2);
    c.line(g.header_w-1,g.y+4,g.header_w-1,g.y+g.height-4,theme::borderSoft,1);
    c.text(8,g.y+16,tr("ui.tracks","Tracks"),theme::dim,9,true);
    const int content_x=g.x+g.header_w;
    const double visible=std::max(1.0,(g.width-g.header_w)/g.px_per_sec);
    const double tick=g.px_per_sec>=160?1.0:(g.px_per_sec>=80?5.0:10.0);
    const double first=std::floor(g.scroll_sec/tick)*tick;
    for(double t=first;t<=g.scroll_sec+visible+tick;t+=tick){
        const int x=edit_.x_at(g,t);if(x<content_x)continue;
        c.line(x,g.y+g.ruler_h-8,x,g.y+g.ruler_h,Color{92,92,92});
        c.line(x,g.y+g.ruler_h,x,g.y+g.height,Color{42,42,47});
        c.text(x+3,g.y+15,timecode(t).substr(3,8),Color{170,170,170},8);
    }
    for(double t=first;t<=g.scroll_sec+visible+1.0;t+=tick/5.0){int x=edit_.x_at(g,t);if(x>=content_x)c.line(x,g.y+g.ruler_h-4,x,g.y+g.ruler_h,Color{68,68,68});}
    for(auto&m:project_.markers){int x=edit_.x_at(g,m.time);if(x>=content_x&&x<g.x+g.width)c.line(x,g.y+g.ruler_h-7,x,g.y+g.ruler_h,theme::warning,2);}

    const int body_top=g.y+g.ruler_h;
    const int body_bottom=g.y+g.height;
    int y=body_top-g.scroll_y,ti=0,track_index=0;
    c.push_clip({g.x,body_top,g.width,std::max(0,body_bottom-body_top)});
    for(const auto& t:project_.tracks){
        const int h=t.height;
        if(y+h<=body_top){++track_index;y+=h;continue;}
        if(y>=body_bottom)break;
        c.fill_rect({content_x,y,g.width-g.header_w,h},ti++%2?theme::trackB:theme::trackA);c.line(content_x,y+h-1,g.width,y+h-1,theme::borderSoft);
        c.fill_rect({g.x,y,g.header_w,h},t.id==edit_.drag.track_id&&edit_.drag.mode==DragMode::TrackReorder?theme::raised:theme::header);c.line(g.x,y+h-1,g.header_w,y+h-1,theme::borderSoft);
        const Color stripe=t.kind==TrackKind::Video?Color{87,133,161}:Color{135,117,167};
        fill_round_rect(c,{g.x+6,y+8,8,std::max(12,h-16)},stripe,4);
        const bool fully_visible=y>=body_top&&y+h<=body_bottom;
        if(fully_visible){
            c.text(g.x+7,y+15,std::to_string(track_index+1),Color{245,245,245},9,true);
            std::string tname=t.name.empty()?(t.kind==TrackKind::Video?("Video "+std::to_string(track_index+1)):("Audio "+std::to_string(track_index+1))):t.name;
            c.push_clip({g.x+29,y,138,24});c.text(g.x+29,y+18,tname,theme::text,10,true);c.pop_clip();
            Rect lock{g.x+172,y+5,23,20},mute{g.x+198,y+5,23,20},solo{g.x+224,y+5,23,20};
            Button lb{lock,"track_lock:"+std::to_string(t.id),"L",t.locked,true};Button mb{mute,"track_mute:"+std::to_string(t.id),"M",t.mute,true};Button sb{solo,"track_solo:"+std::to_string(t.id),"S",t.solo,true};
            for(auto b:{lb,mb,sb}){buttons_.push_back(b);draw_button(c,b);}
            const int slider_y=y+38;
            c.text(g.x+30,slider_y+8,t.kind==TrackKind::Video?tr("ui.level","Level:"):tr("ui.volume","Vol:"),theme::dim,8);
            fill_round_rect(c,{g.x+69,slider_y+4,122,4},theme::bg,2);
            double value=t.kind==TrackKind::Video?t.opacity:t.gain;
            if(slider_drag_.active()&&slider_drag_.kind==SliderKind::TrackLevel&&slider_drag_.track_id==t.id)value=slider_drag_.value;
            const int knob=g.x+69+static_cast<int>(std::clamp(value,0.0,1.0)*118.0);
            fill_round_rect(c,{knob,slider_y-1,7,14},theme::text,4);
            if(t.kind==TrackKind::Audio){
                const std::string afx_label=t.audio_effects.empty()?tr("ui.audio_fx","Audio FX"):("FX "+std::to_string(t.audio_effects.size()));
                Button afx{{g.x+29,y+55,68,17},"track_audio_fx:"+std::to_string(t.id),afx_label,selected_track_id_==t.id&&bin_tab_==BinTab::AudioFx,true};
                buttons_.push_back(afx);draw_button(c,afx);
                double pan=t.pan;if(slider_drag_.active()&&slider_drag_.kind==SliderKind::TrackPan&&slider_drag_.track_id==t.id)pan=slider_drag_.value;
                c.text(g.x+104,y+65,tr("timeline.pan","Pan:"),theme::dim,8);
                fill_round_rect(c,{g.x+130,y+60,108,4},theme::bg,2);
                const int panKnob=g.x+130+static_cast<int>(std::clamp(pan+1.0,0.0,2.0)*51.0);
                fill_round_rect(c,{panKnob,y+55,7,14},theme::text,4);
            }else{
                Button fx{{g.x+29,y+55,92,17},"track_fx:"+std::to_string(t.id),tr("timeline.compositing_fx","Compositing / FX"),selected_track_id_==t.id&&bin_tab_==BinTab::VideoFx,true};buttons_.push_back(fx);draw_button(c,fx);
            }
        }
        // Track headers are a fixed pane. Event geometry may extend far to the
        // left when the timeline is scrolled, so constrain every event draw to
        // the timeline content viewport instead of relying on the outer body
        // clip (which intentionally includes the headers).
        c.push_clip({content_x,body_top,std::max(0,g.width-g.header_w),std::max(0,body_bottom-body_top)});
        for(auto*cclip:project_.clips_on_track(t.id)){
            const ClipVisualOverride*ov=nullptr;auto oit=edit_.drag.preview.find(cclip->id);if(oit!=edit_.drag.preview.end())ov=&oit->second;draw_clip(c,*cclip,t,y,h,ov);
        }
        c.pop_clip();
        if(edit_.drag.mode==DragMode::TrackReorder&&edit_.drag.target_track_index==track_index)c.stroke_rect({g.x,y,g.width,h},theme::accent,2);
        ++track_index;y+=h;
    }
    c.pop_clip();
    if(y<body_bottom)c.fill_rect({0,std::max(y,body_top),g.width,std::max(0,body_bottom-std::max(y,body_top))},theme::bg);
    // Native vertical track scrollbar. Mouse-wheel scrolling works anywhere in
    // the timeline body; this indicator makes hidden tracks discoverable and
    // keeps track content from visually escaping the timeline viewport.
    const auto vertical_scroll=timeline_vertical_scroll_metrics(project_,g);
    timeline_vscroll_track_={};
    timeline_vscroll_thumb_={};
    if(vertical_scroll.visible()){
        const int bar_x=g.x+g.width-9;
        timeline_vscroll_track_={bar_x,vertical_scroll.track_y,7,vertical_scroll.track_height};
        timeline_vscroll_thumb_={bar_x+1,vertical_scroll.thumb_y,5,vertical_scroll.thumb_height};
        fill_round_rect(c,timeline_vscroll_track_,Color{32,32,36},4);
        fill_round_rect(c,timeline_vscroll_thumb_,timeline_vscroll_drag_.active?theme::accent:Color{112,112,119},3);
    }
    // 12-hour horizontal timeline navigator. The thumb represents the current
    // visible time window and can be dragged/clicked independently of zoom.
    const double visible_seconds=std::max(0.001,(g.width-g.header_w)/std::max(1.0,g.px_per_sec));
    const double max_time_scroll=std::max(0.0,kTimelineMaxSeconds-visible_seconds);
    timeline_hscroll_track_={content_x,g.y+g.height+2,std::max(40,g.width-g.header_w-12),12};
    fill_round_rect(c,timeline_hscroll_track_,Color{32,32,36},5);draw_round_border(c,timeline_hscroll_track_,theme::borderSoft,5);
    const int thumb_w=std::clamp(static_cast<int>(std::lround(timeline_hscroll_track_.w*std::min(1.0,visible_seconds/kTimelineMaxSeconds))),36,timeline_hscroll_track_.w);
    const int travel=std::max(0,timeline_hscroll_track_.w-thumb_w);
    const int thumb_x=timeline_hscroll_track_.x+(max_time_scroll>0.0?static_cast<int>(std::lround(travel*(g.scroll_sec/max_time_scroll))):0);
    timeline_hscroll_thumb_={thumb_x,timeline_hscroll_track_.y,thumb_w,timeline_hscroll_track_.h};
    fill_round_rect(c,timeline_hscroll_thumb_,timeline_hscroll_drag_.active?theme::accent:Color{105,105,112},5);

    const int px=edit_.x_at(g,playhead_);
    if(px>=content_x&&px<=g.width){c.line(px,g.y,px,std::min(g.y+g.height,y),theme::playhead,1);c.fill_rect({px-4,g.y,9,7},theme::playhead);}
    if(edit_.drag.mode==DragMode::BinMedia&&layout_.timeline.contains(mouse_x_,mouse_y_)){
        int tid=edit_.track_at(project_,g,mouse_y_);if(tid){double st=edit_.time_at(g,mouse_x_);auto*m=project_.media_by_id(edit_.drag.media_id);if(m){int yy=g.y+g.ruler_h-g.scroll_y;for(auto&t:project_.tracks){if(t.id==tid)break;yy+=t.height;}int x1=edit_.x_at(g,st),x2=edit_.x_at(g,st+std::max(1.0,m->duration));Rect ghost{x1,yy+6,std::max(4,x2-x1),project_.track_by_id(tid)->height-12};c.fill_rect(ghost,Color{40,113,148,180});c.stroke_rect(ghost,theme::accent,2);}}}
    if(effect_drag_.active&&effect_drag_.moved){
        const EffectDefinition* def=effect_definition(effect_drag_.definition_id);
        const std::string label=std::string("FX ")+(def?tr("catalog."+def->name,def->name):"Effect");const int ww=std::min(220,std::max(80,c.text_width(label,9,true)+18));
        c.fill_rect({effect_drag_.current_x+12,effect_drag_.current_y+12,ww,24},Color{42,62,78,225});c.stroke_rect({effect_drag_.current_x+12,effect_drag_.current_y+12,ww,24},theme::accent);c.text(effect_drag_.current_x+20,effect_drag_.current_y+29,label,theme::text,9,true);
    }
    if((edit_.drag.mode==DragMode::FadeIn||edit_.drag.mode==DragMode::FadeOut)&&edit_.drag.clip_id){
        auto it=edit_.drag.preview.find(edit_.drag.clip_id);
        if(it!=edit_.drag.preview.end()){
            const double value=edit_.drag.mode==DragMode::FadeIn?it->second.fade_in:it->second.fade_out;
            const std::string label=(edit_.drag.mode==DragMode::FadeIn?tr("timeline.fade_in_offset","Fade in offset"):tr("timeline.fade_out_offset","Fade out offset"))+" "+timecode(value);
            const int tw=c.text_width(label,8,true)+10;
            int tx=mouse_x_+10,ty=mouse_y_+16;
            if(tx+tw>layout_.timeline.x+layout_.timeline.w)tx=mouse_x_-tw-8;
            if(ty+20>layout_.timeline.y+layout_.timeline.h)ty=mouse_y_-24;
            c.fill_rect({tx,ty,tw,20},Color{246,246,224});c.stroke_rect({tx,ty,tw,20},Color{70,70,70});
            c.text(tx+5,ty+14,label,Color{25,25,25},8,true);
        }
    }
    if(edit_.drag.mode==DragMode::Marquee){
        int left=std::min(edit_.drag.origin_x,edit_.drag.current_x),right=std::max(edit_.drag.origin_x,edit_.drag.current_x);
        int top=std::min(edit_.drag.origin_y,edit_.drag.current_y),bottom=std::max(edit_.drag.origin_y,edit_.drag.current_y);
        Rect marquee{left,top,std::max(1,right-left),std::max(1,bottom-top)};
        c.fill_rect(marquee,Color{55,155,255,35});c.stroke_rect(marquee,theme::accent,1);
    }
}

void EditorApp::draw_status(Canvas& c){
    c.fill_rect(layout_.status,theme::panel);c.line(0,layout_.status.y,layout_.status.w,layout_.status.y,theme::borderSoft);
    const auto prep=preparation_ui_;
    if((prep.running||prep.queued)&&prep.progress<1.0){
        const int bar_w=std::clamp(layout_.status.w/3,220,520);const int bx=8,by=layout_.status.y+4;
        fill_round_rect(c,{bx,by,bar_w,12},theme::bg,6);draw_round_border(c,{bx,by,bar_w,12},theme::borderSoft,6);
        fill_round_rect(c,{bx+1,by+1,std::max(1,static_cast<int>((bar_w-2)*std::clamp(prep.progress,0.0,1.0))),10},theme::success,5);
        c.text(bx+6,layout_.status.y+14,tr("ui.caching","Caching media")+" "+std::to_string(static_cast<int>(prep.progress*100.0))+"% — "+tr("ui.please_wait","please wait"),Color{232,232,232},8,true);
        c.text(bx+bar_w+10,layout_.status.y+14,prep.stage,theme::dim,8);
    }else if(recording_audio_){
        const double elapsed=std::max(0.0,std::chrono::duration<double>(std::chrono::steady_clock::now()-recording_wall_).count());
        fill_round_rect(c,{7,layout_.status.y+4,8,8},Color{224,66,66},4);
        c.text(21,layout_.status.y+14,"REC  "+timecode(elapsed)+"   "+tr("status.recording_audio","Recording audio"),Color{245,175,175},8,true);
    }else c.text(7,layout_.status.y+14,status_,theme::dim,8);
    std::ostringstream s;s<<tr("status.ui","UI:")<<" "<<short_name(services_.interface_renderer(),32)<<"   "<<tr("status.preview","Preview")<<" "<<preview_quality_name()<<" @ "<<preview_fps_name()<<"   "<<tr("status.media","Media:")<<" "<<(engine_.gpu_enabled()?engine_.gpu_backend().label:tr("common.off","Off"));
    int tw=c.text_width(s.str(),8);if(tw<layout_.status.w/2)c.text(layout_.status.w-tw-8,layout_.status.y+14,s.str(),theme::dim,8);
}

std::optional<EditorApp::Button> EditorApp::button_at(int x,int y)const{for(auto it=buttons_.rbegin();it!=buttons_.rend();++it)if(it->enabled&&it->r.contains(x,y))return*it;return std::nullopt;}
int EditorApp::bin_row_at(int x,int y)const{for(auto&r:bin_rows_)if(r.r.contains(x,y))return r.media_id;return 0;}

void EditorApp::commit_project_toggle(const std::function<void()>& fn){
    undo_.begin(project_);
    fn();
    if(undo_.commit(project_)) mark_dirty();
}

void EditorApp::mouse_down(int x,int y,int button,bool ctrl,bool shift,bool alt){
    x=static_cast<int>(std::lround(x/ui_scale_));y=static_cast<int>(std::lround(y/ui_scale_));
    mouse_x_=x;mouse_y_=y;mouse_down_=button==1;
    if(button==3&&animation_workspace_){
        animation_finish_drag(true);
        context_menu_.clear();active_menu_=MainMenu::None;
        for(const auto& hit:animation_key_hits_)if(hit.r.contains(x,y)){
            context_menu_.kind=ContextMenuKind::AnimationKey;context_menu_.x=x;context_menu_.y=y;context_menu_.property=hit.property;context_menu_.time=hit.time;
            context_menu_.items.push_back({"animation_key_delete","context.key.delete","Delete keyframe","Del",true,false});
            animation_property_=hit.property;animation_seek(hit.time);
            set_status(tr("status.context_keyframe","Keyframe context menu"));services_.request_redraw();return;
        }
        services_.request_redraw();return;
    }
    if(button==3&&dialog_==DialogMode::PanCrop){
        context_menu_.clear();active_menu_=MainMenu::None;
        Clip* clip=project_.clip_by_id(pan_crop_clip_id_);
        if(clip&&pan_crop_keyline_.contains(x,y)){
            const double dur=std::max(1e-6,clip->duration);double best=0.0;int best_px=9;bool found=false;
            for(const double key_time:motion_key_times(clip->video_motion)){const int kx=pan_crop_keyline_.x+static_cast<int>(std::lround(std::clamp(key_time/dur,0.0,1.0)*pan_crop_keyline_.w));const int d=std::abs(x-kx);if(d<best_px){best_px=d;best=key_time;found=true;}}
            if(found){context_menu_.kind=ContextMenuKind::PanCropKey;context_menu_.x=x;context_menu_.y=y;context_menu_.clip_id=clip->id;context_menu_.time=best;context_menu_.items.push_back({"pan_crop_key_delete","context.key.delete","Delete keyframe","Del",true,false});pan_crop_time_=best;set_playhead(clip->start+best,true);set_status(tr("status.context_keyframe","Keyframe context menu"));services_.request_redraw();return;}
        }
        return;
    }
    if(button==3){if(dialog_==DialogMode::None){open_context_menu(x,y);services_.request_redraw();}return;}
    if(button==1&&context_menu_.open()){
        if(auto b=button_at(x,y);b&&b->id.rfind("context:",0)==0){dispatch_context_button(b->id);return;}
        close_context_menu();return;
    }
    if(button==2&&layout_.timeline.contains(x,y)){timeline_pan_drag_.active=true;timeline_pan_drag_.origin_x=x;timeline_pan_drag_.origin_scroll=layout_.timeline_geo.scroll_sec;set_status(tr("status.timeline_pan","Timeline pan"));return;}
    if(button!=1)return;
    if(dialog_!=DialogMode::None){
        if(dialog_==DialogMode::PanCrop){
            if(auto b=button_at(x,y)){dispatch_button(b->id);return;}
            Clip* clip=project_.clip_by_id(pan_crop_clip_id_);if(!clip)return;
            if(pan_crop_keyline_.contains(x,y)){pan_crop_time_=std::clamp((x-pan_crop_keyline_.x)/static_cast<double>(std::max(1,pan_crop_keyline_.w)),0.0,1.0)*clip->duration;set_playhead(clip->start+pan_crop_time_,true);services_.request_redraw();return;}
            {
                const auto sample=sample_motion(clip->video_motion,pan_crop_time_);const Rect frame=motion_frame_rect(pan_crop_workspace_,sample);
                const int cx=frame.x+frame.w/2,cy=frame.y+frame.h/2;
                const double ra=(sample.rotation-90.0)*3.14159265358979323846/180.0;const double rr=std::max(30.0,frame.h*0.5+22.0);
                const int rhx=cx+static_cast<int>(std::lround(std::cos(ra)*rr)),rhy=cy+static_cast<int>(std::lround(std::sin(ra)*rr));
                const bool near_rotation=std::hypot(static_cast<double>(x-rhx),static_cast<double>(y-rhy))<=14.0;
                const int corners[][2]={{frame.x,frame.y},{frame.x+frame.w,frame.y},{frame.x,frame.y+frame.h},{frame.x+frame.w,frame.y+frame.h}};bool near_corner=false;
                for(const auto& pt:corners)if(std::abs(x-pt[0])<=12&&std::abs(y-pt[1])<=12){near_corner=true;break;}
                if(near_rotation||frame.contains(x,y)||near_corner){undo_.begin(project_);pan_crop_drag_.kind=near_rotation?PanCropDragKind::Rotation:(near_corner?PanCropDragKind::Resize:PanCropDragKind::Move);pan_crop_drag_.origin_x=x;pan_crop_drag_.origin_y=y;pan_crop_drag_.start=sample;pan_crop_drag_.preview=sample;set_status(near_rotation?tr("status.pan_crop_rotation_preview","Pan/Crop rotation preview"):(near_corner?tr("status.pan_crop_zoom_preview","Pan/Crop zoom preview"):tr("status.pan_crop_position_preview","Pan/Crop position preview")));return;}
            }
            return;
        }
        if(dialog_==DialogMode::TextEditor){
            if(auto b=button_at(x,y)){dispatch_button(b->id);return;}
            if(text_editor_preview_.contains(x,y)){
                text_position_drag_=true;text_editor_text_focus_=false;
                text_editor_pending_.location_x=std::clamp((x-text_editor_preview_.x)/static_cast<double>(std::max(1,text_editor_preview_.w)),0.0,1.0);
                text_editor_pending_.location_y=std::clamp((y-text_editor_preview_.y)/static_cast<double>(std::max(1,text_editor_preview_.h)),0.0,1.0);
                request_preview(true);services_.request_redraw();return;
            }
            text_editor_text_focus_=false;services_.request_redraw();return;
        }
        if(dialog_==DialogMode::EffectEditor){
            for(const auto& slider:fx_slider_hits_){
                Rect hit{slider.r.x-4,slider.r.y-6,slider.r.w+8,22};
                if(!hit.contains(x,y))continue;
                Clip* clip=project_.clip_by_id(fx_editor_clip_id_);if(!clip)return;
                auto effect_it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){return e.id==slider.effect_id;});
                if(effect_it==clip->video_effects.end())return;
                undo_.begin(project_);
                fx_param_drag_.active=true;fx_param_drag_.clip_id=clip->id;fx_param_drag_.effect_id=slider.effect_id;fx_param_drag_.parameter_id=slider.parameter_id;fx_param_drag_.r=slider.r;fx_param_drag_.min_value=slider.min_value;fx_param_drag_.max_value=slider.max_value;fx_param_drag_.start_value=slider.value;
                const double u=std::clamp((x-slider.r.x)/static_cast<double>(std::max(1,slider.r.w-1)),0.0,1.0);
                fx_param_drag_.value=slider.min_value+(slider.max_value-slider.min_value)*u;
                set_status(tr("status.fx_parameter_preview","FX parameter preview:")+" "+slider.parameter_id+" = "+motion_number(fx_param_drag_.value,2));request_preview(true);services_.request_redraw();return;
            }
            if(auto b=button_at(x,y)){dispatch_button(b->id);return;}
            return;
        }
        if(auto b=button_at(x,y);b&&(b->id.rfind("dialog:",0)==0||b->id.rfind("render:",0)==0)){dispatch_button(b->id);return;}
        return;
    }
    // Event fade handles live in the same narrow top strip as the compact
    // Event FX / Pan-Crop buttons. Give the actual corner handle priority so
    // a VEGAS-style drag from the event edge cannot accidentally open P/C.
    if(!animation_workspace_&&layout_.timeline.contains(x,y)&&!ctrl&&!shift&&!alt){
        auto& g=layout_.timeline_geo;int edge=0;const int cid=edit_.hit_clip(project_,g,x,y,&edge);
        if(cid){
            if(const Clip* clip=project_.clip_by_id(cid)){
                int clip_y=g.y+g.ruler_h-g.scroll_y;
                for(const auto& track:project_.tracks){if(track.id==clip->track_id)break;clip_y+=track.height;}
                const int top=clip_y+5;
                if(y>=top&&y<=top+11){
                    const double fi=std::clamp(clip->fade_in,0.0,clip->duration),fo=std::clamp(clip->fade_out,0.0,clip->duration);
                    const int in_x=edit_.x_at(g,clip->start+fi),out_x=edit_.x_at(g,clip->end()-fo);
                    const int di=std::abs(x-in_x),dout=std::abs(x-out_x);constexpr int fade_handle_radius=8;
                    if(di<=fade_handle_radius||dout<=fade_handle_radius){
                        const DragMode requested=di<=dout?DragMode::FadeIn:DragMode::FadeOut;
                        edit_.begin_clip_drag(project_,g,cid,x,y,requested,false);
                        set_status((requested==DragMode::FadeIn?tr("timeline.fade_in_offset","Fade in offset"):tr("timeline.fade_out_offset","Fade out offset"))+" "+timecode(requested==DragMode::FadeIn?clip->fade_in:clip->fade_out));
                        request_preview(true);services_.request_redraw();return;
                    }
                }
            }
        }
    }
    if(auto b=button_at(x,y)){
        if(b->id.rfind("fx_select:",0)==0){selected_fx_definition_=b->id.substr(10);fx_search_editing_=false;effect_drag_.active=true;effect_drag_.origin_x=effect_drag_.current_x=x;effect_drag_.origin_y=effect_drag_.current_y=y;effect_drag_.definition_id=selected_fx_definition_;set_status(tr("status.drag_fx_hint","Drag FX onto a video event or click to select"));services_.request_redraw();return;}
        dispatch_button(b->id);return;
    }
    if(active_menu_!=MainMenu::None){active_menu_=MainMenu::None;services_.request_redraw();return;}
    if(animation_workspace_){animation_mouse_down(x,y,shift);services_.request_redraw();return;}
    if(tool_mode_==ToolMode::PaintMask&&paint_viewport_.contains(x,y)){
        auto* clip=project_.clip_by_id(edit_.selection.primary_clip());auto* track=clip?project_.track_by_id(clip->track_id):nullptr;
        if(!clip||!track||track->kind!=TrackKind::Video||clip->locked||track->locked||!clip->contains(playhead_)||preview_tab_!=PreviewTab::VideoPreview){set_status(tr("status.select_unlocked_video","Select an unlocked video clip under the cursor"));return;}
        undo_.begin(project_);paint_before_=clip->video_effects;paint_clip_=clip->id;paint_count_=0;
        auto it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[](const EffectInstance& e){return e.definition_id=="koralo.paint_mask";});
        if(it==clip->video_effects.end()){clip->video_effects.push_back(make_effect_instance("koralo.paint_mask",project_.next_id()));it=std::prev(clip->video_effects.end());}
        it->enabled=true;paint_effect_=it->id;paint_total_segments_=0;if(auto* st=effect_parameter(*it,"strokes"))if(auto* txt=std::get_if<std::string>(&st->value))paint_total_segments_=int(std::count(txt->begin(),txt->end(),'\n'));engine_.clear_composite_cache();++preview_epoch_;paint_drag_=true;paint_x_=double(x-paint_viewport_.x)/paint_viewport_.w;paint_y_=double(y-paint_viewport_.y)/paint_viewport_.h;paint_segment(x,y,shift);return;
    }
    if(int mid=bin_row_at(x,y)){edit_.selected_media=mid;if(source_media_id_!=mid){source_media_id_=mid;source_time_=0.0;source_in_=0.0;source_out_=-1.0;}edit_.begin_bin_drag(mid,x,y);request_preview(true);services_.request_redraw();return;}
    auto&g=layout_.timeline_geo;
    if(timeline_hscroll_track_.contains(x,y)){
        const double visible=std::max(0.001,(g.width-g.header_w)/std::max(1.0,g.px_per_sec));const double max_scroll=std::max(0.0,kTimelineMaxSeconds-visible);
        if(timeline_hscroll_thumb_.contains(x,y)){timeline_hscroll_drag_.active=true;timeline_hscroll_drag_.grab_offset=x-timeline_hscroll_thumb_.x;}
        else{const int thumb_w=std::max(1,timeline_hscroll_thumb_.w);const int travel=std::max(1,timeline_hscroll_track_.w-thumb_w);const int target=std::clamp(x-timeline_hscroll_track_.x-thumb_w/2,0,travel);g.scroll_sec=max_scroll*(target/static_cast<double>(travel));timeline_hscroll_drag_.active=true;timeline_hscroll_drag_.grab_offset=thumb_w/2;}
        clamp_timeline_scroll();services_.request_redraw();return;
    }
    if(timeline_vscroll_track_.contains(x,y)){
        const auto metrics=timeline_vertical_scroll_metrics(project_,g);
        if(timeline_vscroll_thumb_.contains(x,y)){
            timeline_vscroll_drag_.active=true;
            timeline_vscroll_drag_.grab_offset=y-timeline_vscroll_thumb_.y;
        }else{
            const int thumb_h=std::max(1,timeline_vscroll_thumb_.h);
            const int target_top=y-thumb_h/2;
            g.scroll_y=timeline_vertical_scroll_from_thumb_top(metrics,target_top);
            timeline_vscroll_drag_.active=true;
            timeline_vscroll_drag_.grab_offset=thumb_h/2;
        }
        clamp_timeline_scroll();services_.request_redraw();return;
    }
    if(layout_.timeline.contains(x,y)){
        if(y<g.y+g.ruler_h&&x>=g.x+g.header_w){
            edit_.drag={};edit_.drag.mode=DragMode::Playhead;
            // While scrubbing, mute the old ffplay session rather than letting
            // it run from a stale timestamp (or relaunching on every mouse move).
            if(playing_)engine_.stop_audio_preview();
            set_playhead(edit_.time_at(g,x),true);return;
        }
        if(x<g.x+g.header_w && y>=g.y+g.ruler_h){
            int yy=g.y+g.ruler_h-g.scroll_y;
            for(auto& track:project_.tracks){
                if(y>=yy && y<yy+track.height){
                    selected_track_id_=track.id;
                    if(x>=g.x+69&&x<=g.x+191&&y>=yy+34&&y<=yy+54){
                        undo_.begin(project_);
                        slider_drag_.kind=SliderKind::TrackLevel;slider_drag_.track_id=track.id;
                        slider_drag_.value=std::clamp((x-(g.x+69))/122.0,0.0,1.0);
                        set_status(track.name+" level");services_.request_redraw();return;
                    }
                    if(track.kind==TrackKind::Audio&&x>=g.x+130&&x<=g.x+238&&y>=yy+50&&y<=yy+72){
                        undo_.begin(project_);
                        slider_drag_.kind=SliderKind::TrackPan;slider_drag_.track_id=track.id;
                        slider_drag_.value=std::clamp((x-(g.x+181))/51.0,-1.0,1.0);
                        set_status(track.name+" pan");services_.request_redraw();return;
                    }
                    edit_.begin_track_reorder(project_,g,track.id,x,y);
                    set_status(tr("status.reorder","Reorder")+" "+track.name);services_.request_redraw();return;
                }
                yy+=track.height;
            }
        }
        int edge=0;int cid=edit_.hit_clip(project_,g,x,y,&edge);
        if(cid){
            if(!ctrl&&!shift&&!alt){
                Clip* gain_clip=project_.clip_by_id(cid);const Track* gain_track=gain_clip?project_.track_by_id(gain_clip->track_id):nullptr;
                if(gain_clip&&gain_track&&gain_track->kind==TrackKind::Audio&&!gain_clip->locked&&!gain_track->locked){
                    int clip_y=g.y+g.ruler_h-g.scroll_y;for(const auto& track:project_.tracks){if(track.id==gain_clip->track_id)break;clip_y+=track.height;}
                    const int top=clip_y+23,bottom=clip_y+gain_track->height-9;const double db=20.0*std::log10(std::max(0.0039810717,gain_clip->gain));
                    const int gy=top+static_cast<int>(std::lround(std::clamp((12.0-db)/60.0,0.0,1.0)*std::max(1,bottom-top)));
                    if(std::abs(y-gy)<=6){undo_.begin(project_);audio_gain_drag_.active=true;audio_gain_drag_.clip_id=cid;audio_gain_drag_.top=top;audio_gain_drag_.bottom=bottom;audio_gain_drag_.gain=gain_clip->gain;edit_.selection.select_clip(project_,cid,SelectionOperation::Replace,true);set_status(tr("timeline.event_gain","Event gain")+" "+motion_number(db,1)+" dB");services_.request_redraw();return;}
                }
            }
            if(tool_mode_==ToolMode::Split){
                edit_.selection.select_clip(project_,cid,SelectionOperation::Replace,true);
                const double cut_time=edit_.time_at(g,x);if(edit_.split_selected(project_,undo_,cut_time)){mark_dirty();request_preview(true);set_status(tr("status.split_pointer","Split event at pointer"));}return;
            }
            DragMode requested=DragMode::None;
            if(!ctrl&&!shift&&!alt){
                if(const Clip* clip=project_.clip_by_id(cid)){
                    int clip_y=g.y+g.ruler_h-g.scroll_y;
                    for(const auto& track:project_.tracks){if(track.id==clip->track_id)break;clip_y+=track.height;}
                    const int top=clip_y+5;
                    if(y>=top&&y<=top+11){
                        const double fi=std::clamp(clip->fade_in,0.0,clip->duration),fo=std::clamp(clip->fade_out,0.0,clip->duration);
                        const int in_x=edit_.x_at(g,clip->start+fi),out_x=edit_.x_at(g,clip->end()-fo);
                        const int di=std::abs(x-in_x),dout=std::abs(x-out_x);
                        constexpr int fade_handle_radius=8;
                        if(di<=fade_handle_radius||dout<=fade_handle_radius)requested=di<=dout?DragMode::FadeIn:DragMode::FadeOut;
                    }
                }
            }
            if(requested==DragMode::None){
                if(edge!=0&&ctrl&&shift)requested=DragMode::RippleTrim;
                else if(edge!=0&&shift)requested=DragMode::Roll;
                else if(edge==0&&alt&&shift)requested=DragMode::Slide;
                else if(alt)requested=DragMode::Slip;
            }
            const bool add_selection=requested==DragMode::None&&(ctrl||shift);
            edit_.begin_clip_drag(project_,g,cid,x,y,requested,add_selection);
            if(requested==DragMode::FadeIn)set_status(tr("timeline.fade_in_offset","Fade in offset")+" "+timecode(project_.clip_by_id(cid)?project_.clip_by_id(cid)->fade_in:0.0));
            else if(requested==DragMode::FadeOut)set_status(tr("timeline.fade_out_offset","Fade out offset")+" "+timecode(project_.clip_by_id(cid)?project_.clip_by_id(cid)->fade_out:0.0));
            request_preview(true);services_.request_redraw();return;
        }
        set_playhead(edit_.time_at(g,x),true);
        edit_.begin_marquee(project_,x,y,ctrl||shift);
        services_.request_redraw();
    }
}

void EditorApp::mouse_move(int x,int y,bool ctrl,bool shift,bool alt){
    std::string old_hover; if(auto b=button_at(mouse_x_,mouse_y_))old_hover=b->id;
    x=static_cast<int>(std::lround(x/ui_scale_));y=static_cast<int>(std::lround(y/ui_scale_));
    mouse_x_=x;mouse_y_=y;
    std::string new_hover; if(auto b=button_at(mouse_x_,mouse_y_))new_hover=b->id;
    if(old_hover!=new_hover||tool_mode_==ToolMode::PaintMask)services_.request_redraw();
    if(animation_workspace_){animation_mouse_move(x,y,shift);return;}
    if(paint_drag_){paint_segment(x,y,shift);return;}
    if(timeline_pan_drag_.active){auto&g=layout_.timeline_geo;g.scroll_sec=timeline_pan_drag_.origin_scroll-(x-timeline_pan_drag_.origin_x)/std::max(1.0,g.px_per_sec);clamp_timeline_scroll();services_.request_redraw();return;}
    if(timeline_hscroll_drag_.active&&mouse_down_){auto&g=layout_.timeline_geo;const double visible=std::max(0.001,(g.width-g.header_w)/std::max(1.0,g.px_per_sec));const double max_scroll=std::max(0.0,kTimelineMaxSeconds-visible);const int travel=std::max(1,timeline_hscroll_track_.w-timeline_hscroll_thumb_.w);const int left=std::clamp(x-timeline_hscroll_track_.x-timeline_hscroll_drag_.grab_offset,0,travel);g.scroll_sec=max_scroll*(left/static_cast<double>(travel));clamp_timeline_scroll();services_.request_redraw();return;}
    if(timeline_vscroll_drag_.active&&mouse_down_){auto&g=layout_.timeline_geo;const auto metrics=timeline_vertical_scroll_metrics(project_,g);g.scroll_y=timeline_vertical_scroll_from_thumb_top(metrics,y-timeline_vscroll_drag_.grab_offset);clamp_timeline_scroll();services_.request_redraw();return;}
    if(effect_drag_.active&&mouse_down_){effect_drag_.current_x=x;effect_drag_.current_y=y;if(std::hypot(double(x-effect_drag_.origin_x),double(y-effect_drag_.origin_y))>5.0)effect_drag_.moved=true;services_.request_redraw();return;}
    if(dialog_==DialogMode::TextEditor&&text_position_drag_&&mouse_down_){
        text_editor_pending_.location_x=std::clamp((x-text_editor_preview_.x)/static_cast<double>(std::max(1,text_editor_preview_.w)),0.0,1.0);
        text_editor_pending_.location_y=std::clamp((y-text_editor_preview_.y)/static_cast<double>(std::max(1,text_editor_preview_.h)),0.0,1.0);
        const auto now=std::chrono::steady_clock::now();
        if(last_preview_request_wall_.time_since_epoch().count()==0||std::chrono::duration<double>(now-last_preview_request_wall_).count()>=1.0/30.0)request_preview(true);
        services_.request_redraw();return;
    }
    if(dialog_==DialogMode::EffectEditor&&fx_param_drag_.active&&mouse_down_){
        const double u=std::clamp((x-fx_param_drag_.r.x)/static_cast<double>(std::max(1,fx_param_drag_.r.w-1)),0.0,1.0);
        fx_param_drag_.value=fx_param_drag_.min_value+(fx_param_drag_.max_value-fx_param_drag_.min_value)*u;
        set_status(tr("status.fx_parameter_preview","FX parameter preview:")+" "+fx_param_drag_.parameter_id+" = "+motion_number(fx_param_drag_.value,2));
        const auto now=std::chrono::steady_clock::now();
        if(last_preview_request_wall_.time_since_epoch().count()==0||std::chrono::duration<double>(now-last_preview_request_wall_).count()>=1.0/30.0)request_preview(true);
        services_.request_redraw();return;
    }
    if(dialog_==DialogMode::PanCrop&&pan_crop_drag_.active()&&mouse_down_){
        if(pan_crop_drag_.kind==PanCropDragKind::Move){const Rect frame=motion_frame_rect(pan_crop_workspace_,pan_crop_drag_.start);const int travel_x=std::max(1,pan_crop_workspace_.w-frame.w),travel_y=std::max(1,pan_crop_workspace_.h-frame.h);pan_crop_drag_.preview.center_x=std::clamp(pan_crop_drag_.start.center_x+(x-pan_crop_drag_.origin_x)/static_cast<double>(travel_x),0.0,1.0);pan_crop_drag_.preview.center_y=std::clamp(pan_crop_drag_.start.center_y+(y-pan_crop_drag_.origin_y)/static_cast<double>(travel_y),0.0,1.0);}
        else if(pan_crop_drag_.kind==PanCropDragKind::Resize){const Rect frame=motion_frame_rect(pan_crop_workspace_,pan_crop_drag_.start);const double cx=frame.x+frame.w*0.5,cy=frame.y+frame.h*0.5;const double r0=std::max(4.0,std::hypot(pan_crop_drag_.origin_x-cx,pan_crop_drag_.origin_y-cy));const double r=std::max(4.0,std::hypot(x-cx,y-cy));pan_crop_drag_.preview.zoom=std::clamp(pan_crop_drag_.start.zoom*r0/r,1.0,8.0);}
        else if(pan_crop_drag_.kind==PanCropDragKind::Rotation){const Rect frame=motion_frame_rect(pan_crop_workspace_,pan_crop_drag_.start);const double cx=frame.x+frame.w*0.5,cy=frame.y+frame.h*0.5;const double a0=std::atan2(pan_crop_drag_.origin_y-cy,pan_crop_drag_.origin_x-cx);const double a1=std::atan2(y-cy,x-cx);double deg=pan_crop_drag_.start.rotation+(a1-a0)*180.0/3.14159265358979323846;while(deg>180.0)deg-=360.0;while(deg<-180.0)deg+=360.0;pan_crop_drag_.preview.rotation=deg;}
        services_.request_redraw();return;
    }
    if(audio_gain_drag_.active&&mouse_down_){
        const double u=std::clamp((y-audio_gain_drag_.top)/static_cast<double>(std::max(1,audio_gain_drag_.bottom-audio_gain_drag_.top)),0.0,1.0);
        const double db=12.0-u*60.0;audio_gain_drag_.gain=std::pow(10.0,db/20.0);set_status(tr("timeline.event_gain","Event gain")+" "+motion_number(db,1)+" dB");services_.request_redraw();return;
    }
    if(slider_drag_.active()&&mouse_down_){
        const auto& g=layout_.timeline_geo;
        if(slider_drag_.kind==SliderKind::TrackLevel)slider_drag_.value=std::clamp((x-(g.x+69))/122.0,0.0,1.0);
        else if(slider_drag_.kind==SliderKind::TrackPan)slider_drag_.value=std::clamp((x-(g.x+130))/61.0,-1.0,1.0);
        services_.request_redraw();
    }
    else if(edit_.drag.mode==DragMode::Playhead&&mouse_down_){set_playhead(edit_.time_at(layout_.timeline_geo,x),false);}
    else if(edit_.drag.mode!=DragMode::None){edit_.update_drag(project_,layout_.timeline_geo,x,y,playhead_);services_.request_redraw();}
    (void)ctrl;(void)shift;(void)alt;
}

void EditorApp::mouse_up(int x,int y,int button,bool ctrl,bool shift,bool alt){
    x=static_cast<int>(std::lround(x/ui_scale_));y=static_cast<int>(std::lround(y/ui_scale_));
    mouse_x_=x;mouse_y_=y;
    if(button==2){timeline_pan_drag_.clear();services_.request_redraw();return;}
    mouse_down_=false;if(button!=1)return;
    if(animation_workspace_){animation_mouse_up(x,y,shift);return;}
    if(paint_drag_){paint_segment(x,y,shift);finish_paint();return;}
    if(text_position_drag_){text_position_drag_=false;request_preview(true);set_status(tr("status.text_position_preview","Text position preview updated — Apply to commit"));services_.request_redraw();return;}
    if(timeline_hscroll_drag_.active){timeline_hscroll_drag_.clear();services_.request_redraw();return;}
    if(timeline_vscroll_drag_.active){timeline_vscroll_drag_.clear();services_.request_redraw();return;}
    if(fx_param_drag_.active){
        const EffectParamDrag drag=fx_param_drag_;fx_param_drag_.clear();
        Clip* clip=project_.clip_by_id(drag.clip_id);
        if(clip){
            auto effect_it=std::find_if(clip->video_effects.begin(),clip->video_effects.end(),[&](const EffectInstance& e){return e.id==drag.effect_id;});
            if(effect_it!=clip->video_effects.end()){
                set_effect_numeric(*effect_it,drag.parameter_id,std::clamp(drag.value,drag.min_value,drag.max_value));
                if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.fx_parameter_committed","FX parameter committed:")+" "+drag.parameter_id+" = "+motion_number(drag.value,2));}
                else undo_.cancel();
            }else undo_.cancel();
        }else undo_.cancel();
        services_.request_redraw();return;
    }
    if(effect_drag_.active){const auto drag=effect_drag_;effect_drag_.clear();if(drag.moved){if(!drop_effect_on_timeline(drag.definition_id,x,y))set_status(tr("status.drop_fx","Drop FX on a video event"));}else if(const auto* def=effect_definition(drag.definition_id))set_status(tr("catalog."+def->name,def->name));services_.request_redraw();return;}
    if(dialog_==DialogMode::PanCrop&&pan_crop_drag_.active()){const VideoMotionSample value=pan_crop_drag_.preview;pan_crop_drag_.clear();if(Clip* clip=project_.clip_by_id(pan_crop_clip_id_)){clip->video_motion.set_key(pan_crop_time_,value.center_x,value.center_y,value.zoom,value.rotation);if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.pan_crop_key_committed","Pan/Crop keyframe committed"));}else undo_.cancel();}services_.request_redraw();return;}
    if(audio_gain_drag_.active){
        const AudioGainDrag drag=audio_gain_drag_;audio_gain_drag_.clear();if(Clip* clip=project_.clip_by_id(drag.clip_id)){clip->gain=std::clamp(drag.gain,0.0039810717,3.981071706);if(undo_.commit(project_)){mark_dirty();request_preview(true);if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}const double db=20.0*std::log10(clip->gain);set_status(tr("timeline.event_gain","Event gain")+" "+motion_number(db,1)+" dB");}else undo_.cancel();}else undo_.cancel();services_.request_redraw();return;
    }
    if(slider_drag_.active()){
        const SliderDrag drag=slider_drag_;slider_drag_.clear();
        if(Track* track=project_.track_by_id(drag.track_id)){
            if(drag.kind==SliderKind::TrackLevel){if(track->kind==TrackKind::Video)track->opacity=drag.value;else track->gain=drag.value;}
            else if(drag.kind==SliderKind::TrackPan&&track->kind==TrackKind::Audio)track->pan=drag.value;
            if(undo_.commit(project_)){
                mark_dirty();request_preview(true);
                if(playing_ && track->kind==TrackKind::Audio){engine_.stop_audio_preview();resync_audio_preview(true);}
                set_status(track->name+(drag.kind==SliderKind::TrackPan?tr("status.pan_adjusted"," pan adjusted"):tr("status.level_adjusted"," level adjusted")));
            }
            else undo_.cancel();
        }else undo_.cancel();
        services_.request_redraw();return;
    }
    if(edit_.drag.mode==DragMode::Playhead){
        edit_.cancel_drag();
        if(playing_){
            play_wall_=std::chrono::steady_clock::now();play_start_=playhead_;
            engine_.stop_audio_preview();resync_audio_preview(true);
        }
        request_preview(true);return;
    }
    if(edit_.drag.mode!=DragMode::None){
        const DragMode committed_mode=edit_.drag.mode;
        double committed_fade=0.0;
        if((committed_mode==DragMode::FadeIn||committed_mode==DragMode::FadeOut)&&edit_.drag.preview.contains(edit_.drag.clip_id)){
            const auto& preview=edit_.drag.preview.at(edit_.drag.clip_id);committed_fade=committed_mode==DragMode::FadeIn?preview.fade_in:preview.fade_out;
        }
        if(edit_.commit_drag(project_,undo_,layout_.timeline_geo,x,y,playhead_)){
            mark_dirty();request_preview(true);
            if(committed_mode==DragMode::FadeIn||committed_mode==DragMode::FadeOut){
                if(playing_){engine_.stop_audio_preview();resync_audio_preview(true);}
                set_status((committed_mode==DragMode::FadeIn?tr("timeline.fade_in_offset","Fade in offset"):tr("timeline.fade_out_offset","Fade out offset"))+" "+timecode(committed_fade));
            }
        }else edit_.cancel_drag();
        services_.request_redraw();
    }
    (void)ctrl;(void)shift;(void)alt;
}

void EditorApp::mouse_wheel(int x,int y,double delta,bool ctrl,bool shift){
    x=static_cast<int>(std::lround(x/ui_scale_));y=static_cast<int>(std::lround(y/ui_scale_));
    mouse_x_=x;mouse_y_=y;auto&g=layout_.timeline_geo;
    if(animation_workspace_){if(layout_.inspector.w&&layout_.inspector.contains(x,y)){inspector_scroll_=std::clamp(inspector_scroll_+(delta>0?-32:32),0,std::max(0,inspector_content_height_-(layout_.inspector.h-38)));}else if(animation_layers_.contains(x,y)){auto* m=animation_media();animation_layer_scroll_=std::clamp(animation_layer_scroll_+(delta>0?-35:35),0,std::max(0,(m?int(m->generated_vector.shapes.size())*35:0)-(animation_layers_.h-123)));}else if(layout_.timeline.contains(x,y))animation_key_scroll_=std::clamp(animation_key_scroll_+(delta>0?-23:23),0,std::max(0,230-animation_keyline_.h));services_.request_redraw();return;}
    if(dialog_==DialogMode::EffectEditor&&fx_parameter_view_.contains(x,y)){fx_parameter_scroll_=std::max(0,fx_parameter_scroll_+(delta>0?-1:1));services_.request_redraw();return;}
    if(dialog_!=DialogMode::None)return;
    if(layout_.inspector.w&&layout_.inspector.contains(x,y)){inspector_scroll_=std::clamp(inspector_scroll_+(delta>0?-32:32),0,std::max(0,inspector_content_height_-(layout_.inspector.h-37)));services_.request_redraw();return;}
    if(layout_.timeline.contains(x,y)){
        if(ctrl){double anchor=edit_.time_at(g,x);g.px_per_sec=std::clamp(g.px_per_sec*(delta>0?1.18:0.85),8.0,900.0);double after=g.scroll_sec+(x-g.x-g.header_w)/g.px_per_sec;g.scroll_sec=std::max(0.0,g.scroll_sec+(anchor-after));}
        else if(x<g.x+g.header_w || !shift){
            int total=0;for(const auto& track:project_.tracks)total+=track.height;
            const int visible_h=std::max(1,g.height-g.ruler_h);const int max_scroll=std::max(0,total-visible_h);
            const int step=std::max(24,static_cast<int>(std::lround(std::abs(delta)*42.0)));
            g.scroll_y=std::clamp(g.scroll_y+(delta>0?-step:step),0,max_scroll);
        }else{
            const double amount=5.0*(delta>0?-1:1);g.scroll_sec=std::max(0.0,g.scroll_sec+amount);
        }
        clamp_timeline_scroll();services_.request_redraw();
    }
}

void EditorApp::key_down(Key key,bool ctrl,bool shift,bool alt){
    if(context_menu_.open()){
        if(key==Key::Escape){close_context_menu();return;}
        if(key==Key::Delete){
            if(context_menu_.kind==ContextMenuKind::AnimationKey){dispatch_context_button("context:animation_key_delete");return;}
            if(context_menu_.kind==ContextMenuKind::PanCropKey){dispatch_context_button("context:pan_crop_key_delete");return;}
        }
    }
    if(animation_key(key,ctrl,shift)){services_.request_redraw();return;}
    if(paint_drag_){if(key==Key::Escape)finish_paint(true);return;}
    if(key==Key::Escape&&rendering_){render_cancel_=true;set_status(tr("status.cancelling_render","Cancelling render..."));return;}
    if(dialog_==DialogMode::TextEditor){
        if(key==Key::Escape){dispatch_modal_button("text_cancel");services_.request_redraw();return;}
        if(text_editor_text_focus_){
            if(key==Key::Backspace){if(!text_editor_pending_.text.empty()){std::size_t pos=text_editor_pending_.text.size()-1;while(pos>0&&(static_cast<unsigned char>(text_editor_pending_.text[pos])&0xC0)==0x80)--pos;text_editor_pending_.text.erase(pos);request_preview(true);}services_.request_redraw();return;}
            if(key==Key::Enter){if(text_editor_pending_.text.size()<2048)text_editor_pending_.text.push_back('\n');request_preview(true);services_.request_redraw();return;}
            if(ctrl&&key==Key::S){dispatch_modal_button("text_apply");save_project(false);return;}
            return;
        }
    }
    if(fx_search_editing_){
        if(key==Key::Escape||key==Key::Enter){fx_search_editing_=false;set_status(fx_search_query_.empty()?tr("status.video_fx_search_cleared","Video FX search cleared"):tr("status.video_fx_filter","Video FX filter:")+" "+fx_search_query_);services_.request_redraw();return;}
        if(key==Key::Backspace){erase_last_utf8(fx_search_query_);services_.request_redraw();return;}
        return;
    }
    if(search_editing_){
        if(key==Key::Escape||key==Key::Enter){search_editing_=false;set_status(search_query_.empty()?tr("status.media_search_cleared","Media search cleared"):tr("status.media_filter","Media filter:")+" "+search_query_);services_.request_redraw();return;}
        if(key==Key::Backspace){erase_last_utf8(search_query_);services_.request_redraw();return;}
        return;
    }
    if(key==Key::Escape){if(fx_param_drag_.active){fx_param_drag_.clear();undo_.cancel();request_preview(true);services_.request_redraw();return;}if(pan_crop_drag_.active()){pan_crop_drag_.clear();undo_.cancel();services_.request_redraw();return;}if(dialog_!=DialogMode::None){dialog_=DialogMode::None;fx_slider_hits_.clear();services_.request_redraw();return;}if(slider_drag_.active()){slider_drag_.clear();undo_.cancel();}edit_.cancel_drag();pause_playback(false);tool_mode_=ToolMode::Select;services_.request_redraw();return;}
    if(key==Key::B&&!ctrl&&dialog_==DialogMode::None){dispatch_button("tool_mask");services_.request_redraw();return;}
    if(ctrl&&key==Key::Z){if(undo_.undo(project_)){sync_preview_settings_from_project();mark_dirty();request_preview(true);}return;}
    if(ctrl&&key==Key::Y){if(undo_.redo(project_)){sync_preview_settings_from_project();mark_dirty();request_preview(true);}return;}
    if(ctrl&&key==Key::S){save_project(shift);return;}
    if(ctrl&&key==Key::O){open_project();return;}
    if(ctrl&&key==Key::N){new_project();return;}
    if(ctrl&&key==Key::I){import_paths(services_.open_media_files());return;}
    if(ctrl&&key==Key::C){dispatch_button("copy");return;}
    if(ctrl&&key==Key::V){dispatch_button("paste");return;}
    if(ctrl&&key==Key::X){dispatch_button("cut_clipboard");return;}
    if(ctrl&&key==Key::L){dispatch_button("lock_selection");return;}
    if(key==Key::F1){show_help();return;}
    switch(key){
        case Key::Delete: if(edit_.delete_selected(project_,undo_)){mark_dirty();request_preview(true);}break;
        case Key::S: if(edit_.split_selected(project_,undo_,playhead_)){mark_dirty();request_preview(true);}break;
        case Key::I: set_source_in();break;
        case Key::O: set_source_out();break;
        case Key::Space: if(playing_)pause_playback(false);else start_playback();break;
        case Key::Left: if(shift){if(edit_.nudge_selected(project_,undo_,-1.0/project_.settings.fps))mark_dirty();}else step_preview(-1);break;
        case Key::Right: if(shift){if(edit_.nudge_selected(project_,undo_,1.0/project_.settings.fps))mark_dirty();}else step_preview(1);break;
        case Key::M: add_marker();break;
        case Key::Plus: layout_.timeline_geo.px_per_sec=std::min(900.0,layout_.timeline_geo.px_per_sec*1.2);break;
        case Key::Minus: layout_.timeline_geo.px_per_sec=std::max(8.0,layout_.timeline_geo.px_per_sec/1.2);break;
        default:break;
    }
    (void)alt;services_.request_redraw();
}

void EditorApp::text_input(const std::string& text){
    if(text.empty())return;
    if(dialog_==DialogMode::TextEditor&&text_editor_text_focus_){
        if(text_editor_pending_.text.size()+text.size()<=2048){for(unsigned char ch:text)if(ch>=32||ch>=128)text_editor_pending_.text.push_back(static_cast<char>(ch));request_preview(true);services_.request_redraw();}return;
    }
    if(fx_search_editing_){if(fx_search_query_.size()+text.size()<=96)for(unsigned char ch:text)if(ch>=32&&ch!=127)fx_search_query_.push_back(static_cast<char>(ch));services_.request_redraw();return;}
    if(!search_editing_)return;
    if(search_query_.size()+text.size()<=96)for(unsigned char ch:text){if(ch>=32&&ch!=127)search_query_.push_back(static_cast<char>(ch));}
    services_.request_redraw();
}

void EditorApp::file_dropped(const std::string& path,int x,int y){
    x=static_cast<int>(std::lround(x/ui_scale_));y=static_cast<int>(std::lround(y/ui_scale_));
    std::string ext=path_to_utf8(path_from_utf8(path).extension());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    if(ext==".veg"||ext==".kora"){open_project_path(path);return;}
    std::vector<std::string> p{path};std::size_t before=project_.media.size();import_paths(p);if(project_.media.size()>before&&layout_.timeline.contains(x,y)){int tid=edit_.track_at(project_,layout_.timeline_geo,y);add_media_to_timeline(project_.media.back().id,edit_.time_at(layout_.timeline_geo,x),tid?tid:-1);}
}

void EditorApp::import_paths(const std::vector<std::string>& paths){
    if(paths.empty()) return;
    if(!engine_.ready()){services_.show_message(tr("dialog.media_engine","Media engine"),tr("error.ffmpeg_missing","ffmpeg/ffprobe not found. Run the installer or place them in KoraLo/bin."),true);return;}
    int ok=0;std::string errs;
    for(auto&path:paths){std::string err;auto item=engine_.probe(path,&err);if(item){MediaItem& added=project_.add_media(std::move(*item));engine_.prepare_media(added);++ok;}else errs+=basename_utf8(path)+": "+err+"\n";}
    if(ok){mark_dirty();edit_.selected_media=project_.media.back().id;source_media_id_=edit_.selected_media;source_time_=0;source_in_=0;source_out_=-1;request_preview(true);}
    set_status(tr("status.imported","Imported")+" "+std::to_string(ok)+" "+tr("status.files_preparing_cache","file(s) — preparing optimized cache; please wait before heavy scrubbing"));preparation_ui_=engine_.overall_preparation_status();if(!errs.empty())services_.show_message(tr("dialog.import","Import"),errs,true);services_.request_redraw();
}

void EditorApp::add_media_to_timeline(int media_id,double at,int track_id){
    undo_.begin(project_);
    const int clip_id=project_.place_media(media_id,std::max(0.0,at),std::max(0,track_id),track_id<0);
    if(!clip_id){undo_.cancel();return;}
    if(undo_.commit(project_)){
        edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,true);
        selected_track_id_=project_.clip_by_id(clip_id)->track_id;
        mark_dirty();request_preview(true);services_.request_redraw();
    }

}

void EditorApp::set_playhead(double t,bool force_preview){
    playhead_=std::clamp(t,0.0,kTimelineMaxSeconds);
    // Pan/Crop keyframes are event-local. Keep its mini-timeline locked to
    // the main transport whenever the selected event owns the playhead.
    if(dialog_==DialogMode::PanCrop){
        if(const Clip* clip=project_.clip_by_id(pan_crop_clip_id_)){
            pan_crop_time_=std::clamp(playhead_-clip->start,0.0,std::max(0.0,clip->duration));
        }
    }
    if(playing_ && (force_preview || (mouse_down_ && edit_.drag.mode==DragMode::Playhead))){
        play_wall_=std::chrono::steady_clock::now();play_start_=playhead_;
        if(!(mouse_down_ && edit_.drag.mode==DragMode::Playhead)){
            engine_.stop_audio_preview();resync_audio_preview(true);
        }
    }
    request_preview(force_preview);services_.request_redraw();
}

void EditorApp::request_preview(bool force){
    const double quality_fps=preview_quality_==PreviewQuality::Draft?15.0:(preview_quality_==PreviewQuality::Preview?24.0:(preview_quality_==PreviewQuality::Good?30.0:60.0));
    const double effective_preview_fps=std::max(1.0,std::min<double>(preview_fps_limit_,quality_fps));
    if(!force&&playing_){
        const auto now=std::chrono::steady_clock::now();
        if(last_preview_request_wall_.time_since_epoch().count()!=0&&std::chrono::duration<double>(now-last_preview_request_wall_).count()<1.0/effective_preview_fps)return;
        last_preview_request_wall_=now;
    }else if(force){last_preview_request_wall_=std::chrono::steady_clock::now();}
    if(preview_tab_==PreviewTab::VideoPreview&&!animation_workspace_){
        if(force||!playing_)++preview_epoch_;
        PreviewRequest scene;
        scene.token=++preview_token_;scene.playback_epoch=preview_epoch_;
        scene.playback=playing_&&!force;scene.continuous=scene.playback;
        scene.requested_fps=effective_preview_fps;
        scene.width=preview_quality_==PreviewQuality::Draft?320:(preview_quality_==PreviewQuality::Preview?640:(preview_quality_==PreviewQuality::Good?960:std::min(1920,project_.settings.width)));
        scene.height=std::max(2,int(scene.width*double(project_.settings.height)/std::max(1,project_.settings.width))&~1);
        scene.width=std::max(2,scene.width&~1);
        scene.layers=build_preview_layers(project_,playhead_,use_prepared_cache_&&preview_quality_!=PreviewQuality::Best);
        int cost=effect_preview_cost(project_.video_output_effects);
        for(auto& layer:scene.layers){
            layer.continuous=scene.continuous&&!layer.path.empty()&&!is_still_image_path(layer.path);
            layer.requested_fps=effective_preview_fps;
            if(layer.has_text_overlay&&dialog_==DialogMode::TextEditor){
                const Clip* clip=project_.clip_by_id(layer.stream_id);
                if(clip&&clip->media_id()==text_editor_media_id_)layer.text_overlay=text_editor_pending_;
            }
            if(fx_param_drag_.active&&layer.stream_id==fx_param_drag_.clip_id){
                for(auto& effect:layer.effects)if(effect.id==fx_param_drag_.effect_id)set_effect_numeric(effect,fx_param_drag_.parameter_id,fx_param_drag_.value);
            }
            cost+=effect_preview_cost(layer.effects);
        }
        if(playing_&&(cost>=8||scene.layers.size()>3)&&scene.width>640){
            scene.height=std::max(2,int(scene.height*640.0/scene.width)&~1);scene.width=640;
        }
        for(auto& layer:scene.layers){layer.width=scene.width;layer.height=scene.height;}
        scene.output_effects=project_.video_output_effects;scene.output_effect_time=playhead_;
        preview_media_id_=scene.layers.empty()?0:project_.clip_by_id(scene.layers.back().stream_id)->media_id();
        preview_source_time_=playhead_;
        engine_.request_preview(std::move(scene));return;
    }
    const MediaItem* media=nullptr;const Clip* preview_clip=nullptr;const MediaItem* text_media=nullptr;const Clip* text_clip=nullptr;const Clip* background_clip=nullptr;const MediaItem* background_media=nullptr;double source=0.0;int media_id=0;
    if(preview_tab_==PreviewTab::Trimmer&&edit_.selected_media){
        media=project_.media_by_id(edit_.selected_media);source=source_time_;media_id=edit_.selected_media;if(media&&media->generated_text.enabled){text_media=media;media=nullptr;}
    }else{
        auto vids=project_.video_at(playhead_);
        for(auto it=vids.rbegin();it!=vids.rend();++it){if(!visible_video_clip(**it))continue;const Clip*c=*it;const MediaItem*m=project_.media_by_id(c->media_id());if(m&&m->generated_text.enabled){text_clip=c;text_media=m;break;}}
        for(auto it=vids.rbegin();it!=vids.rend();++it){if(!visible_video_clip(**it))continue;const Clip*c=*it;const MediaItem*m=project_.media_by_id(c->media_id());if(!m||m->generated_text.enabled)continue;preview_clip=c;media=m;source=c->source_offset()+(playhead_-c->start)*c->rate;if(c->loop&&media->duration>0.0)source=std::fmod(source,media->duration);media_id=c->media_id();break;}
        if(preview_clip){bool found_top=false;for(auto it=vids.rbegin();it!=vids.rend();++it){const Clip*c=*it;if(c==preview_clip){found_top=true;continue;}if(!found_top||!visible_video_clip(*c))continue;const MediaItem*m=project_.media_by_id(c->media_id());if(!m||m->generated_text.enabled||!m->has_video)continue;background_clip=c;background_media=m;break;}}
        if(!media&&!text_media&&edit_.selected_media){media=project_.media_by_id(edit_.selected_media);source=0.0;media_id=edit_.selected_media;if(media&&media->generated_text.enabled){text_media=media;media=nullptr;}}
    }
    if(animation_workspace_){animation_sync_selection();if(auto* am=animation_media()){if(media!=am){background_clip=nullptr;background_media=nullptr;}media=am;preview_clip=project_.clip_by_id(animation_clip_id_);source=animation_time_;media_id=am->id;text_clip=nullptr;text_media=nullptr;}}
    if((!media||!media->has_video)&&!text_media){
        const bool had_frame=!preview_frame_.rgb.empty()||preview_media_id_!=0;
        if(had_frame||force){shown_preview_token_=++preview_token_;++preview_epoch_;}
        preview_frame_={};preview_media_id_=0;preview_source_time_=-1.0;
        if(had_frame)services_.request_redraw();
        return;
    }
    const bool interactive=paint_drag_||animation_drag_!=AnimationDrag::Idle;
    const bool transient_fx=fx_param_drag_.active&&preview_clip&&fx_param_drag_.clip_id==preview_clip->id;
    if(preview_tab_==PreviewTab::Trimmer&&!force&&!interactive&&!transient_fx&&!text_media&&media_id==preview_media_id_&&std::abs(source-preview_source_time_)<1.0/std::max(1.0,project_.settings.fps)*0.75)return;
    const int clip_id=preview_clip?preview_clip->id:0,bg_id=background_clip?background_clip->id:0,text_id=text_clip?text_clip->id:0;
    if(force||(!playing_&&!interactive)||transient_fx||media_id!=preview_media_id_||clip_id!=preview_clip_id_||bg_id!=preview_background_clip_id_||text_id!=preview_text_clip_id_||source<preview_source_time_-1e-4||source>preview_source_time_+.5)++preview_epoch_;
    preview_clip_id_=clip_id;preview_background_clip_id_=bg_id;preview_text_clip_id_=text_id;
    preview_media_id_=media_id;preview_source_time_=source;
    int w=640,h=360;
    if(preview_quality_==PreviewQuality::Draft){w=320;h=180;}
    else if(preview_quality_==PreviewQuality::Preview){w=640;h=360;}
    else if(preview_quality_==PreviewQuality::Good){w=960;h=540;}
    else {w=std::min(1920,std::max(640,project_.settings.width));h=std::min(1080,std::max(360,project_.settings.height));}
    const bool manual_proxy=media&&!media->proxy_path.empty()&&fs::exists(path_from_utf8(media->proxy_path));
    PreviewRequest req;req.path=media?(media->generated_vector.enabled?std::string{}:(manual_proxy?media->proxy_path:media->path)):std::string{};if(media&&media->generated_vector.enabled)req.vector_source=media->generated_vector;req.time=source;req.width=w;req.height=h;req.token=++preview_token_;req.allow_prepared_cache=media&&!manual_proxy&&use_prepared_cache_&&preview_quality_!=PreviewQuality::Best;
    if((media&&media->generated_vector.enabled)||(background_media&&background_media->generated_vector.enabled)){const double aspect=double(project_.settings.width)/std::max(1,project_.settings.height);if(double(req.width)/req.height>aspect)req.width=std::max(2,int(req.height*aspect)/2*2);else req.height=std::max(2,int(req.width/aspect)/2*2);}
    if(media&&media->duration>0&&!is_still_image_path(req.path))req.time=std::clamp(req.time,0.0,std::max(0.0,media->duration-1.0/std::max(1.0,media->fps)));
    req.continuous=media&&!req.path.empty()&&playing_&&!force;req.requested_fps=effective_preview_fps;req.source_rate=preview_clip?std::max(0.0001,preview_clip->rate):1.0;
    req.playback=(playing_&&!force)||interactive;req.playback_epoch=preview_epoch_;
    const double event_time=preview_clip?std::clamp(playhead_-preview_clip->start,0.0,preview_clip->duration):source;req.effect_time=event_time;
    if(preview_clip){
        double fade=1.0;
        if(preview_clip->fade_in>1e-9)fade*=std::clamp(event_time/preview_clip->fade_in,0.0,1.0);
        if(preview_clip->fade_out>1e-9)fade*=std::clamp((preview_clip->duration-event_time)/preview_clip->fade_out,0.0,1.0);
        const Track* track=project_.track_by_id(preview_clip->track_id);
        req.opacity=std::clamp(preview_clip->opacity*(track?track->opacity:1.0)*fade,0.0,1.0);
    }
    if(preview_clip&&preview_clip->video_motion.enabled){req.apply_motion=true;req.motion=sample_motion(preview_clip->video_motion,event_time);}
    if(media)req.effects.insert(req.effects.end(),media->video_effects.begin(),media->video_effects.end());
    if(preview_clip){
        for(const auto& source_effect:preview_clip->video_effects){
            EffectInstance effect=source_effect;
            if(transient_fx&&effect.id==fx_param_drag_.effect_id)set_effect_numeric(effect,fx_param_drag_.parameter_id,fx_param_drag_.value);
            req.effects.push_back(std::move(effect));
        }
        if(const Track* tr=project_.track_by_id(preview_clip->track_id))req.effects.insert(req.effects.end(),tr->video_effects.begin(),tr->video_effects.end());
    }
    if(background_clip&&background_media){
        double bg_source=background_clip->source_offset()+(playhead_-background_clip->start)*background_clip->rate;if(background_clip->loop&&background_media->duration>0.0)bg_source=std::fmod(bg_source,background_media->duration);
        req.has_background=true;req.background_source_rate=background_clip->rate;req.background_path=(!background_media->proxy_path.empty()&&fs::exists(path_from_utf8(background_media->proxy_path)))?background_media->proxy_path:background_media->path;if(background_media->generated_vector.enabled){req.background_path.clear();req.background_vector_source=background_media->generated_vector;}req.background_time=is_still_image_path(background_media->path)?0.0:std::clamp(bg_source,0.0,std::max(0.0,background_media->duration-1.0/std::max(1.0,background_media->fps)));req.background_allow_prepared_cache=background_media->proxy_path.empty()&&use_prepared_cache_&&preview_quality_!=PreviewQuality::Best;
        const double bg_event_time=std::clamp(playhead_-background_clip->start,0.0,background_clip->duration);req.background_effect_time=bg_event_time;
        double bg_fade=1.0;if(background_clip->fade_in>1e-9)bg_fade*=std::clamp(bg_event_time/background_clip->fade_in,0.0,1.0);if(background_clip->fade_out>1e-9)bg_fade*=std::clamp((background_clip->duration-bg_event_time)/background_clip->fade_out,0.0,1.0);const Track* bg_track=project_.track_by_id(background_clip->track_id);req.background_opacity=std::clamp(background_clip->opacity*(bg_track?bg_track->opacity:1.0)*bg_fade,0.0,1.0);
        if(background_clip->video_motion.enabled){req.background_apply_motion=true;req.background_motion=sample_motion(background_clip->video_motion,bg_event_time);}
        req.background_effects.insert(req.background_effects.end(),background_media->video_effects.begin(),background_media->video_effects.end());req.background_effects.insert(req.background_effects.end(),background_clip->video_effects.begin(),background_clip->video_effects.end());if(bg_track)req.background_effects.insert(req.background_effects.end(),bg_track->video_effects.begin(),bg_track->video_effects.end());
        // The persistent decoder currently owns one source pipe. A two-layer
        // keyed/opacity composite therefore uses exact cached frame requests
        // until the multi-stream compositor scheduler lands.
        req.continuous=playing_&&!force&&req.vector_source.enabled&&!req.background_path.empty()&&!req.background_vector_source.enabled;
    }
    if(text_media){
        req.has_text_overlay=true;
        req.text_overlay=(dialog_==DialogMode::TextEditor&&text_editor_media_id_==text_media->id)?text_editor_pending_:text_media->generated_text;
        req.text_event_time=text_clip?std::clamp(playhead_-text_clip->start,0.0,text_clip->duration):std::clamp(source_time_,0.0,std::max(0.0,text_media->duration));
        req.text_event_duration=text_clip?std::max(0.001,text_clip->duration):std::max(0.001,text_media->duration);
        req.text_opacity=1.0;
        if(text_clip){double fade=1.0;if(text_clip->fade_in>1e-9)fade*=std::clamp(req.text_event_time/text_clip->fade_in,0.0,1.0);if(text_clip->fade_out>1e-9)fade*=std::clamp((text_clip->duration-req.text_event_time)/text_clip->fade_out,0.0,1.0);const Track* tt=project_.track_by_id(text_clip->track_id);req.text_opacity=std::clamp(text_clip->opacity*(tt?tt->opacity:1.0)*fade,0.0,1.0);}
    }
    req.output_effects=project_.video_output_effects;req.output_effect_time=playhead_;
    // Realtime editing is allowed to trade temporary preview resolution for
    // cadence when the chain contains neighborhood/analysis-heavy effects.
    // Pause/stop immediately requests the full project-selected preview tier.
    const int fx_cost=effect_preview_cost(req.effects)+effect_preview_cost(req.output_effects);
    int realtime_cap_w=req.width,realtime_cap_h=req.height;
    if(playing_&&fx_cost>=8){realtime_cap_w=std::min(realtime_cap_w,480);realtime_cap_h=std::min(realtime_cap_h,270);}
    else if((playing_&&fx_cost>=4)||fx_param_drag_.active||paint_drag_){realtime_cap_w=std::min(realtime_cap_w,640);realtime_cap_h=std::min(realtime_cap_h,360);}
    req.width=std::max(2,realtime_cap_w&~1);req.height=std::max(2,realtime_cap_h&~1);
    engine_.request_preview(std::move(req));
}

void EditorApp::start_playback(){
    if(recording_audio_){set_status(tr("status.stop_recording_playback","Stop audio recording before playback"));return;}
    if(playing_)return;
    if(project_.duration()<=1e-9){set_status(tr("status.timeline_empty","Timeline is empty"));return;}
    playing_=true;play_wall_=std::chrono::steady_clock::now();play_start_=playhead_;
    audio_warning_shown_=false;resync_audio_preview(true);
    set_status(engine_.audio_preview_ready()?tr("status.playing_audio","Playing — audio preview on"):tr("status.playing_silent","Playing — silent (ffplay not found)"));
}

void EditorApp::pause_playback(bool stopped){
    playing_=false;engine_.stop_audio_preview();
    if(stopped)playhead_=0.0;
    set_status(stopped?tr("status.stopped","Stopped"):tr("status.paused","Paused"));request_preview(true);services_.request_redraw();
}

void EditorApp::resync_audio_preview(bool force){
    if(!playing_||!audio_preview_enabled_){engine_.stop_audio_preview();return;}
    if(mouse_down_ && edit_.drag.mode==DragMode::Playhead)return;
    const auto now=std::chrono::steady_clock::now();
    if(!force&&last_audio_sync_wall_.time_since_epoch().count()!=0&&std::chrono::duration<double>(now-last_audio_sync_wall_).count()<0.08)return;
    last_audio_sync_wall_=now;
    std::string err;
    if(!engine_.sync_audio_preview(project_,playhead_,&err)&&!err.empty()&&!audio_warning_shown_){
        audio_warning_shown_=true;set_status(tr("status.audio_preview_unavailable","Audio preview unavailable:")+" "+err);
    }
}

void EditorApp::toggle_audio_recording(){
    if(recording_audio_){stop_audio_recording(true);return;}
    pause_playback(false);
    int target=selected_track_id_;
    Track* track=project_.track_by_id(target);
    if(!track||track->kind!=TrackKind::Audio){
        target=0;for(auto& t:project_.tracks)if(t.kind==TrackKind::Audio){target=t.id;break;}
    }
    if(target==0){undo_.begin(project_);Track& created=project_.add_track(TrackKind::Audio,"Audio Record");target=created.id;if(undo_.commit(project_))mark_dirty();}
    const fs::path root=!project_.path.empty()?path_from_utf8(project_.path).parent_path()/"Recordings":fs::temp_directory_path()/"KoraLo"/"Recordings";
    std::error_code ec;fs::create_directories(root,ec);
    const auto stamp=std::chrono::high_resolution_clock::now().time_since_epoch().count();
    const std::string stem="Recording_"+std::to_string(stamp);
    recording_raw_path_=path_to_utf8(root/(stem+".pcm"));recording_wav_path_=path_to_utf8(root/(stem+".wav"));
    std::string error;
    if(!engine_.start_audio_recording(recording_raw_path_,project_.settings.sample_rate,1,&error)){
        services_.show_message(tr("dialog.audio_recording","Audio recording"),error.empty()?tr("error.audio_input_open","Could not open the default microphone/input device"):error,true);return;
    }
    recording_audio_=true;recording_track_id_=target;recording_start_time_=playhead_;recording_wall_=std::chrono::steady_clock::now();selected_track_id_=target;
    set_status(tr("status.recording_click_stop","Recording audio… click REC again to stop"));services_.request_redraw();
}

void EditorApp::stop_audio_recording(bool commit){
    if(!recording_audio_)return;
    double duration=0.0;std::string error;
    const bool ok=engine_.stop_audio_recording(recording_wav_path_,&duration,&error);
    recording_audio_=false;
    if(!ok){if(commit)services_.show_message(tr("dialog.audio_recording","Audio recording"),error.empty()?tr("error.recording_finalize","Recording could not be finalized"):error,true);std::error_code ec;fs::remove(path_from_utf8(recording_wav_path_),ec);services_.request_redraw();return;}
    if(!commit){std::error_code ec;fs::remove(path_from_utf8(recording_wav_path_),ec);services_.request_redraw();return;}
    const double frame=1.0/std::max(1.0,project_.settings.fps);
    if(duration<frame){std::error_code ec;fs::remove(path_from_utf8(recording_wav_path_),ec);set_status(tr("status.recording_too_short","Recording was too short"));return;}
    MediaItem item;std::string probe_error;if(auto probed=engine_.probe(recording_wav_path_,&probe_error))item=std::move(*probed);else{item.path=recording_wav_path_;item.name=basename_utf8(recording_wav_path_);item.duration=duration;item.has_audio=true;item.audio_channels=1;item.sample_rate=project_.settings.sample_rate;item.audio_codec="pcm_s16le";}
    undo_.begin(project_);MediaItem& media=project_.add_media(std::move(item));Clip& clip=project_.add_clip(media.id,recording_track_id_,recording_start_time_,0.0,std::max(frame,duration),0);const int clip_id=clip.id;
    if(undo_.commit(project_)){mark_dirty();edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,false);edit_.selected_media=media.id;engine_.prepare_media(media);playhead_=recording_start_time_+duration;set_status(tr("status.recorded","Recorded")+" "+media.name+" ("+timecode(duration)+")");}
    recording_raw_path_.clear();recording_wav_path_.clear();services_.request_redraw();
}

void EditorApp::tick(){
    const auto ui_now=std::chrono::steady_clock::now();
    if((paint_preview_pending_||animation_preview_pending_)&&(last_edit_preview_wall_.time_since_epoch().count()==0||std::chrono::duration<double>(ui_now-last_edit_preview_wall_).count()>=1.0/30.0)){last_edit_preview_wall_=ui_now;paint_preview_pending_=animation_preview_pending_=false;request_preview(false);}

    if(ui_animation_active_&&(last_ui_anim_redraw_.time_since_epoch().count()==0||std::chrono::duration<double>(ui_now-last_ui_anim_redraw_).count()>=1.0/60.0)){last_ui_anim_redraw_=ui_now;services_.request_redraw();}
    if(recording_audio_){if(!engine_.audio_recording_active()){stop_audio_recording(true);}else{const auto now=std::chrono::steady_clock::now();playhead_=std::min(kTimelineMaxSeconds,recording_start_time_+std::chrono::duration<double>(now-recording_wall_).count());services_.request_redraw();}}
    if(playing_){
        auto now=std::chrono::steady_clock::now();
        double elapsed=std::chrono::duration<double>(now-play_wall_).count();
        double t=play_start_+elapsed*play_speed_;
        double end=project_.duration();
        if(preview_tab_==PreviewTab::Trimmer){
            const MediaItem* m=project_.media_by_id(edit_.selected_media);
            double trim_end=(source_out_>0.0)?source_out_:(m?m->duration:0.0);
            if(trim_end>0.0)end=trim_end;
        }
        if(end<=1e-9){
            pause_playback(true);
            return;
        }else if(t>=end){
            if(preview_tab_==PreviewTab::Trimmer)source_time_=end;
            else playhead_=end;
            pause_playback(false);
            return;
        }
        if(preview_tab_==PreviewTab::Trimmer)source_time_=t;
        else playhead_=t;
        if(dialog_==DialogMode::PanCrop){
            if(const Clip* clip=project_.clip_by_id(pan_crop_clip_id_))
                pan_crop_time_=std::clamp(playhead_-clip->start,0.0,std::max(0.0,clip->duration));
        }
        resync_audio_preview(false);
        request_preview(false);
        const auto meter=engine_.master_meter(project_,playhead_);
        const double target_l=meter.ready?meter.left:0.0,target_r=meter.ready?meter.right:0.0;
        // Fast attack / smooth release so the native meter behaves like an NLE
        // meter rather than flickering between analysis blocks.
        meter_left_=target_l>meter_left_?target_l:(meter_left_*0.88+target_l*0.12);
        meter_right_=target_r>meter_right_?target_r:(meter_right_*0.88+target_r*0.12);
        services_.request_redraw();}
    else {meter_left_*=0.82;meter_right_*=0.82;if(meter_left_<1e-5)meter_left_=0.0;if(meter_right_<1e-5)meter_right_=0.0;}
    std::uint64_t token;Frame f;std::string err;if(engine_.poll_preview(token,f,err)&&token>=shown_preview_token_){shown_preview_token_=token;if(!f.rgb.empty())preview_frame_=std::move(f);preview_error_=std::move(err);services_.request_redraw();}
    const auto thumb_rev=engine_.thumbnail_revision();if(thumb_rev!=thumbnail_revision_seen_){thumbnail_revision_seen_=thumb_rev;services_.request_redraw();}
    const auto prep=engine_.overall_preparation_status();if(std::abs(prep.progress-preparation_ui_.progress)>0.002||prep.stage!=preparation_ui_.stage||prep.running!=preparation_ui_.running||prep.ready!=preparation_ui_.ready){preparation_ui_=prep;services_.request_redraw();}
    if(rendering_){
        const auto now=std::chrono::steady_clock::now();
        if(now-render_redraw_>=std::chrono::milliseconds(100)){render_redraw_=now;services_.request_redraw();}
        if(render_future_.valid()&&render_future_.wait_for(std::chrono::milliseconds(0))==std::future_status::ready){
            auto[ok,message]=render_future_.get();rendering_=false;render_finished_=true;render_succeeded_=ok;
            render_elapsed_=std::chrono::duration<double>(now-render_started_).count();render_result_message_=message;
            if(ok){render_progress_=1;render_cancel_=false;}
            set_status(ok?tr("status.render_complete","Export complete"):(render_cancel_?tr("status.render_cancelled","Export cancelled"):tr("status.render_failed","Export failed")));
            dialog_=DialogMode::RenderAs;
            if(!ok&&!render_cancel_)services_.show_message(tr("status.render_failed","Export failed"),message,true);
            services_.request_redraw();
        }
    }
    autosave_if_needed(false);
}

void EditorApp::new_project(){if(recording_audio_)stop_audio_recording(true);if(!confirm_project_replace())return;shown_preview_token_=++preview_token_;preview_media_id_=0;preview_source_time_=-1;last_autosave_wall_={};engine_.stop_audio_preview();playing_=false;project_=Project::make_default();sync_preview_settings_from_project();undo_.clear();edit_={};clipboard_.clear();playhead_=0;source_media_id_=0;source_time_=0;source_in_=0;source_out_=-1;dirty_=false;engine_.clear_cache();preview_frame_={};update_title();set_status(tr("status.new_project","New project"));}
void EditorApp::open_project(){auto path=services_.open_project_file();if(path.empty())return;open_project_path(path);}

void EditorApp::open_project_path(const std::string& path){
    if(recording_audio_)stop_audio_recording(true);
    std::string ext=path_to_utf8(path_from_utf8(path).extension());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    if(ext==".veg"){import_vegas_project(path);return;}
    std::string err;auto p=Project::load(path,&err);if(!p){services_.show_message(tr("dialog.open_project","Open project"),err,true);return;}
    if(!confirm_project_replace())return;
    shown_preview_token_=++preview_token_;preview_media_id_=0;preview_source_time_=-1;preview_frame_={};last_autosave_wall_={};
    engine_.stop_audio_preview();playing_=false;project_=std::move(*p);sync_preview_settings_from_project();undo_.clear();edit_={};clipboard_.clear();playhead_=0;source_media_id_=0;source_time_=0;source_in_=0;source_out_=-1;dirty_=false;engine_.clear_cache();engine_.prepare_project(project_);update_title();request_preview(true);
}

bool EditorApp::import_vegas_project(const std::string& path){
    std::string error;auto inspection=inspect_vegas_project(path,&error);
    if(!inspection){services_.show_message(tr("dialog.open_vegas","Open VEGAS project"),error,true);return false;}
    if (recording_audio_) {
        stop_audio_recording(true);
    }
    if (!confirm_project_replace()) return false;
    shown_preview_token_=++preview_token_;preview_media_id_=0;preview_source_time_=-1;preview_frame_={};last_autosave_wall_={};
    Project imported=make_vegas_import_project(*inspection,path);
    imported.media.clear();imported.clips.clear();
    int available=0,offline=0,relinked=0,mapped_fx=0,generated_events=0;
    const fs::path project_dir=path_from_utf8(path).parent_path();
    auto lower_ext=[](const std::string& p){const std::string base=basename_utf8(p);const auto dot=base.find_last_of('.');std::string ext=dot==std::string::npos?std::string{}:base.substr(dot);std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return ext;};
    auto audio_ext=[&](const std::string& p){const std::string e=lower_ext(p);return e==".wav"||e==".mp3"||e==".flac"||e==".aac"||e==".m4a"||e==".ogg"||e==".wma";};
    auto resolve_media=[&](const std::string& original)->std::string{
        if(fs::exists(path_from_utf8(original)))return original;
        const std::string wanted=basename_utf8(original);if(wanted.empty())return original;
        const fs::path exact=project_dir/path_from_utf8(wanted);if(fs::exists(exact))return path_to_utf8(exact);
        const std::string wanted_lower=lower_ascii(wanted);std::error_code ec;
        for(const auto& entry:fs::directory_iterator(project_dir,ec)){if(ec)break;if(!entry.is_regular_file())continue;if(lower_ascii(path_to_utf8(entry.path().filename()))==wanted_lower)return path_to_utf8(entry.path());}
        return original;
    };
    for(const auto& media_path:inspection->media_paths){
        MediaItem item;std::string probe_error;const std::string resolved=resolve_media(media_path);const bool local_relink=resolved!=media_path;
        if(engine_.ready()&&fs::exists(path_from_utf8(resolved))){auto probed=engine_.probe(resolved,&probe_error);if(probed){item=std::move(*probed);++available;if(local_relink)++relinked;}}
        if(item.path.empty()){
            item.path=resolved;item.name=basename_utf8(media_path);++offline;
            const std::string ext=lower_ext(media_path);
            if(audio_ext(media_path))item.has_audio=true;
            else if(ext==".png"||ext==".jpg"||ext==".jpeg"||ext==".bmp"||ext==".tif"||ext==".tiff"||ext==".webp"){item.has_video=true;item.duration=5.0;}
            else item.has_video=true;
        }else item.name=basename_utf8(media_path);
        // FFmpeg exposes album artwork as video streams for many MP3 files.
        // VEGAS treats the source itself as audio media.
        if(audio_ext(media_path)){item.has_video=false;item.has_audio=true;}
        imported.add_media(std::move(item));
    }

    auto find_media=[&](const VegasImportedEvent& event)->MediaItem*{
        if(event.generated_media||imported.media.empty())return nullptr;
        if(imported.media.size()==1)return &imported.media.front();
        const std::string hint=lower_ascii(event.media_hint);
        for(auto& m:imported.media){
            std::string stem=basename_utf8(m.name);const auto dot=stem.find_last_of('.');if(dot!=std::string::npos)stem=stem.substr(0,dot);stem=lower_ascii(stem);
            if(!hint.empty()&&(stem==hint||stem.find(hint)!=std::string::npos||hint.find(stem)!=std::string::npos))return &m;
        }
        return nullptr;
    };
    auto ensure_generated_media=[&](const VegasImportedEvent& event)->MediaItem*{
        const std::string name=event.media_hint.empty()?"(Legacy) Text":event.media_hint;
        for(auto& m:imported.media)if(m.path.empty()&&m.video_codec=="koralo.generated.legacy_text"&&m.name==name)return &m;
        MediaItem generated;generated.name=name;generated.duration=std::max(0.001,event.duration);generated.width=imported.settings.width;generated.height=imported.settings.height;generated.fps=imported.settings.fps;generated.has_video=true;generated.video_codec="koralo.generated.legacy_text";generated.generated_text.enabled=true;generated.generated_text.text="Sample Text";generated.generated_text.font_family="Inter";
        return &imported.add_media(std::move(generated));
    };

    int recovered_events=0;
    if(!inspection->tracks.empty()){
        imported.tracks.clear();
        for(std::size_t ti=0;ti<inspection->tracks.size();++ti){
            const auto& src_track=inspection->tracks[ti];
            TrackKind kind=TrackKind::Video;
            bool any_audio=false,any_video=false;
            for(const auto& event:src_track.events){if(event.generated_media)any_video=true;else if(auto* m=find_media(event)){any_audio|=m->has_audio;any_video|=m->has_video;}}
            if(!src_track.audio_fx_names.empty())any_audio=true;
            if(any_audio&&!any_video)kind=TrackKind::Audio;else kind=TrackKind::Video;
            Track& dst=imported.add_track(kind,(kind==TrackKind::Video?"Video ":"Audio ")+std::to_string(ti+1));
            dst.imported_audio_fx=src_track.audio_fx_names;
            if(kind==TrackKind::Audio){for(const auto& name:src_track.audio_fx_names){std::string lower=name;std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});std::string mapped;if(lower.find("noise gate")!=std::string::npos)mapped="koralo.audio.noise_gate";else if(lower.find("compressor")!=std::string::npos)mapped="koralo.audio.compressor";else if(lower.find("track eq")!=std::string::npos||lower.find("equalizer")!=std::string::npos)mapped="koralo.audio.eq3";if(!mapped.empty()){auto fx=make_audio_effect_instance(mapped,imported.next_id());fx.enabled=false;dst.audio_effects.push_back(std::move(fx));++mapped_fx;}}}
            for(const auto& event:src_track.events){
                MediaItem* media=event.generated_media?ensure_generated_media(event):find_media(event);if(!media)continue;
                if(kind==TrackKind::Audio&&!media->has_audio)continue;
                if(kind==TrackKind::Video&&!media->has_video)continue;
                media->duration=std::max(media->duration,event.source_offset+event.duration);
                Clip& clip=imported.add_clip(media->id,dst.id,event.start,event.source_offset,event.duration,0);
                if(event.generated_media)++generated_events;
                for(const auto& source_fx:event.video_fx_ids){
                    if(source_fx.find("chromakeyer")!=std::string::npos&&event.chroma_key.valid){
                        EffectInstance instance=make_effect_instance("koralo.chroma_key",imported.next_id());
                        set_effect_numeric(instance,"color_r",event.chroma_key.color.r);set_effect_numeric(instance,"color_g",event.chroma_key.color.g);set_effect_numeric(instance,"color_b",event.chroma_key.color.b);
                        set_effect_numeric(instance,"low_threshold",event.chroma_key.low_threshold);set_effect_numeric(instance,"high_threshold",event.chroma_key.high_threshold);set_effect_numeric(instance,"blur_amount",event.chroma_key.blur_amount);
                        if(auto* mask=effect_parameter(instance,"show_mask_only"))mask->value=event.chroma_key.show_mask_only;
                        instance.enabled=true;clip.video_effects.push_back(std::move(instance));++mapped_fx;continue;
                    }
                    const std::string mapped=mapped_vegas_video_fx(source_fx);if(mapped.empty())continue;EffectInstance instance=make_effect_instance(mapped,imported.next_id());instance.enabled=false;clip.video_effects.push_back(std::move(instance));++mapped_fx;
                }
                ++recovered_events;
            }
        }
        if(imported.tracks.empty())imported=make_vegas_import_project(*inspection,path);
    }
    if(recovered_events==0&&imported.media.size()==1&&imported.media.front().duration>0.0){
        const MediaItem& m=imported.media.front();int vt=0,at=0;for(const auto&t:imported.tracks){if(!vt&&t.kind==TrackKind::Video)vt=t.id;if(!at&&t.kind==TrackKind::Audio)at=t.id;}
        const int group=m.has_video&&m.has_audio?imported.next_group_id():0;if(m.has_video&&vt)imported.add_clip(m.id,vt,0.0,0.0,m.duration,group);if(m.has_audio&&at)imported.add_clip(m.id,at,0.0,0.0,m.duration,group);
    }
    engine_.stop_audio_preview();playing_=false;project_=std::move(imported);sync_preview_settings_from_project();undo_.clear();edit_={};clipboard_.clear();playhead_=0;source_time_=0;source_in_=0;source_out_=-1;engine_.clear_cache();dirty_=true;fit_timeline_requested_=true;
    if(!project_.media.empty()){edit_.selected_media=project_.media.front().id;source_media_id_=edit_.selected_media;}
    update_title();engine_.prepare_project(project_);request_preview(true);
    std::ostringstream report;report<<"Imported VEGAS project container.\n\n"<<"Recovered media references: "<<inspection->media_paths.size()<<"\n"<<"Recovered tracks: "<<inspection->tracks.size()<<"   TrackEvents: "<<recovered_events<<"\n"<<"Online: "<<available<<"   Relinked beside .veg: "<<relinked<<"   Offline: "<<offline;
    if(inspection->has_settings)report<<"\nProject: "<<inspection->settings.width<<"x"<<inspection->settings.height<<" @ "<<std::fixed<<std::setprecision(3)<<inspection->settings.fps<<" fps, "<<inspection->settings.sample_rate<<" Hz";
    report<<"\nGenerated-media events preserved: "<<generated_events<<" (Legacy Text rendering is still pending).";
    report<<"\nPreserved event FX identities: "<<mapped_fx<<" / observed "<<inspection->observed_video_fx_ids.size()<<" unique VEGAS video FX IDs.";
    if(!inspection->observed_audio_fx_names.empty())report<<"\nObserved audio track FX: "<<inspection->observed_audio_fx_names.size()<<" (identity preserved in import report; DSP mapping pending).";
    report<<"\n\nValidated now: VEGAS 12/17 project settings layouts, media pool paths including WMV, local-folder relinking, empty track order, TrackEvent timing, Take offsets and Event FX identities. Old Svfx Chroma Keyer named color/threshold/blur/mask values are converted to the native KoraLo keyer when validated; unknown FX blobs, fades/groups, Bézier curve-point serialization and unmapped FX remain opaque.";
    for(const auto&w:inspection->warnings)report<<"\n- "<<w;
    set_status(tr("status.vegas_imported","VEGAS project imported - save as .kora to preserve KoraLo edits"));services_.show_message(tr("dialog.vegas_report","VEGAS import report"),report.str(),false);services_.request_redraw();return true;
}

void EditorApp::save_project(bool save_as){if(recording_audio_)stop_audio_recording(true);std::string path=project_.path;if(save_as||path.empty())path=services_.save_project_file(project_.name);if(path.empty())return;if(path_from_utf8(path).extension().empty())path+=".kora";if(project_.save(path)){project_.path=path;project_.name=basename_utf8(path);dirty_=false;remove_autosave();last_autosave_wall_=std::chrono::steady_clock::now();update_title();set_status(tr("status.saved_prefix","Saved")+" "+project_.name);}else services_.show_message(tr("dialog.save_project","Save project"),tr("error.save_project","Could not write project"),true);}

void EditorApp::render_as(){
    if(recording_audio_){set_status(tr("status.stop_recording_render","Stop audio recording before rendering"));return;}
    if(rendering_){dialog_=DialogMode::RenderAs;services_.request_redraw();return;}
    if(project_.clips.empty()){services_.show_message(tr("render.start","Render"),tr("status.timeline_empty","Timeline is empty"),true);return;}
    if(render_presets_.empty())return;
    render_pending_=render_presets_[static_cast<std::size_t>(std::clamp(render_preset_index_,0,static_cast<int>(render_presets_.size())-1))];
    if(render_pending_.name=="Editing / High Bitrate"){render_pending_.width=project_.settings.width;render_pending_.height=project_.settings.height;render_pending_.fps=project_.settings.fps;}
    render_finished_=false;dialog_=DialogMode::RenderAs;active_menu_=MainMenu::None;set_status(tr("status.render_choose_preset","Render As — choose or edit a preset"));services_.request_redraw();
}

void EditorApp::begin_render_with_preset(){
    if(rendering_)return;
    auto path=services_.save_render_file("output.mp4");if(path.empty())return;
    Project snapshot=project_;
    RenderOptions options;options.width=render_pending_.width;options.height=render_pending_.height;options.fps=render_pending_.fps;options.video_bitrate_kbps=render_pending_.video_kbps;options.audio_bitrate_kbps=render_pending_.audio_kbps;options.use_gpu=render_pending_.gpu;options.preset_name=render_pending_.name;options.fsr_upscale=render_fsr_;options.fsr_sharpness=render_fsr_sharpness_;
    std::string preflight_error;
    if(!plan_render_project(snapshot,path,&options,engine_.gpu_enabled(),nullptr,&preflight_error)){services_.show_message(tr("status.render_failed","Export failed"),preflight_error,true);return;}
    pause_playback(false);
    dialog_=DialogMode::RenderAs;render_output_path_=path;render_finished_=false;render_succeeded_=false;render_result_message_.clear();
    render_started_=std::chrono::steady_clock::now();render_elapsed_=0;
    render_progress_=0;render_cancel_=false;rendering_=true;set_status(tr("status.preflight_rendering","Preflight complete — rendering")+" "+render_pending_.name+"...");
    try {
    render_future_=std::async(std::launch::async,[this,snapshot=std::move(snapshot),path,options]()mutable{try{std::string err;bool ok=engine_.render_project(snapshot,path,&render_progress_,&err,&options,&render_cancel_);return std::make_pair(ok,ok?("Saved: "+path+"\nPreset: "+options.preset_name):err);}catch(const std::exception& e){return std::make_pair(false,std::string(e.what()));}catch(...){return std::make_pair(false,std::string("Unexpected export failure"));}});
    }catch(const std::exception& error){rendering_=false;render_finished_=true;render_result_message_=error.what();services_.show_message(tr("status.render_failed","Export failed"),error.what(),true);}
}

void EditorApp::refresh_ofx_plugins(bool show_status){
    ofx_registry_.scan();
    std::vector<EffectDefinition> external;
    external.reserve(ofx_registry_.plugins().size());
    for(const auto& plugin:ofx_registry_.plugins()){
        if(!plugin.image_effect||plugin.identifier.empty())continue;
        std::string name=plugin.identifier;
        const auto dot=name.find_last_of('.');if(dot!=std::string::npos&&dot+1<name.size())name=name.substr(dot+1);
        if(name.size()>40)name=name.substr(0,37)+"...";
        const std::string category=plugin.boris_fx?"OFX / Boris FX (beta)":"OFX / External (beta)";
        external.push_back({"ofx:"+plugin.identifier,name,category,EffectEvent|EffectTrack|EffectOutput,true,{}});
    }
    set_external_effect_definitions(std::move(external));
    if(show_status){
        set_status(ofx_registry_.summary());
        services_.show_message("OpenFX / Boris FX",ofx_registry_.summary()+"\n\nKoraLo r24 can discover and identify OFX image-effect plug-ins. Third-party OFX pixel rendering is deliberately gated until the full image/parameter suites are implemented and validated against a real installed plug-in.",false);
    }
}

void EditorApp::run_system_check(bool show_dialog){
    std::ostringstream report;
    const unsigned threads=std::max(1u,std::thread::hardware_concurrency());
    report<<"CPU threads: "<<threads<<"\n"<<engine_.diagnostics()<<"\n"<<ofx_registry_.summary()<<"\nTimeline limit: 12 hours";
    bool temp_ok=false;
    try{TemporaryFile probe(temporary_directory(),".diagnostic");temp_ok=probe.valid();}catch(...){temp_ok=false;}
    report<<"\nTemporary storage: "<<(temp_ok?"writable":"NOT writable");
    if(!engine_.ready())report<<"\nCRITICAL: FFmpeg/FFprobe unavailable";
    if(!engine_.audio_preview_ready())report<<"\nWarning: ffplay unavailable; realtime preview audio disabled";
    system_report_=report.str();
    std::ostringstream short_status;short_status<<"System check: "<<threads<<" threads, "<<(engine_.ready()?"FFmpeg OK":"FFmpeg missing")<<", GPU "<<engine_.gpu_backend().label;set_status(short_status.str());
    if(show_dialog)services_.show_message("KoraLo System Check",system_report_,!engine_.ready()||!temp_ok);
}

void EditorApp::clamp_timeline_scroll(){
    auto&g=layout_.timeline_geo;const double visible=std::max(0.001,(g.width-g.header_w)/std::max(1.0,g.px_per_sec));
    g.scroll_sec=std::clamp(g.scroll_sec,0.0,std::max(0.0,kTimelineMaxSeconds-visible));
    const auto vertical_scroll=timeline_vertical_scroll_metrics(project_,g);
    g.scroll_y=std::clamp(g.scroll_y,0,vertical_scroll.max_scroll);
}

bool EditorApp::drop_effect_on_timeline(const std::string& definition_id,int x,int y){
    const EffectDefinition* def=effect_definition(definition_id);if(!def||!(def->contexts&EffectEvent)||!layout_.timeline.contains(x,y))return false;
    if(definition_id.rfind("ofx:",0)==0){set_status(tr("status.ofx_drag_gated","OFX/Boris FX plug-in detected; drag/drop rendering is gated until the full OFX image suites are ready"));return true;}
    int edge=0;const int cid=edit_.hit_clip(project_,layout_.timeline_geo,x,y,&edge);if(!cid)return false;
    Clip* clip=project_.clip_by_id(cid);const Track* track=clip?project_.track_by_id(clip->track_id):nullptr;if(!clip||!track||track->kind!=TrackKind::Video)return false;
    undo_.begin(project_);clip->video_effects.push_back(make_effect_instance(definition_id,project_.next_id()));
    if(!undo_.commit(project_)){undo_.cancel();return false;}
    edit_.selection.select_clip(project_,cid,SelectionOperation::Replace,false);selected_track_id_=track->id;mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.dropped_fx","Dropped FX:")+" "+tr("catalog."+def->name,def->name));return true;
}

void EditorApp::create_proxy_for_selected(){
    auto*m=project_.media_by_id(edit_.selected_media);if(!m){set_status(tr("status.select_media_first","Select media in Project Media first"));return;}if(!m->has_video){set_status(tr("status.proxy_video_only","Proxy is available for video media"));return;}
    fs::path src=path_from_utf8(m->path);fs::path out=src.parent_path()/src.stem();out += ".koralo-proxy.mp4";const std::string out_utf8=path_to_utf8(out);std::string err;set_status(tr("status.creating_proxy","Creating proxy..."));if(engine_.create_proxy(*m,out_utf8,540,&err)){m->proxy_path=out_utf8;mark_dirty();set_status(tr("status.proxy_ready","Proxy ready:")+" "+path_to_utf8(out.filename()));}else services_.show_message(tr("dialog.proxy","Proxy"),err,true);
}

void EditorApp::step_preview(int frames){
    const double frame=1.0/std::max(1.0,project_.settings.fps);
    if(preview_tab_==PreviewTab::Trimmer){
        const MediaItem* media=project_.media_by_id(edit_.selected_media);if(!media)return;
        source_time_=std::clamp(source_time_+frames*frame,0.0,std::max(0.0,media->duration));request_preview(true);services_.request_redraw();return;
    }
    set_playhead(playhead_+frames*frame,true);
}

void EditorApp::show_project_settings(){
    pending_project_settings_=project_.settings;dialog_=DialogMode::ProjectProperties;active_menu_=MainMenu::None;services_.request_redraw();
}

void EditorApp::show_help(){
    services_.show_message("KoraLo shortcuts",
        "Space Play/Pause\nS Split at cursor\nI/O Source In/Out\nM Marker\nDelete Delete selection\nShift+Arrow Nudge event\nCtrl+Z/Y Undo/Redo\nCtrl+C/X/V Copy/Cut/Paste\nCtrl+S Save, Ctrl+Shift+S Save As\nCtrl+O Open, Ctrl+I Import\nCtrl+L Lock selection\nCtrl+mouse wheel Timeline zoom\nShift+edge Roll; Ctrl+Shift+edge Ripple Trim; Alt+Shift body Slide; Alt body Slip",false);
}

void EditorApp::add_marker(){
    undo_.begin(project_);project_.markers.push_back({playhead_,"Marker "+std::to_string(project_.markers.size()+1)});if(undo_.commit(project_)){mark_dirty();set_status(tr("status.marker_added","Marker added at")+" "+timecode(playhead_));}
}

void EditorApp::set_source_in(){
    const MediaItem* media=project_.media_by_id(edit_.selected_media);if(!media){set_status(tr("status.select_source_first","Select source media first"));return;}
    source_in_=std::clamp(source_time_,0.0,std::max(0.0,media->duration));if(source_out_>=0&&source_out_<=source_in_)source_out_=-1;set_status(tr("status.source_in","Source In:")+" "+timecode(source_in_));
}

void EditorApp::set_source_out(){
    const MediaItem* media=project_.media_by_id(edit_.selected_media);if(!media){set_status(tr("status.select_source_first","Select source media first"));return;}
    const double frame=1.0/std::max(1.0,project_.settings.fps);source_out_=std::clamp(std::max(source_time_,source_in_+frame),0.0,std::max(frame,media->duration));set_status(tr("status.source_out","Source Out:")+" "+timecode(source_out_));
}

void EditorApp::insert_from_trimmer(bool overwrite){
    const MediaItem* media=project_.media_by_id(edit_.selected_media);if(!media){set_status(tr("status.select_source_first","Select source media first"));return;}
    const double out=source_out_>source_in_?source_out_:media->duration;
    const bool changed=overwrite?edit_.overwrite_media(project_,undo_,media->id,source_in_,out,playhead_):edit_.insert_media(project_,undo_,media->id,source_in_,out,playhead_);
    if(changed){mark_dirty();request_preview(true);set_status(overwrite?tr("status.overwrite_trimmer","Overwrite from Trimmer"):tr("status.insert_trimmer","Insert from Trimmer"));}else set_status(tr("status.trimmer_failed","Trimmer edit could not be applied (check range/locks)"));
}

void EditorApp::open_pan_crop(int clip_id){
    Clip* clip=project_.clip_by_id(clip_id);if(!clip)return;
    const Track* track=project_.track_by_id(clip->track_id);const MediaItem* media=project_.media_by_id(clip->media_id());
    if(!track||track->kind!=TrackKind::Video||!media||!media->has_video){set_status(tr("status.pan_crop_video_only","Pan/Crop is available for video events"));return;}
    edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,!project_.ignore_event_grouping);
    pan_crop_clip_id_=clip_id;pan_crop_time_=clip->contains(playhead_)?std::clamp(playhead_-clip->start,0.0,clip->duration):0.0;pan_crop_drag_.clear();
    dialog_=DialogMode::PanCrop;active_menu_=MainMenu::None;set_playhead(clip->start+pan_crop_time_,true);set_status(tr("pan_crop.title","Video Event Pan/Crop"));services_.request_redraw();
}

void EditorApp::open_effect_editor(int clip_id,int effect_id){
    Clip* clip=project_.clip_by_id(clip_id);if(!clip)return;
    const Track* track=project_.track_by_id(clip->track_id);const MediaItem* media=project_.media_by_id(clip->media_id());
    if(!track||track->kind!=TrackKind::Video||!media||!media->has_video){set_status(tr("status.fx_video_only","FX editor is available for video events"));return;}
    edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,!project_.ignore_event_grouping);
    fx_editor_clip_id_=clip_id;
    fx_editor_effect_id_=effect_id;
    if(fx_editor_effect_id_==0 && !clip->video_effects.empty()) fx_editor_effect_id_=clip->video_effects.front().id;
    dialog_=DialogMode::EffectEditor;active_menu_=MainMenu::None;bin_tab_=BinTab::VideoFx;
    if(!clip->contains(playhead_)) set_playhead(clip->start,true); else request_preview(true);
    set_status(tr("status.video_fx_editor","Video Event FX editor"));services_.request_redraw();
}

void EditorApp::insert_text_event(){
    Track* target=nullptr;
    if(selected_track_id_){Track* selected=project_.track_by_id(selected_track_id_);if(selected&&selected->kind==TrackKind::Video&&!selected->locked)target=selected;}
    if(!target)for(auto& track:project_.tracks)if(track.kind==TrackKind::Video&&!track.locked){target=&track;break;}
    if(!target){undo_.begin(project_);target=&project_.add_track(TrackKind::Video,"Video 1");if(!undo_.commit(project_))undo_.cancel();}
    if(!target)return;
    undo_.begin(project_);
    MediaItem generated;generated.name="Titles & Text";generated.duration=5.0;generated.width=project_.settings.width;generated.height=project_.settings.height;generated.fps=project_.settings.fps;generated.has_video=true;generated.video_codec="koralo.generated.titles_text";generated.generated_text.enabled=true;generated.generated_text.text="Sample Text";generated.generated_text.font_family="Inter";
    MediaItem& media=project_.add_media(std::move(generated));
    Clip& clip=project_.add_clip(media.id,target->id,playhead_,0.0,5.0,0);
    const int clip_id=clip.id,media_id=media.id;
    if(undo_.commit(project_)){mark_dirty();edit_.selected_media=media_id;edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,false);open_text_editor(clip_id);set_status(tr("status.text_inserted","Titles & Text inserted at cursor"));}
    else undo_.cancel();
}

void EditorApp::open_text_editor(int clip_id){
    Clip* clip=project_.clip_by_id(clip_id);if(!clip)return;MediaItem* media=project_.media_by_id(clip->media_id());const Track* track=project_.track_by_id(clip->track_id);
    if(!media||!track||track->kind!=TrackKind::Video||!media->generated_text.enabled){set_status(tr("status.not_generated_text","This event is not generated text"));return;}
    edit_.selection.select_clip(project_,clip_id,SelectionOperation::Replace,false);selected_track_id_=clip->track_id;text_editor_clip_id_=clip_id;text_editor_media_id_=media->id;text_editor_pending_=media->generated_text;text_editor_text_focus_=true;dialog_=DialogMode::TextEditor;active_menu_=MainMenu::None;
    if(!clip->contains(playhead_)) playhead_=clip->start;
    request_preview(true);
    services_.request_redraw();
}

void EditorApp::pan_crop_set_key(const VideoMotionSample& sample){
    Clip* clip=project_.clip_by_id(pan_crop_clip_id_);if(!clip)return;undo_.begin(project_);clip->video_motion.set_key(pan_crop_time_,sample.center_x,sample.center_y,sample.zoom,sample.rotation);
    if(undo_.commit(project_)){mark_dirty();engine_.clear_composite_cache();request_preview(true);set_status(tr("status.pan_crop_key_updated","Pan/Crop keyframe updated"));}else undo_.cancel();services_.request_redraw();
}

void EditorApp::set_bin_tab(BinTab tab){bin_tab_=tab;search_editing_=false;if(tab!=BinTab::VideoFx&&tab!=BinTab::AudioFx)fx_search_editing_=false;services_.request_redraw();}
void EditorApp::set_media_filter(MediaFilter filter){media_filter_=filter;bin_tab_=BinTab::ProjectMedia;services_.request_redraw();}

bool EditorApp::media_visible(const MediaItem& media) const{
    std::string ext=path_to_utf8(path_from_utf8(media.path).extension());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    const bool still=ext==".png"||ext==".jpg"||ext==".jpeg"||ext==".bmp"||ext==".webp"||ext==".tif"||ext==".tiff";
    if(media_filter_==MediaFilter::Audio&&!(media.has_audio&&!media.has_video))return false;
    if(media_filter_==MediaFilter::Video&&!(media.has_video&&!still))return false;
    if(media_filter_==MediaFilter::Stills&&!still)return false;
    if(search_query_.empty())return true;
    auto lower=[](std::string v){for(char& ch:v)if(static_cast<unsigned char>(ch)<128)ch=static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));return v;};
    return lower(media.name).find(lower(search_query_))!=std::string::npos;
}

bool EditorApp::visible_video_clip(const Clip& clip) const{
    if(clip.muted)return false;
    const Track* track=project_.track_by_id(clip.track_id);
    if(!track||track->kind!=TrackKind::Video||track->mute)return false;
    bool any_solo=false;
    for(const auto& t:project_.tracks)if(t.kind==TrackKind::Video&&t.solo)any_solo=true;
    return !any_solo||track->solo;
}

std::string EditorApp::preview_quality_name() const{
    if(preview_quality_==PreviewQuality::Draft)return tr("preview.quality.draft","Draft");
    if(preview_quality_==PreviewQuality::Preview)return tr("preview.quality.preview","Preview");
    if(preview_quality_==PreviewQuality::Good)return tr("preview.quality.good","Good");
    return tr("preview.quality.best","Best");
}
std::string EditorApp::preview_fps_name() const{return std::to_string(preview_fps_limit_)+" fps";}

std::string EditorApp::autosave_path() const{
    auto root=data_directory();if(root.empty())return{};std::uint64_t hash=14695981039346656037ULL;
    auto identity=project_.path.empty()?std::string("Untitled"):project_.path;for(unsigned char c:identity){hash^=c;hash*=1099511628211ULL;}
    std::error_code ec;fs::create_directories(root/"recovery",ec);if(ec)return{};
    return path_to_utf8(root/"recovery"/(std::to_string(hash)+"_"+autosave_session_+".autosave.kora"));
}

void EditorApp::autosave_if_needed(bool force){
    if(!dirty_||recording_audio_||edit_.drag.mode!=DragMode::None||fx_param_drag_.active||pan_crop_drag_.active())return;
    const auto now=std::chrono::steady_clock::now();
    if(!force&&last_autosave_wall_.time_since_epoch().count()!=0&&std::chrono::duration<double>(now-last_autosave_wall_).count()<30.0)return;
    const std::string path=autosave_path();if(path.empty())return;
    last_autosave_wall_=now;
    if(project_.save(path)){autosave_file_=path;set_status(tr("status.autosaved","Autosaved recovery copy:")+" "+basename_utf8(path));}
}

void EditorApp::remove_autosave() {
  const std::string path = autosave_file_;
  if (path.empty())
    return;
  std::error_code ec;
  fs::remove(path_from_utf8(path), ec);
  autosave_file_.clear();
}

bool EditorApp::confirm_project_replace() {
  if (!dirty_) {
    remove_autosave();
    return true;
  }
  autosave_if_needed(true);
  auto choice = services_.ask_save_changes(project_.name);
  if (choice == SaveChangesChoice::Cancel)
    return false;
  if (choice == SaveChangesChoice::Save) {
    save_project(false);
    if (dirty_)
      return false;
  }
  remove_autosave();
  return true;
}
void EditorApp::recover_latest_autosave() {
  std::optional<Project> recovered;
  auto latest = fs::file_time_type::min();
  fs::path file;
  for (const auto &root :
       {data_directory() / "recovery",
        path_from_utf8(services_.executable_dir()) / "autosave"}) {
    std::error_code ec;
    fs::directory_iterator it(
        root, fs::directory_options::skip_permission_denied, ec),
        end;
    while (!ec && it != end) {
      auto entry = *it;
      if (entry.path().extension() == ".kora" &&
          path_to_utf8(entry.path()) != autosave_file_) {
        auto modified = entry.last_write_time(ec);
        if (!ec && modified > latest) {
          auto candidate = Project::load(path_to_utf8(entry.path()));
          if (candidate) {
            recovered = std::move(candidate);
            latest = modified;
            file = entry.path();
          }
        }
      }
      ec.clear();
      it.increment(ec);
    }
  }
  if (!recovered) {
    services_.show_message(tr("dialog.recovery","Recovery"), tr("error.no_recovery","No valid recovery copy was found."));
    return;
  }
  if (recording_audio_)
    stop_audio_recording(true);
  if (!confirm_project_replace())
    return;
  engine_.stop_audio_preview();
  playing_ = false;
  project_ = std::move(*recovered);
  project_.path.clear();
  project_.name = "Recovered project";
  undo_.clear();
  edit_ = {};
  clipboard_.clear();
  playhead_ = 0;
  source_media_id_ = 0;
  source_time_ = 0;
  source_in_ = 0;
  source_out_ = -1;
  preview_frame_ = {};
  shown_preview_token_ = ++preview_token_;
  preview_media_id_ = 0;
  preview_source_time_ = -1;
  sync_preview_settings_from_project();
  engine_.clear_cache();
  engine_.prepare_project(project_);
  last_autosave_wall_ = {};
  mark_dirty();
  request_preview(true);
  set_status(tr("status.recovered","Recovered:") + " " + path_to_utf8(file));
}
void EditorApp::collect_project() {
  if (recording_audio_)
    stop_audio_recording(true);
  auto chosen = services_.save_project_file(project_.name);
  if (chosen.empty())
    return;
  auto destination = path_from_utf8(chosen).parent_path() /
                     (path_to_utf8(path_from_utf8(chosen).stem()) + "_Media");
  std::string error;
  if (project_.collect(path_to_utf8(destination), &error)) {
    set_status(tr("status.collected","Collected:") + " " + path_to_utf8(destination));
    services_.show_message(tr("dialog.collect_project","Collect Project"),
                           "Saved: " +
                               path_to_utf8(destination / "project.kora"));
  } else
    services_.show_message(tr("dialog.collect_project","Collect Project"), error, true);
}
void EditorApp::relink_missing_media() {
  auto files = services_.open_media_files();
  if (files.empty())
    return;
  auto lower = [](std::string value) {
    for (auto &c : value)
      c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return value;
  };
  int linked = 0;
  undo_.begin(project_);
  for (auto &media : project_.media) {
    std::error_code ec;
    if (media.generated_vector.enabled || media.generated_text.enabled ||
        fs::is_regular_file(path_from_utf8(media.path), ec))
      continue;
    std::string match;
    int matches = 0;
    for (const auto &file : files)
      if (lower(basename_utf8(file)) == lower(basename_utf8(media.path))) {
        match = file;
        ++matches;
      }
    if (matches != 1)
      continue;
    auto probe = engine_.probe(match);
    if (!probe || probe->has_video != media.has_video ||
        probe->has_audio != media.has_audio)
      continue;
    media.path = probe->path;
    media.proxy_path.clear();
    media.duration = probe->duration;
    media.width = probe->width;
    media.height = probe->height;
    media.fps = probe->fps;
    media.sample_rate = probe->sample_rate;
    media.audio_channels = probe->audio_channels;
    ++linked;
  }
  if (undo_.commit(project_)) {
    mark_dirty();
    engine_.clear_cache();
    engine_.prepare_project(project_);
    request_preview(true);
  } else
    undo_.cancel();
  set_status(tr("status.relinked","Relinked") + " " + std::to_string(linked) + " " + tr("status.missing_files","missing files"));
}

void EditorApp::request_close() {
  if (wants_close_)
    return;
  if (recording_audio_)
    stop_audio_recording(true);
  if (!dirty_) {
    remove_autosave();
    wants_close_ = true;
    return;
  }
  autosave_if_needed(true);
  const auto choice = services_.ask_save_changes(project_.name);
  if (choice == SaveChangesChoice::Cancel)
    return;
  if (choice == SaveChangesChoice::Discard) {
    remove_autosave();
    wants_close_ = true;
    return;
  }
  save_project(false);
  if (!dirty_) {
    remove_autosave();
    wants_close_ = true;
  }
}

void EditorApp::mark_dirty(){dirty_=true;if(last_autosave_wall_.time_since_epoch().count()==0)last_autosave_wall_=std::chrono::steady_clock::now();update_title();services_.request_redraw();}
void EditorApp::update_title(){services_.set_title(std::string(dirty_?"*":"")+project_.name+" — KoraLo Native 0.7");}
void EditorApp::set_status(std::string s){status_=std::move(s);services_.request_redraw();}

std::string EditorApp::timecode(double sec)const{
    sec=std::max(0.0,sec);
    const double exact_fps=std::max(1.0,project_.settings.fps);
    const bool drop30=std::abs(exact_fps-30000.0/1001.0)<0.02;
    const bool drop60=std::abs(exact_fps-60000.0/1001.0)<0.03;
    const int nominal=drop60?60:(drop30?30:std::max(1,static_cast<int>(std::round(exact_fps))));
    long long frames=static_cast<long long>(std::llround(sec*exact_fps));
    char separator=':';
    if(drop30||drop60){
        separator=';';
        const int dropped=drop60?4:2;
        const long long frames_per_10min=static_cast<long long>(std::llround(exact_fps*600.0));
        const long long frames_per_minute=nominal*60-dropped;
        const long long ten_min_blocks=frames/frames_per_10min;
        const long long remainder=frames%frames_per_10min;
        frames+=static_cast<long long>(dropped)*9*ten_min_blocks;
        if(remainder>=dropped)frames+=static_cast<long long>(dropped)*((remainder-dropped)/frames_per_minute);
    }
    const int ff=static_cast<int>(frames%nominal);
    const long long totalSec=frames/nominal;
    const int ss=static_cast<int>(totalSec%60),mm=static_cast<int>((totalSec/60)%60),hh=static_cast<int>((totalSec/3600)%24);
    std::ostringstream out;out<<std::setfill('0')<<std::setw(2)<<hh<<':'<<std::setw(2)<<mm<<':'<<std::setw(2)<<ss<<separator<<std::setw(2)<<ff;return out.str();
}

} // namespace koralo

namespace koralo {
void EditorApp::paint_segment(int x, int y, bool restore) {
  auto *clip = project_.clip_by_id(paint_clip_);
  if (!clip || !paint_drag_ || paint_count_ >= 512)
    return;
  auto it = std::find_if(
      clip->video_effects.begin(), clip->video_effects.end(),
      [&](const EffectInstance &e) { return e.id == paint_effect_; });
  if (it == clip->video_effects.end())
    return;
  auto *state = effect_parameter(*it, "strokes");
  if (!state)
    return;
  auto *text = std::get_if<std::string>(&state->value);
  if (!text || text->size() > 239900 || paint_total_segments_ >= 4096) {
    set_status(tr("animation.status.mask_limit","Mask stroke limit reached"));
    return;
  }
  double nx = std::clamp(double(x - paint_viewport_.x) /
                             std::max(1, paint_viewport_.w),
                         0.0, 1.0),
         ny = std::clamp(double(y - paint_viewport_.y) /
                             std::max(1, paint_viewport_.h),
                         0.0, 1.0);
  if (paint_count_ > 0 && std::hypot(nx - paint_x_, ny - paint_y_) < .001)
    return;
  *text += encode_brush_stroke(
      {paint_x_, paint_y_, nx, ny, paint_radius_, paint_hardness_, !restore});
  paint_x_ = nx;
  paint_y_ = ny;
  ++paint_count_;
  ++paint_total_segments_;
  paint_preview_pending_ = true;
  services_.request_redraw();
}
void EditorApp::finish_paint(bool cancel) {
  if (!paint_drag_)
    return;
  paint_drag_ = false;
  paint_preview_pending_ = false;
  if (cancel) {
    if (auto *clip = project_.clip_by_id(paint_clip_))
      clip->video_effects = paint_before_;
    undo_.cancel();
    set_status(tr("status.mask_stroke_cancelled","Mask stroke cancelled"));
  } else if (undo_.commit(project_)) {
    mark_dirty();
    set_status(tr("status.mask_saved","Mask saved. Ctrl+Z to undo the stroke"));
  }
  paint_before_.clear();
  engine_.clear_composite_cache();
  request_preview(true);
  services_.request_redraw();
}
} // namespace koralo
