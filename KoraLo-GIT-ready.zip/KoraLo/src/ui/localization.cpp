#include "localization.hpp"
#include "../platform/process.hpp"
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <set>

namespace koralo {
namespace fs = std::filesystem;

std::string search_casefold(std::string text){
    for(std::size_t i=0;i<text.size();++i){
        const auto c=static_cast<unsigned char>(text[i]);
        if(c>='A'&&c<='Z')text[i]=static_cast<char>(c+32);
        else if(c==0xd0&&i+1<text.size()){
            const auto next=static_cast<unsigned char>(text[i+1]);
            if(next==0x81){text[i]=static_cast<char>(0xd1);text[++i]=static_cast<char>(0x91);}
            else if(next>=0x90&&next<=0x9f){text[++i]=static_cast<char>(next+32);}
            else if(next>=0xa0&&next<=0xaf){text[i]=static_cast<char>(0xd1);text[++i]=static_cast<char>(next-32);}
        }
    }
    return text;
}
void erase_last_utf8(std::string& text){
    if(text.empty())return;
    std::size_t start=text.size()-1;
    while(start>0&&(static_cast<unsigned char>(text[start])&0xc0)==0x80)--start;
    text.erase(start);
}

namespace {
std::string trim(std::string s){
    auto not_space=[](unsigned char c){return c!=' '&&c!='\t'&&c!='\r'&&c!='\n';};
    auto first=std::find_if(s.begin(),s.end(),not_space);
    auto last=std::find_if(s.rbegin(),s.rend(),not_space).base();
    if(first>=last)return{};
    return std::string(first,last);
}

std::string environment_value(const char* name){return environment_utf8(name); }
}

Localization::Localization(const std::vector<std::string>& search_roots){ discover(search_roots); }

std::string Localization::unescape(std::string value){
    std::string out;out.reserve(value.size());
    for(std::size_t i=0;i<value.size();++i){
        if(value[i]=='\\'&&i+1<value.size()){
            const char n=value[++i];
            if(n=='n')out.push_back('\n');
            else if(n=='t')out.push_back('\t');
            else if(n=='r')out.push_back('\r');
            else out.push_back(n);
        }else out.push_back(value[i]);
    }
    return out;
}

std::unordered_map<std::string,std::string> Localization::load_file(const std::string& path){
    std::unordered_map<std::string,std::string> values;
    std::ifstream input(path_from_utf8(path),std::ios::binary);
    if(!input)return values;
    std::string line;
    while(std::getline(input,line)){
        if(line.size()>=3&&static_cast<unsigned char>(line[0])==0xEF&&static_cast<unsigned char>(line[1])==0xBB&&static_cast<unsigned char>(line[2])==0xBF)line.erase(0,3);
        const std::string stripped=trim(line);
        if(stripped.empty()||stripped[0]=='#'||stripped[0]==';')continue;
        const auto eq=stripped.find('=');if(eq==std::string::npos)continue;
        const std::string key=trim(stripped.substr(0,eq));
        if(key.empty())continue;
        values[key]=unescape(trim(stripped.substr(eq+1)));
    }
    return values;
}

void Localization::discover(const std::vector<std::string>& search_roots){
    languages_.clear();fallback_.clear();active_.clear();
    std::set<std::string> seen;
    std::vector<std::string> all_roots = search_roots;
    all_roots.push_back(path_to_utf8(app_install_directory()));
    all_roots.push_back(path_to_utf8(current_executable_path().parent_path()));
    all_roots.push_back(path_to_utf8(current_executable_path().parent_path().parent_path()));
    all_roots.push_back(path_to_utf8(std::filesystem::current_path()));
    all_roots.push_back(path_to_utf8(std::filesystem::current_path().parent_path()));
    for(const auto& root_utf8:all_roots){
        if(root_utf8.empty())continue;
        std::vector<fs::path> dirs;
        const fs::path root=path_from_utf8(root_utf8);
        dirs.push_back(root/"locales");dirs.push_back(root);
        for(const auto& dir:dirs){
            std::error_code ec;if(!fs::is_directory(dir,ec))continue;
            for(const auto& entry:fs::directory_iterator(dir,ec)){
                if(ec||!entry.is_regular_file()||entry.path().extension()!=".lang")continue;
                const auto values=load_file(path_to_utf8(entry.path()));
                auto code_it=values.find("meta.code");if(code_it==values.end()||code_it->second.empty())continue;
                if(!seen.insert(code_it->second).second)continue;
                auto name_it=values.find("meta.name");
                languages_.push_back({code_it->second,name_it==values.end()?code_it->second:name_it->second,path_to_utf8(entry.path())});
            }
        }
    }
    std::sort(languages_.begin(),languages_.end(),[](const LanguageInfo&a,const LanguageInfo&b){return a.code<b.code;});
    for(const auto& lang:languages_)if(lang.code=="en-US"){fallback_=load_file(lang.path);break;}
    std::string desired="en-US";const std::string env=environment_value("KORALO_LANG");if(!env.empty())desired=env;
    if(!set_language(desired))set_language("en-US");
}

bool Localization::set_language(const std::string& code){
    auto it=std::find_if(languages_.begin(),languages_.end(),[&](const LanguageInfo& info){return info.code==code;});
    if(it==languages_.end())return false;
    active_=load_file(it->path);language_code_=it->code;return true;
}

std::string Localization::text(std::string_view key,std::string_view fallback)const{
    const std::string k(key);
    if(auto it=active_.find(k);it!=active_.end())return it->second;
    if(auto it=fallback_.find(k);it!=fallback_.end())return it->second;
    return fallback.empty()?k:std::string(fallback);
}

} // namespace koralo
