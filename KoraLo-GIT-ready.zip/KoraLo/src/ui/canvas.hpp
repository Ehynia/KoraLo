#pragma once
#include "../media/media_engine.hpp"
#include <cstdint>
#include <string>

namespace koralo {

struct Color {
    std::uint8_t r=0,g=0,b=0,a=255;
    constexpr Color() = default;
    constexpr Color(int rr,int gg,int bb,int aa=255):r(static_cast<std::uint8_t>(rr)),g(static_cast<std::uint8_t>(gg)),b(static_cast<std::uint8_t>(bb)),a(static_cast<std::uint8_t>(aa)){}
};
struct Rect { int x=0,y=0,w=0,h=0; bool contains(int px,int py) const {return px>=x&&py>=y&&px<x+w&&py<y+h;} };

class Canvas {
public:
    virtual ~Canvas()=default;
    virtual int width() const=0;
    virtual int height() const=0;
    virtual void fill_rect(Rect r, Color c)=0;
    virtual void stroke_rect(Rect r, Color c, int thickness=1)=0;
    virtual void line(int x1,int y1,int x2,int y2,Color c,int thickness=1)=0;
    virtual void text(int x,int y,const std::string& value,Color c,int size=12,bool bold=false)=0;
    virtual int text_width(const std::string& value,int size=12,bool bold=false)=0;
    virtual void image(Rect dst,const Frame& frame)=0;
    virtual void push_clip(Rect r)=0;
    virtual void pop_clip()=0;
};

namespace theme {
// Neutral graphite desktop surfaces; teal is reserved for focus and selection.
constexpr Color bg{35,35,35};
constexpr Color panel{43,43,43};
constexpr Color panel2{48,48,48};
constexpr Color panel3{56,56,56};
constexpr Color raised{64,64,64};
constexpr Color border{79,79,79};
constexpr Color borderSoft{58,58,58};
constexpr Color text{229,229,229};
constexpr Color dim{177,177,177};
constexpr Color dim2{124,124,124};
constexpr Color accent{76,207,192};
constexpr Color accentHover{104,224,211};
constexpr Color accent2{40,102,98};
constexpr Color success{87,172,133};
constexpr Color ruler{40,40,40};
constexpr Color trackA{34,34,34};
constexpr Color trackB{38,38,38};
constexpr Color header{47,47,47};
constexpr Color video{62,98,127};
constexpr Color videoSel{72,115,143};
constexpr Color audio{83,77,121};
constexpr Color audioSel{101,92,144};
constexpr Color playhead{76,207,192};
constexpr Color warning{225,190,97};
constexpr Color danger{218,100,105};
constexpr Color black{18,18,18};
}

} // namespace koralo
