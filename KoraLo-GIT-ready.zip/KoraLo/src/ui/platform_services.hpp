#pragma once
#include <string>
#include <vector>

namespace koralo {
enum class SaveChangesChoice { Save, Discard, Cancel };

class PlatformServices {
public:
    virtual ~PlatformServices()=default;
    virtual std::vector<std::string> open_media_files()=0;
    virtual std::string open_project_file()=0;
    virtual std::string save_project_file(const std::string& suggested)=0;
    virtual std::string save_render_file(const std::string& suggested)=0;
    virtual void show_message(const std::string& title,const std::string& message,bool error=false)=0;
    virtual SaveChangesChoice ask_save_changes(const std::string& project_name)=0;
    virtual void set_title(const std::string& title)=0;
    virtual void request_redraw()=0;
    virtual std::string executable_dir() const=0;
    virtual std::string interface_renderer() const{return "CPU";}
    virtual bool set_interface_gpu_enabled(bool){return false;}
};
}
