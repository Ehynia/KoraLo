#pragma once
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace koralo {

// Search helpers for the supported English/Russian interface.
std::string search_casefold(std::string text);
void erase_last_utf8(std::string& text);

struct LanguageInfo {
    std::string code;
    std::string name;
    std::string path;
};

class Localization {
public:
    Localization() = default;
    explicit Localization(const std::vector<std::string>& search_roots);

    void discover(const std::vector<std::string>& search_roots);
    bool set_language(const std::string& code);
    std::string text(std::string_view key, std::string_view fallback = {}) const;

    const std::string& language_code() const { return language_code_; }
    const std::vector<LanguageInfo>& languages() const { return languages_; }

private:
    static std::unordered_map<std::string,std::string> load_file(const std::string& path);
    static std::string unescape(std::string value);

    std::vector<LanguageInfo> languages_;
    std::unordered_map<std::string,std::string> fallback_;
    std::unordered_map<std::string,std::string> active_;
    std::string language_code_="en-US";
};

} // namespace koralo
