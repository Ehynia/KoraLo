#include "opengl_canvas.hpp"
#include "inter_atlas.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <unordered_map>
// The subset below is the stable OpenGL 1.1 ABI, available through WGL/GLX.
// All rectangles and glyphs are batched triangles; image scaling and alpha
// composition happen on the graphics device, not in CPU-sized DIBs/XImages.
#ifdef _WIN32
#define KGL_CALL __stdcall
#else
#define KGL_CALL
#endif
namespace koralo {
namespace {
using U = unsigned;
using I = int;
using F = float;
constexpr U BLEND = 0x0be2, TEXTURE = 0x0de1, SCISSOR = 0x0c11, DEPTH = 0x0b71,
            CULL = 0x0b44, SRC_ALPHA = 0x0302, ONE_MINUS_SRC_ALPHA = 0x0303,
            PROJECTION = 0x1701, MODELVIEW = 0x1700, VERTEX_ARRAY = 0x8074,
            COLOR_ARRAY = 0x8076, TEXCOORD_ARRAY = 0x8078, FLOAT = 0x1406,
            BYTE = 0x1401, TRIANGLES = 0x0004, RGB = 0x1907, RGBA = 0x1908,
            ALPHA = 0x1906, UNPACK_ALIGNMENT = 0x0cf5, MIN_FILTER = 0x2801,
            MAG_FILTER = 0x2800, WRAP_S = 0x2802, WRAP_T = 0x2803,
            LINEAR = 0x2601, CLAMP_EDGE = 0x812f, RENDERER = 0x1f01,
            MAX_TEXTURE = 0x0d33, COLOR_BUFFER = 0x4000;
std::uint32_t utf8(const std::string &s, std::size_t &p) {
  const auto a = static_cast<unsigned char>(s[p++]);
  if (a < 128)
    return a;
  int n = (a & 0xe0) == 0xc0
              ? 1
              : ((a & 0xf0) == 0xe0 ? 2 : ((a & 0xf8) == 0xf0 ? 3 : 0));
  std::uint32_t cp = n == 1 ? (a & 31) : (n == 2 ? (a & 15) : (a & 7));
  if (!n)
    return '?';
  while (n--) {
    if (p >= s.size())
      return '?';
    const auto b = static_cast<unsigned char>(s[p++]);
    if ((b & 0xc0) != 0x80)
      return '?';
    cp = (cp << 6) | (b & 63);
  }
  return cp;
}
const inter_atlas::Glyph *glyph(std::uint32_t cp, int size, bool bold) {
  auto *g = inter_atlas::find(cp, size, bold);
  return g ? g : inter_atlas::find('?', size, bold);
}
struct Vertex {
  F x, y, u, v;
  std::uint8_t color[4];
};
} // namespace
struct OpenGlCanvas::Impl {
#define KGL(name, ret, ...) ret(KGL_CALL *name)(__VA_ARGS__) = nullptr
  KGL(Enable, void, U);
  KGL(Disable, void, U);
  KGL(BlendFunc, void, U, U);
  KGL(Viewport, void, I, I, I, I);
  KGL(Scissor, void, I, I, I, I);
  KGL(MatrixMode, void, U);
  KGL(LoadIdentity, void);
  KGL(Ortho, void, double, double, double, double, double, double);
  KGL(EnableClientState, void, U);
  KGL(DisableClientState, void, U);
  KGL(VertexPointer, void, I, U, I, const void *);
  KGL(ColorPointer, void, I, U, I, const void *);
  KGL(TexCoordPointer, void, I, U, I, const void *);
  KGL(DrawArrays, void, U, I, I);
  KGL(BindTexture, void, U, U);
  KGL(GenTextures, void, I, U *);
  KGL(DeleteTextures, void, I, const U *);
  KGL(TexParameteri, void, U, U, I);
  KGL(TexImage2D, void, U, I, I, I, I, I, U, U, const void *);
  KGL(TexSubImage2D, void, U, I, I, I, I, I, U, U, const void *);
  KGL(PixelStorei, void, U, I);
  KGL(GetString, const unsigned char *, U);
  KGL(GetIntegerv, void, U, I *);
  KGL(GetError, U);
  KGL(Flush, void);
  KGL(ClearColor, void, F, F, F, F);
  KGL(Clear, void, U);
#undef KGL
  int w = 1, h = 1, page_size = 1024;
  bool ready = false;
  std::string label;
  U batch_texture = 0;
  std::vector<Vertex> vertices;
  std::vector<Rect> clips;
  std::uint64_t calls = 0, uploads = 0, stamp = 0;
  struct Page {
    U texture = 0;
    int x = 1, y = 1, row = 0;
  };
  std::vector<Page> pages;
  struct Sprite {
    U texture;
    F u0, v0, u1, v1;
  };
  std::unordered_map<const inter_atlas::Glyph *, Sprite> glyphs;
  struct Image {
    U texture = 0;
    int w = 0, h = 0;
    std::uint64_t stamp = 0;
    std::size_t bytes = 0;
  };
  std::unordered_map<std::uint64_t, Image> images;
  std::size_t image_bytes = 0;
  ~Impl() {
    if (!ready)
      return;
    for (auto &p : pages)
      DeleteTextures(1, &p.texture);
    for (auto &[_, im] : images)
      DeleteTextures(1, &im.texture);
  }
  void flush() {
    if (vertices.empty())
      return;
    if (batch_texture) {
      Enable(TEXTURE);
      BindTexture(TEXTURE, batch_texture);
      EnableClientState(TEXCOORD_ARRAY);
      TexCoordPointer(2, FLOAT, sizeof(Vertex), &vertices.front().u);
    } else {
      Disable(TEXTURE);
      DisableClientState(TEXCOORD_ARRAY);
    }
    VertexPointer(2, FLOAT, sizeof(Vertex), &vertices.front().x);
    ColorPointer(4, BYTE, sizeof(Vertex), vertices.front().color);
    DrawArrays(TRIANGLES, 0, int(vertices.size()));
    ++calls;
    vertices.clear();
  }
  void set_texture(U texture) {
    if (batch_texture != texture) {
      flush();
      batch_texture = texture;
    }
  }
  void add(F x, F y, F u, F v, Color c) {
    vertices.push_back({x, y, u, v, {c.r, c.g, c.b, c.a}});
  }
  void quad(F x, F y, F right, F bottom, Color c, U texture = 0, F u0 = 0,
            F v0 = 0, F u1 = 1, F v1 = 1) {
    set_texture(texture);
    add(x, y, u0, v0, c);
    add(right, y, u1, v0, c);
    add(right, bottom, u1, v1, c);
    add(x, y, u0, v0, c);
    add(right, bottom, u1, v1, c);
    add(x, bottom, u0, v1, c);
    if (vertices.size() > 65520)
      flush();
  }
  U texture() {
    U id = 0;
    GenTextures(1, &id);
    BindTexture(TEXTURE, id);
    TexParameteri(TEXTURE, MIN_FILTER, LINEAR);
    TexParameteri(TEXTURE, MAG_FILTER, LINEAR);
    TexParameteri(TEXTURE, WRAP_S, CLAMP_EDGE);
    TexParameteri(TEXTURE, WRAP_T, CLAMP_EDGE);
    return id;
  }
  Sprite sprite(const inter_atlas::Glyph *g) {
    if (auto it = glyphs.find(g); it != glyphs.end())
      return it->second;
    flush();
    if (pages.empty() || pages.back().y + g->height + 2 >= page_size) {
      Page p;
      p.texture = texture();
      std::vector<std::uint8_t> zeros(std::size_t(page_size) * page_size, 0);
      TexImage2D(TEXTURE, 0, ALPHA, page_size, page_size, 0, ALPHA, BYTE,
                 zeros.data());
      pages.push_back(p);
    }
    if (pages.back().x + g->width + 2 >= page_size) {
      pages.back().x = 1;
      pages.back().y += pages.back().row + 2;
      pages.back().row = 0;
      if (pages.back().y + g->height + 2 >= page_size) {
        Page p;
        p.texture = texture();
        std::vector<std::uint8_t> zeros(std::size_t(page_size) * page_size, 0);
        TexImage2D(TEXTURE, 0, ALPHA, page_size, page_size, 0, ALPHA, BYTE,
                   zeros.data());
        pages.push_back(p);
      }
    }
    auto &p = pages.back();
    std::vector<std::uint8_t> alpha(std::size_t(g->width) * g->height);
    for (std::size_t i = 0; i < alpha.size(); ++i)
      alpha[i] = inter_atlas::kPixels[g->offset + i] * 17;
    BindTexture(TEXTURE, p.texture);
    if (!alpha.empty())
      TexSubImage2D(TEXTURE, 0, p.x, p.y, g->width, g->height, ALPHA, BYTE,
                    alpha.data());
    ++uploads;
    Sprite s{p.texture, F(p.x) / page_size, F(p.y) / page_size,
             F(p.x + g->width) / page_size, F(p.y + g->height) / page_size};
    p.x += g->width + 2;
    p.row = std::max(p.row, int(g->height));
    glyphs[g] = s;
    return s;
  }
  void clip() {
    flush();
    if (clips.empty()) {
      Disable(SCISSOR);
      return;
    }
    const auto r = clips.back();
    Enable(SCISSOR);
    Scissor(r.x, h - r.y - r.h, std::max(0, r.w), std::max(0, r.h));
  }
};
OpenGlCanvas::OpenGlCanvas() : impl_(std::make_unique<Impl>()) {}
OpenGlCanvas::~OpenGlCanvas() = default;
bool OpenGlCanvas::initialize(
    const std::function<void *(const char *)> &resolve) {
  auto &p = *impl_;
#define LOAD(name)                                                             \
  p.name = reinterpret_cast<decltype(p.name)>(resolve("gl" #name));            \
  if (!p.name)                                                                 \
  return false
  LOAD(Enable);
  LOAD(Disable);
  LOAD(BlendFunc);
  LOAD(Viewport);
  LOAD(Scissor);
  LOAD(MatrixMode);
  LOAD(LoadIdentity);
  LOAD(Ortho);
  LOAD(EnableClientState);
  LOAD(DisableClientState);
  LOAD(VertexPointer);
  LOAD(ColorPointer);
  LOAD(TexCoordPointer);
  LOAD(DrawArrays);
  LOAD(BindTexture);
  LOAD(GenTextures);
  LOAD(DeleteTextures);
  LOAD(TexParameteri);
  LOAD(TexImage2D);
  LOAD(TexSubImage2D);
  LOAD(PixelStorei);
  LOAD(GetString);
  LOAD(GetIntegerv);
  LOAD(GetError);
  LOAD(Flush);
  LOAD(ClearColor);
  LOAD(Clear);
#undef LOAD
  const auto *renderer = p.GetString(RENDERER);
  if (!renderer)
    return false;
  p.label = reinterpret_cast<const char *>(renderer);
  I max = 0;
  p.GetIntegerv(MAX_TEXTURE, &max);
  if (max < 256)
    return false;
  p.page_size = std::min(1024, max);
  p.PixelStorei(UNPACK_ALIGNMENT, 1);
  p.ready = true;
  p.vertices.reserve(8192);
  return true;
}
void OpenGlCanvas::begin(int w, int h) {
  auto &p = *impl_;
  p.w = std::max(1, w);
  p.h = std::max(1, h);
  p.vertices.clear();
  p.clips.clear();
  p.batch_texture = 0;
  for (int i = 0; i < 32 && p.GetError() != 0; ++i) {
  }
  p.Viewport(0, 0, p.w, p.h);
  p.Disable(DEPTH);
  p.Disable(CULL);
  p.Disable(SCISSOR);
  p.Enable(BLEND);
  p.BlendFunc(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
  p.MatrixMode(PROJECTION);
  p.LoadIdentity();
  p.Ortho(0, p.w, p.h, 0, -1, 1);
  p.MatrixMode(MODELVIEW);
  p.LoadIdentity();
  p.EnableClientState(VERTEX_ARRAY);
  p.EnableClientState(COLOR_ARRAY);
  p.ClearColor(0, 0, 0, 1);
  p.Clear(COLOR_BUFFER);
}
bool OpenGlCanvas::finish() {
  impl_->flush();
  impl_->Flush();
  return impl_->GetError() == 0;
}
std::string OpenGlCanvas::renderer() const {
  const auto &label = impl_->label;
  const bool software = label.find("llvmpipe") != std::string::npos ||
                        label.find("softpipe") != std::string::npos ||
                        label.find("Software") != std::string::npos;
  return std::string(software ? "OpenGL CPU · " : "OpenGL GPU · ") + label;
}
std::uint64_t OpenGlCanvas::draw_calls() const { return impl_->calls; }
std::uint64_t OpenGlCanvas::texture_uploads() const { return impl_->uploads; }
int OpenGlCanvas::width() const { return impl_->w; }
int OpenGlCanvas::height() const { return impl_->h; }
void OpenGlCanvas::fill_rect(Rect r, Color c) {
  if (r.w > 0 && r.h > 0 && c.a)
    impl_->quad(F(r.x), F(r.y), F(r.x + r.w), F(r.y + r.h), c);
}
void OpenGlCanvas::stroke_rect(Rect r, Color c, int t) {
  if (r.w < 1 || r.h < 1)
    return;
  t = std::max(1, t);
  fill_rect({r.x, r.y, r.w, t}, c);
  fill_rect({r.x, r.y + r.h - t, r.w, t}, c);
  fill_rect({r.x, r.y + t, t, std::max(0, r.h - 2 * t)}, c);
  fill_rect({r.x + r.w - t, r.y + t, t, std::max(0, r.h - 2 * t)}, c);
}
void OpenGlCanvas::line(int x0, int y0, int x1, int y1, Color c, int t) {
  auto &p = *impl_;
  const F dx = F(x1 - x0), dy = F(y1 - y0), len = std::hypot(dx, dy);
  if (len < .01f) {
    fill_rect({x0, y0, std::max(1, t), std::max(1, t)}, c);
    return;
  }
  const F nx = -dy / len * std::max(1, t) * .5f,
          ny = dx / len * std::max(1, t) * .5f;
  p.set_texture(0);
  p.add(x0 + nx + .5f, y0 + ny + .5f, 0, 0, c);
  p.add(x1 + nx + .5f, y1 + ny + .5f, 0, 0, c);
  p.add(x1 - nx + .5f, y1 - ny + .5f, 0, 0, c);
  p.add(x0 + nx + .5f, y0 + ny + .5f, 0, 0, c);
  p.add(x1 - nx + .5f, y1 - ny + .5f, 0, 0, c);
  p.add(x0 - nx + .5f, y0 - ny + .5f, 0, 0, c);
}
void OpenGlCanvas::text(int x, int y, const std::string &text, Color c,
                        int size, bool bold) {
  int pen = x;
  std::size_t pos = 0;
  while (pos < text.size()) {
    auto *g = glyph(utf8(text, pos), size, bold);
    if (!g)
      continue;
    if (g->width > 0 && g->height > 0) {
      const auto s = impl_->sprite(g);
      impl_->quad(F(pen + g->left), F(y + g->top), F(pen + g->left + g->width),
                  F(y + g->top + g->height), c, s.texture, s.u0, s.v0, s.u1,
                  s.v1);
    }
    pen += g->advance;
  }
}
int OpenGlCanvas::text_width(const std::string &text, int size, bool bold) {
  int n = 0;
  std::size_t pos = 0;
  while (pos < text.size())
    if (auto *g = glyph(utf8(text, pos), size, bold))
      n += g->advance;
  return n;
}
void OpenGlCanvas::image(Rect dst, const Frame &f) {
  const std::size_t n =
      std::size_t(std::max(0, f.width)) * std::max(0, f.height);
  if (!n || f.rgb.size() != n * 3 || dst.w < 1 || dst.h < 1)
    return;
  auto &p = *impl_;
  std::uint64_t hash = 1469598103934665603ull;
  auto add = [&](std::uint8_t b) {
    hash ^= b;
    hash *= 1099511628211ull;
  };
  for (auto b : f.rgb)
    add(b);
  if (f.alpha.size() == n)
    for (auto b : f.alpha)
      add(b);
  hash ^= std::uint64_t(f.width) << 32 | unsigned(f.height);
  auto it = p.images.find(hash);
  if (it == p.images.end()) {
    p.flush();
    const auto bytes = n * 4;
    while (!p.images.empty() && (p.images.size() >= 128 ||
                                 p.image_bytes + bytes > 64 * 1024 * 1024)) {
      auto oldest = std::min_element(p.images.begin(), p.images.end(),
                                     [](const auto &a, const auto &b) {
                                       return a.second.stamp < b.second.stamp;
                                     });
      p.DeleteTextures(1, &oldest->second.texture);
      p.image_bytes -= oldest->second.bytes;
      p.images.erase(oldest);
    }
    Impl::Image im;
    im.texture = p.texture();
    im.w = f.width;
    im.h = f.height;
    im.bytes = bytes;
    im.stamp = ++p.stamp;
    if (f.alpha.size() == n) {
      std::vector<std::uint8_t> rgba(n * 4);
      for (std::size_t i = 0; i < n; ++i) {
        std::memcpy(rgba.data() + i * 4, f.rgb.data() + i * 3, 3);
        rgba[i * 4 + 3] = f.alpha[i];
      }
      p.TexImage2D(TEXTURE, 0, RGBA, f.width, f.height, 0, RGBA, BYTE,
                   rgba.data());
    } else
      p.TexImage2D(TEXTURE, 0, RGB, f.width, f.height, 0, RGB, BYTE,
                   f.rgb.data());
    ++p.uploads;
    p.image_bytes += bytes;
    it = p.images.emplace(hash, im).first;
  }
  it->second.stamp = ++p.stamp;
  const double scale =
      std::min(double(dst.w) / f.width, double(dst.h) / f.height);
  const int ow = std::max(1, int(f.width * scale)),
            oh = std::max(1, int(f.height * scale)),
            x = dst.x + (dst.w - ow) / 2, y = dst.y + (dst.h - oh) / 2;
  p.quad(F(x), F(y), F(x + ow), F(y + oh), {255, 255, 255}, it->second.texture);
}
void OpenGlCanvas::push_clip(Rect r) {
  auto &p = *impl_;
  if (!p.clips.empty()) {
    auto a = p.clips.back();
    int x = std::max(a.x, r.x), y = std::max(a.y, r.y);
    r = {x, y, std::max(0, std::min(a.x + a.w, r.x + r.w) - x),
         std::max(0, std::min(a.y + a.h, r.y + r.h) - y)};
  }
  p.clips.push_back(r);
  p.clip();
}
void OpenGlCanvas::pop_clip() {
  if (!impl_->clips.empty())
    impl_->clips.pop_back();
  impl_->clip();
}
bool interface_gpu_requested() {
  const char *v = std::getenv("KORALO_UI_RENDERER");
  return !v || std::string(v) != "cpu";
}
} // namespace koralo
