#pragma once

#include "ofx_host.hpp"

#include <cstddef>
#include <string>
#include <string_view>
#include <vector>

namespace koralo {

constexpr int kOfxScannerProtocolVersion = 1;

struct OfxScanResponse {
    bool ok = false;
    std::size_t bundle_count = 0;
    std::vector<OfxPluginInfo> plugins;
    std::string error;
};

// One request/response per line. Keeping the protocol line-delimited makes it
// easy to inspect manually while remaining safe for paths and plug-in ids via
// normal JSON escaping.
std::string make_ofx_scan_request(const std::vector<std::string>& paths);
bool parse_ofx_scan_request(std::string_view json,
                            std::vector<std::string>& paths,
                            std::string* error = nullptr);
std::string make_ofx_scan_response(const OfxScanResponse& response);
bool parse_ofx_scan_response(std::string_view json,
                             OfxScanResponse& response,
                             std::string* error = nullptr);

} // namespace koralo
