#include "ofx_ipc.hpp"

#include <charconv>
#include <cctype>
#include <cstdlib>
#include <limits>
#include <map>
#include <sstream>
#include <string_view>
#include <utility>
#include <variant>

namespace koralo {
namespace {

struct JsonValue {
    using Array = std::vector<JsonValue>;
    using Object = std::map<std::string, JsonValue>;
    std::variant<std::nullptr_t, bool, double, std::string, Array, Object> value;

    const Object* object() const { return std::get_if<Object>(&value); }
    const Array* array() const { return std::get_if<Array>(&value); }
    const std::string* string() const { return std::get_if<std::string>(&value); }
    const bool* boolean() const { return std::get_if<bool>(&value); }
    const double* number() const { return std::get_if<double>(&value); }
};

class JsonParser {
public:
    explicit JsonParser(std::string_view input) : input_(input) {}

    bool parse(JsonValue& out, std::string* error) {
        skip_ws();
        if (!parse_value(out)) return fail(error);
        skip_ws();
        if (pos_ != input_.size()) {
            error_ = "trailing data";
            return fail(error);
        }
        return true;
    }

private:
    bool fail(std::string* error) {
        if (error) {
            *error = error_.empty() ? "invalid JSON" : error_;
            *error += " at byte " + std::to_string(pos_);
        }
        return false;
    }

    void skip_ws() {
        while (pos_ < input_.size() && std::isspace(static_cast<unsigned char>(input_[pos_]))) ++pos_;
    }

    bool parse_value(JsonValue& out) {
        skip_ws();
        if (pos_ >= input_.size()) return set_error("unexpected end of JSON");
        const char ch = input_[pos_];
        if (ch == '{') return parse_object(out);
        if (ch == '[') return parse_array(out);
        if (ch == '"') {
            std::string s;
            if (!parse_string(s)) return false;
            out.value = std::move(s);
            return true;
        }
        if (ch == 't' && consume("true")) { out.value = true; return true; }
        if (ch == 'f' && consume("false")) { out.value = false; return true; }
        if (ch == 'n' && consume("null")) { out.value = nullptr; return true; }
        return parse_number(out);
    }

    bool parse_object(JsonValue& out) {
        ++pos_;
        JsonValue::Object object;
        skip_ws();
        if (take('}')) { out.value = std::move(object); return true; }
        for (;;) {
            std::string key;
            if (!parse_string(key)) return false;
            skip_ws();
            if (!take(':')) return set_error("expected ':'");
            JsonValue item;
            if (!parse_value(item)) return false;
            object[std::move(key)] = std::move(item);
            skip_ws();
            if (take('}')) break;
            if (!take(',')) return set_error("expected ',' or '}'");
            skip_ws();
        }
        out.value = std::move(object);
        return true;
    }

    bool parse_array(JsonValue& out) {
        ++pos_;
        JsonValue::Array array;
        skip_ws();
        if (take(']')) { out.value = std::move(array); return true; }
        for (;;) {
            JsonValue item;
            if (!parse_value(item)) return false;
            array.push_back(std::move(item));
            skip_ws();
            if (take(']')) break;
            if (!take(',')) return set_error("expected ',' or ']'");
        }
        out.value = std::move(array);
        return true;
    }

    static int hex_value(char ch) {
        if (ch >= '0' && ch <= '9') return ch - '0';
        if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
        if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
        return -1;
    }

    static void append_utf8(std::string& out, unsigned int codepoint) {
        if (codepoint <= 0x7f) out.push_back(static_cast<char>(codepoint));
        else if (codepoint <= 0x7ff) {
            out.push_back(static_cast<char>(0xc0 | (codepoint >> 6)));
            out.push_back(static_cast<char>(0x80 | (codepoint & 0x3f)));
        } else if (codepoint <= 0xffff) {
            out.push_back(static_cast<char>(0xe0 | (codepoint >> 12)));
            out.push_back(static_cast<char>(0x80 | ((codepoint >> 6) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | (codepoint & 0x3f)));
        } else {
            out.push_back(static_cast<char>(0xf0 | (codepoint >> 18)));
            out.push_back(static_cast<char>(0x80 | ((codepoint >> 12) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | ((codepoint >> 6) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | (codepoint & 0x3f)));
        }
    }

    bool parse_string(std::string& out) {
        skip_ws();
        if (!take('"')) return set_error("expected JSON string");
        out.clear();
        while (pos_ < input_.size()) {
            const char ch = input_[pos_++];
            if (ch == '"') return true;
            if (static_cast<unsigned char>(ch) < 0x20) return set_error("control character in string");
            if (ch != '\\') { out.push_back(ch); continue; }
            if (pos_ >= input_.size()) return set_error("unfinished escape");
            const char esc = input_[pos_++];
            switch (esc) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    if (pos_ + 4 > input_.size()) return set_error("short unicode escape");
                    unsigned int cp = 0;
                    for (int i = 0; i < 4; ++i) {
                        const int h = hex_value(input_[pos_++]);
                        if (h < 0) return set_error("invalid unicode escape");
                        cp = (cp << 4) | static_cast<unsigned int>(h);
                    }
                    append_utf8(out, cp);
                    break;
                }
                default: return set_error("invalid string escape");
            }
        }
        return set_error("unterminated string");
    }

    bool parse_number(JsonValue& out) {
        const std::size_t start = pos_;
        if (pos_ < input_.size() && input_[pos_] == '-') ++pos_;
        if (pos_ >= input_.size()) return set_error("invalid number");
        if (input_[pos_] == '0') ++pos_;
        else {
            if (!std::isdigit(static_cast<unsigned char>(input_[pos_]))) return set_error("invalid number");
            while (pos_ < input_.size() && std::isdigit(static_cast<unsigned char>(input_[pos_]))) ++pos_;
        }
        if (pos_ < input_.size() && input_[pos_] == '.') {
            ++pos_;
            if (pos_ >= input_.size() || !std::isdigit(static_cast<unsigned char>(input_[pos_]))) return set_error("invalid fraction");
            while (pos_ < input_.size() && std::isdigit(static_cast<unsigned char>(input_[pos_]))) ++pos_;
        }
        if (pos_ < input_.size() && (input_[pos_] == 'e' || input_[pos_] == 'E')) {
            ++pos_;
            if (pos_ < input_.size() && (input_[pos_] == '+' || input_[pos_] == '-')) ++pos_;
            if (pos_ >= input_.size() || !std::isdigit(static_cast<unsigned char>(input_[pos_]))) return set_error("invalid exponent");
            while (pos_ < input_.size() && std::isdigit(static_cast<unsigned char>(input_[pos_]))) ++pos_;
        }
        double number = 0.0;
        const std::string token(input_.substr(start, pos_ - start));
        char* end = nullptr;
        number = std::strtod(token.c_str(), &end);
        if (!end || *end != '\0') return set_error("invalid number");
        out.value = number;
        return true;
    }

    bool consume(std::string_view token) {
        if (input_.substr(pos_, token.size()) != token) return false;
        pos_ += token.size();
        return true;
    }

    bool take(char ch) {
        if (pos_ >= input_.size() || input_[pos_] != ch) return false;
        ++pos_;
        return true;
    }

    bool set_error(const char* message) {
        error_ = message;
        return false;
    }

    std::string_view input_;
    std::size_t pos_ = 0;
    std::string error_;
};

std::string json_escape(std::string_view value) {
    std::ostringstream out;
    out << '"';
    for (unsigned char ch : value) {
        switch (ch) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\b': out << "\\b"; break;
            case '\f': out << "\\f"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (ch < 0x20) {
                    static const char* hex = "0123456789abcdef";
                    out << "\\u00" << hex[(ch >> 4) & 0xf] << hex[ch & 0xf];
                } else out << static_cast<char>(ch);
        }
    }
    out << '"';
    return out.str();
}

const JsonValue* field(const JsonValue::Object& object, const char* key) {
    const auto it = object.find(key);
    return it == object.end() ? nullptr : &it->second;
}

bool integer_field(const JsonValue::Object& object, const char* key, int& value) {
    const auto* item = field(object, key);
    const auto* number = item ? item->number() : nullptr;
    if (!number || *number < static_cast<double>(std::numeric_limits<int>::min()) ||
        *number > static_cast<double>(std::numeric_limits<int>::max())) return false;
    value = static_cast<int>(*number);
    return true;
}

bool size_field(const JsonValue::Object& object, const char* key, std::size_t& value) {
    const auto* item = field(object, key);
    const auto* number = item ? item->number() : nullptr;
    if (!number || *number < 0.0 || *number > static_cast<double>(std::numeric_limits<std::size_t>::max())) return false;
    value = static_cast<std::size_t>(*number);
    return true;
}

bool string_field(const JsonValue::Object& object, const char* key, std::string& value, bool required = true) {
    const auto* item = field(object, key);
    if (!item) return !required;
    const auto* string = item->string();
    if (!string) return false;
    value = *string;
    return true;
}

bool bool_field(const JsonValue::Object& object, const char* key, bool& value) {
    const auto* item = field(object, key);
    const auto* boolean = item ? item->boolean() : nullptr;
    if (!boolean) return false;
    value = *boolean;
    return true;
}

bool protocol_ok(const JsonValue::Object& object) {
    int protocol = 0;
    return integer_field(object, "protocol", protocol) && protocol == kOfxScannerProtocolVersion;
}

} // namespace

std::string make_ofx_scan_request(const std::vector<std::string>& paths) {
    std::ostringstream out;
    out << "{\"protocol\":" << kOfxScannerProtocolVersion << ",\"command\":\"scan\",\"paths\":[";
    for (std::size_t i = 0; i < paths.size(); ++i) {
        if (i) out << ',';
        out << json_escape(paths[i]);
    }
    out << "]}\n";
    return out.str();
}

bool parse_ofx_scan_request(std::string_view json,
                            std::vector<std::string>& paths,
                            std::string* error) {
    JsonValue root;
    if (!JsonParser(json).parse(root, error)) return false;
    const auto* object = root.object();
    if (!object || !protocol_ok(*object)) {
        if (error) *error = "unsupported OFX scanner protocol";
        return false;
    }
    std::string command;
    if (!string_field(*object, "command", command) || command != "scan") {
        if (error) *error = "unsupported OFX scanner command";
        return false;
    }
    const auto* item = field(*object, "paths");
    const auto* array = item ? item->array() : nullptr;
    if (!array) {
        if (error) *error = "OFX scan request is missing paths";
        return false;
    }
    paths.clear();
    if (array->size() > 128) {
        if (error) *error = "too many OFX search paths";
        return false;
    }
    for (const auto& entry : *array) {
        const auto* string = entry.string();
        if (!string || string->size() > 32768) {
            if (error) *error = "invalid OFX search path";
            return false;
        }
        paths.push_back(*string);
    }
    return true;
}

std::string make_ofx_scan_response(const OfxScanResponse& response) {
    std::ostringstream out;
    out << "{\"protocol\":" << kOfxScannerProtocolVersion
        << ",\"ok\":" << (response.ok ? "true" : "false")
        << ",\"bundle_count\":" << response.bundle_count
        << ",\"error\":" << json_escape(response.error)
        << ",\"plugins\":[";
    for (std::size_t i = 0; i < response.plugins.size(); ++i) {
        if (i) out << ',';
        const auto& p = response.plugins[i];
        out << "{\"identifier\":" << json_escape(p.identifier)
            << ",\"api\":" << json_escape(p.api)
            << ",\"api_version\":" << p.api_version
            << ",\"version_major\":" << p.version_major
            << ",\"version_minor\":" << p.version_minor
            << ",\"binary_path\":" << json_escape(p.binary_path)
            << ",\"bundle_path\":" << json_escape(p.bundle_path)
            << ",\"vendor\":" << json_escape(p.vendor)
            << ",\"boris_fx\":" << (p.boris_fx ? "true" : "false")
            << ",\"image_effect\":" << (p.image_effect ? "true" : "false")
            << ",\"binary_loaded\":" << (p.binary_loaded ? "true" : "false")
            << ",\"error\":" << json_escape(p.error) << '}';
    }
    out << "]}\n";
    return out.str();
}

bool parse_ofx_scan_response(std::string_view json,
                             OfxScanResponse& response,
                             std::string* error) {
    JsonValue root;
    if (!JsonParser(json).parse(root, error)) return false;
    const auto* object = root.object();
    if (!object || !protocol_ok(*object)) {
        if (error) *error = "unsupported OFX scanner protocol";
        return false;
    }
    OfxScanResponse parsed;
    if (!bool_field(*object, "ok", parsed.ok) ||
        !size_field(*object, "bundle_count", parsed.bundle_count) ||
        !string_field(*object, "error", parsed.error)) {
        if (error) *error = "invalid OFX scanner response header";
        return false;
    }
    const auto* item = field(*object, "plugins");
    const auto* plugins = item ? item->array() : nullptr;
    if (!plugins || plugins->size() > 16384) {
        if (error) *error = "invalid OFX scanner plug-in list";
        return false;
    }
    parsed.plugins.reserve(plugins->size());
    for (const auto& plugin_value : *plugins) {
        const auto* plugin = plugin_value.object();
        if (!plugin) {
            if (error) *error = "invalid OFX scanner plug-in entry";
            return false;
        }
        OfxPluginInfo p;
        if (!string_field(*plugin, "identifier", p.identifier) ||
            !string_field(*plugin, "api", p.api) ||
            !integer_field(*plugin, "api_version", p.api_version) ||
            !integer_field(*plugin, "version_major", p.version_major) ||
            !integer_field(*plugin, "version_minor", p.version_minor) ||
            !string_field(*plugin, "binary_path", p.binary_path) ||
            !string_field(*plugin, "bundle_path", p.bundle_path) ||
            !string_field(*plugin, "vendor", p.vendor) ||
            !bool_field(*plugin, "boris_fx", p.boris_fx) ||
            !bool_field(*plugin, "image_effect", p.image_effect) ||
            !bool_field(*plugin, "binary_loaded", p.binary_loaded) ||
            !string_field(*plugin, "error", p.error)) {
            if (error) *error = "invalid OFX scanner plug-in fields";
            return false;
        }
        parsed.plugins.push_back(std::move(p));
    }
    response = std::move(parsed);
    return true;
}

} // namespace koralo
