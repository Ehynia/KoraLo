#include "ofx_inspector.hpp"
#include "ofx_ipc.hpp"

#include <exception>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    if (argc != 2 || std::string(argv[1]) != "--jsonl") return 64;

    std::string line;
    while (std::getline(std::cin, line)) {
        if (line.empty()) continue;
        koralo::OfxScanResponse response;
        std::vector<std::string> paths;
        std::string error;
        if (!koralo::parse_ofx_scan_request(line, paths, &error)) {
            response.ok = false;
            response.error = std::move(error);
            std::cout << koralo::make_ofx_scan_response(response);
            std::cout.flush();
            continue;
        }
        try {
            auto scanned = koralo::inspect_ofx_paths_in_process(paths);
            response.ok = true;
            response.bundle_count = scanned.bundle_count;
            response.plugins = std::move(scanned.plugins);
        } catch (const std::exception& ex) {
            response.ok = false;
            response.error = ex.what();
        } catch (...) {
            response.ok = false;
            response.error = "unknown OFX scanner exception";
        }
        std::cout << koralo::make_ofx_scan_response(response);
        std::cout.flush();
    }
    return 0;
}
