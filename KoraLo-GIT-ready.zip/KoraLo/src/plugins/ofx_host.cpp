#include "ofx_host.hpp"
#include "ofx_ipc.hpp"
#include "../platform/app_paths.hpp"
#include "../platform/process.hpp"

#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <set>
#include <sstream>

namespace koralo {
namespace fs = std::filesystem;
namespace {

std::string environment_value(const char* name) { return environment_utf8(name); }

std::vector<std::string> split_env_paths(const char* raw) {
    std::vector<std::string> out;
    if (!raw || !*raw) return out;
#ifdef _WIN32
    constexpr char sep = ';';
#else
    constexpr char sep = ':';
#endif
    std::string cur;
    for (const char* p = raw;; ++p) {
        if (*p == sep || *p == '\0') {
            if (!cur.empty()) out.push_back(cur);
            cur.clear();
            if (*p == '\0') break;
        } else {
            cur.push_back(*p);
        }
    }
    return out;
}

std::string scanner_executable() {
    const std::string override_path = environment_value("KORALO_OFX_SCANNER");
    if (!override_path.empty() && is_executable_file(path_from_utf8(override_path))) return override_path;
#ifdef _WIN32
    const auto candidate = app_install_directory() / "koralo-ofx-scanner.exe";
#else
    const auto candidate = app_install_directory() / "koralo-ofx-scanner";
#endif
    return is_executable_file(candidate) ? path_to_utf8(candidate) : std::string{};
}

std::string one_json_line(std::string output) {
    while (!output.empty() && (output.back() == '\n' || output.back() == '\r')) output.pop_back();
    const auto newline = output.find_first_of("\r\n");
    if (newline != std::string::npos) return {};
    return output;
}

} // namespace

std::vector<std::string> OfxHostRegistry::default_search_paths() {
    const std::string ofx_path = environment_value("OFX_PLUGIN_PATH");
    std::vector<std::string> out = split_env_paths(ofx_path.empty() ? nullptr : ofx_path.c_str());
#ifdef _WIN32
    const std::string common = environment_value("CommonProgramFiles");
    if (!common.empty()) out.push_back(path_to_utf8(path_from_utf8(common) / "OFX" / "Plugins"));
    out.push_back("C:\\Program Files\\Common Files\\OFX\\Plugins");
#else
    out.push_back("/usr/OFX/Plugins");
    out.push_back("/usr/local/OFX/Plugins");
#endif
    std::vector<std::string> unique;
    std::set<std::string> seen;
    for (auto& p : out) {
        if (!p.empty() && seen.insert(p).second) unique.push_back(std::move(p));
    }
    return unique;
}

void OfxHostRegistry::scan() { scan_paths(default_search_paths()); }

void OfxHostRegistry::scan_paths(const std::vector<std::string>& search_paths) {
    plugins_.clear();
    bundle_count_ = 0;
    last_error_.clear();
    const std::string scanner = scanner_executable();
    if (scanner.empty()) {
        last_error_ = "OFX scanner executable is missing";
        return;
    }

    ProcessOptions options;
    options.timeout_ms = 20000;
    options.max_output_bytes = 16u * 1024u * 1024u;
    options.input = make_ofx_scan_request(search_paths);
    options.capture_stderr = false;
    const ProcessResult process = run_process(scanner, {"--jsonl"}, options);
    if (!process.started) {
        last_error_ = "OFX scanner failed to start: " + process.output;
        return;
    }
    if (process.timed_out) {
        last_error_ = "OFX scanner timed out";
        return;
    }
    if (process.cancelled) {
        last_error_ = "OFX scanner was cancelled";
        return;
    }
    if (process.exit_code != 0) {
        last_error_ = "OFX scanner exited with code " + std::to_string(process.exit_code);
        return;
    }

    const std::string json = one_json_line(process.output);
    if (json.empty()) {
        last_error_ = "OFX scanner returned an empty or multi-line response";
        return;
    }
    OfxScanResponse response;
    std::string parse_error;
    if (!parse_ofx_scan_response(json, response, &parse_error)) {
        last_error_ = "Invalid OFX scanner response: " + parse_error;
        return;
    }
    if (!response.ok) {
        last_error_ = response.error.empty() ? "OFX scanner reported an error" : response.error;
        return;
    }
    bundle_count_ = response.bundle_count;
    plugins_ = std::move(response.plugins);
}

std::size_t OfxHostRegistry::image_effect_count() const {
    return static_cast<std::size_t>(std::count_if(plugins_.begin(), plugins_.end(),
        [](const auto& p) { return p.image_effect; }));
}

std::size_t OfxHostRegistry::boris_fx_count() const {
    return static_cast<std::size_t>(std::count_if(plugins_.begin(), plugins_.end(),
        [](const auto& p) { return p.boris_fx && p.image_effect; }));
}

std::string OfxHostRegistry::summary() const {
    std::ostringstream s;
    s << "OpenFX bundles: " << bundle_count_ << ", image effects: " << image_effect_count()
      << ", Boris FX: " << boris_fx_count();
    if (!last_error_.empty()) s << ". Scanner: " << last_error_ << '.';
    else if (plugins_.empty()) s << ". Set OFX_PLUGIN_PATH or install plug-ins in the standard OFX folder.";
    else s << ". Discovery/identity loading is enabled; pixel rendering through third-party OFX is experimental and not enabled yet.";
    return s.str();
}

} // namespace koralo
