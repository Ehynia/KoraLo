#include "ofx_inspector.hpp"
#include "../platform/utf8_fs.hpp"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <set>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace koralo {
namespace fs = std::filesystem;
namespace {

using OfxStatus = int;
using OfxPropertySetHandle = void*;
struct OfxHost;
using OfxSetHost = void (*)(OfxHost*);
using OfxMainEntry = OfxStatus (*)(const char*, const void*, OfxPropertySetHandle, OfxPropertySetHandle);
struct OfxPlugin {
    const char* pluginApi;
    int apiVersion;
    const char* pluginIdentifier;
    unsigned int pluginVersionMajor;
    unsigned int pluginVersionMinor;
    OfxSetHost setHost;
    OfxMainEntry mainEntry;
};
struct OfxHost {
    OfxPropertySetHandle host;
    const void* (*fetchSuite)(OfxPropertySetHandle, const char*, int);
};
using GetNumberFn = int (*)();
using GetPluginFn = OfxPlugin* (*)(int);

std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return value;
}

bool looks_boris(const std::string& text) {
    const auto v = lower(text);
    return v.find("boris") != std::string::npos || v.find("genarts") != std::string::npos ||
           v.find("sapphire") != std::string::npos || v.find("continuum") != std::string::npos ||
           v.find("bcc") != std::string::npos;
}

std::string vendor_from(const std::string& id, const std::string& path) {
    const auto l = lower(id + " " + path);
    if (looks_boris(l)) return "Boris FX";
    if (l.find("blackmagic") != std::string::npos) return "Blackmagic Design";
    if (l.find("foundry") != std::string::npos) return "Foundry";
    return "OpenFX";
}

bool candidate_binary(const fs::path& path) {
    if (utf8_fs::to_utf8(path.filename()).starts_with("@")) return false;
    const auto ext = lower(utf8_fs::to_utf8(path.extension()));
#ifdef _WIN32
    return ext == ".ofx" || ext == ".dll";
#else
    return ext == ".ofx" || ext == ".so";
#endif
}

std::string find_bundle(const fs::path& p) {
    fs::path cur = p.parent_path();
    while (!cur.empty()) {
        const std::string name = utf8_fs::to_utf8(cur.filename());
        if (name.size() >= 11 && lower(name.substr(name.size() - 11)) == ".ofx.bundle") {
            return utf8_fs::to_utf8(cur);
        }
        auto next = cur.parent_path();
        if (next == cur) break;
        cur = std::move(next);
    }
    return {};
}

void inspect_binary(const fs::path& binary, std::vector<OfxPluginInfo>& out) {
#ifdef _WIN32
    HMODULE lib = LoadLibraryW(binary.wstring().c_str());
    if (!lib) {
        OfxPluginInfo i;
        i.binary_path = utf8_fs::to_utf8(binary);
        i.bundle_path = find_bundle(binary);
        i.error = "LoadLibrary failed";
        out.push_back(std::move(i));
        return;
    }
    auto get_count = reinterpret_cast<GetNumberFn>(GetProcAddress(lib, "OfxGetNumberOfPlugins"));
    auto get_plugin = reinterpret_cast<GetPluginFn>(GetProcAddress(lib, "OfxGetPlugin"));
#else
    void* lib = dlopen(binary.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!lib) {
        OfxPluginInfo i;
        i.binary_path = utf8_fs::to_utf8(binary);
        i.bundle_path = find_bundle(binary);
        const char* msg = dlerror();
        i.error = msg ? msg : "dlopen failed";
        out.push_back(std::move(i));
        return;
    }
    auto get_count = reinterpret_cast<GetNumberFn>(dlsym(lib, "OfxGetNumberOfPlugins"));
    auto get_plugin = reinterpret_cast<GetPluginFn>(dlsym(lib, "OfxGetPlugin"));
#endif
    if (!get_count || !get_plugin) {
        OfxPluginInfo i;
        i.binary_path = utf8_fs::to_utf8(binary);
        i.bundle_path = find_bundle(binary);
        i.binary_loaded = true;
        i.error = "Missing OFX entry points";
        out.push_back(std::move(i));
    } else {
        int count = 0;
        try { count = std::clamp(get_count(), 0, 4096); } catch (...) { count = 0; }
        for (int n = 0; n < count; ++n) {
            OfxPlugin* p = nullptr;
            try { p = get_plugin(n); } catch (...) { p = nullptr; }
            if (!p) continue;
            OfxPluginInfo i;
            i.identifier = p->pluginIdentifier ? p->pluginIdentifier : "";
            i.api = p->pluginApi ? p->pluginApi : "";
            i.api_version = p->apiVersion;
            i.version_major = static_cast<int>(p->pluginVersionMajor);
            i.version_minor = static_cast<int>(p->pluginVersionMinor);
            i.binary_path = utf8_fs::to_utf8(binary);
            i.bundle_path = find_bundle(binary);
            i.binary_loaded = true;
            i.image_effect = (i.api == "OfxImageEffectPluginAPI");
            i.boris_fx = looks_boris(i.identifier) || looks_boris(i.binary_path) || looks_boris(i.bundle_path);
            i.vendor = vendor_from(i.identifier, i.binary_path);
            out.push_back(std::move(i));
        }
    }
#ifdef _WIN32
    FreeLibrary(lib);
#else
    dlclose(lib);
#endif
}

} // namespace

OfxInProcessScanResult inspect_ofx_paths_in_process(const std::vector<std::string>& search_paths) {
    OfxInProcessScanResult result;
    std::set<std::string> binaries;
    std::set<std::string> bundles;
    for (const auto& root_string : search_paths) {
        const fs::path root = utf8_fs::from_utf8(root_string);
        std::error_code ec;
        if (!fs::exists(root, ec)) continue;
        fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end;
        for (; it != end; it.increment(ec)) {
            if (ec) { ec.clear(); continue; }
            const auto& p = it->path();
            if (it->is_directory(ec)) {
                const std::string name = utf8_fs::to_utf8(p.filename());
                if (!name.empty() && name.front() == '@') {
                    it.disable_recursion_pending();
                    continue;
                }
                if (name.size() >= 11 && lower(name.substr(name.size() - 11)) == ".ofx.bundle") {
                    bundles.insert(utf8_fs::to_utf8(p));
                }
                continue;
            }
            if (it->is_regular_file(ec) && candidate_binary(p)) {
                const auto parent = lower(utf8_fs::to_utf8(p.parent_path().filename()));
#ifdef _WIN32
                if (parent == "win64" || parent.empty() || p.extension() == ".dll") binaries.insert(utf8_fs::to_utf8(p));
#else
                if (parent == "linux-x86-64" || parent == "linux-x86" || parent.empty() || p.extension() == ".so") binaries.insert(utf8_fs::to_utf8(p));
#endif
            }
        }
    }
    result.bundle_count = bundles.size();
    for (const auto& binary : binaries) inspect_binary(utf8_fs::from_utf8(binary), result.plugins);
    std::sort(result.plugins.begin(), result.plugins.end(), [](const auto& a, const auto& b) {
        if (a.boris_fx != b.boris_fx) return a.boris_fx > b.boris_fx;
        return a.identifier < b.identifier;
    });
    return result;
}

} // namespace koralo
