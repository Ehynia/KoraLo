#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace koralo {

struct OfxPluginInfo {
    std::string identifier;
    std::string api;
    int api_version = 0;
    int version_major = 0;
    int version_minor = 0;
    std::string binary_path;
    std::string bundle_path;
    std::string vendor;
    bool boris_fx = false;
    bool image_effect = false;
    bool binary_loaded = false;
    std::string error;
};

class OfxHostRegistry {
public:
    void scan();
    void scan_paths(const std::vector<std::string>& search_paths);
    const std::vector<OfxPluginInfo>& plugins() const { return plugins_; }
    std::size_t bundle_count() const { return bundle_count_; }
    std::size_t image_effect_count() const;
    std::size_t boris_fx_count() const;
    std::string summary() const;
    const std::string& last_error() const { return last_error_; }
    static std::vector<std::string> default_search_paths();

private:
    std::vector<OfxPluginInfo> plugins_;
    std::size_t bundle_count_ = 0;
    std::string last_error_;
};

} // namespace koralo
