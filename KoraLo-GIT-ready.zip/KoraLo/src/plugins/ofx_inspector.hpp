#pragma once

#include "ofx_host.hpp"

#include <cstddef>
#include <string>
#include <vector>

namespace koralo {

struct OfxInProcessScanResult {
    std::vector<OfxPluginInfo> plugins;
    std::size_t bundle_count = 0;
};

// This API is linked only into koralo-ofx-scanner and controlled scanner tests.
// The desktop editor intentionally does not link the implementation that calls
// third-party OFX entry points.
OfxInProcessScanResult inspect_ofx_paths_in_process(
    const std::vector<std::string>& search_paths);

} // namespace koralo
